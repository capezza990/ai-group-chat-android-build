# GitHub cloud build

This repository is configured to build the debug APK with GitHub Actions.

The workflow is `.github/workflows/build-apk.yml` and runs automatically on pushes to `main` or manually with **Actions -> Build Android APK -> Run workflow**.

Successful builds upload an artifact named `AI_GROUP_CHAT_ANDROID_M1-debug-apk` containing `AI_GROUP_CHAT_ANDROID_M1-debug.apk`.

No OpenAI or Anthropic API credentials are required by this project or workflow.
