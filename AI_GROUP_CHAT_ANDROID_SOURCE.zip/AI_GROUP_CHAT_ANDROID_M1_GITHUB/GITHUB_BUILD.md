# GitHub cloud build

This repository is configured to build the debug APK with GitHub Actions.

The workflow is `.github/workflows/build-apk.yml` and runs automatically on pushes to `main` or manually with **Actions -> Build Android APK -> Run workflow**.

Successful builds upload an artifact named `AI_GROUP_CHAT_ANDROID_M1-debug-apk` containing `AI_GROUP_CHAT_ANDROID_M1-debug.apk`.

No OpenAI or Anthropic API credentials are required by this project or workflow.


M9 note: large Claude handoffs that are automatically converted by the native Claude app into a removable TXT “Pasted content” attachment are now treated as a successful first insertion. The relay will not repaste the same payload five times. A removable attachment must leave the composer after Send before the relay proceeds.


M10 adds keyboard/navigation safe-area handling, draft preservation, a cleaner diagnostics row, and Auto Collaborate with a selectable 5/10/20-turn safety limit. The workflow filename and artifact name remain unchanged for compatibility.
