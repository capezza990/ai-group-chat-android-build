# GitHub build source

Upload this project inside `AI_GROUP_CHAT_ANDROID_SOURCE.zip` using the exact repository filename expected by `.github/workflows/build-apk.yml`.

M11.6 version: `0.11.6` / versionCode `17`.
