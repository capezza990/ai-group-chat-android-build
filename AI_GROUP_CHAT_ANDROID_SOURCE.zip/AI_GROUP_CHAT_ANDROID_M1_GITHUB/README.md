# AI Group Chat — M11

Android accessibility bridge for a shared conversation between the user, the official ChatGPT Android app, and the official Claude Android app. No provider API keys are used.

## M11 highlights

- Keeps the verified M9/M10 send/capture transport baseline intact.
- Compact messenger-style UI: transcript and composer get priority; setup, diagnostics, clear/refresh, and provider launch actions live in the overflow menu.
- Keyboard-aware layout: when the IME is open, secondary collaboration controls collapse instead of being dragged above the keyboard.
- Safe-area handling for three-button navigation, gesture navigation, status bars, and display cutouts.
- Draft text and selected user attachments persist across app switches/recreation.
- Auto Collaborate preserves the original user request and uses bounded routing markers with a hard turn cap and STOP.
- Durable relay checkpointing with Resume/Retry after service/process interruption. Completed steps are never rewritten on normal forward resume.
- Shared-turn attachment foundation: files/images selected once in AI Group Chat are retained by URI and handed to each participating provider once using Android share intents. The bridge refuses to send the text if it cannot verify that the attachment reached the provider composer.

## Attachment scope

M11 is the first real shared-attachment handoff build. User-selected attachments can follow the shared turn to ChatGPT and Claude. Provider-generated file extraction/download capture is intentionally deferred to M12 because it requires mapping the native generated-file/download UI of each provider.

The first attachment test should use one image. If the target app receives the image but M11 cannot verify its attachment chip, use the Diagnostics UI-map action so the provider-specific attachment state can be mapped without guessing.

## Build

Use the repository GitHub Actions workflow or `BUILD_APK.bat`. The debug APK is signed with the same stable test keystore used by the established bridge baseline.
