# AI Group Chat — M11

Android accessibility bridge for a shared conversation between the user, the official ChatGPT Android app, and the official Claude Android app. No provider API keys are used.

## M11 highlights

- Keeps the verified M9/M10 send/capture transport baseline intact.
- Compact messenger-style UI: transcript and composer get priority; setup, diagnostics, clear/refresh, and provider launch actions live in the overflow menu.
- Keyboard-aware layout: when the IME is open, secondary collaboration controls collapse instead of being dragged above the keyboard.
- Safe-area handling for three-button navigation, gesture navigation, status bars, and display cutouts.
- Draft text and selected user attachments persist across app switches/recreation.
- Auto Collaborate preserves the original user request and uses bounded routing markers with a hard turn cap and STOP.
- Durable relay checkpointing with Resume/Retry after service/process interruption. Completed steps are never rewritten on normal forward resume.
- Shared-turn attachment foundation: files/images selected once in AI Group Chat are retained by URI and handed to each participating provider inside the already-mapped provider conversation. The live path does not use ACTION_SEND to create a new native chat. The bridge refuses to send the text if it cannot verify that the attachment reached the provider composer.

## Attachment scope

M11 is the first real shared-attachment handoff build. User-selected attachments can follow the shared turn to ChatGPT and Claude. Provider-generated file extraction/download capture is intentionally deferred to M12 because it requires mapping the native generated-file/download UI of each provider.

The first attachment test should use one image. If the target app receives the image but M11 cannot verify its attachment chip, use the Diagnostics UI-map action so the provider-specific attachment state can be mapped without guessing.

## Build

Use the repository GitHub Actions workflow or `BUILD_APK.bat`. The debug APK is signed with the same stable test keystore used by the established bridge baseline.

## M11.2 correction pass

- Keeps the successful compact M11 UI baseline.
- Replaces the clipped text overflow glyph with a vector MoreVert icon.
- Adds a jump-to-latest button that appears only when the transcript is away from the bottom.
- Adds per-message Copy plus Copy last message / Copy whole transcript utilities.
- Preserves the latest transcript position through IME changes when the user was already following the bottom, without yanking a user who intentionally scrolled upward.
- Hardens repeated-response detection: a reply anchored after this step's newly sent prompt is considered new even when its text is identical to the previous answer.
- Clears all transient relay state after success/failure while retaining a FAILED disk checkpoint only for explicit Resume/Retry.
- Removes ACTION_SEND from the live shared-attachment path so attachments can no longer intentionally launch a new provider chat. M11.2 first tries URI clipboard paste into the mapped existing composer and refuses to send associated text unless an attachment is verified there. If a provider rejects rich URI paste, capture that existing-composer state with Diagnostics so its native attach flow can be mapped without regressing to new-chat sharing.
- AI-generated file capture/relay remains M12 work.


## M11.3 transcript synchronization correction

- Keeps the M11.2 response-identity detector, strict stale-reply protection, in-thread attachment transport, and keyboard focus fix unchanged.
- Makes SharedPreferences the single source of truth for conversation messages across the Activity and Accessibility Service.
- Every transcript read and append re-syncs before use, preventing stale in-memory caches from hiding freshly captured replies or resurrecting previously cleared messages.
- A single process-wide lock serializes message mutations across both ConversationStore instances.
