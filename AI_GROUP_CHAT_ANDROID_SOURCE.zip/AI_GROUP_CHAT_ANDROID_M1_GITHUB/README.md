# AI Group Chat Android Bridge — M1

A phone-first experimental relay that uses the **official installed ChatGPT and Claude Android apps** instead of OpenAI/Anthropic API keys.

## What this build is trying to prove

The app presents one local three-participant transcript (`YOU`, `CHATGPT`, `CLAUDE`) and uses a user-enabled Android Accessibility Service to move an explicitly started message between the two native AI apps.

Supported relay modes in M1:

- **ChatGPT** — send only to ChatGPT and capture its reply.
- **Claude** — send only to Claude and capture its reply.
- **Both** — send the same user message independently to ChatGPT and Claude, one after the other.
- **Collaborate** — controlled relay with a hard limit:
  - ChatGPT → Claude review → ChatGPT revision, or
  - Claude → ChatGPT review → Claude revision.
  - Optional second review/revision round.
- **STOP** — available in the main app and in a floating accessibility overlay while the native AI app is in front.

The official Android package IDs targeted by this build are:

- ChatGPT: `com.openai.chatgpt`
- Claude: `com.anthropic.claude`

## Important behavior

Android does not let an ordinary app freely read two unrelated apps while they are completely backgrounded. This prototype therefore **brings ChatGPT or Claude to the foreground when it needs to interact with it**. You may visibly see the phone switch between apps during a collaboration.

The Accessibility Service is package-limited to the official ChatGPT and Claude apps. The bridge itself makes no direct provider network requests, contains no OpenAI/Anthropic API keys, and does not ask for or store your provider passwords.

## Build the APK on Windows

This package includes a one-click local builder because the environment that produced this source did not contain the Android SDK and therefore could not compile the APK here.

1. Extract this folder on your Windows PC.
2. Double-click **`BUILD_APK.bat`**.
3. On the first run it downloads a local build toolchain into `.toolchain/`:
   - Android command-line tools
   - Android SDK 36
   - Build Tools 36.0.0
   - platform-tools
   - Gradle 9.6.0
   - Android Gradle Plugin dependencies
4. The finished file will appear as:
   - **`AI_GROUP_CHAT_ANDROID_M1-debug.apk`**

The builder uses Android Gradle Plugin 9.4.1 / Gradle 9.6.0 and the current Windows Android command-line tools package pinned in the script.

If Java is not already installed, install Android Studio or a JDK 17+ first. The rest of the Android/Gradle build environment is bootstrapped by the included script.

## Install on the phone

Either:

- Copy `AI_GROUP_CHAT_ANDROID_M1-debug.apk` to the phone and open it, allowing installation from that source when Android asks, **or**
- Enable Android USB debugging and double-click **`INSTALL_APK_USB.bat`**.

## First run on Android

1. Make sure the official **ChatGPT** and **Claude** apps are installed and signed into the accounts you normally use.
2. Open **AI Group Chat**.
3. Tap **Enable bridge**.
4. In Android Accessibility settings, turn on **AI Group Chat Bridge**. Android will show a strong warning because an Accessibility Service can read/control supported app UI; this is the capability the relay needs.
5. Return to AI Group Chat.
6. Tap **Open ChatGPT** and navigate to the ChatGPT conversation you want the bridge to use. Set the model/thinking level in ChatGPT normally for now.
7. Return to AI Group Chat, tap **Open Claude**, and prepare the Claude conversation/model the same way.
8. Return to AI Group Chat, type a message, then choose **ChatGPT**, **Claude**, **Both**, or **COLLABORATE**.

While the relay is running, a dark floating bar remains at the top with a **STOP** button.

## What is deliberately NOT automated yet

M1 does **not** yet try to manipulate provider model pickers or thinking/effort controls. Use the normal settings in the ChatGPT and Claude apps before starting a relay.

M1 also does not yet attempt file/image handoff between apps, conversation selection by title, or synchronization to a Windows companion.

Those should come only after the message input/output selectors are verified against the actual current ChatGPT and Claude app UIs on the target phone.

## Expected first-device tuning

This is the most important limitation: the source has been validated locally, but it has **not** been run against your authenticated ChatGPT and Claude Android sessions. Both apps can change their accessibility trees at any time.

The first phone test is therefore primarily intended to answer four questions:

1. Can the bridge locate each app's editable message field?
2. Can it activate the current send control?
3. Does each app expose a reliable "Stop" control while generating?
4. Does the response appear in the Accessibility node tree in a form the capture heuristic can distinguish from surrounding UI text?

If one of those fails, the next build should tune the adapter for that app rather than redesigning the entire application.

## Privacy / security

- No API keys are used.
- No ChatGPT or Claude password is requested or stored.
- The bridge's persistent data is its own local unified transcript in Android app-private SharedPreferences.
- Accessibility events themselves are not logged.
- There is no network permission in this application.
- The service is restricted to `com.openai.chatgpt` and `com.anthropic.claude`.

## Provider/platform caveat

This is a personal experimental sideload that automates consumer-app UI. It is not an official OpenAI or Anthropic integration and should not be represented as one. Provider terms/UI can change, and Android/Google Play applies special restrictions to Accessibility-based automation. This build is intended for local testing, not Play Store publication.


M9 note: large Claude handoffs that are automatically converted by the native Claude app into a removable TXT “Pasted content” attachment are now treated as a successful first insertion. The relay will not repaste the same payload five times. A removable attachment must leave the composer after Send before the relay proceeds.
