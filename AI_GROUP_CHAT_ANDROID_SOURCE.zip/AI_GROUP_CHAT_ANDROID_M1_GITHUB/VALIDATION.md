# M11 validation checklist

1. Existing M9/M10 short and long text relay still works in both directions.
2. Claude large pasted-content TXT conversion still sends exactly once without duplicate attachments.
3. Keyboard opens with only the composer/attachment strip at the bottom; collaboration controls collapse.
4. Navigation buttons do not cover the composer or controls.
5. Draft text survives app switching.
6. Auto Collaborate preserves `[ORIGINAL USER REQUEST]`, follows routing markers, and stops on `[[DONE]]` / `[[NEXT:USER]]` / safety cap.
7. Interrupted relay exposes Resume/Retry in the overflow menu.
8. Select one image with `+`; verify the chip appears in AI Group Chat.
9. Start a collaboration with that image. M11 should share the original attachment to each participating provider once and should not send text without a verified attachment.
10. Diagnostics remain available from the overflow menu for provider UI mapping.
