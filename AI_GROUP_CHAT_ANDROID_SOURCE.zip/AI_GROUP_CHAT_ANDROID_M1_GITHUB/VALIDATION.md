# Validation — AI Group Chat Android Bridge M1

Date: 2026-09-28

## Completed validation

- `RelayPlan.java` compiled with the local JDK.
- Collaboration plan tests passed:
  - ChatGPT-first, 1 review round = ChatGPT → Claude → ChatGPT (3 AI steps).
  - Claude-first, 2 review rounds = Claude → ChatGPT → Claude → ChatGPT → Claude (5 AI steps).
  - `Both` remains independent and does not cross-relay the first AI's answer into the second AI.
- Android manifest and all resource XML files parse successfully.
- Required package wiring is present:
  - `com.openai.chatgpt`
  - `com.anthropic.claude`
- Accessibility service requirements are declared, including `BIND_ACCESSIBILITY_SERVICE` and window-content retrieval.
- Floating Accessibility Overlay STOP control is wired.
- Source/package scan confirms there is no `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `sk-proj-`, or `sk-ant-` configuration.
- A broad `javac` parse pass over all Java source showed only the expected missing-Android-SDK symbol/package errors in this container and no common Java syntax-error signatures.
- The included project-validation script passes.

## Toolchain choices verified against current official documentation

- Android Gradle Plugin: 9.4.1
- Gradle: 9.6.0
- compile/target SDK: 36
- Build Tools: 36.0.0
- Windows command-line tools package: `commandlinetools-win-15859902_latest.zip`

## Not yet validated

The build environment used to create this package does not contain the Android SDK, and its normal shell has no outbound package-download access. Therefore:

- A real APK was **not** compiled here.
- The app has **not** yet been installed on a physical Android device.
- The accessibility node trees of the user's currently installed ChatGPT and Claude versions have not been observed.
- Message-field detection, Send-button detection, Stop-button detection, and response extraction remain device/app-version test items.

`BUILD_APK.bat` is included to bootstrap the official Android command-line build toolchain on Windows and produce `AI_GROUP_CHAT_ANDROID_M1-debug.apk` without requiring the user to manually assemble the project.

The app also contains explicit diagnostic buttons that can launch each native app, capture its current Accessibility UI tree, copy that tree to the Android clipboard, and return to the bridge. Those diagnostics may include visible conversation text and should only be shared intentionally.
