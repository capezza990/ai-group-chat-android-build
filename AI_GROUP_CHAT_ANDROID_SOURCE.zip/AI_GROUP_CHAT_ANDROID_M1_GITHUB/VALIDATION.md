# Validation — AI Group Chat Android Bridge M1

Date: 2026-09-28

## Completed validation

- `RelayPlan.java` compiled with the local JDK.
- Collaboration plan tests passed:
  - ChatGPT-first, 1 review round = ChatGPT → Claude → ChatGPT (3 AI steps).
  - Claude-first, 2 review rounds = Claude → ChatGPT → Claude → ChatGPT → Claude (5 AI steps).
  - `Both` remains independent and does not cross-relay the first AI's answer into the second AI.
- Android manifest and all resource XML files parse successfully.
- Required package wiring is present:
  - `com.openai.chatgpt`
  - `com.anthropic.claude`
- Accessibility service requirements are declared, including `BIND_ACCESSIBILITY_SERVICE` and window-content retrieval.
- Floating Accessibility Overlay STOP control is wired.
- Source/package scan confirms there is no `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `sk-proj-`, or `sk-ant-` configuration.
- A broad `javac` parse pass over all Java source showed only the expected missing-Android-SDK symbol/package errors in this container and no common Java syntax-error signatures.
- The included project-validation script passes.

## Toolchain choices verified against current official documentation

- Android Gradle Plugin: 9.4.1
- Gradle: 9.6.0
- compile/target SDK: 36
- Build Tools: 36.0.0
- Windows command-line tools package: `commandlinetools-win-15859902_latest.zip`

## Not yet validated

The build environment used to create this package does not contain the Android SDK, and its normal shell has no outbound package-download access. Therefore:

- A real APK was **not** compiled here.
- The app has **not** yet been installed on a physical Android device.
- The accessibility node trees of the user's currently installed ChatGPT and Claude versions have not been observed.
- Message-field detection, Send-button detection, Stop-button detection, and response extraction remain device/app-version test items.

`BUILD_APK.bat` is included to bootstrap the official Android command-line build toolchain on Windows and produce `AI_GROUP_CHAT_ANDROID_M1-debug.apk` without requiring the user to manually assemble the project.

The app also contains explicit diagnostic buttons that can launch each native app, capture its current Accessibility UI tree, copy that tree to the Android clipboard, and return to the bridge. Those diagnostics may include visible conversation text and should only be shared intentionally.


M9 note: large Claude handoffs that are automatically converted by the native Claude app into a removable TXT “Pasted content” attachment are now treated as a successful first insertion. The relay will not repaste the same payload five times. A removable attachment must leave the composer after Send before the relay proceeds.


## M10 validation additions

- Project validator passes after the M10 changes.
- `RelayPlan.java` compiles under Java 17 and tests pass for the original 5-step fixed collaboration plan, Auto Collaborate creation, and max-turn clamping.
- Broad Java parse pass shows no Java syntax-error signatures; Android symbols remain unavailable in this local container, so final Android compilation is still delegated to the existing GitHub Actions workflow.
- M9 provider transport code remains in place; M10 changes the surrounding plan/routing state and bridge UI rather than replacing the proven provider adapters.
