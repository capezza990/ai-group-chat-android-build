package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

public abstract class AppAdapter {
    public abstract String packageName();
    public abstract String displayName();

    protected abstract String[] sendWords();
    protected abstract String[] stopWords();
    protected abstract String[] newChatWords();
    protected abstract String[] composerHints();
    protected abstract String[] responseActionDescriptions();
    protected abstract String[] ignoredReplyTexts();

    public boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName());
        if (intent == null) return false;
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
        return true;
    }

    public boolean isActive(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null && packageName().contentEquals(root.getPackageName());
    }

    protected AccessibilityNodeInfo findComposer(AccessibilityNodeInfo root) {
        if (!isActive(root)) return null;
        return NodeUtils.findEditableNearHints(root, composerHints());
    }

    public boolean fillComposer(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        return composer != null && NodeUtils.setText(composer, text);
    }

    public boolean composerContains(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        if (composer == null || TextUtils.isEmpty(composer.getText())) return false;
        return NodeUtils.normalize(composer.getText().toString()).equals(NodeUtils.normalize(text));
    }

    public boolean clickSend(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        // Compose apps often expose the "Send" label on a non-clickable child while the
        // clickable action lives on its parent. Find the labelled node first, then climb.
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, sendWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean sendAppearsComplete(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        AccessibilityNodeInfo composer = findComposer(root);
        boolean composerNoLongerContainsSentText = composer == null
                || TextUtils.isEmpty(composer.getText())
                || !NodeUtils.normalize(String.valueOf(composer.getText())).equals(NodeUtils.normalize(sentText));

        // Critical M3 rule: text still sitting in an editable composer is NOT proof of send.
        // Require the exact message to exist as a visible, non-editable chat bubble too.
        boolean userBubbleExists = NodeUtils.treeHasExactNonEditableText(root, sentText);
        return composerNoLongerContainsSentText && userBubbleExists;
    }

    public String captureLatestAnchoredReply(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return "";
        return NodeUtils.extractLatestResponseAnchored(
                root,
                sentText,
                responseActionDescriptions(),
                ignoredReplyTexts());
    }

    public boolean clickStop(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, stopWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean generationAppearsActive(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        // Only a real visible stop control counts as active generation. Do not let the
        // word "stop" inside ordinary response text keep the relay waiting forever.
        return NodeUtils.findLastNodeByExactOrPrefixWords(root, stopWords()) != null;
    }

    public boolean tryNewChat(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root, newChatWords());
        return node != null && NodeUtils.click(node);
    }
}
