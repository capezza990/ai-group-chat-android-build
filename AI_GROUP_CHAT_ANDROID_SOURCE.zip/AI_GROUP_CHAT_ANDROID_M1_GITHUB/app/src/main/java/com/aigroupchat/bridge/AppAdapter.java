package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public abstract class AppAdapter {
    public abstract String packageName();
    public abstract String displayName();

    protected abstract String[] sendWords();
    protected abstract String[] stopWords();
    protected abstract String[] newChatWords();

    public boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName());
        if (intent == null) return false;
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
        return true;
    }

    public boolean isActive(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null && packageName().contentEquals(root.getPackageName());
    }

    public boolean send(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo editable = NodeUtils.findEditable(root);
        if (editable == null) return false;
        if (!NodeUtils.setText(editable, text)) return false;

        root = service.getRootInActiveWindow();
        AccessibilityNodeInfo send = NodeUtils.findClickableByWords(root, sendWords());
        if (send != null && NodeUtils.click(send)) return true;

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            return editable.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
        }
        return false;
    }

    public boolean clickStop(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo stop = NodeUtils.findClickableByWords(root, stopWords());
        return stop != null && NodeUtils.click(stop);
    }

    public boolean generationAppearsActive(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        return isActive(root) && NodeUtils.findAnyByWords(root, stopWords()) != null;
    }

    public boolean tryNewChat(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root, newChatWords());
        return node != null && NodeUtils.click(node);
    }

    public List<String> captureVisibleTexts(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        return isActive(root) ? NodeUtils.visibleLeafTexts(root) : new ArrayList<>();
    }

    public String extractLikelyReply(List<String> baseline, List<String> now, String sentText) {
        if (now == null || now.isEmpty()) return "";
        Set<String> baselineNorm = new HashSet<>();
        if (baseline != null) {
            for (String b : baseline) baselineNorm.add(NodeUtils.normalize(b));
        }

        String sentNorm = NodeUtils.normalize(sentText);
        int sentIndex = -1;
        for (int i = 0; i < now.size(); i++) {
            String n = NodeUtils.normalize(now.get(i));
            if (!sentNorm.isEmpty() && (n.equals(sentNorm) || n.contains(sentNorm) || sentNorm.contains(n))) sentIndex = i;
        }

        List<String> candidates = new ArrayList<>();
        int start = sentIndex >= 0 ? sentIndex + 1 : 0;
        for (int i = start; i < now.size(); i++) {
            String raw = now.get(i);
            String n = NodeUtils.normalize(raw);
            if (n.isEmpty() || n.equals(sentNorm)) continue;
            if (isUiChrome(n)) continue;
            if (sentIndex < 0 && baselineNorm.contains(n)) continue;
            if (raw.trim().length() < 2) continue;
            candidates.add(raw.trim());
        }

        if (candidates.isEmpty() && sentIndex < 0) {
            for (String raw : now) {
                String n = NodeUtils.normalize(raw);
                if (!n.isEmpty() && !baselineNorm.contains(n) && !isUiChrome(n) && raw.trim().length() >= 2) {
                    candidates.add(raw.trim());
                }
            }
        }

        StringBuilder sb = new StringBuilder();
        String last = "";
        for (String c : candidates) {
            String n = NodeUtils.normalize(c);
            if (n.equals(last)) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(c);
            last = n;
        }
        return sb.toString().trim();
    }

    private boolean isUiChrome(String normalized) {
        String[] words = {
                "send", "stop", "voice mode", "attach", "camera", "share", "copy", "thumbs up", "thumbs down",
                "regenerate", "retry", "edit message", "new chat", "menu", "settings", "search", "projects",
                "chatgpt", "claude", "model", "thinking", "reasoning"
        };
        String s = normalized.toLowerCase(Locale.US);
        if (s.length() > 80) return false;
        for (String word : words) {
            if (s.equals(word) || s.startsWith(word + " ")) return true;
        }
        return false;
    }
}
