package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

public abstract class AppAdapter {
    public abstract String packageName();
    public abstract String displayName();

    protected abstract String[] sendWords();
    protected abstract String[] stopWords();
    protected abstract String[] newChatWords();
    protected abstract String[] composerHints();
    protected abstract String[] responseActionDescriptions();
    protected abstract String[] ignoredReplyTexts();

    public boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName());
        if (intent == null) return false;
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
        return true;
    }

    /**
     * M11 attachment spike: hand the original user attachment(s) directly to the
     * provider with Android's share contract. The relay then verifies that the
     * target UI exposes an attachment before typing/sending the prompt.
     */
    public boolean launchWithAttachments(Context context, List<AttachmentRecord> attachments) {
        if (attachments == null || attachments.isEmpty()) return launch(context);
        try {
            Intent intent = new Intent(attachments.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
            intent.setPackage(packageName());
            intent.setType(commonMimeType(attachments));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);

            ArrayList<Uri> uris = new ArrayList<>();
            for (AttachmentRecord a : attachments) uris.add(a.uri());
            if (uris.size() == 1) {
                intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            } else {
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            }

            ClipData clip = ClipData.newUri(context.getContentResolver(), "AI Group Chat attachment", uris.get(0));
            for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
            intent.setClipData(clip);
            context.startActivity(intent);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private String commonMimeType(List<AttachmentRecord> attachments) {
        if (attachments == null || attachments.isEmpty()) return "*/*";
        boolean allImages = true;
        String exact = null;
        for (AttachmentRecord a : attachments) {
            if (!a.isImage()) allImages = false;
            if (exact == null) exact = a.mimeType;
            else if (!exact.equals(a.mimeType)) exact = "*/*";
        }
        if (allImages) return "image/*";
        return exact == null ? "*/*" : exact;
    }

    public boolean composerHasSharedAttachments(AccessibilityService service, List<AttachmentRecord> attachments) {
        if (attachments == null || attachments.isEmpty()) return true;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        int namedMatches = 0;
        for (AttachmentRecord a : attachments) {
            if (NodeUtils.treeContainsVisibleText(root, a.displayName)) namedMatches++;
        }
        if (namedMatches == attachments.size()) return true;

        // Images often expose only a preview/remove affordance, not the original file name.
        if (attachments.size() == 1 && attachments.get(0).isImage()) {
            return NodeUtils.treeContainsAnyVisibleWords(root,
                    "remove attachment", "remove image", "attached image", "image attachment", "attachment");
        }
        return false;
    }

    public boolean isActive(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null && packageName().contentEquals(root.getPackageName());
    }

    protected AccessibilityNodeInfo findComposer(AccessibilityNodeInfo root) {
        if (!isActive(root)) return null;
        return NodeUtils.findEditableNearHints(root, composerHints());
    }

    public boolean fillComposer(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        return composer != null && NodeUtils.setText(composer, text);
    }

    public boolean composerContains(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        if (composer == null || TextUtils.isEmpty(composer.getText())) return false;
        return NodeUtils.normalize(composer.getText().toString()).equals(NodeUtils.normalize(text));
    }

    public boolean composerHasAutoPastedAttachment(AccessibilityService service) {
        return false;
    }

    public boolean clickSend(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, sendWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean sendAppearsComplete(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo composer = findComposer(root);
        boolean composerStillContainsExactSentText = composer != null
                && !TextUtils.isEmpty(composer.getText())
                && NodeUtils.normalize(String.valueOf(composer.getText())).equals(NodeUtils.normalize(sentText));
        if (composerStillContainsExactSentText) return false;
        if (NodeUtils.treeHasExactNonEditableText(root, sentText)) return true;
        return composer != null;
    }

    public String captureLatestAnchoredReply(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return "";
        return NodeUtils.extractLatestResponseAnchored(root, sentText, responseActionDescriptions(), ignoredReplyTexts());
    }

    public boolean scrollConversationTowardBottom(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.scrollLargestContainerForward(root);
    }

    public boolean copyControlVisible(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.findLastByContentDescriptionExact(root, responseActionDescriptions()) != null;
    }

    public boolean clickCopyLatestResponse(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastByContentDescriptionExact(root, responseActionDescriptions());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean clickStop(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, stopWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean generationAppearsActive(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.findLastNodeByExactOrPrefixWords(root, stopWords()) != null;
    }

    public boolean tryNewChat(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root, newChatWords());
        return node != null && NodeUtils.click(node);
    }
}
