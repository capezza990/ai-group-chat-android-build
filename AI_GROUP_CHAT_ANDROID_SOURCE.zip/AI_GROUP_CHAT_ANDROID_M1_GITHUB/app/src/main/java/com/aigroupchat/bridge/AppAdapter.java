package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

public abstract class AppAdapter {
    public abstract String packageName();
    public abstract String displayName();

    protected abstract String[] sendWords();
    protected abstract String[] stopWords();
    protected abstract String[] newChatWords();
    protected abstract String[] composerHints();
    protected abstract String[] responseActionDescriptions();
    protected abstract String[] ignoredReplyTexts();

    public boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName());
        if (intent == null) return false;
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
        return true;
    }

    public boolean isActive(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null && packageName().contentEquals(root.getPackageName());
    }

    protected AccessibilityNodeInfo findComposer(AccessibilityNodeInfo root) {
        if (!isActive(root)) return null;
        return NodeUtils.findEditableNearHints(root, composerHints());
    }

    public boolean fillComposer(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        return composer != null && NodeUtils.setText(composer, text);
    }

    public boolean composerContains(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        if (composer == null || TextUtils.isEmpty(composer.getText())) return false;
        return NodeUtils.normalize(composer.getText().toString()).equals(NodeUtils.normalize(text));
    }

    public boolean clickSend(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        AccessibilityNodeInfo send = NodeUtils.findLastClickableByExactWords(root, sendWords());
        if (send != null && NodeUtils.click(send)) return true;

        // Fallback only; RelayCoordinator verifies that the composer actually clears afterward.
        AccessibilityNodeInfo composer = findComposer(root);
        return Build.VERSION.SDK_INT >= 30 && composer != null
                && composer.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
    }

    public boolean sendAppearsComplete(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo composer = findComposer(root);
        boolean composerCleared = composer == null || TextUtils.isEmpty(composer.getText())
                || !NodeUtils.normalize(String.valueOf(composer.getText())).equals(NodeUtils.normalize(sentText));
        return composerCleared || NodeUtils.treeHasExactText(root, sentText);
    }

    public String captureLatestAnchoredReply(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return "";
        return NodeUtils.extractLatestResponseAnchored(
                root,
                sentText,
                responseActionDescriptions(),
                ignoredReplyTexts());
    }

    public boolean clickStop(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo stop = NodeUtils.findClickableByWords(root, stopWords());
        return stop != null && NodeUtils.click(stop);
    }

    public boolean generationAppearsActive(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        return isActive(root) && NodeUtils.findAnyByWords(root, stopWords()) != null;
    }

    public boolean tryNewChat(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root, newChatWords());
        return node != null && NodeUtils.click(node);
    }
}
