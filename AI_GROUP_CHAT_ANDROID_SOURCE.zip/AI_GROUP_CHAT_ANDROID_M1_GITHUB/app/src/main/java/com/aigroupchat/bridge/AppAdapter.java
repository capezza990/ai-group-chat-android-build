package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

public abstract class AppAdapter {
    public abstract String packageName();
    public abstract String displayName();

    protected abstract String[] sendWords();
    protected abstract String[] stopWords();
    protected abstract String[] newChatWords();
    protected abstract String[] composerHints();
    protected abstract String[] responseActionDescriptions();
    protected abstract String[] ignoredReplyTexts();

    public boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName());
        if (intent == null) return false;
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
        return true;
    }

    public boolean isActive(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null && packageName().contentEquals(root.getPackageName());
    }

    protected AccessibilityNodeInfo findComposer(AccessibilityNodeInfo root) {
        if (!isActive(root)) return null;
        return NodeUtils.findEditableNearHints(root, composerHints());
    }

    public boolean fillComposer(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        return composer != null && NodeUtils.setText(composer, text);
    }

    public boolean composerContains(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        if (composer == null || TextUtils.isEmpty(composer.getText())) return false;
        return NodeUtils.normalize(composer.getText().toString()).equals(NodeUtils.normalize(text));
    }

    /**
     * Some provider apps convert a very large ACTION_SET_TEXT payload into a native
     * attachment instead of leaving it in the editable composer. The default adapters
     * do not expose such a state; provider-specific adapters may override this.
     */
    public boolean composerHasAutoPastedAttachment(AccessibilityService service) {
        return false;
    }

    public boolean clickSend(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        // Compose apps often expose the "Send" label on a non-clickable child while the
        // clickable action lives on its parent. Find the labelled node first, then climb.
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, sendWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean sendAppearsComplete(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        AccessibilityNodeInfo composer = findComposer(root);
        boolean composerStillContainsExactSentText = composer != null
                && !TextUtils.isEmpty(composer.getText())
                && NodeUtils.normalize(String.valueOf(composer.getText())).equals(NodeUtils.normalize(sentText));

        // If the exact payload is still in the editable composer, it definitely has NOT
        // been sent. Otherwise, either a real user bubble or a cleared/changed composer
        // is sufficient evidence. This handles Claude's live behavior where the click can
        // succeed but Accessibility returns false and a long relayed bubble is not exposed
        // as one exact TextView immediately.
        if (composerStillContainsExactSentText) return false;
        if (NodeUtils.treeHasExactNonEditableText(root, sentText)) return true;
        return composer != null;
    }

    public String captureLatestAnchoredReply(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return "";
        return NodeUtils.extractLatestResponseAnchored(
                root,
                sentText,
                responseActionDescriptions(),
                ignoredReplyTexts());
    }


    /**
     * Keep the native provider conversation pinned toward its newest content. Long
     * Compose/LazyColumn conversations virtualize off-screen nodes, so the response
     * action row may not enter the Accessibility tree unless we move the list down.
     */
    public boolean scrollConversationTowardBottom(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.scrollLargestContainerForward(root);
    }

    public boolean copyControlVisible(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.findLastByContentDescriptionExact(root, responseActionDescriptions()) != null;
    }


    public boolean clickCopyLatestResponse(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastByContentDescriptionExact(root, responseActionDescriptions());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean clickStop(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, stopWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean generationAppearsActive(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        // Only a real visible stop control counts as active generation. Do not let the
        // word "stop" inside ordinary response text keep the relay waiting forever.
        return NodeUtils.findLastNodeByExactOrPrefixWords(root, stopWords()) != null;
    }

    public boolean tryNewChat(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root, newChatWords());
        return node != null && NodeUtils.click(node);
    }
}
