package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class BridgeAccessibilityService extends AccessibilityService {
    public static final String ACTION_STATUS = "com.aigroupchat.bridge.STATUS";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_ERROR = "error";

    private static volatile BridgeAccessibilityService instance;

    private RelayCoordinator coordinator;
    private WindowManager windowManager;
    private View overlay;
    private TextView overlayText;
    private PowerManager.WakeLock wakeLock;

    public static BridgeAccessibilityService getInstance() {
        return instance;
    }

    public static boolean isConnected() {
        return instance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        coordinator = new RelayCoordinator(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        postStatus("Accessibility bridge connected.", false);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // The first prototype polls the active UI tree during an explicit relay.
        // Events are intentionally not copied into logs or persistent storage.
    }

    @Override
    public void onInterrupt() {
        if (coordinator != null && coordinator.isRunning()) coordinator.suspend("Accessibility service interrupted");
    }

    @Override
    public void onDestroy() {
        if (coordinator != null && coordinator.isRunning()) coordinator.suspend("Accessibility service disabled");
        hideOverlay();
        releaseRelayWakeLock();
        instance = null;
        super.onDestroy();
    }

    public void startRelay(RelayPlan plan) {
        if (coordinator == null) coordinator = new RelayCoordinator(this);
        coordinator.start(plan);
    }

    public void stopRelay() {
        if (coordinator != null) coordinator.stop("stopped by user");
    }

    public boolean relayRunning() {
        return coordinator != null && coordinator.isRunning();
    }

    public boolean hasRecoverableRelay() {
        if (coordinator != null && coordinator.hasRecoverableRun()) return true;
        return new RunStateStore(this).hasRecoverable();
    }

    public void resumeRelay() {
        if (coordinator == null) coordinator = new RelayCoordinator(this);
        coordinator.resumeSavedRun();
    }

    public void discardRecoverableRelay() {
        if (coordinator == null) coordinator = new RelayCoordinator(this);
        coordinator.discardRecoverableRun();
        postStatus("Saved relay discarded.", false);
    }

    public boolean openChatGpt() {
        return new ChatGptAdapter().launch(this);
    }

    public boolean openClaude() {
        return new ClaudeAdapter().launch(this);
    }

    public void inspectApp(RelayPlan.Actor actor) {
        if (relayRunning()) {
            postStatus("Stop the relay before running diagnostics.", true);
            return;
        }
        AppAdapter adapter = actor == RelayPlan.Actor.CHATGPT ? new ChatGptAdapter() : new ClaudeAdapter();
        if (!adapter.launch(this)) {
            postStatus("Could not open " + adapter.displayName() + ".", true);
            return;
        }
        showOverlay("Diagnostics: reading " + adapter.displayName() + " UI…");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            String dump = NodeUtils.dumpTree(getRootInActiveWindow());
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("AI Group Chat " + adapter.displayName() + " UI map", dump));
            hideOverlay();
            postStatus(adapter.displayName() + " UI map copied to clipboard. It may include visible conversation text.", false);
            returnToBridgeApp();
        }, 2200L);
    }

    public void postStatus(String text, boolean error) {
        Intent intent = new Intent(ACTION_STATUS);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_STATUS, text);
        intent.putExtra(EXTRA_ERROR, error);
        sendBroadcast(intent);
    }

    public void showOverlay(String status) {
        if (overlay != null) {
            updateOverlay(status);
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(24, 18, 18, 18);
        box.setBackgroundColor(0xEE202124);

        overlayText = new TextView(this);
        overlayText.setTextColor(0xFFFFFFFF);
        overlayText.setTextSize(14f);
        overlayText.setText(status);
        box.addView(overlayText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button stop = new Button(this);
        stop.setText("STOP");
        stop.setOnClickListener(v -> stopRelay());
        box.addView(stop, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP;
        overlay = box;
        try {
            windowManager.addView(overlay, params);
        } catch (Exception e) {
            overlay = null;
            overlayText = null;
        }
    }

    public void updateOverlay(String status) {
        if (overlayText != null) overlayText.setText(status);
    }

    public void hideOverlay() {
        if (overlay != null && windowManager != null) {
            try {
                windowManager.removeView(overlay);
            } catch (Exception ignored) {
            }
        }
        overlay = null;
        overlayText = null;
    }

    public void acquireRelayWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AIGroupChatBridge:Relay");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(30L * 60L * 1000L);
    }

    public void releaseRelayWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }


    public String readClipboardText() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null || cm.getPrimaryClip().getItemCount() == 0) {
            return "";
        }
        CharSequence text = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        return text == null ? "" : text.toString();
    }

    public void returnToBridgeApp() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    public static Intent accessibilitySettingsIntent() {
        return new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    }
}
