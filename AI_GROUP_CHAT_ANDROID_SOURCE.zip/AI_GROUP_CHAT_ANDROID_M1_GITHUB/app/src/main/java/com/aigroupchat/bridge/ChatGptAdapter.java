package com.aigroupchat.bridge;

public final class ChatGptAdapter extends AppAdapter {
    @Override public String packageName() { return "com.openai.chatgpt"; }
    @Override public String displayName() { return "ChatGPT"; }
    @Override protected String[] sendWords() { return new String[]{"send", "submit"}; }
    @Override protected String[] stopWords() { return new String[]{"stop", "stop generating"}; }
    @Override protected String[] newChatWords() { return new String[]{"new chat", "start new chat"}; }
}
