package com.aigroupchat.bridge;

public final class ClaudeAdapter extends AppAdapter {
    @Override public String packageName() { return "com.anthropic.claude"; }
    @Override public String displayName() { return "Claude"; }
    @Override protected String[] sendWords() { return new String[]{"send", "send message", "submit"}; }
    @Override protected String[] stopWords() { return new String[]{"stop", "stop response"}; }
    @Override protected String[] newChatWords() { return new String[]{"new chat", "new conversation", "start new chat"}; }
    @Override protected String[] composerHints() { return new String[]{"Chat with Claude…", "Chat with Claude...", "Reply to Claude…", "Reply to Claude..."}; }
    @Override protected String[] responseActionDescriptions() { return new String[]{"Copy message"}; }
    @Override protected String[] ignoredReplyTexts() {
        return new String[]{"Chat with Claude…", "Chat with Claude...", "Reply to Claude…", "Reply to Claude...", "Claude is AI and can make mistakes."};
    }
}
