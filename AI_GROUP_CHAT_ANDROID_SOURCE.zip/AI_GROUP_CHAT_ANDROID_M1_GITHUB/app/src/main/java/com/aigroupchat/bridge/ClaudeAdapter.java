package com.aigroupchat.bridge;

public final class ClaudeAdapter extends AppAdapter {
    @Override public String packageName() { return "com.anthropic.claude"; }
    @Override public String displayName() { return "Claude"; }
    @Override protected String[] sendWords() { return new String[]{"send", "submit"}; }
    @Override protected String[] stopWords() { return new String[]{"stop", "stop response"}; }
    @Override protected String[] newChatWords() { return new String[]{"new chat", "new conversation", "start new chat"}; }
}
