package com.aigroupchat.bridge;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ConversationStore {
    private static final String PREFS = "ai_group_chat_bridge";
    private static final String KEY_MESSAGES = "messages_json";

    private final SharedPreferences prefs;
    private final List<Message> messages = new ArrayList<>();

    public ConversationStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
    }

    public synchronized void add(Message message) {
        messages.add(message);
        save();
    }

    public synchronized void clear() {
        messages.clear();
        save();
    }

    public synchronized List<Message> all() {
        return Collections.unmodifiableList(new ArrayList<>(messages));
    }

    private void load() {
        messages.clear();
        String raw = prefs.getString(KEY_MESSAGES, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                messages.add(Message.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {
            messages.clear();
        }
    }

    private void save() {
        JSONArray arr = new JSONArray();
        for (Message message : messages) {
            try {
                arr.put(message.toJson());
            } catch (JSONException ignored) {
            }
        }
        prefs.edit().putString(KEY_MESSAGES, arr.toString()).apply();
    }
}
