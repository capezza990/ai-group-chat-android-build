package com.aigroupchat.bridge;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public final class MainActivity extends Activity {
    private ConversationStore store;
    private TextView transcript;
    private ScrollView transcriptScroll;
    private EditText input;
    private TextView status;
    private Spinner firstActor;
    private Spinner rounds;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!BridgeAccessibilityService.ACTION_STATUS.equals(intent.getAction())) return;
            String s = intent.getStringExtra(BridgeAccessibilityService.EXTRA_STATUS);
            boolean error = intent.getBooleanExtra(BridgeAccessibilityService.EXTRA_ERROR, false);
            status.setText((error ? "⚠ " : "") + (s == null ? "" : s));
            refreshTranscript();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new ConversationStore(this);
        setContentView(buildUi());
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(BridgeAccessibilityService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(statusReceiver, filter);
        }
    }

    @Override
    protected void onStop() {
        try { unregisterReceiver(statusReceiver); } catch (Exception ignored) {}
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTranscript();
        refreshServiceStatus();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(12));
        root.setBackgroundColor(0xFF111315);

        TextView title = text("AI GROUP CHAT", 24, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = text("Native ChatGPT + Claude bridge", 13, 0xFFB8C0C8);
        root.addView(subtitle, lpMatchWrap(0, dp(4), 0, dp(10)));

        status = text("Checking accessibility bridge…", 13, 0xFFFFD166);
        status.setPadding(dp(10), dp(8), dp(10), dp(8));
        status.setBackgroundColor(0xFF202428);
        root.addView(status, lpMatchWrap(0, 0, 0, dp(10)));

        LinearLayout setupRow = horizontal();
        setupRow.addView(button("Enable bridge", v -> startActivity(BridgeAccessibilityService.accessibilitySettingsIntent())), weightedButton());
        setupRow.addView(button("Open ChatGPT", v -> openPackage("com.openai.chatgpt", "ChatGPT")), weightedButton());
        setupRow.addView(button("Open Claude", v -> openPackage("com.anthropic.claude", "Claude")), weightedButton());
        root.addView(setupRow, lpMatchWrap(0, 0, 0, dp(10)));

        transcriptScroll = new ScrollView(this);
        transcriptScroll.setFillViewport(true);
        transcript = text("", 16, 0xFFE8EAED);
        transcript.setTextIsSelectable(true);
        transcript.setPadding(dp(4), dp(8), dp(4), dp(8));
        transcriptScroll.addView(transcript, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(transcriptScroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        input = new EditText(this);
        input.setHint("Message ChatGPT and Claude…");
        input.setHintTextColor(0xFF8A949E);
        input.setTextColor(0xFFFFFFFF);
        input.setBackgroundColor(0xFF202428);
        input.setMinLines(2);
        input.setMaxLines(7);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(input, lpMatchWrap(0, dp(8), 0, dp(8)));

        LinearLayout options = horizontal();
        firstActor = spinner(new String[]{"ChatGPT first", "Claude first"});
        rounds = spinner(new String[]{"1 review round", "2 review rounds"});
        options.addView(firstActor, weightedButton());
        options.addView(rounds, weightedButton());
        root.addView(options, lpMatchWrap(0, 0, 0, dp(8)));

        LinearLayout sendRow1 = horizontal();
        sendRow1.addView(button("ChatGPT", v -> submit(RelayPlan.Mode.CHATGPT_ONLY)), weightedButton());
        sendRow1.addView(button("Claude", v -> submit(RelayPlan.Mode.CLAUDE_ONLY)), weightedButton());
        sendRow1.addView(button("Both", v -> submit(RelayPlan.Mode.BOTH)), weightedButton());
        root.addView(sendRow1, lpMatchWrap(0, 0, 0, dp(6)));

        LinearLayout sendRow2 = horizontal();
        Button collab = button("COLLABORATE", v -> submit(RelayPlan.Mode.COLLABORATE));
        sendRow2.addView(collab, new LinearLayout.LayoutParams(0, dp(52), 2f));
        Button stop = button("STOP", v -> {
            BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
            if (service != null) service.stopRelay();
        });
        stop.setBackgroundColor(0xFF8B1E2D);
        sendRow2.addView(stop, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(sendRow2, lpMatchWrap(0, 0, 0, dp(6)));

        LinearLayout bottom = horizontal();
        bottom.addView(button("Clear transcript", v -> {
            if (BridgeAccessibilityService.getInstance() != null && BridgeAccessibilityService.getInstance().relayRunning()) {
                toast("Stop the relay before clearing the transcript.");
                return;
            }
            store.clear();
            refreshTranscript();
        }), weightedButton());
        bottom.addView(button("Refresh", v -> {
            refreshTranscript();
            refreshServiceStatus();
        }), weightedButton());
        root.addView(bottom);

        LinearLayout diagnostics = horizontal();
        diagnostics.addView(button("Copy ChatGPT UI map", v -> inspect(RelayPlan.Actor.CHATGPT)), weightedButton());
        diagnostics.addView(button("Copy Claude UI map", v -> inspect(RelayPlan.Actor.CLAUDE)), weightedButton());
        root.addView(diagnostics, lpMatchWrap(0, dp(4), 0, 0));

        refreshTranscript();
        return root;
    }

    private void submit(RelayPlan.Mode mode) {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) {
            toast("Type a message first.");
            return;
        }
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        if (service == null) {
            status.setText("⚠ Enable AI Group Chat Bridge in Android Accessibility settings first.");
            startActivity(BridgeAccessibilityService.accessibilitySettingsIntent());
            return;
        }
        if (service.relayRunning()) {
            toast("A relay is already running. Use STOP first.");
            return;
        }
        RelayPlan.Actor first = firstActor.getSelectedItemPosition() == 0 ? RelayPlan.Actor.CHATGPT : RelayPlan.Actor.CLAUDE;
        int roundCount = rounds.getSelectedItemPosition() + 1;
        RelayPlan plan = RelayPlan.build(text, mode, first, roundCount);
        input.setText("");
        service.startRelay(plan);
        refreshTranscript();
    }

    private void inspect(RelayPlan.Actor actor) {
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        if (service == null) {
            toast("Enable the accessibility bridge first.");
            startActivity(BridgeAccessibilityService.accessibilitySettingsIntent());
            return;
        }
        toast("Diagnostic copy may include visible conversation text.");
        service.inspectApp(actor);
    }

    private void refreshServiceStatus() {
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        if (service == null) {
            status.setText("Bridge OFF — tap Enable bridge, then turn on AI Group Chat Bridge.");
        } else if (service.relayRunning()) {
            status.setText("Relay running — the phone will switch between the native AI apps.");
        } else {
            status.setText("Bridge ON — prepare the ChatGPT and Claude conversations, then send below.");
        }
    }

    private void refreshTranscript() {
        if (transcript == null) return;
        List<Message> messages = new ConversationStore(this).all();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        DateFormat df = DateFormat.getTimeInstance(DateFormat.SHORT);
        for (Message m : messages) {
            int start = sb.length();
            String label = label(m.participant);
            sb.append(label).append("  ").append(df.format(new Date(m.timestamp))).append('\n');
            int end = sb.length();
            sb.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new ForegroundColorSpan(color(m.participant)), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append(m.text).append("\n\n");
        }
        if (messages.isEmpty()) {
            sb.append("No messages yet.\n\n1. Enable the bridge.\n2. Open ChatGPT and Claude and choose the conversations you want to use.\n3. Return here and send a message.");
        }
        transcript.setText(sb);
        transcriptScroll.post(() -> transcriptScroll.fullScroll(View.FOCUS_DOWN));
    }

    private String label(Message.Participant p) {
        switch (p) {
            case USER: return "YOU";
            case CHATGPT: return "CHATGPT";
            case CLAUDE: return "CLAUDE";
            default: return "SYSTEM";
        }
    }

    private int color(Message.Participant p) {
        switch (p) {
            case USER: return 0xFF7FD1AE;
            case CHATGPT: return 0xFF85B7FF;
            case CLAUDE: return 0xFFE8A87C;
            default: return 0xFFFFD166;
        }
    }

    private void openPackage(String packageName, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) {
            toast(name + " is not installed.");
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    private Spinner spinner(String[] items) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        s.setAdapter(adapter);
        return s;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setOnClickListener(listener);
        return b;
    }

    private TextView text(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weightedButton() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
