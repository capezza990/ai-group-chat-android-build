package com.aigroupchat.bridge;

import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class NodeUtils {
    private NodeUtils() {}

    public static List<AccessibilityNodeInfo> flatten(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        if (root == null) return out;
        walk(root, out);
        return out;
    }

    private static void walk(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, out);
        }
    }

    public static List<AccessibilityNodeInfo> visibleEditables(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (node.isVisibleToUser() && node.isEditable()) out.add(node);
        }
        return out;
    }

    public static AccessibilityNodeInfo findEditableNearHints(AccessibilityNodeInfo root, String... hints) {
        List<AccessibilityNodeInfo> editables = visibleEditables(root);
        if (editables.isEmpty()) return null;

        for (AccessibilityNodeInfo editable : editables) {
            if (nearbyContainsAny(editable, 4, hints)) return editable;
        }
        return editables.size() == 1 ? editables.get(0) : null;
    }

    public static boolean nearbyContainsAny(AccessibilityNodeInfo node, int maxParents, String... words) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i <= maxParents && current != null; i++) {
            if (subtreeContainsAny(current, words)) return true;
            current = current.getParent();
        }
        return false;
    }

    public static boolean subtreeContainsAny(AccessibilityNodeInfo root, String... words) {
        if (root == null) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            String t = normalize(combinedText(node));
            if (t.isEmpty()) continue;
            for (String word : words) {
                String w = normalize(word);
                if (!w.isEmpty() && (t.equals(w) || t.contains(w))) return true;
            }
        }
        return false;
    }

    public static AccessibilityNodeInfo findLastClickableByExactWords(AccessibilityNodeInfo root, String... words) {
        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = normalize(combinedText(node));
            if (hay.isEmpty()) continue;
            for (String word : words) {
                String w = normalize(word);
                if (w.isEmpty()) continue;
                boolean labelMatch = hay.equals(w) || hay.startsWith(w + " ");
                if (labelMatch && (node.isClickable() || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))) {
                    found = node;
                }
            }
        }
        return found;
    }

    public static AccessibilityNodeInfo findLastNodeByExactOrPrefixWords(AccessibilityNodeInfo root, String... words) {
        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = normalize(combinedText(node));
            if (hay.isEmpty()) continue;
            for (String word : words) {
                String w = normalize(word);
                if (w.isEmpty()) continue;
                if (hay.equals(w) || hay.startsWith(w + " ")) found = node;
            }
        }
        return found;
    }

    public static AccessibilityNodeInfo findLastByContentDescriptionExact(AccessibilityNodeInfo root, String... descriptions) {
        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence desc = node.getContentDescription();
            if (TextUtils.isEmpty(desc)) continue;
            String d = normalize(desc.toString());
            for (String wanted : descriptions) {
                if (d.equals(normalize(wanted))) found = node;
            }
        }
        return found;
    }

    public static AccessibilityNodeInfo findClickableByWords(AccessibilityNodeInfo root, String... words) {
        if (root == null) return null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = combinedText(node).toLowerCase(Locale.US);
            if (hay.isEmpty()) continue;
            for (String word : words) {
                if (hay.contains(word.toLowerCase(Locale.US)) && (node.isClickable() || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))) {
                    return node;
                }
            }
        }
        return null;
    }

    public static AccessibilityNodeInfo findAnyByWords(AccessibilityNodeInfo root, String... words) {
        if (root == null) return null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            String hay = combinedText(node).toLowerCase(Locale.US);
            for (String word : words) {
                if (!word.isEmpty() && hay.contains(word.toLowerCase(Locale.US))) return node;
            }
        }
        return null;
    }



    /**
     * Claude turns sufficiently large pasted text into a native TXT attachment labelled
     * "Pasted content". While that attachment is still in the composer it also exposes
     * a nearby Remove control. Detecting this state lets the relay treat the first paste
     * as successful instead of pasting the same payload repeatedly.
     */
    public static boolean hasClaudePastedContentAttachmentInComposer(AccessibilityNodeInfo root) {
        if (root == null) return false;
        boolean hasPastedContent = false;
        boolean hasTxt = false;
        boolean hasRemove = false;
        boolean hasEditableComposer = false;

        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            if (node.isEditable()) hasEditableComposer = true;

            String text = normalize(String.valueOf(node.getText()));
            String desc = normalize(String.valueOf(node.getContentDescription()));
            if (text.equals("pasted content")) hasPastedContent = true;
            if (text.equals("txt")) hasTxt = true;
            if (text.equals("remove") || desc.equals("remove")) hasRemove = true;
        }

        return hasEditableComposer && hasPastedContent && hasTxt && hasRemove;
    }


    /**
     * Scroll the largest visible vertical/scrollable container toward newer content.
     * ChatGPT and Claude use virtualized Compose lists, so old/new response nodes are
     * not guaranteed to exist in the Accessibility tree until the list is scrolled.
     *
     * We prefer the biggest scroll-capable node on screen to avoid accidentally
     * scrolling a small nested control. At the bottom performAction simply returns
     * false, which is harmless and lets the caller know there was nowhere else to go.
     */
    public static boolean scrollLargestContainerForward(AccessibilityNodeInfo root) {
        if (root == null) return false;

        AccessibilityNodeInfo best = null;
        long bestArea = -1L;
        int bestDepth = -1;

        for (AccessibilityNodeInfo node : flatten(root)) {
            if (node == null || !node.isVisibleToUser() || node.isEditable()) continue;
            if (!supportsForwardScroll(node)) continue;

            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            long area = Math.max(0, bounds.width()) * (long) Math.max(0, bounds.height());
            int depth = depth(node);

            if (area > bestArea || (area == bestArea && depth > bestDepth)) {
                best = node;
                bestArea = area;
                bestDepth = depth;
            }
        }

        if (best == null) return false;
        if (best.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
        return best.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId());
    }

    private static boolean supportsForwardScroll(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isScrollable()) return true;
        int actions = node.getActions();
        if ((actions & AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) != 0) return true;
        int downId = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId();
        for (AccessibilityNodeInfo.AccessibilityAction action : node.getActionList()) {
            if (action != null && action.getId() == downId) return true;
        }
        return false;
    }

    private static int depth(AccessibilityNodeInfo node) {
        int depth = 0;
        AccessibilityNodeInfo current = node;
        while (current != null && depth < 64) {
            depth++;
            current = current.getParent();
        }
        return depth;
    }

    public static boolean setText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    public static boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i < 5 && current != null; i++) {
            if ((current.isClickable() || current.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))
                    && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            current = current.getParent();
        }
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    public static boolean textEquals(AccessibilityNodeInfo node, String expected) {
        return node != null && normalize(String.valueOf(node.getText())).equals(normalize(expected));
    }

    public static boolean treeHasExactText(AccessibilityNodeInfo root, String expected) {
        String want = normalize(expected);
        if (want.isEmpty()) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence t = node.getText();
            if (!TextUtils.isEmpty(t) && normalize(t.toString()).equals(want)) return true;
        }
        return false;
    }

    public static boolean treeHasExactNonEditableText(AccessibilityNodeInfo root, String expected) {
        String want = normalize(expected);
        if (want.isEmpty()) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser() || node.isEditable()) continue;
            CharSequence t = node.getText();
            if (!TextUtils.isEmpty(t) && normalize(t.toString()).equals(want)) return true;
        }
        return false;
    }

    public static String extractLatestResponseAnchored(
            AccessibilityNodeInfo root,
            String sentText,
            String[] responseActionDescriptions,
            String[] ignoredTextExact) {
        if (root == null) return "";

        List<AccessibilityNodeInfo> all = flatten(root);
        String sentNorm = normalize(sentText);
        int sentIndex = -1;

        // When looking for a reply to a specific message, the anchor must be the REAL
        // non-editable user bubble. Never treat text inside the composer as a sent message.
        if (!sentNorm.isEmpty()) {
            for (int i = 0; i < all.size(); i++) {
                AccessibilityNodeInfo node = all.get(i);
                if (!node.isVisibleToUser() || node.isEditable()) continue;
                CharSequence t = node.getText();
                if (!TextUtils.isEmpty(t) && normalize(t.toString()).equals(sentNorm)) sentIndex = i;
            }
            // If the exact bubble is not exposed as one node (common for long relayed
            // messages), fall through to the provider action-row fallback below instead
            // of declaring that no reply exists.
        }

        // M4/M5 primary path: once the exact non-editable user bubble is present, read the
        // response directly from subsequent visible TextViews until the composer begins.
        // This does NOT depend on a Copy/Copy message action row appearing, which proved
        // too brittle on the live ChatGPT app even though the reply itself was visible.
        if (sentIndex >= 0) {
            List<String> streamed = new ArrayList<>();
            for (int i = sentIndex + 1; i < all.size(); i++) {
                AccessibilityNodeInfo node = all.get(i);
                if (!node.isVisibleToUser()) continue;

                // The first editable after the sent bubble is the reply composer. Anything
                // after it is composer chrome/model controls, not the assistant response.
                if (node.isEditable()) break;

                CharSequence raw = node.getText();
                if (TextUtils.isEmpty(raw)) continue;
                CharSequence cls = node.getClassName();
                if (cls == null || !"android.widget.TextView".contentEquals(cls)) continue;

                String text = raw.toString().trim();
                String n = normalize(text);
                if (n.isEmpty() || n.equals(sentNorm)) continue;
                if (isIgnoredExact(n, ignoredTextExact) || isCommonUiText(n)) continue;

                // Ignore labels belonging to clickable controls. Real message text in the
                // mapped ChatGPT/Claude trees is a non-clickable TextView.
                AccessibilityNodeInfo parent = node.getParent();
                if (node.isClickable() || (parent != null && parent.isClickable())) continue;

                if (streamed.isEmpty() || !normalize(streamed.get(streamed.size() - 1)).equals(n)) {
                    streamed.add(text);
                }
            }
            if (!streamed.isEmpty()) return joinDistinct(streamed);
            return "";
        }

        // Baseline snapshots (sentText empty) can still use the provider-specific response
        // action row to identify the most recent existing response before a new send.
        AccessibilityNodeInfo anchor = null;
        int anchorIndex = -1;
        for (int i = 0; i < all.size(); i++) {
            AccessibilityNodeInfo node = all.get(i);
            if (!node.isVisibleToUser()) continue;
            CharSequence desc = node.getContentDescription();
            if (TextUtils.isEmpty(desc)) continue;
            String d = normalize(desc.toString());
            for (String action : responseActionDescriptions) {
                if (d.equals(normalize(action))) {
                    anchor = node;
                    anchorIndex = i;
                }
            }
        }

        if (anchor == null || anchorIndex < 0) return "";

        AccessibilityNodeInfo current = anchor;
        for (int up = 0; up < 10 && current != null; up++) {
            List<String> texts = collectMeaningfulText(current, sentNorm, ignoredTextExact);
            if (!texts.isEmpty()) return joinDistinct(texts);
            current = current.getParent();
        }
        return "";
    }

    private static List<String> collectMeaningfulText(AccessibilityNodeInfo root, String sentNorm, String[] ignoredTextExact) {
        List<String> out = new ArrayList<>();
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence raw = node.getText();
            if (TextUtils.isEmpty(raw)) continue;
            String text = raw.toString().trim();
            String n = normalize(text);
            if (n.isEmpty() || n.equals(sentNorm)) continue;
            if (isIgnoredExact(n, ignoredTextExact) || isCommonUiText(n)) continue;
            if (node.isEditable()) continue;
            if (out.isEmpty() || !normalize(out.get(out.size() - 1)).equals(n)) out.add(text);
        }
        return out;
    }

    private static boolean isIgnoredExact(String normalized, String[] ignored) {
        if (ignored == null) return false;
        for (String s : ignored) if (normalized.equals(normalize(s))) return true;
        return false;
    }

    private static boolean isCommonUiText(String n) {
        String[] exact = {
                "copy", "copy message", "share", "good response", "bad response", "read aloud", "narrate",
                "retry message", "more actions", "open menu", "new chat", "edit menu", "menu",
                "add to chat", "start speech input", "voice mode", "attachment", "dictation",
                "ask chatgpt", "reply to chatgpt", "chat with claude…", "reply to claude…",
                "claude is ai and can make mistakes."
        };
        for (String s : exact) if (n.equals(normalize(s))) return true;
        return false;
    }

    private static String joinDistinct(List<String> texts) {
        StringBuilder sb = new StringBuilder();
        String last = "";
        for (String text : texts) {
            String n = normalize(text);
            if (n.isEmpty() || n.equals(last)) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(text.trim());
            last = n;
        }
        return sb.toString().trim();
    }

    public static String text(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        if (!TextUtils.isEmpty(text)) return text.toString();
        CharSequence desc = node.getContentDescription();
        return TextUtils.isEmpty(desc) ? "" : desc.toString();
    }

    public static String combinedText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(node.getText())) sb.append(node.getText()).append(' ');
        if (!TextUtils.isEmpty(node.getContentDescription())) sb.append(node.getContentDescription());
        return sb.toString().trim();
    }

    public static String normalize(String s) {
        return s == null ? "" : s.replaceAll("\\s+", " ").trim().toLowerCase(Locale.US);
    }

    public static String dumpTree(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        dump(root, sb, 0);
        return sb.toString();
    }

    private static void dump(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(node.getClassName())
                .append(" text=").append(String.valueOf(node.getText()))
                .append(" desc=").append(String.valueOf(node.getContentDescription()))
                .append(" id=").append(String.valueOf(node.getViewIdResourceName()))
                .append(" editable=").append(node.isEditable())
                .append(" clickable=").append(node.isClickable())
                .append(" visible=").append(node.isVisibleToUser())
                .append(" bounds=").append(bounds.toShortString())
                .append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) dump(child, sb, depth + 1);
        }
    }
}
