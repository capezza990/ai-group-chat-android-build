package com.aigroupchat.bridge;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class NodeUtils {
    private NodeUtils() {}

    public static List<AccessibilityNodeInfo> flatten(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        if (root == null) return out;
        walk(root, out);
        return out;
    }

    private static void walk(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, out);
        }
    }

    public static AccessibilityNodeInfo findEditable(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo fallback = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            if (node.isEditable()) {
                if (node.isFocused()) return node;
                if (fallback == null) fallback = node;
            }
        }
        return fallback;
    }

    public static AccessibilityNodeInfo findClickableByWords(AccessibilityNodeInfo root, String... words) {
        if (root == null) return null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = combinedText(node).toLowerCase(Locale.US);
            if (hay.isEmpty()) continue;
            for (String word : words) {
                if (hay.contains(word.toLowerCase(Locale.US)) && (node.isClickable() || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))) {
                    return node;
                }
            }
        }
        return null;
    }

    public static AccessibilityNodeInfo findAnyByWords(AccessibilityNodeInfo root, String... words) {
        if (root == null) return null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            String hay = combinedText(node).toLowerCase(Locale.US);
            for (String word : words) {
                if (!word.isEmpty() && hay.contains(word.toLowerCase(Locale.US))) return node;
            }
        }
        return null;
    }

    public static boolean setText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    public static boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i < 4 && current != null; i++) {
            if (current.isClickable() && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            current = current.getParent();
        }
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    public static List<String> visibleLeafTexts(AccessibilityNodeInfo root) {
        List<String> out = new ArrayList<>();
        Set<String> dedupeAdjacent = new HashSet<>();
        collectLeafTexts(root, out, dedupeAdjacent);
        return out;
    }

    private static void collectLeafTexts(AccessibilityNodeInfo node, List<String> out, Set<String> dedupeAdjacent) {
        if (node == null || !node.isVisibleToUser()) return;
        if (node.getChildCount() == 0) {
            String t = text(node);
            if (!TextUtils.isEmpty(t)) {
                String normalized = normalize(t);
                if (!normalized.isEmpty()) {
                    if (out.isEmpty() || !normalize(out.get(out.size() - 1)).equals(normalized)) out.add(t.trim());
                }
            }
            return;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectLeafTexts(child, out, dedupeAdjacent);
        }
    }

    public static String text(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        if (!TextUtils.isEmpty(text)) return text.toString();
        CharSequence desc = node.getContentDescription();
        return TextUtils.isEmpty(desc) ? "" : desc.toString();
    }

    public static String combinedText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(node.getText())) sb.append(node.getText()).append(' ');
        if (!TextUtils.isEmpty(node.getContentDescription())) sb.append(node.getContentDescription());
        return sb.toString().trim();
    }

    public static String normalize(String s) {
        return s == null ? "" : s.replaceAll("\\s+", " ").trim().toLowerCase(Locale.US);
    }

    public static String dumpTree(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        dump(root, sb, 0);
        return sb.toString();
    }

    private static void dump(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null) return;
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(node.getClassName())
                .append(" text=").append(String.valueOf(node.getText()))
                .append(" desc=").append(String.valueOf(node.getContentDescription()))
                .append(" editable=").append(node.isEditable())
                .append(" clickable=").append(node.isClickable())
                .append(" visible=").append(node.isVisibleToUser())
                .append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) dump(child, sb, depth + 1);
        }
    }
}
