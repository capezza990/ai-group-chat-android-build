package com.aigroupchat.bridge;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Durable provider-conversation binding for the relay.
 *
 * Android's public launcher intent does not expose a stable ChatGPT/Claude conversation id.
 * Instead we bind each provider to the last full assistant reply that the bridge itself captured.
 * Before another send, the accessibility tree must still contain a strong tail-token match for
 * that reply after scrolling to the bottom. If it does not, the relay fails closed before typing.
 */
public final class ProviderThreadStore {
    private static final String PREFS = "ai_group_chat_bridge";
    private static final String KEY_CHATGPT = "provider_thread_anchor_chatgpt_v1";
    private static final String KEY_CLAUDE = "provider_thread_anchor_claude_v1";
    private static final int MAX_STORED_CHARS = 4000;

    private final SharedPreferences prefs;

    public ProviderThreadStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized String get(RelayPlan.Actor actor) {
        return prefs.getString(key(actor), "");
    }

    public synchronized void set(RelayPlan.Actor actor, String reply) {
        String value = reply == null ? "" : reply.trim();
        if (value.length() > MAX_STORED_CHARS) {
            value = value.substring(value.length() - MAX_STORED_CHARS);
        }
        if (value.isEmpty()) return;
        prefs.edit().putString(key(actor), value).apply();
    }

    public synchronized void clear() {
        prefs.edit().remove(KEY_CHATGPT).remove(KEY_CLAUDE).apply();
    }

    private String key(RelayPlan.Actor actor) {
        return actor == RelayPlan.Actor.CLAUDE ? KEY_CLAUDE : KEY_CHATGPT;
    }
}
