package com.aigroupchat.bridge;

import android.os.Handler;
import android.os.Looper;

public final class RelayCoordinator {
    private static final long LAUNCH_SETTLE_MS = 1900L;
    private static final long FILL_SETTLE_MS = 900L;
    private static final long SEND_VERIFY_MS = 1200L;
    private static final long SEND_RETRY_MS = 1200L;
    private static final long FIRST_POLL_MS = 1000L;
    private static final long POLL_MS = 800L;
    private static final long MIN_STABLE_MS = 2200L;
    private static final long AUTO_SCROLL_SETTLE_MS = 280L;
    private static final long COPY_RETRY_MS = 420L;
    private static final int MAX_COPY_FIND_ATTEMPTS = 12;
    private static final long STEP_TIMEOUT_MS = 20L * 60L * 1000L;

    private final BridgeAccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ConversationStore store;
    private final ChatGptAdapter chatGpt = new ChatGptAdapter();
    private final ClaudeAdapter claude = new ClaudeAdapter();

    private RelayPlan plan;
    private int stepIndex;
    private boolean running;
    private boolean stopped;
    private String previousResponse = "";
    private AppAdapter currentAdapter;
    private String currentSent = "";
    private String baselineReply = "";
    private String lastCandidate = "";
    private long candidateSince;
    private long stepStarted;
    private int stablePolls;
    private int sendAttempts;
    private boolean sendActionAttempted;

    public RelayCoordinator(BridgeAccessibilityService service) {
        this.service = service;
        this.store = new ConversationStore(service);
    }

    public boolean isRunning() {
        return running;
    }

    public void start(RelayPlan plan) {
        if (running) {
            service.postStatus("A relay is already running.", true);
            return;
        }
        this.plan = plan;
        this.stepIndex = 0;
        this.stopped = false;
        this.running = true;
        this.previousResponse = "";
        store.add(Message.create(Message.Participant.USER, plan.userText));
        service.acquireRelayWakeLock();
        service.showOverlay("Starting relay…");
        runStep();
    }

    public void stop(String reason) {
        if (!running) return;
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        if (currentAdapter != null) currentAdapter.clickStop(service);
        store.add(Message.create(Message.Participant.SYSTEM, "STOPPED — " + reason));
        finish("STOPPED — " + reason, true);
    }

    private void runStep() {
        if (!running || stopped) return;
        if (stepIndex >= plan.steps.size()) {
            finish("Complete — waiting for you.", false);
            return;
        }

        RelayPlan.Step step = plan.steps.get(stepIndex);
        currentAdapter = adapter(step.actor);
        currentSent = buildMessageForStep(step);
        baselineReply = "";
        lastCandidate = "";
        candidateSince = 0L;
        stablePolls = 0;
        sendAttempts = 0;
        sendActionAttempted = false;
        stepStarted = System.currentTimeMillis();

        String status = "Step " + (stepIndex + 1) + "/" + plan.steps.size() + " — " + step.label;
        service.postStatus(status, false);
        service.updateOverlay(status);

        if (!currentAdapter.launch(service)) {
            fail("Could not open " + currentAdapter.displayName() + ". Is the official app installed?");
            return;
        }
        handler.postDelayed(this::prepareAndFill, LAUNCH_SETTLE_MS);
    }

    private void prepareAndFill() {
        if (!running || stopped) return;
        baselineReply = currentAdapter.captureLatestAnchoredReply(service, "").trim();
        tryFillComposer();
    }

    private void tryFillComposer() {
        if (!running || stopped) return;

        // M5 idempotency guard: if a prior click actually sent the handoff, do not paste
        // the same text again just because Accessibility returned a false negative.
        if (sendActionAttempted && currentAdapter.sendAppearsComplete(service, currentSent)) {
            stepStarted = System.currentTimeMillis();
            service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
            handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
            return;
        }

        sendAttempts++;
        if (!currentAdapter.fillComposer(service, currentSent)) {
            retrySendOrFail("I could not find the mapped message composer in " + currentAdapter.displayName() + ".");
            return;
        }
        service.updateOverlay("Verifying " + currentAdapter.displayName() + " message…\nSTOP is always available.");
        handler.postDelayed(this::verifyComposerThenSend, FILL_SETTLE_MS);
    }

    private void verifyComposerThenSend() {
        if (!running || stopped) return;
        if (!currentAdapter.composerContains(service, currentSent)) {
            retrySendOrFail(currentAdapter.displayName() + " did not retain the message text in its composer.");
            return;
        }

        // Accessibility performAction() is not a trustworthy acknowledgement of the
        // provider's Compose send button. On the live Claude app the message can be sent
        // successfully even when Android reports the click as false. Never retry based
        // on the click return value alone; verify the observable UI state first.
        sendActionAttempted = true;
        currentAdapter.clickSend(service);
        service.updateOverlay("Confirming send to " + currentAdapter.displayName() + "…\nSTOP is always available.");
        handler.postDelayed(this::verifySent, SEND_VERIFY_MS);
    }

    private void verifySent() {
        if (!running || stopped) return;
        if (!currentAdapter.sendAppearsComplete(service, currentSent)) {
            retrySendOrFail(currentAdapter.displayName() + " did not confirm that the message left the composer.");
            return;
        }

        stepStarted = System.currentTimeMillis();
        service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
        handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
    }

    private void retrySendOrFail(String lastError) {
        if (!running || stopped) return;
        if (sendAttempts < 5) {
            currentAdapter.launch(service);
            handler.postDelayed(this::tryFillComposer, SEND_RETRY_MS);
        } else {
            fail(lastError + " Tried " + sendAttempts + " times without a verified send.");
        }
    }

    private void pollResponse() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        // M8: actively keep the provider conversation at its newest content. The native
        // apps virtualize long threads; if the viewport falls behind, the current reply
        // and its completion/Copy row can disappear from Accessibility entirely. This is
        // the exact state that previously required the user to manually scroll down.
        currentAdapter.scrollConversationTowardBottom(service);
        handler.postDelayed(this::evaluateResponseAfterScroll, AUTO_SCROLL_SETTLE_MS);
    }

    private void evaluateResponseAfterScroll() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        String candidate = currentAdapter.captureLatestAnchoredReply(service, currentSent).trim();
        boolean generating = currentAdapter.generationAppearsActive(service);

        if (!candidate.isEmpty() && !candidate.equals(baselineReply)) {
            if (candidate.equals(lastCandidate)) {
                stablePolls++;
            } else {
                lastCandidate = candidate;
                stablePolls = 0;
                candidateSince = nowTime;
            }

            if (!generating && stablePolls >= 2 && candidateSince > 0 && nowTime - candidateSince >= MIN_STABLE_MS) {
                captureFullReplyThenComplete(candidate);
                return;
            }
        }

        handler.postDelayed(this::pollResponse, POLL_MS);
    }


    private void captureFullReplyThenComplete(String visibleCandidate) {
        if (!running || stopped) return;
        service.updateOverlay("Capturing full " + currentAdapter.displayName() + " reply…\nSTOP is always available.");
        tryCopyFullReply(visibleCandidate, 1);
    }

    private void tryCopyFullReply(String visibleCandidate, int attempt) {
        if (!running || stopped) return;

        // Keep nudging the virtualized conversation to the end until the response action
        // row is actually exposed. M7 silently relayed the visible slice when Copy was
        // missing; M8 never treats a potentially truncated viewport slice as complete.
        currentAdapter.scrollConversationTowardBottom(service);

        handler.postDelayed(() -> {
            if (!running || stopped) return;

            boolean copyClicked = currentAdapter.clickCopyLatestResponse(service);
            if (!copyClicked) {
                if (attempt < MAX_COPY_FIND_ATTEMPTS) {
                    handler.postDelayed(() -> tryCopyFullReply(visibleCandidate, attempt + 1), COPY_RETRY_MS);
                } else {
                    fail("Full " + currentAdapter.displayName() + " reply capture failed: the native Copy control never became reachable after automatic scrolling.");
                }
                return;
            }

            // Android restricts background clipboard reads on modern versions. The
            // provider remains foregrounded for the Copy click; then our activity comes
            // forward solely to read the clipboard it just populated.
            handler.postDelayed(() -> {
                if (!running || stopped) return;
                service.returnToBridgeApp();
                handler.postDelayed(() -> {
                    if (!running || stopped) return;
                    String copied = service.readClipboardText().trim();
                    if (isPlausibleCopiedReply(copied, visibleCandidate)) {
                        completeStep(copied);
                    } else {
                        fail("Full " + currentAdapter.displayName() + " reply capture failed: Copy was activated, but the clipboard did not contain a verified complete reply. No partial reply was relayed.");
                    }
                }, 500L);
            }, 300L);
        }, AUTO_SCROLL_SETTLE_MS);
    }

    private boolean isPlausibleCopiedReply(String copied, String visibleCandidate) {
        if (copied == null || copied.trim().isEmpty()) return false;
        String c = NodeUtils.normalize(copied);
        String sent = NodeUtils.normalize(currentSent);
        if (c.isEmpty() || c.equals(sent)) return false;

        String v = NodeUtils.normalize(visibleCandidate);
        if (v.isEmpty()) return true;
        if (c.contains(v) || v.contains(c)) return true;

        // Formatting copied as Markdown can differ slightly from accessibility text.
        String cLoose = NodeUtils.normalize(copied.replace("*", " ").replace("_", " ").replace("`", " ").replace("#", " ").replace(">", " ").replace("-", " "));
        String vLoose = NodeUtils.normalize(visibleCandidate.replace("*", " ").replace("_", " ").replace("`", " ").replace("#", " ").replace(">", " ").replace("-", " "));
        if (!cLoose.isEmpty() && !vLoose.isEmpty() && (cLoose.contains(vLoose) || vLoose.contains(cLoose))) return true;

        // For a long response, the visible viewport may be only one slice. A copied reply
        // substantially longer than that slice is still a reasonable result from the
        // provider's just-clicked Copy action.
        return copied.length() >= Math.max(80, (int) (visibleCandidate.length() * 0.85));
    }

    private void completeStep(String response) {
        RelayPlan.Step step = plan.steps.get(stepIndex);
        Message.Participant participant = step.actor == RelayPlan.Actor.CHATGPT
                ? Message.Participant.CHATGPT : Message.Participant.CLAUDE;
        store.add(Message.create(participant, response));
        previousResponse = response;
        stepIndex++;
        service.postStatus(RelayPlan.display(step.actor) + " reply captured.", false);
        handler.postDelayed(this::runStep, 650L);
    }

    private String buildMessageForStep(RelayPlan.Step step) {
        if (!step.relayPrevious) return plan.userText;

        RelayPlan.Actor previousActor = step.actor == RelayPlan.Actor.CHATGPT ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        StringBuilder sb = new StringBuilder();
        sb.append("You are participating in a shared conversation with me and another AI. ")
                .append("The labeled text below was written by the indicated participant, not by me. ")
                .append("Respond directly to the shared task and the other AI's contribution.\n\n");
        if (step.includeOriginalUser) {
            sb.append("[USER]\n").append(plan.userText).append("\n\n");
        }
        sb.append('[').append(RelayPlan.display(previousActor).toUpperCase()).append("]\n")
                .append(previousResponse);
        return sb.toString();
    }

    private AppAdapter adapter(RelayPlan.Actor actor) {
        return actor == RelayPlan.Actor.CHATGPT ? chatGpt : claude;
    }

    private void fail(String message) {
        store.add(Message.create(Message.Participant.SYSTEM, "Relay error: " + message));
        finish("Relay error — " + message, true);
    }

    private void finish(String status, boolean error) {
        running = false;
        handler.removeCallbacksAndMessages(null);
        service.releaseRelayWakeLock();
        service.hideOverlay();
        service.postStatus(status, error);
        service.returnToBridgeApp();
    }
}
