package com.aigroupchat.bridge;

import android.os.Handler;
import android.os.Looper;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class RelayCoordinator {
    private static final long LAUNCH_SETTLE_MS = 1900L;
    private static final long FILL_SETTLE_MS = 900L;
    private static final long SEND_VERIFY_MS = 1200L;
    private static final long SEND_RETRY_MS = 1200L;
    private static final long FIRST_POLL_MS = 1000L;
    private static final long POLL_MS = 800L;
    private static final long MIN_STABLE_MS = 2200L;
    private static final long AUTO_SCROLL_SETTLE_MS = 280L;
    private static final long COPY_RETRY_MS = 420L;
    private static final int MAX_COPY_FIND_ATTEMPTS = 12;
    private static final long STEP_TIMEOUT_MS = 20L * 60L * 1000L;

    private static final Pattern AUTO_ROUTE_PATTERN = Pattern.compile(
            "(?im)^[\\t ]*\\[\\[(NEXT:CHATGPT|NEXT:CLAUDE|NEXT:USER|DONE)\\]\\][\\t ]*$");

    private enum AutoRoute {
        NEXT_CHATGPT,
        NEXT_CLAUDE,
        NEXT_USER,
        DONE,
        MISSING
    }

    private static final class RoutedResponse {
        final String cleanText;
        final AutoRoute route;

        RoutedResponse(String cleanText, AutoRoute route) {
            this.cleanText = cleanText;
            this.route = route;
        }
    }

    private final BridgeAccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ConversationStore store;
    private final ChatGptAdapter chatGpt = new ChatGptAdapter();
    private final ClaudeAdapter claude = new ClaudeAdapter();

    private RelayPlan plan;
    private int stepIndex;
    private boolean running;
    private boolean stopped;
    private String previousResponse = "";
    private RelayPlan.Actor autoActor;
    private AppAdapter currentAdapter;
    private String currentSent = "";
    private String baselineReply = "";
    private String lastCandidate = "";
    private long candidateSince;
    private long stepStarted;
    private int stablePolls;
    private int sendAttempts;
    private boolean sendActionAttempted;
    private boolean attachmentPresentBeforeFill;
    private boolean currentPayloadBecameAttachment;

    public RelayCoordinator(BridgeAccessibilityService service) {
        this.service = service;
        this.store = new ConversationStore(service);
    }

    public boolean isRunning() {
        return running;
    }

    public void start(RelayPlan plan) {
        if (running) {
            service.postStatus("A relay is already running.", true);
            return;
        }
        this.plan = plan;
        this.stepIndex = 0;
        this.stopped = false;
        this.running = true;
        this.previousResponse = "";
        this.autoActor = plan.firstActor;
        store.add(Message.create(Message.Participant.USER, plan.userText));
        service.acquireRelayWakeLock();
        service.showOverlay(plan.isAutoCollaborate() ? "Starting Auto Collaborate…" : "Starting relay…");
        runStep();
    }

    public void stop(String reason) {
        if (!running) return;
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        if (currentAdapter != null) currentAdapter.clickStop(service);
        store.add(Message.create(Message.Participant.SYSTEM, "STOPPED — " + reason));
        finish("STOPPED — " + reason, true);
    }

    private RelayPlan.Step currentStep() {
        if (!plan.isAutoCollaborate()) return plan.steps.get(stepIndex);
        boolean relayPrevious = stepIndex > 0;
        boolean includeOriginalUser = relayPrevious;
        return new RelayPlan.Step(
                autoActor,
                relayPrevious,
                includeOriginalUser,
                RelayPlan.display(autoActor) + " auto collaborating");
    }

    private void runStep() {
        if (!running || stopped) return;

        if (plan.isAutoCollaborate()) {
            if (stepIndex >= plan.maxTurns) {
                store.add(Message.create(
                        Message.Participant.SYSTEM,
                        "Auto Collaborate reached the safety limit of " + plan.maxTurns + " AI turns."));
                finish("Auto Collaborate reached its " + plan.maxTurns + "-turn limit — waiting for you.", false);
                return;
            }
        } else if (stepIndex >= plan.steps.size()) {
            finish("Complete — waiting for you.", false);
            return;
        }

        RelayPlan.Step step = currentStep();
        currentAdapter = adapter(step.actor);
        currentSent = buildMessageForStep(step);
        baselineReply = "";
        lastCandidate = "";
        candidateSince = 0L;
        stablePolls = 0;
        sendAttempts = 0;
        sendActionAttempted = false;
        attachmentPresentBeforeFill = false;
        currentPayloadBecameAttachment = false;
        stepStarted = System.currentTimeMillis();

        String status;
        if (plan.isAutoCollaborate()) {
            status = "Auto turn " + (stepIndex + 1) + "/" + plan.maxTurns + " — " + step.label;
        } else {
            status = "Step " + (stepIndex + 1) + "/" + plan.steps.size() + " — " + step.label;
        }
        service.postStatus(status, false);
        service.updateOverlay(status + "\nSTOP is always available.");

        if (!currentAdapter.launch(service)) {
            fail("Could not open " + currentAdapter.displayName() + ". Is the official app installed?");
            return;
        }
        handler.postDelayed(this::prepareAndFill, LAUNCH_SETTLE_MS);
    }

    private void prepareAndFill() {
        if (!running || stopped) return;
        baselineReply = currentAdapter.captureLatestAnchoredReply(service, "").trim();
        attachmentPresentBeforeFill = currentAdapter.composerHasAutoPastedAttachment(service);
        if (attachmentPresentBeforeFill) {
            fail(currentAdapter.displayName() + " already has a pasted-content attachment waiting in its composer. Remove it before starting a new relay so the bridge cannot confuse an old attachment with this handoff.");
            return;
        }
        tryFillComposer();
    }

    private void tryFillComposer() {
        if (!running || stopped) return;

        // M5/M9 transport baseline: if a prior click actually sent the handoff, do not
        // paste the same text again just because Accessibility returned a false negative.
        if (sendActionAttempted && currentAdapter.sendAppearsComplete(service, currentSent)) {
            stepStarted = System.currentTimeMillis();
            service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
            handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
            return;
        }

        sendAttempts++;
        if (!currentAdapter.fillComposer(service, currentSent)) {
            retrySendOrFail("I could not find the mapped message composer in " + currentAdapter.displayName() + ".");
            return;
        }
        service.updateOverlay("Verifying " + currentAdapter.displayName() + " message…\nSTOP is always available.");
        handler.postDelayed(this::verifyComposerThenSend, FILL_SETTLE_MS);
    }

    private void verifyComposerThenSend() {
        if (!running || stopped) return;

        boolean retainedAsText = currentAdapter.composerContains(service, currentSent);
        boolean convertedToAttachment = !attachmentPresentBeforeFill
                && currentAdapter.composerHasAutoPastedAttachment(service);

        // M9 transport baseline: Claude can convert a large paste into one TXT/Pasted
        // content card and clear its EditText. That counts as a successful insertion.
        if (!retainedAsText && !convertedToAttachment) {
            retrySendOrFail(currentAdapter.displayName() + " did not retain the message text or expose a verified pasted-content attachment.");
            return;
        }

        currentPayloadBecameAttachment = convertedToAttachment;
        sendActionAttempted = true;
        currentAdapter.clickSend(service);
        service.updateOverlay("Confirming send to " + currentAdapter.displayName()
                + (currentPayloadBecameAttachment ? " pasted-content attachment" : "")
                + "…\nSTOP is always available.");
        handler.postDelayed(this::verifySent, SEND_VERIFY_MS);
    }

    private void verifySent() {
        if (!running || stopped) return;

        if (currentPayloadBecameAttachment) {
            // Once Send succeeds, the removable composer attachment must disappear.
            // Never paste another copy while it is still present.
            if (currentAdapter.composerHasAutoPastedAttachment(service)) {
                fail(currentAdapter.displayName() + " converted the large handoff into a pasted-content attachment, but the attachment did not leave the composer after Send. It was not pasted again.");
                return;
            }
        } else if (!currentAdapter.sendAppearsComplete(service, currentSent)) {
            retrySendOrFail(currentAdapter.displayName() + " did not confirm that the message left the composer.");
            return;
        }

        stepStarted = System.currentTimeMillis();
        service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
        handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
    }

    private void retrySendOrFail(String lastError) {
        if (!running || stopped) return;
        if (sendAttempts < 5) {
            currentAdapter.launch(service);
            handler.postDelayed(this::tryFillComposer, SEND_RETRY_MS);
        } else {
            fail(lastError + " Tried " + sendAttempts + " times without a verified send.");
        }
    }

    private void pollResponse() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        // M8/M9 transport baseline: keep the virtualized conversation at its newest
        // content so the completed reply and native Copy action enter Accessibility.
        currentAdapter.scrollConversationTowardBottom(service);
        handler.postDelayed(this::evaluateResponseAfterScroll, AUTO_SCROLL_SETTLE_MS);
    }

    private void evaluateResponseAfterScroll() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        String candidate = currentAdapter.captureLatestAnchoredReply(
                service, currentPayloadBecameAttachment ? "" : currentSent).trim();
        boolean generating = currentAdapter.generationAppearsActive(service);

        if (!candidate.isEmpty() && !candidate.equals(baselineReply)) {
            if (candidate.equals(lastCandidate)) {
                stablePolls++;
            } else {
                lastCandidate = candidate;
                stablePolls = 0;
                candidateSince = nowTime;
            }

            if (!generating && stablePolls >= 2 && candidateSince > 0 && nowTime - candidateSince >= MIN_STABLE_MS) {
                captureFullReplyThenComplete(candidate);
                return;
            }
        }

        handler.postDelayed(this::pollResponse, POLL_MS);
    }

    private void captureFullReplyThenComplete(String visibleCandidate) {
        if (!running || stopped) return;
        service.updateOverlay("Capturing full " + currentAdapter.displayName() + " reply…\nSTOP is always available.");
        tryCopyFullReply(visibleCandidate, 1);
    }

    private void tryCopyFullReply(String visibleCandidate, int attempt) {
        if (!running || stopped) return;

        currentAdapter.scrollConversationTowardBottom(service);

        handler.postDelayed(() -> {
            if (!running || stopped) return;

            boolean copyClicked = currentAdapter.clickCopyLatestResponse(service);
            if (!copyClicked) {
                if (attempt < MAX_COPY_FIND_ATTEMPTS) {
                    handler.postDelayed(() -> tryCopyFullReply(visibleCandidate, attempt + 1), COPY_RETRY_MS);
                } else {
                    fail("Full " + currentAdapter.displayName() + " reply capture failed: the native Copy control never became reachable after automatic scrolling.");
                }
                return;
            }

            handler.postDelayed(() -> {
                if (!running || stopped) return;
                service.returnToBridgeApp();
                handler.postDelayed(() -> {
                    if (!running || stopped) return;
                    String copied = service.readClipboardText().trim();
                    if (isPlausibleCopiedReply(copied, visibleCandidate)) {
                        completeStep(copied);
                    } else {
                        fail("Full " + currentAdapter.displayName() + " reply capture failed: Copy was activated, but the clipboard did not contain a verified complete reply. No partial reply was relayed.");
                    }
                }, 500L);
            }, 300L);
        }, AUTO_SCROLL_SETTLE_MS);
    }

    private boolean isPlausibleCopiedReply(String copied, String visibleCandidate) {
        if (copied == null || copied.trim().isEmpty()) return false;
        String c = NodeUtils.normalize(copied);
        String sent = NodeUtils.normalize(currentSent);
        if (c.isEmpty() || c.equals(sent)) return false;

        String v = NodeUtils.normalize(visibleCandidate);
        if (v.isEmpty()) return true;
        if (c.contains(v) || v.contains(c)) return true;

        String cLoose = NodeUtils.normalize(copied.replace("*", " ").replace("_", " ").replace("`", " ").replace("#", " ").replace(">", " ").replace("-", " "));
        String vLoose = NodeUtils.normalize(visibleCandidate.replace("*", " ").replace("_", " ").replace("`", " ").replace("#", " ").replace(">", " ").replace("-", " "));
        if (!cLoose.isEmpty() && !vLoose.isEmpty() && (cLoose.contains(vLoose) || vLoose.contains(cLoose))) return true;

        return copied.length() >= Math.max(80, (int) (visibleCandidate.length() * 0.85));
    }

    private void completeStep(String response) {
        RelayPlan.Step step = currentStep();

        if (plan.isAutoCollaborate()) {
            completeAutoStep(step, response);
            return;
        }

        Message.Participant participant = step.actor == RelayPlan.Actor.CHATGPT
                ? Message.Participant.CHATGPT : Message.Participant.CLAUDE;
        store.add(Message.create(participant, response));
        previousResponse = response;
        stepIndex++;
        service.postStatus(RelayPlan.display(step.actor) + " reply captured.", false);
        handler.postDelayed(this::runStep, 650L);
    }

    private void completeAutoStep(RelayPlan.Step step, String response) {
        RoutedResponse routed = parseAutoRoute(response);
        String visibleResponse = routed.cleanText.isEmpty()
                ? "(Auto Collaborate response contained no visible message text.)"
                : routed.cleanText;

        Message.Participant participant = step.actor == RelayPlan.Actor.CHATGPT
                ? Message.Participant.CHATGPT : Message.Participant.CLAUDE;
        store.add(Message.create(participant, visibleResponse));
        previousResponse = visibleResponse;
        stepIndex++;
        service.postStatus(RelayPlan.display(step.actor) + " reply captured.", false);

        switch (routed.route) {
            case DONE:
                finish("Auto Collaborate complete — waiting for you.", false);
                return;
            case NEXT_USER:
                finish("Auto Collaborate paused — " + RelayPlan.display(step.actor) + " requested your input.", false);
                return;
            case NEXT_CHATGPT:
                if (step.actor == RelayPlan.Actor.CHATGPT) {
                    fail("Auto Collaborate received an invalid self-route from ChatGPT.");
                    return;
                }
                autoActor = RelayPlan.Actor.CHATGPT;
                break;
            case NEXT_CLAUDE:
                if (step.actor == RelayPlan.Actor.CLAUDE) {
                    fail("Auto Collaborate received an invalid self-route from Claude.");
                    return;
                }
                autoActor = RelayPlan.Actor.CLAUDE;
                break;
            case MISSING:
            default:
                store.add(Message.create(
                        Message.Participant.SYSTEM,
                        "Auto Collaborate paused because " + RelayPlan.display(step.actor)
                                + " did not return a routing marker."));
                finish("Auto Collaborate paused — routing marker missing.", true);
                return;
        }

        if (stepIndex >= plan.maxTurns) {
            store.add(Message.create(
                    Message.Participant.SYSTEM,
                    "Auto Collaborate reached the safety limit of " + plan.maxTurns
                            + " AI turns before another handoff."));
            finish("Auto Collaborate reached its " + plan.maxTurns + "-turn limit — waiting for you.", false);
            return;
        }

        handler.postDelayed(this::runStep, 650L);
    }

    private RoutedResponse parseAutoRoute(String response) {
        Matcher matcher = AUTO_ROUTE_PATTERN.matcher(response == null ? "" : response);
        String lastToken = null;
        while (matcher.find()) lastToken = matcher.group(1);

        String cleaned = AUTO_ROUTE_PATTERN.matcher(response == null ? "" : response)
                .replaceAll("")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();

        if (lastToken == null) return new RoutedResponse(cleaned, AutoRoute.MISSING);

        switch (lastToken.toUpperCase(Locale.US)) {
            case "NEXT:CHATGPT": return new RoutedResponse(cleaned, AutoRoute.NEXT_CHATGPT);
            case "NEXT:CLAUDE": return new RoutedResponse(cleaned, AutoRoute.NEXT_CLAUDE);
            case "NEXT:USER": return new RoutedResponse(cleaned, AutoRoute.NEXT_USER);
            case "DONE": return new RoutedResponse(cleaned, AutoRoute.DONE);
            default: return new RoutedResponse(cleaned, AutoRoute.MISSING);
        }
    }

    private String buildMessageForStep(RelayPlan.Step step) {
        if (plan.isAutoCollaborate()) return buildAutoMessageForStep(step);
        if (!step.relayPrevious) return plan.userText;

        RelayPlan.Actor previousActor = step.actor == RelayPlan.Actor.CHATGPT
                ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        StringBuilder sb = new StringBuilder();
        sb.append("You are participating in a shared conversation with me and another AI. ")
                .append("The labeled text below was written by the indicated participant, not by me. ")
                .append("Respond directly to the shared task and the other AI's contribution.\n\n");
        if (step.includeOriginalUser) {
            sb.append("[ORIGINAL USER REQUEST]\n").append(plan.userText).append("\n\n");
        }
        sb.append('[').append(RelayPlan.display(previousActor).toUpperCase()).append("]\n")
                .append(previousResponse);
        return sb.toString();
    }

    private String buildAutoMessageForStep(RelayPlan.Step step) {
        if (!step.relayPrevious) {
            return plan.userText + "\n\n" + autoRoutingInstruction(step.actor);
        }

        RelayPlan.Actor previousActor = step.actor == RelayPlan.Actor.CHATGPT
                ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        StringBuilder sb = new StringBuilder();
        sb.append("You are participating in an Auto Collaborate conversation with me and another AI. ")
                .append("The labeled text below was written by the indicated participant, not by me. ")
                .append("Continue the shared task directly. Do not merely acknowledge the other AI; ")
                .append("do whatever useful review, verification, revision, or next work is needed.\n\n");
        if (step.includeOriginalUser) {
            sb.append("[ORIGINAL USER REQUEST]\n").append(plan.userText).append("\n\n");
        }
        sb.append('[').append(RelayPlan.display(previousActor).toUpperCase()).append("]\n")
                .append(previousResponse)
                .append("\n\n")
                .append(autoRoutingInstruction(step.actor));
        return sb.toString();
    }

    private String autoRoutingInstruction(RelayPlan.Actor actor) {
        RelayPlan.Actor other = actor == RelayPlan.Actor.CHATGPT
                ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        String nextOther = other == RelayPlan.Actor.CHATGPT ? "[[NEXT:CHATGPT]]" : "[[NEXT:CLAUDE]]";
        return "AI GROUP CHAT AUTO-ROUTING CONTROL (required): At the very end of your response, "
                + "on its own line and outside any code block, output exactly ONE routing marker. "
                + "Use " + nextOther + " if the other AI should respond next because another review, answer, "
                + "verification, revision, or piece of work would materially help. Use [[NEXT:USER]] if you need "
                + "the user to answer a question, choose, approve, test, or provide something before useful work can continue. "
                + "Use [[DONE]] if the shared task is complete and no further AI response is needed. "
                + "Do not omit the marker and do not explain the marker.";
    }

    private AppAdapter adapter(RelayPlan.Actor actor) {
        return actor == RelayPlan.Actor.CHATGPT ? chatGpt : claude;
    }

    private void fail(String message) {
        store.add(Message.create(Message.Participant.SYSTEM, "Relay error: " + message));
        finish("Relay error — " + message, true);
    }

    private void finish(String status, boolean error) {
        running = false;
        handler.removeCallbacksAndMessages(null);
        service.releaseRelayWakeLock();
        service.hideOverlay();
        service.postStatus(status, error);
        service.returnToBridgeApp();
    }
}
