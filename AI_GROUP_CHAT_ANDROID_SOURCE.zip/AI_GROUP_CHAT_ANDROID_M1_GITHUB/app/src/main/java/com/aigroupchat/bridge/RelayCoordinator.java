package com.aigroupchat.bridge;

import android.os.Handler;
import android.os.Looper;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class RelayCoordinator {
    private static final long LAUNCH_SETTLE_MS = 1900L;
    private static final long FILL_SETTLE_MS = 900L;
    private static final long SEND_VERIFY_MS = 1200L;
    private static final long SEND_RETRY_MS = 1200L;
    private static final long FIRST_POLL_MS = 1000L;
    private static final long POLL_MS = 800L;
    private static final long MIN_STABLE_MS = 2200L;
    private static final long PRIME_MS = 2500L;
    private static final long PRIME_POLL_MS = 250L;
    private static final long IDENTITY_WARN_MS = 60_000L;
    private static final long BOTTOM_SETTLE_MS = 450L;
    private static final int BOTTOM_STABLE_SAMPLES = 3;
    private static final long AUTO_SCROLL_SETTLE_MS = 280L;
    private static final long COPY_RETRY_MS = 420L;
    private static final int MAX_COPY_FIND_ATTEMPTS = 12;
    private static final long ATTACH_VERIFY_POLL_MS = 450L;
    private static final int MAX_ATTACH_VERIFY_POLLS = 8;
    private static final long NATIVE_ATTACH_MENU_SETTLE_MS = 650L;
    private static final long NATIVE_PICKER_SETTLE_MS = 950L;
    private static final long NATIVE_ATTACH_RETURN_MS = 1400L;
    private static final long STEP_TIMEOUT_MS = 20L * 60L * 1000L;

    private static final Pattern AUTO_ROUTE_PATTERN = Pattern.compile(
            "(?im)^[\\t ]*\\[\\[(NEXT:CHATGPT|NEXT:CLAUDE|NEXT:USER|DONE)\\]\\][\\t ]*$");

    private enum AutoRoute {
        NEXT_CHATGPT,
        NEXT_CLAUDE,
        NEXT_USER,
        DONE,
        MISSING
    }

    private static final class RoutedResponse {
        final String cleanText;
        final AutoRoute route;

        RoutedResponse(String cleanText, AutoRoute route) {
            this.cleanText = cleanText;
            this.route = route;
        }
    }

    private final BridgeAccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ConversationStore store;
    private final RunStateStore runStateStore;
    private final ChatGptAdapter chatGpt = new ChatGptAdapter();
    private final ClaudeAdapter claude = new ClaudeAdapter();

    private RelayPlan plan;
    private int stepIndex;
    private boolean running;
    private boolean stopped;
    private String previousResponse = "";
    private RelayPlan.Actor autoActor;
    private AppAdapter currentAdapter;
    private String currentSent = "";
    private String baselineReply = "";
    private String lastCandidate = "";
    private long candidateSince;
    private long stepStarted;
    private int stablePolls;
    private int sendAttempts;
    private boolean sendActionAttempted;
    private boolean attachmentPresentBeforeFill;
    private boolean currentPayloadBecameAttachment;
    private boolean attachmentsDeliveredChatGpt;
    private boolean attachmentsDeliveredClaude;
    private boolean sharedAttachmentsThisStep;
    private int attachmentVerifyPolls;
    private int baselineResponseActionCount;
    private boolean nativeAttachmentFallbackAttempted;
    private boolean promptPreexisted;
    private boolean sentAnchorConfirmed;
    private boolean sentStepConfirmed;
    private int preSendFingerprint;
    private boolean responseStartedForThisStep;
    private boolean sawGenerationForThisStep;
    private long sendVerifiedAt;
    private long responseStartedAt;
    private long generationEndedAt;
    private long primingUntil;
    private int lastFingerprint;
    private int noMoveScrolls;
    private boolean lastPollScrolled;
    private int lastScrollResult;
    private boolean manualTurnProof;
    private boolean identityWarned;

    public RelayCoordinator(BridgeAccessibilityService service) {
        this.service = service;
        this.store = new ConversationStore(service);
        this.runStateStore = new RunStateStore(service);
    }

    public boolean isRunning() {
        return running;
    }

    public void start(RelayPlan plan) {
        if (running) {
            service.postStatus("A relay is already running.", true);
            return;
        }
        handler.removeCallbacksAndMessages(null);
        clearTransientRuntimeState();
        this.plan = plan;
        this.stepIndex = 0;
        this.stopped = false;
        this.running = true;
        this.previousResponse = "";
        this.autoActor = plan.firstActor;
        this.attachmentsDeliveredChatGpt = false;
        this.attachmentsDeliveredClaude = false;
        runStateStore.clear();
        store.add(Message.create(Message.Participant.USER, transcriptUserText(plan)));
        checkpoint(RunStateStore.Stage.READY_NEXT, "");
        service.acquireRelayWakeLock();
        service.showOverlay(plan.isAutoCollaborate() ? "Starting Auto Collaborate…" : "Starting relay…");
        runStep();
    }

    public void stop(String reason) {
        if (!running) return;
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        if (currentAdapter != null) currentAdapter.clickStop(service);
        runStateStore.clear();
        store.add(Message.create(Message.Participant.SYSTEM, "STOPPED — " + reason));
        finish("STOPPED — " + reason, true);
    }

    public void suspend(String reason) {
        if (!running) return;
        running = false;
        handler.removeCallbacksAndMessages(null);
        service.releaseRelayWakeLock();
        service.hideOverlay();
        service.postStatus("Relay paused — " + reason + ". Resume is available.", true);
    }

    public boolean hasRecoverableRun() {
        return runStateStore.hasRecoverable();
    }

    public void discardRecoverableRun() {
        if (!running) runStateStore.clear();
    }

    public void resumeSavedRun() {
        if (running) {
            service.postStatus("A relay is already running.", true);
            return;
        }
        RunStateStore.Snapshot snap = runStateStore.load();
        if (snap == null || snap.plan == null) {
            service.postStatus("No interrupted relay is available to resume.", true);
            return;
        }
        plan = snap.plan;
        stepIndex = Math.max(0, snap.stepIndex);
        previousResponse = snap.previousResponse == null ? "" : snap.previousResponse;
        autoActor = snap.autoActor == null ? plan.firstActor : snap.autoActor;
        currentSent = snap.currentSent == null ? "" : snap.currentSent;
        currentPayloadBecameAttachment = snap.payloadBecameAttachment;
        attachmentsDeliveredChatGpt = snap.attachmentsDeliveredChatGpt;
        attachmentsDeliveredClaude = snap.attachmentsDeliveredClaude;
        baselineReply = snap.baselineReply == null ? "" : snap.baselineReply;
        baselineResponseActionCount = snap.baselineResponseActionCount;
        promptPreexisted = snap.promptPreexisted;
        sentAnchorConfirmed = snap.sentAnchorConfirmed;
        sentStepConfirmed = snap.sentStepConfirmed;
        preSendFingerprint = snap.preSendFingerprint;
        responseStartedForThisStep = snap.responseStartedForThisStep;
        sawGenerationForThisStep = snap.sawGenerationForThisStep;
        sendVerifiedAt = snap.sendVerifiedAt;
        responseStartedAt = snap.responseStartedAt;
        generationEndedAt = 0L;
        primingUntil = 0L;
        manualTurnProof = false;
        identityWarned = false;
        resetVolatileDetectorState();
        stopped = false;
        running = true;
        sendActionAttempted = snap.stage == RunStateStore.Stage.SEND_ACTION_ATTEMPTED
                || snap.stage == RunStateStore.Stage.WAITING_RESPONSE
                || snap.stage == RunStateStore.Stage.CAPTURING_REPLY;
        service.acquireRelayWakeLock();
        service.showOverlay("Resuming interrupted relay…");

        if (snap.currentActor != null) {
            currentAdapter = adapter(snap.currentActor);
            sharedAttachmentsThisStep = shouldShareOriginalAttachments(snap.currentActor);
        }
        if ((snap.stage == RunStateStore.Stage.WAITING_RESPONSE || snap.stage == RunStateStore.Stage.CAPTURING_REPLY)
                && currentAdapter != null) {
            currentAdapter.launch(service);
            resetResponsePollingState();
            handler.postDelayed(() -> {
                stepStarted = System.currentTimeMillis();
                service.updateOverlay("Resumed — waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
                handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
            }, LAUNCH_SETTLE_MS);
            return;
        }
        if (snap.stage == RunStateStore.Stage.SEND_ACTION_ATTEMPTED && currentAdapter != null) {
            currentAdapter.launch(service);
            handler.postDelayed(this::resumeSendVerification, LAUNCH_SETTLE_MS);
            return;
        }
        runStep();
    }

    private RelayPlan.Step currentStep() {
        if (!plan.isAutoCollaborate()) return plan.steps.get(stepIndex);
        boolean relayPrevious = stepIndex > 0;
        boolean includeOriginalUser = relayPrevious;
        return new RelayPlan.Step(
                autoActor,
                relayPrevious,
                includeOriginalUser,
                RelayPlan.display(autoActor) + " auto collaborating");
    }

    private void runStep() {
        if (!running || stopped) return;

        if (plan.isAutoCollaborate()) {
            if (stepIndex >= plan.maxTurns) {
                store.add(Message.create(
                        Message.Participant.SYSTEM,
                        "Auto Collaborate reached the safety limit of " + plan.maxTurns + " AI turns."));
                finish("Auto Collaborate reached its " + plan.maxTurns + "-turn limit — waiting for you.", false);
                return;
            }
        } else if (stepIndex >= plan.steps.size()) {
            finish("Complete — waiting for you.", false);
            return;
        }

        RelayPlan.Step step = currentStep();
        resetStepTransientState();
        currentAdapter = adapter(step.actor);
        currentSent = buildMessageForStep(step);
        sharedAttachmentsThisStep = shouldShareOriginalAttachments(step.actor);
        stepStarted = System.currentTimeMillis();

        String status;
        if (plan.isAutoCollaborate()) {
            status = "Auto turn " + (stepIndex + 1) + "/" + plan.maxTurns + " — " + step.label;
        } else {
            status = "Step " + (stepIndex + 1) + "/" + plan.steps.size() + " — " + step.label;
        }
        service.postStatus(status, false);
        service.updateOverlay(status + "\nSTOP is always available.");

        checkpoint(RunStateStore.Stage.PREPARING, "");
        // Always open the provider normally so we stay in its existing conversation.
        // ACTION_SEND was removed from the live path because ChatGPT used it to create
        // a new native chat instead of attaching to the mapped thread.
        boolean launched = currentAdapter.launch(service);
        if (!launched) {
            fail("Could not open " + currentAdapter.displayName() + ". Is the official app installed?");
            return;
        }
        handler.postDelayed(this::prepareAndFill, LAUNCH_SETTLE_MS);
    }

    private void prepareAndFill() {
        if (!running || stopped) return;
        baselineReply = currentAdapter.captureLatestAnchoredReply(service, "").trim();
        baselineResponseActionCount = currentAdapter.responseActionCount(service);
        promptPreexisted = currentAdapter.hasSentMessageAnchor(service, currentSent);
        attachmentPresentBeforeFill = currentAdapter.composerHasAutoPastedAttachment(service);
        if (attachmentPresentBeforeFill) {
            fail(currentAdapter.displayName() + " already has a pasted-content attachment waiting in its composer. Remove it before starting a new relay so the bridge cannot confuse an old attachment with this handoff.");
            return;
        }

        if (sharedAttachmentsThisStep) {
            if (currentAdapter.composerHasSharedAttachments(service, plan.attachments)) {
                fail(currentAdapter.displayName() + " already has an attachment waiting in the mapped composer. Remove it before retrying so the bridge cannot confuse an old file with this shared turn.");
                return;
            }
            service.updateOverlay("Attaching inside the existing " + currentAdapter.displayName()
                    + " conversation…\nSTOP is always available.");
            boolean pasteAccepted = currentAdapter.pasteSharedAttachmentsIntoCurrentComposer(service, plan.attachments);
            if (!pasteAccepted) {
                beginNativeAttachmentFallback();
                return;
            }
            attachmentVerifyPolls = 0;
            handler.postDelayed(this::verifySharedAttachmentsThenFill, ATTACH_VERIFY_POLL_MS);
            return;
        }
        tryFillComposer();
    }

    private void verifySharedAttachmentsThenFill() {
        if (!running || stopped) return;
        if (currentAdapter.composerHasSharedAttachments(service, plan.attachments)) {
            service.updateOverlay("Attachment verified in the existing " + currentAdapter.displayName()
                    + " conversation. Preparing message…\nSTOP is always available.");
            tryFillComposer();
            return;
        }
        attachmentVerifyPolls++;
        if (attachmentVerifyPolls < MAX_ATTACH_VERIFY_POLLS) {
            handler.postDelayed(this::verifySharedAttachmentsThenFill, ATTACH_VERIFY_POLL_MS);
            return;
        }
        beginNativeAttachmentFallback();
    }

    private void beginNativeAttachmentFallback() {
        if (!running || stopped) return;
        if (nativeAttachmentFallbackAttempted) {
            fail("The shared file could not be verified inside the existing " + currentAdapter.displayName()
                    + " conversation after both rich-paste and native-attach attempts. No text was sent and ACTION_SEND/new-chat sharing was not used. Capture this exact provider composer state with Diagnostics.");
            return;
        }
        nativeAttachmentFallbackAttempted = true;
        // If a provider interpreted URI paste as plain text, clear only the editable composer
        // before trying the provider's own attachment UI. A verified attachment would already
        // have returned earlier and never reaches this path.
        currentAdapter.fillComposer(service, "");
        if (plan.attachments == null || plan.attachments.size() != 1) {
            fail("Native in-thread attachment fallback currently requires one file at a time. No text was sent and no new provider chat was opened.");
            return;
        }
        service.updateOverlay("Opening " + currentAdapter.displayName()
                + " attachment controls in the existing conversation…\nSTOP is always available.");
        if (!currentAdapter.clickNativeAttachmentLauncher(service)) {
            fail("Could not find " + currentAdapter.displayName()
                    + "'s attachment control in the existing mapped conversation. No text was sent and no new provider chat was opened. Use Diagnostics to capture this composer state.");
            return;
        }
        handler.postDelayed(this::openNativeAttachmentFileSource, NATIVE_ATTACH_MENU_SETTLE_MS);
    }

    private void openNativeAttachmentFileSource() {
        if (!running || stopped) return;
        // Some provider versions open Android's picker directly; others first show a small
        // menu with Files/Upload. If we are still in the provider, choose that file option.
        if (currentAdapter.providerIsForeground(service)) currentAdapter.clickNativeFileSourceIfVisible(service);
        handler.postDelayed(this::selectNativeAttachmentByName, NATIVE_PICKER_SETTLE_MS);
    }

    private void selectNativeAttachmentByName() {
        if (!running || stopped) return;
        AttachmentRecord attachment = plan.attachments.get(0);
        boolean clicked = currentAdapter.clickPickerItemByName(service, attachment.displayName);
        if (!clicked) {
            fail("The native file picker opened for " + currentAdapter.displayName()
                    + ", but the bridge could not find " + attachment.displayName
                    + " in the visible picker results. No text was sent. Keep the file visible in Recent and capture a UI map if this repeats.");
            return;
        }
        service.updateOverlay("Returning to the existing " + currentAdapter.displayName()
                + " conversation and verifying the attachment…\nSTOP is always available.");
        handler.postDelayed(this::verifyNativeAttachmentReturn, NATIVE_ATTACH_RETURN_MS);
    }

    private void verifyNativeAttachmentReturn() {
        if (!running || stopped) return;
        if (!currentAdapter.providerIsForeground(service)) {
            currentAdapter.launch(service);
            handler.postDelayed(this::verifyNativeAttachmentReturn, LAUNCH_SETTLE_MS);
            return;
        }
        if (!currentAdapter.composerHasSharedAttachments(service, plan.attachments)) {
            fail("The native picker returned to " + currentAdapter.displayName()
                    + ", but the bridge could not verify the selected attachment in the existing composer. No text was sent. Use Diagnostics now to map the provider's real attachment chip.");
            return;
        }
        service.updateOverlay("Attachment verified in the existing " + currentAdapter.displayName()
                + " conversation. Preparing message…\nSTOP is always available.");
        tryFillComposer();
    }

    private void tryFillComposer() {
        if (!running || stopped) return;

        // M5/M9 transport baseline: if a prior click actually sent the handoff, do not
        // paste the same text again just because Accessibility returned a false negative.
        if (sendActionAttempted && currentAdapter.sendAppearsComplete(service, currentSent)) {
            if (sharedAttachmentsThisStep) markAttachmentsDelivered(currentStep().actor);
            stepStarted = System.currentTimeMillis();
            beginResponseLatch();
            checkpoint(RunStateStore.Stage.WAITING_RESPONSE, "");
            service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
            handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
            return;
        }

        sendAttempts++;
        if (!currentAdapter.fillComposer(service, currentSent)) {
            retrySendOrFail("I could not find the mapped message composer in " + currentAdapter.displayName() + ".");
            return;
        }
        checkpoint(RunStateStore.Stage.FILLED, "");
        service.updateOverlay("Verifying " + currentAdapter.displayName() + " message…\nSTOP is always available.");
        handler.postDelayed(this::verifyComposerThenSend, FILL_SETTLE_MS);
    }

    private void verifyComposerThenSend() {
        if (!running || stopped) return;

        boolean retainedAsText = currentAdapter.composerContains(service, currentSent);
        boolean convertedToAttachment = !attachmentPresentBeforeFill
                && currentAdapter.composerHasAutoPastedAttachment(service);

        // M9 transport baseline: Claude can convert a large paste into one TXT/Pasted
        // content card and clear its EditText. That counts as a successful insertion.
        if (!retainedAsText && !convertedToAttachment) {
            retrySendOrFail(currentAdapter.displayName() + " did not retain the message text or expose a verified pasted-content attachment.");
            return;
        }

        currentPayloadBecameAttachment = convertedToAttachment;
        sendActionAttempted = true;
        preSendFingerprint = currentAdapter.visibleFingerprint(service);
        checkpoint(RunStateStore.Stage.SEND_ACTION_ATTEMPTED, "");
        currentAdapter.clickSend(service);
        service.updateOverlay("Confirming send to " + currentAdapter.displayName()
                + (currentPayloadBecameAttachment ? " pasted-content attachment" : "")
                + "…\nSTOP is always available.");
        handler.postDelayed(this::verifySent, SEND_VERIFY_MS);
    }

    private void verifySent() {
        if (!running || stopped) return;

        if (currentPayloadBecameAttachment) {
            // Once Send succeeds, the removable composer attachment must disappear.
            // Never paste another copy while it is still present.
            if (currentAdapter.composerHasAutoPastedAttachment(service)) {
                fail(currentAdapter.displayName() + " converted the large handoff into a pasted-content attachment, but the attachment did not leave the composer after Send. It was not pasted again.");
                return;
            }
        } else if (!currentAdapter.sendAppearsComplete(service, currentSent)) {
            retrySendOrFail(currentAdapter.displayName() + " did not confirm that the message left the composer.");
            return;
        }

        if (sharedAttachmentsThisStep) markAttachmentsDelivered(currentStep().actor);
        stepStarted = System.currentTimeMillis();
        beginResponseLatch();
        checkpoint(RunStateStore.Stage.WAITING_RESPONSE, "");
        service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
        handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
    }

    private void beginResponseLatch() {
        long now = System.currentTimeMillis();
        responseStartedForThisStep = false;
        sentAnchorConfirmed = false;
        sentStepConfirmed = false;
        sawGenerationForThisStep = currentAdapter != null && currentAdapter.generationAppearsActive(service);
        generationEndedAt = 0L;
        sendVerifiedAt = now;
        responseStartedAt = 0L;
        manualTurnProof = false;
        identityWarned = false;
        primingUntil = now + PRIME_MS;
        resetVolatileDetectorState();
    }

    private void resetVolatileDetectorState() {
        lastCandidate = "";
        candidateSince = 0L;
        stablePolls = 0;
        lastFingerprint = 0;
        noMoveScrolls = 0;
        lastPollScrolled = false;
        lastScrollResult = -1;
    }

    private void retrySendOrFail(String lastError) {
        if (!running || stopped) return;
        if (sendAttempts < 5) {
            currentAdapter.launch(service);
            handler.postDelayed(this::tryFillComposer, SEND_RETRY_MS);
        } else {
            fail(lastError + " Tried " + sendAttempts + " times without a verified send.");
        }
    }

    private void pollResponse() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        // M11.2 priming: observe without scrolling immediately after a verified send so the
        // newly committed prompt / generation state can be latched before virtualization hides it.
        if (nowTime < primingUntil) {
            lastPollScrolled = false;
            handler.postDelayed(this::evaluateResponseAfterScroll, PRIME_POLL_MS);
            return;
        }
        lastScrollResult = currentAdapter.scrollConversationTowardBottomResult(service);
        lastPollScrolled = true;
        handler.postDelayed(this::evaluateResponseAfterScroll, BOTTOM_SETTLE_MS);
    }

    private void evaluateResponseAfterScroll() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        boolean generating = currentAdapter.generationAppearsActive(service);
        boolean anchoredNow = !currentPayloadBecameAttachment
                && currentAdapter.hasSentMessageAnchor(service, currentSent);
        int responseActionCount = currentAdapter.responseActionCount(service);
        boolean inPriming = nowTime < primingUntil;
        boolean stateChanged = false;

        if (anchoredNow && !sentAnchorConfirmed) {
            sentAnchorConfirmed = true;
            stateChanged = true;
        }
        if (!sentStepConfirmed) {
            boolean composerCleared = currentPayloadBecameAttachment
                    ? !currentAdapter.composerHasAutoPastedAttachment(service)
                    : !currentAdapter.composerContains(service, currentSent);
            boolean uniqueAnchor = sentAnchorConfirmed && !promptPreexisted;
            boolean viewportEvidence = inPriming && !lastPollScrolled && preSendFingerprint != 0
                    && currentAdapter.visibleFingerprint(service) != preSendFingerprint;
            if (composerCleared && (uniqueAnchor || viewportEvidence)) {
                sentStepConfirmed = true;
                stateChanged = true;
            }
        }

        if (lastPollScrolled) {
            int fp = currentAdapter.visibleFingerprint(service);
            boolean unchanged = fp == lastFingerprint;
            lastFingerprint = fp;
            if (!unchanged || generating || !currentAdapter.providerIsForeground(service)) noMoveScrolls = 0;
            else noMoveScrolls += (lastScrollResult == 0 ? 2 : 1);
        } else {
            noMoveScrolls = 0;
        }
        boolean atTrueBottom = noMoveScrolls >= BOTTOM_STABLE_SAMPLES;

        if (generating) {
            if (!sawGenerationForThisStep) stateChanged = true;
            sawGenerationForThisStep = true;
            generationEndedAt = 0L;
        } else if (sawGenerationForThisStep && generationEndedAt == 0L) {
            generationEndedAt = nowTime;
        }

        if (!responseStartedForThisStep) {
            boolean anchoredReplyText = sentStepConfirmed && !promptPreexisted
                    && !currentPayloadBecameAttachment
                    && !currentAdapter.captureLatestAnchoredReply(service, currentSent).trim().isEmpty();
            // Strong evidence only. The visible Copy-row count is NOT proof: in a virtualized list
            // it can change merely because different old rows are on screen. (Kept as a diagnostic.)
            if (sawGenerationForThisStep || anchoredReplyText) {
                responseStartedForThisStep = true;
                responseStartedAt = nowTime;
                resetVolatileDetectorState();
                stateChanged = true;
            }
        }
        if (stateChanged) checkpoint(RunStateStore.Stage.WAITING_RESPONSE, "");

        boolean generationDone = !sawGenerationForThisStep
                || (generationEndedAt > 0 && nowTime - generationEndedAt >= MIN_STABLE_MS);
        boolean turnProof = manualTurnProof
                || (sentStepConfirmed && responseStartedForThisStep && generationDone);

        String candidate = "";
        if (responseStartedForThisStep) {
            if (!currentPayloadBecameAttachment) {
                candidate = currentAdapter.captureLatestAnchoredReply(service, currentSent).trim();
            }
            if (candidate.isEmpty() && !generating && atTrueBottom) {
                candidate = currentAdapter.captureLatestAnchoredReply(service, "").trim();
            }
        }

        if (!turnProof && !identityWarned && nowTime - sendVerifiedAt > IDENTITY_WARN_MS) {
            identityWarned = true;
            service.postStatus("Can't yet prove which " + currentAdapter.displayName()
                    + " reply belongs to this step. If the reply is finished on screen, tap Check now to accept it.", false);
        }

        if (responseStartedForThisStep && !candidate.isEmpty()) {
            if (candidate.equals(lastCandidate)) {
                stablePolls++;
            } else {
                lastCandidate = candidate;
                stablePolls = 0;
                candidateSince = nowTime;
            }

            if (!generating && turnProof && stablePolls >= 2 && candidateSince > 0
                    && nowTime - candidateSince >= MIN_STABLE_MS) {
                captureFullReplyThenComplete(candidate);
                return;
            }
        }

        handler.postDelayed(this::pollResponse, nowTime < primingUntil ? PRIME_POLL_MS : POLL_MS);
    }

    private void captureFullReplyThenComplete(String visibleCandidate) {
        if (!running || stopped) return;
        checkpoint(RunStateStore.Stage.CAPTURING_REPLY, "");
        service.updateOverlay("Capturing full " + currentAdapter.displayName() + " reply…\nSTOP is always available.");
        tryCopyFullReply(visibleCandidate, 1);
    }

    private void tryCopyFullReply(String visibleCandidate, int attempt) {
        if (!running || stopped) return;

        currentAdapter.scrollConversationTowardBottom(service);

        handler.postDelayed(() -> {
            if (!running || stopped) return;

            boolean copyClicked = currentAdapter.clickCopyLatestResponse(service);
            if (!copyClicked) {
                if (attempt < MAX_COPY_FIND_ATTEMPTS) {
                    handler.postDelayed(() -> tryCopyFullReply(visibleCandidate, attempt + 1), COPY_RETRY_MS);
                } else {
                    fail("Full " + currentAdapter.displayName() + " reply capture failed: the native Copy control never became reachable after automatic scrolling.");
                }
                return;
            }

            handler.postDelayed(() -> {
                if (!running || stopped) return;
                service.returnToBridgeApp();
                handler.postDelayed(() -> {
                    if (!running || stopped) return;
                    String copied = service.readClipboardText().trim();
                    if (isPlausibleCopiedReply(copied, visibleCandidate)) {
                        completeStep(copied);
                    } else {
                        fail("Full " + currentAdapter.displayName() + " reply capture failed: Copy was activated, but the clipboard did not contain a verified complete reply. No partial reply was relayed.");
                    }
                }, 500L);
            }, 300L);
        }, AUTO_SCROLL_SETTLE_MS);
    }

    private boolean isPlausibleCopiedReply(String copied, String visibleCandidate) {
        if (copied == null || copied.trim().isEmpty()) return false;
        String c = NodeUtils.normalize(copied);
        String sent = NodeUtils.normalize(currentSent);
        if (c.isEmpty() || c.equals(sent)) return false;

        String v = NodeUtils.normalize(visibleCandidate);
        if (v.isEmpty()) return true;
        if (c.contains(v) || v.contains(c)) return true;

        String cLoose = NodeUtils.normalize(copied.replace("*", " ").replace("_", " ").replace("`", " ").replace("#", " ").replace(">", " ").replace("-", " "));
        String vLoose = NodeUtils.normalize(visibleCandidate.replace("*", " ").replace("_", " ").replace("`", " ").replace("#", " ").replace(">", " ").replace("-", " "));
        if (!cLoose.isEmpty() && !vLoose.isEmpty() && (cLoose.contains(vLoose) || vLoose.contains(cLoose))) return true;

        // M11.2: length alone can never prove identity (an unrelated old reply can be long too).
        // Native Copy may differ from the rendered text (bullets, numbering, links, tables), so
        // require real content overlap: >=85% of the visible reply's distinct words must appear in
        // the copied text, and the visible text must be long enough for that to mean something.
        java.util.Set<String> visibleTokens = wordTokens(visibleCandidate);
        if (visibleTokens.size() < 8) return false;
        java.util.Set<String> copiedTokens = wordTokens(copied);
        int hits = 0;
        for (String t : visibleTokens) if (copiedTokens.contains(t)) hits++;
        return hits >= (int) Math.ceil(visibleTokens.size() * 0.85);
    }

    private static java.util.Set<String> wordTokens(String s) {
        java.util.Set<String> out = new java.util.HashSet<>();
        if (s == null) return out;
        for (String t : s.toLowerCase(java.util.Locale.ROOT).split("[^\\p{L}\\p{N}]+")) {
            if (t.length() >= 3) out.add(t);
        }
        return out;
    }

    private void completeStep(String response) {
        RelayPlan.Step step = currentStep();

        if (plan.isAutoCollaborate()) {
            completeAutoStep(step, response);
            return;
        }

        Message.Participant participant = step.actor == RelayPlan.Actor.CHATGPT
                ? Message.Participant.CHATGPT : Message.Participant.CLAUDE;
        store.add(Message.create(participant, response));
        previousResponse = response;
        stepIndex++;
        checkpoint(RunStateStore.Stage.READY_NEXT, "");
        service.postStatus(RelayPlan.display(step.actor) + " reply captured.", false);
        handler.postDelayed(this::runStep, 650L);
    }

    private void completeAutoStep(RelayPlan.Step step, String response) {
        RoutedResponse routed = parseAutoRoute(response);
        String visibleResponse = routed.cleanText.isEmpty()
                ? "(Auto Collaborate response contained no visible message text.)"
                : routed.cleanText;

        Message.Participant participant = step.actor == RelayPlan.Actor.CHATGPT
                ? Message.Participant.CHATGPT : Message.Participant.CLAUDE;
        store.add(Message.create(participant, visibleResponse));
        previousResponse = visibleResponse;
        stepIndex++;
        service.postStatus(RelayPlan.display(step.actor) + " reply captured.", false);

        switch (routed.route) {
            case DONE:
                finish("Auto Collaborate complete — waiting for you.", false);
                return;
            case NEXT_USER:
                finish("Auto Collaborate paused — " + RelayPlan.display(step.actor) + " requested your input.", false);
                return;
            case NEXT_CHATGPT:
                if (step.actor == RelayPlan.Actor.CHATGPT) {
                    fail("Auto Collaborate received an invalid self-route from ChatGPT.");
                    return;
                }
                autoActor = RelayPlan.Actor.CHATGPT;
                break;
            case NEXT_CLAUDE:
                if (step.actor == RelayPlan.Actor.CLAUDE) {
                    fail("Auto Collaborate received an invalid self-route from Claude.");
                    return;
                }
                autoActor = RelayPlan.Actor.CLAUDE;
                break;
            case MISSING:
            default:
                store.add(Message.create(
                        Message.Participant.SYSTEM,
                        "Auto Collaborate paused because " + RelayPlan.display(step.actor)
                                + " did not return a routing marker."));
                finish("Auto Collaborate paused — routing marker missing.", true);
                return;
        }

        if (stepIndex >= plan.maxTurns) {
            store.add(Message.create(
                    Message.Participant.SYSTEM,
                    "Auto Collaborate reached the safety limit of " + plan.maxTurns
                            + " AI turns before another handoff."));
            finish("Auto Collaborate reached its " + plan.maxTurns + "-turn limit — waiting for you.", false);
            return;
        }

        checkpoint(RunStateStore.Stage.READY_NEXT, "");
        handler.postDelayed(this::runStep, 650L);
    }

    private RoutedResponse parseAutoRoute(String response) {
        Matcher matcher = AUTO_ROUTE_PATTERN.matcher(response == null ? "" : response);
        String lastToken = null;
        while (matcher.find()) lastToken = matcher.group(1);

        String cleaned = AUTO_ROUTE_PATTERN.matcher(response == null ? "" : response)
                .replaceAll("")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();

        if (lastToken == null) return new RoutedResponse(cleaned, AutoRoute.MISSING);

        switch (lastToken.toUpperCase(Locale.US)) {
            case "NEXT:CHATGPT": return new RoutedResponse(cleaned, AutoRoute.NEXT_CHATGPT);
            case "NEXT:CLAUDE": return new RoutedResponse(cleaned, AutoRoute.NEXT_CLAUDE);
            case "NEXT:USER": return new RoutedResponse(cleaned, AutoRoute.NEXT_USER);
            case "DONE": return new RoutedResponse(cleaned, AutoRoute.DONE);
            default: return new RoutedResponse(cleaned, AutoRoute.MISSING);
        }
    }

    private String buildMessageForStep(RelayPlan.Step step) {
        if (plan.isAutoCollaborate()) return buildAutoMessageForStep(step);
        if (!step.relayPrevious) return plan.userText;

        RelayPlan.Actor previousActor = step.actor == RelayPlan.Actor.CHATGPT
                ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        StringBuilder sb = new StringBuilder();
        sb.append("You are participating in a shared conversation with me and another AI. ")
                .append("The labeled text below was written by the indicated participant, not by me. ")
                .append("Respond directly to the shared task and the other AI's contribution.\n\n");
        if (step.includeOriginalUser) {
            sb.append("[ORIGINAL USER REQUEST]\n").append(plan.userText).append("\n\n");
        }
        sb.append('[').append(RelayPlan.display(previousActor).toUpperCase()).append("]\n")
                .append(previousResponse);
        return sb.toString();
    }

    private String buildAutoMessageForStep(RelayPlan.Step step) {
        if (!step.relayPrevious) {
            return plan.userText + "\n\n" + autoRoutingInstruction(step.actor);
        }

        RelayPlan.Actor previousActor = step.actor == RelayPlan.Actor.CHATGPT
                ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        StringBuilder sb = new StringBuilder();
        sb.append("You are participating in an Auto Collaborate conversation with me and another AI. ")
                .append("The labeled text below was written by the indicated participant, not by me. ")
                .append("Continue the shared task directly. Do not merely acknowledge the other AI; ")
                .append("do whatever useful review, verification, revision, or next work is needed.\n\n");
        if (step.includeOriginalUser) {
            sb.append("[ORIGINAL USER REQUEST]\n").append(plan.userText).append("\n\n");
        }
        sb.append('[').append(RelayPlan.display(previousActor).toUpperCase()).append("]\n")
                .append(previousResponse)
                .append("\n\n")
                .append(autoRoutingInstruction(step.actor));
        return sb.toString();
    }

    private String autoRoutingInstruction(RelayPlan.Actor actor) {
        RelayPlan.Actor other = actor == RelayPlan.Actor.CHATGPT
                ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        String nextOther = other == RelayPlan.Actor.CHATGPT ? "[[NEXT:CHATGPT]]" : "[[NEXT:CLAUDE]]";
        return "AI GROUP CHAT AUTO-ROUTING CONTROL (required): At the very end of your response, "
                + "on its own line and outside any code block, output exactly ONE routing marker. "
                + "Use " + nextOther + " if the other AI should respond next because another review, answer, "
                + "verification, revision, or piece of work would materially help. Use [[NEXT:USER]] if you need "
                + "the user to answer a question, choose, approve, test, or provide something before useful work can continue. "
                + "Use [[DONE]] if the shared task is complete and no further AI response is needed. "
                + "Do not omit the marker and do not explain the marker.";
    }

    private boolean shouldShareOriginalAttachments(RelayPlan.Actor actor) {
        if (plan == null || !plan.hasAttachments()) return false;
        return actor == RelayPlan.Actor.CHATGPT ? !attachmentsDeliveredChatGpt : !attachmentsDeliveredClaude;
    }

    private void markAttachmentsDelivered(RelayPlan.Actor actor) {
        if (actor == RelayPlan.Actor.CHATGPT) attachmentsDeliveredChatGpt = true;
        else attachmentsDeliveredClaude = true;
    }

    private void resetStepTransientState() {
        baselineReply = "";
        baselineResponseActionCount = 0;
        lastCandidate = "";
        candidateSince = 0L;
        stablePolls = 0;
        sendAttempts = 0;
        sendActionAttempted = false;
        attachmentPresentBeforeFill = false;
        currentPayloadBecameAttachment = false;
        sharedAttachmentsThisStep = false;
        attachmentVerifyPolls = 0;
        nativeAttachmentFallbackAttempted = false;
        clearResponseIdentity();
    }

    private void clearResponseIdentity() {
        promptPreexisted = false;
        sentAnchorConfirmed = false;
        sentStepConfirmed = false;
        preSendFingerprint = 0;
        responseStartedForThisStep = false;
        sawGenerationForThisStep = false;
        sendVerifiedAt = 0L;
        responseStartedAt = 0L;
        generationEndedAt = 0L;
        primingUntil = 0L;
        manualTurnProof = false;
        identityWarned = false;
        lastFingerprint = 0;
        noMoveScrolls = 0;
        lastPollScrolled = false;
    }

    private void clearTransientRuntimeState() {
        currentAdapter = null;
        currentSent = "";
        baselineReply = "";
        baselineResponseActionCount = 0;
        lastCandidate = "";
        candidateSince = 0L;
        stablePolls = 0;
        sendAttempts = 0;
        sendActionAttempted = false;
        attachmentPresentBeforeFill = false;
        currentPayloadBecameAttachment = false;
        sharedAttachmentsThisStep = false;
        attachmentVerifyPolls = 0;
        nativeAttachmentFallbackAttempted = false;
        clearResponseIdentity();
        stepStarted = 0L;
    }

    public void checkCurrentReplyNow() {
        if (!running || stopped || currentAdapter == null) {
            service.postStatus("No active provider reply is waiting to be checked.", true);
            return;
        }
        service.postStatus("Re-checking the current " + currentAdapter.displayName() + " reply…", false);
        manualTurnProof = true;
        noMoveScrolls = 0;
        if (!responseStartedForThisStep) {
            responseStartedForThisStep = true;
            responseStartedAt = System.currentTimeMillis();
            resetVolatileDetectorState();
        }
        lastScrollResult = currentAdapter.scrollConversationTowardBottomResult(service);
        lastPollScrolled = true;
        handler.postDelayed(this::evaluateResponseAfterScroll, BOTTOM_SETTLE_MS);
    }

    private void resetResponsePollingState() {
        resetVolatileDetectorState();
        sendAttempts = 0;
        stepStarted = System.currentTimeMillis();
    }

    private void resumeSendVerification() {
        if (!running || stopped || currentAdapter == null) return;
        if (currentPayloadBecameAttachment) {
            if (currentAdapter.composerHasAutoPastedAttachment(service)) {
                currentAdapter.clickSend(service);
                handler.postDelayed(this::verifySent, SEND_VERIFY_MS);
            } else {
                if (sharedAttachmentsThisStep && currentAdapter != null) markAttachmentsDelivered(currentStep().actor);
                resetResponsePollingState();
                beginResponseLatch();
                checkpoint(RunStateStore.Stage.WAITING_RESPONSE, "");
                handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
            }
            return;
        }
        if (currentAdapter.sendAppearsComplete(service, currentSent)) {
            if (sharedAttachmentsThisStep) markAttachmentsDelivered(currentStep().actor);
            resetResponsePollingState();
            beginResponseLatch();
            checkpoint(RunStateStore.Stage.WAITING_RESPONSE, "");
            handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
        } else if (currentAdapter.composerContains(service, currentSent)) {
            currentAdapter.clickSend(service);
            handler.postDelayed(this::verifySent, SEND_VERIFY_MS);
        } else {
            runStep();
        }
    }

    private void checkpoint(RunStateStore.Stage stage, String error) {
        if (plan == null) return;
        RunStateStore.Snapshot snap = new RunStateStore.Snapshot();
        snap.plan = plan;
        snap.stepIndex = stepIndex;
        snap.previousResponse = previousResponse;
        snap.autoActor = autoActor;
        try { snap.currentActor = currentAdapter == null ? null : currentStep().actor; } catch (Exception ignored) { snap.currentActor = null; }
        snap.currentSent = currentSent;
        snap.stage = stage;
        snap.payloadBecameAttachment = currentPayloadBecameAttachment;
        snap.attachmentsDeliveredChatGpt = attachmentsDeliveredChatGpt;
        snap.attachmentsDeliveredClaude = attachmentsDeliveredClaude;
        snap.lastError = error == null ? "" : error;
        snap.baselineReply = baselineReply;
        snap.baselineResponseActionCount = baselineResponseActionCount;
        snap.promptPreexisted = promptPreexisted;
        snap.sentAnchorConfirmed = sentAnchorConfirmed;
        snap.sentStepConfirmed = sentStepConfirmed;
        snap.preSendFingerprint = preSendFingerprint;
        snap.responseStartedForThisStep = responseStartedForThisStep;
        snap.sawGenerationForThisStep = sawGenerationForThisStep;
        snap.sendVerifiedAt = sendVerifiedAt;
        snap.responseStartedAt = responseStartedAt;
        runStateStore.save(snap);
    }

    private String transcriptUserText(RelayPlan plan) {
        if (plan == null || !plan.hasAttachments()) return plan == null ? "" : plan.userText;
        StringBuilder sb = new StringBuilder(plan.userText);
        for (AttachmentRecord a : plan.attachments) {
            sb.append("\n📎 ").append(a.displayName);
        }
        return sb.toString();
    }

    private AppAdapter adapter(RelayPlan.Actor actor) {
        return actor == RelayPlan.Actor.CHATGPT ? chatGpt : claude;
    }

    private void fail(String message) {
        checkpoint(RunStateStore.Stage.FAILED, message);
        store.add(Message.create(Message.Participant.SYSTEM, "Relay error: " + message));
        finish("Relay error — " + message, true);
    }

    private void finish(String status, boolean error) {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (!error) runStateStore.clear();
        service.releaseRelayWakeLock();
        service.hideOverlay();
        service.postStatus(status, error);
        service.returnToBridgeApp();
        // Keep any FAILED checkpoint on disk for explicit Retry/Resume, but never let
        // stale runtime flags poison the next fresh relay in this service instance.
        clearTransientRuntimeState();
    }
}
