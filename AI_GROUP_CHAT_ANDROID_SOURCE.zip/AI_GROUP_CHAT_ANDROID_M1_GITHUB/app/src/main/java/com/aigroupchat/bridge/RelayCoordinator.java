package com.aigroupchat.bridge;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;

public final class RelayCoordinator {
    private static final long LAUNCH_SETTLE_MS = 1800L;
    private static final long SEND_RETRY_MS = 900L;
    private static final long FIRST_POLL_MS = 1400L;
    private static final long POLL_MS = 850L;
    private static final long MIN_STABLE_MS = 3800L;
    private static final long STEP_TIMEOUT_MS = 20L * 60L * 1000L;

    private final BridgeAccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ConversationStore store;
    private final ChatGptAdapter chatGpt = new ChatGptAdapter();
    private final ClaudeAdapter claude = new ClaudeAdapter();

    private RelayPlan plan;
    private int stepIndex;
    private boolean running;
    private boolean stopped;
    private String previousResponse = "";
    private AppAdapter currentAdapter;
    private String currentSent = "";
    private List<String> baseline = new ArrayList<>();
    private String lastCandidate = "";
    private long candidateSince;
    private long stepStarted;
    private int stablePolls;
    private int sendAttempts;

    public RelayCoordinator(BridgeAccessibilityService service) {
        this.service = service;
        this.store = new ConversationStore(service);
    }

    public boolean isRunning() {
        return running;
    }

    public void start(RelayPlan plan) {
        if (running) {
            service.postStatus("A relay is already running.", true);
            return;
        }
        this.plan = plan;
        this.stepIndex = 0;
        this.stopped = false;
        this.running = true;
        this.previousResponse = "";
        store.add(Message.create(Message.Participant.USER, plan.userText));
        service.acquireRelayWakeLock();
        service.showOverlay("Starting relay…");
        runStep();
    }

    public void stop(String reason) {
        if (!running) return;
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        if (currentAdapter != null) currentAdapter.clickStop(service);
        store.add(Message.create(Message.Participant.SYSTEM, "STOPPED — " + reason));
        finish("STOPPED — " + reason, true);
    }

    private void runStep() {
        if (!running || stopped) return;
        if (stepIndex >= plan.steps.size()) {
            finish("Complete — waiting for you.", false);
            return;
        }

        RelayPlan.Step step = plan.steps.get(stepIndex);
        currentAdapter = adapter(step.actor);
        currentSent = buildMessageForStep(step);
        baseline = new ArrayList<>();
        lastCandidate = "";
        candidateSince = 0L;
        stablePolls = 0;
        sendAttempts = 0;
        stepStarted = System.currentTimeMillis();

        String status = "Step " + (stepIndex + 1) + "/" + plan.steps.size() + " — " + step.label;
        service.postStatus(status, false);
        service.updateOverlay(status);

        if (!currentAdapter.launch(service)) {
            fail("Could not open " + currentAdapter.displayName() + ". Is the official app installed?");
            return;
        }
        handler.postDelayed(this::prepareAndSend, LAUNCH_SETTLE_MS);
    }

    private void prepareAndSend() {
        if (!running || stopped) return;
        baseline = currentAdapter.captureVisibleTexts(service);
        trySend();
    }

    private void trySend() {
        if (!running || stopped) return;
        sendAttempts++;
        boolean sent = currentAdapter.send(service, currentSent);
        if (sent) {
            service.updateOverlay("Waiting for " + currentAdapter.displayName() + "…\nSTOP is always available.");
            handler.postDelayed(this::pollResponse, FIRST_POLL_MS);
            return;
        }
        if (sendAttempts < 6) {
            currentAdapter.launch(service);
            handler.postDelayed(this::trySend, SEND_RETRY_MS);
        } else {
            fail("I could not find or activate the message box/send control in " + currentAdapter.displayName() + ". The app UI may have changed.");
        }
    }

    private void pollResponse() {
        if (!running || stopped) return;
        long nowTime = System.currentTimeMillis();
        if (nowTime - stepStarted > STEP_TIMEOUT_MS) {
            fail(currentAdapter.displayName() + " did not produce a capturable reply before the safety timeout.");
            return;
        }

        List<String> now = currentAdapter.captureVisibleTexts(service);
        if (now.isEmpty()) {
            currentAdapter.launch(service);
            handler.postDelayed(this::pollResponse, POLL_MS);
            return;
        }

        String candidate = currentAdapter.extractLikelyReply(baseline, now, currentSent).trim();
        boolean generating = currentAdapter.generationAppearsActive(service);

        if (!candidate.isEmpty()) {
            if (candidate.equals(lastCandidate)) {
                stablePolls++;
            } else {
                lastCandidate = candidate;
                stablePolls = 0;
                candidateSince = nowTime;
            }

            if (!generating && stablePolls >= 3 && candidateSince > 0 && nowTime - candidateSince >= MIN_STABLE_MS) {
                completeStep(candidate);
                return;
            }
        }

        handler.postDelayed(this::pollResponse, POLL_MS);
    }

    private void completeStep(String response) {
        RelayPlan.Step step = plan.steps.get(stepIndex);
        Message.Participant participant = step.actor == RelayPlan.Actor.CHATGPT
                ? Message.Participant.CHATGPT : Message.Participant.CLAUDE;
        store.add(Message.create(participant, response));
        previousResponse = response;
        stepIndex++;
        service.postStatus(RelayPlan.display(step.actor) + " reply captured.", false);
        handler.postDelayed(this::runStep, 500L);
    }

    private String buildMessageForStep(RelayPlan.Step step) {
        if (!step.relayPrevious) return plan.userText;

        RelayPlan.Actor previousActor = step.actor == RelayPlan.Actor.CHATGPT ? RelayPlan.Actor.CLAUDE : RelayPlan.Actor.CHATGPT;
        StringBuilder sb = new StringBuilder();
        sb.append("You are participating in a shared conversation with me and another AI. ")
                .append("The labeled text below was written by the indicated participant, not by me. ")
                .append("Respond directly to the shared task and the other AI's contribution.\n\n");
        if (step.includeOriginalUser) {
            sb.append("[USER]\n").append(plan.userText).append("\n\n");
        }
        sb.append('[').append(RelayPlan.display(previousActor).toUpperCase()).append("]\n")
                .append(previousResponse);
        return sb.toString();
    }

    private AppAdapter adapter(RelayPlan.Actor actor) {
        return actor == RelayPlan.Actor.CHATGPT ? chatGpt : claude;
    }

    private void fail(String message) {
        store.add(Message.create(Message.Participant.SYSTEM, "Relay error: " + message));
        finish("Relay error — " + message, true);
    }

    private void finish(String status, boolean error) {
        running = false;
        handler.removeCallbacksAndMessages(null);
        service.releaseRelayWakeLock();
        service.hideOverlay();
        service.postStatus(status, error);
        service.returnToBridgeApp();
    }
}
