package com.aigroupchat.bridge;

import java.util.ArrayList;
import java.util.List;

public final class RelayPlan {
    public enum Mode { CHATGPT_ONLY, CLAUDE_ONLY, BOTH, COLLABORATE, AUTO_COLLABORATE }
    public enum Actor { CHATGPT, CLAUDE }

    public static final class Step {
        public final Actor actor;
        public final boolean relayPrevious;
        public final boolean includeOriginalUser;
        public final String label;

        Step(Actor actor, boolean relayPrevious, boolean includeOriginalUser, String label) {
            this.actor = actor;
            this.relayPrevious = relayPrevious;
            this.includeOriginalUser = includeOriginalUser;
            this.label = label;
        }
    }

    public final String userText;
    public final Mode mode;
    public final Actor firstActor;
    public final int rounds;
    public final int maxTurns;
    public final List<Step> steps;

    private RelayPlan(String userText, Mode mode, Actor firstActor, int rounds, int maxTurns, List<Step> steps) {
        this.userText = userText;
        this.mode = mode;
        this.firstActor = firstActor;
        this.rounds = rounds;
        this.maxTurns = maxTurns;
        this.steps = steps;
    }

    public static RelayPlan build(String userText, Mode mode, Actor firstActor, int rounds) {
        int safeRounds = Math.max(1, Math.min(2, rounds));
        List<Step> steps = new ArrayList<>();

        switch (mode) {
            case CHATGPT_ONLY:
                steps.add(new Step(Actor.CHATGPT, false, true, "ChatGPT answering"));
                break;
            case CLAUDE_ONLY:
                steps.add(new Step(Actor.CLAUDE, false, true, "Claude answering"));
                break;
            case BOTH:
                steps.add(new Step(Actor.CHATGPT, false, true, "ChatGPT answering independently"));
                steps.add(new Step(Actor.CLAUDE, false, true, "Claude answering independently"));
                break;
            case COLLABORATE:
                Actor second = firstActor == Actor.CHATGPT ? Actor.CLAUDE : Actor.CHATGPT;
                steps.add(new Step(firstActor, false, true, display(firstActor) + " proposing"));
                steps.add(new Step(second, true, true, display(second) + " reviewing"));
                steps.add(new Step(firstActor, true, true, display(firstActor) + " revising"));
                if (safeRounds == 2) {
                    steps.add(new Step(second, true, true, display(second) + " reviewing round 2"));
                    steps.add(new Step(firstActor, true, true, display(firstActor) + " revising round 2"));
                }
                break;
            case AUTO_COLLABORATE:
                return buildAuto(userText, firstActor, 10);
        }
        return new RelayPlan(userText, mode, firstActor, safeRounds, 0, steps);
    }

    public static RelayPlan buildAuto(String userText, Actor firstActor, int maxTurns) {
        int safeMaxTurns = Math.max(3, Math.min(20, maxTurns));
        return new RelayPlan(
                userText,
                Mode.AUTO_COLLABORATE,
                firstActor,
                0,
                safeMaxTurns,
                new ArrayList<>());
    }

    public boolean isAutoCollaborate() {
        return mode == Mode.AUTO_COLLABORATE;
    }

    public static String display(Actor actor) {
        return actor == Actor.CHATGPT ? "ChatGPT" : "Claude";
    }
}
