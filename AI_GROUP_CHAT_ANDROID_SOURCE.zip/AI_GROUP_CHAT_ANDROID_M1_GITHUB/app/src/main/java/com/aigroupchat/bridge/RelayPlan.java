package com.aigroupchat.bridge;

import java.util.ArrayList;
import java.util.List;

public final class RelayPlan {
    public enum Mode { CHATGPT_ONLY, CLAUDE_ONLY, BOTH, COLLABORATE }
    public enum Actor { CHATGPT, CLAUDE }

    public static final class Step {
        public final Actor actor;
        public final boolean relayPrevious;
        public final boolean includeOriginalUser;
        public final String label;

        Step(Actor actor, boolean relayPrevious, boolean includeOriginalUser, String label) {
            this.actor = actor;
            this.relayPrevious = relayPrevious;
            this.includeOriginalUser = includeOriginalUser;
            this.label = label;
        }
    }

    public final String userText;
    public final Mode mode;
    public final Actor firstActor;
    public final int rounds;
    public final List<Step> steps;

    private RelayPlan(String userText, Mode mode, Actor firstActor, int rounds, List<Step> steps) {
        this.userText = userText;
        this.mode = mode;
        this.firstActor = firstActor;
        this.rounds = rounds;
        this.steps = steps;
    }

    public static RelayPlan build(String userText, Mode mode, Actor firstActor, int rounds) {
        int safeRounds = Math.max(1, Math.min(2, rounds));
        List<Step> steps = new ArrayList<>();

        switch (mode) {
            case CHATGPT_ONLY:
                steps.add(new Step(Actor.CHATGPT, false, true, "ChatGPT answering"));
                break;
            case CLAUDE_ONLY:
                steps.add(new Step(Actor.CLAUDE, false, true, "Claude answering"));
                break;
            case BOTH:
                steps.add(new Step(Actor.CHATGPT, false, true, "ChatGPT answering independently"));
                steps.add(new Step(Actor.CLAUDE, false, true, "Claude answering independently"));
                break;
            case COLLABORATE:
                Actor second = firstActor == Actor.CHATGPT ? Actor.CLAUDE : Actor.CHATGPT;
                steps.add(new Step(firstActor, false, true, display(firstActor) + " proposing"));
                steps.add(new Step(second, true, true, display(second) + " reviewing"));
                steps.add(new Step(firstActor, true, false, display(firstActor) + " revising"));
                if (safeRounds == 2) {
                    steps.add(new Step(second, true, false, display(second) + " reviewing round 2"));
                    steps.add(new Step(firstActor, true, false, display(firstActor) + " revising round 2"));
                }
                break;
        }
        return new RelayPlan(userText, mode, firstActor, safeRounds, steps);
    }

    public static String display(Actor actor) {
        return actor == Actor.CHATGPT ? "ChatGPT" : "Claude";
    }
}
