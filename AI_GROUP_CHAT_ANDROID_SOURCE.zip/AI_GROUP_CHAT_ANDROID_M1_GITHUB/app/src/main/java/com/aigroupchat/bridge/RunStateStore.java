package com.aigroupchat.bridge;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/**
 * Durable, conservative relay checkpointing. A checkpoint is written before/after
 * meaningful relay transitions so Android process/service interruption can resume
 * forward without rewriting completed steps.
 */
public final class RunStateStore {
    private static final String PREFS = "ai_group_chat_bridge";
    private static final String KEY_ACTIVE_RUN = "active_run_v11";

    public enum Stage {
        READY_NEXT,
        PREPARING,
        FILLED,
        SEND_ACTION_ATTEMPTED,
        WAITING_RESPONSE,
        CAPTURING_REPLY,
        FAILED
    }

    public static final class Snapshot {
        public RelayPlan plan;
        public int stepIndex;
        public String previousResponse;
        public RelayPlan.Actor autoActor;
        public RelayPlan.Actor currentActor;
        public String currentSent;
        public Stage stage;
        public boolean payloadBecameAttachment;
        public boolean attachmentsDeliveredChatGpt;
        public boolean attachmentsDeliveredClaude;
        public long updatedAt;
        public String lastError;
    }

    private final SharedPreferences prefs;

    public RunStateStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void save(Snapshot s) {
        if (s == null || s.plan == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("plan", s.plan.toJson());
            o.put("stepIndex", s.stepIndex);
            o.put("previousResponse", s.previousResponse == null ? "" : s.previousResponse);
            o.put("autoActor", s.autoActor == null ? JSONObject.NULL : s.autoActor.name());
            o.put("currentActor", s.currentActor == null ? JSONObject.NULL : s.currentActor.name());
            o.put("currentSent", s.currentSent == null ? "" : s.currentSent);
            o.put("stage", (s.stage == null ? Stage.READY_NEXT : s.stage).name());
            o.put("payloadBecameAttachment", s.payloadBecameAttachment);
            o.put("attachmentsDeliveredChatGpt", s.attachmentsDeliveredChatGpt);
            o.put("attachmentsDeliveredClaude", s.attachmentsDeliveredClaude);
            o.put("updatedAt", System.currentTimeMillis());
            o.put("lastError", s.lastError == null ? "" : s.lastError);
            prefs.edit().putString(KEY_ACTIVE_RUN, o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public synchronized Snapshot load() {
        String raw = prefs.getString(KEY_ACTIVE_RUN, "");
        if (raw == null || raw.trim().isEmpty()) return null;
        try {
            JSONObject o = new JSONObject(raw);
            Snapshot s = new Snapshot();
            s.plan = RelayPlan.fromJson(o.getJSONObject("plan"));
            s.stepIndex = o.optInt("stepIndex", 0);
            s.previousResponse = o.optString("previousResponse", "");
            s.autoActor = actorOrNull(o.optString("autoActor", ""));
            s.currentActor = actorOrNull(o.optString("currentActor", ""));
            s.currentSent = o.optString("currentSent", "");
            try {
                s.stage = Stage.valueOf(o.optString("stage", Stage.READY_NEXT.name()));
            } catch (Exception ignored) {
                s.stage = Stage.READY_NEXT;
            }
            s.payloadBecameAttachment = o.optBoolean("payloadBecameAttachment", false);
            s.attachmentsDeliveredChatGpt = o.optBoolean("attachmentsDeliveredChatGpt", false);
            s.attachmentsDeliveredClaude = o.optBoolean("attachmentsDeliveredClaude", false);
            s.updatedAt = o.optLong("updatedAt", 0L);
            s.lastError = o.optString("lastError", "");
            return s.plan == null ? null : s;
        } catch (Exception ignored) {
            return null;
        }
    }

    public synchronized boolean hasRecoverable() {
        return load() != null;
    }

    public synchronized void clear() {
        prefs.edit().remove(KEY_ACTIVE_RUN).apply();
    }

    private RelayPlan.Actor actorOrNull(String raw) {
        if (raw == null || raw.isEmpty() || "null".equalsIgnoreCase(raw)) return null;
        try {
            return RelayPlan.Actor.valueOf(raw);
        } catch (Exception ignored) {
            return null;
        }
    }
}
