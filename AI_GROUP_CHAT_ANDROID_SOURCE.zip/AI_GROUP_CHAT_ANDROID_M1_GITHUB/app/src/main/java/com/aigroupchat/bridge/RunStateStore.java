package com.aigroupchat.bridge;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/**
 * Durable, conservative relay checkpointing. A checkpoint is written before/after
 * meaningful relay transitions so Android process/service interruption can resume
 * forward without rewriting completed steps.
 */
public final class RunStateStore {
    private static final String PREFS = "ai_group_chat_bridge";
    private static final String KEY_ACTIVE_RUN = "active_run_v11";

    public enum Stage {
        READY_NEXT,
        PREPARING,
        FILLED,
        SEND_ACTION_ATTEMPTED,
        WAITING_RESPONSE,
        CAPTURING_REPLY,
        FAILED
    }

    public static final class Snapshot {
        public RelayPlan plan;
        public int stepIndex;
        public String previousResponse;
        public RelayPlan.Actor autoActor;
        public RelayPlan.Actor currentActor;
        public String currentSent;
        public Stage stage;
        public boolean payloadBecameAttachment;
        public boolean attachmentsDeliveredChatGpt;
        public boolean attachmentsDeliveredClaude;
        public long updatedAt;
        public String lastError;
        // M11.2 durable per-step response identity (survives process death)
        public String baselineReply = "";
        public int baselineResponseActionCount;
        public boolean promptPreexisted;
        public boolean sentAnchorConfirmed;
        public boolean sentStepConfirmed;
        public int preSendFingerprint;
        public boolean responseStartedForThisStep;
        public boolean sawGenerationForThisStep;
        public long sendVerifiedAt;
        public long responseStartedAt;
    }

    private final SharedPreferences prefs;

    public RunStateStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void save(Snapshot s) {
        if (s == null || s.plan == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("plan", s.plan.toJson());
            o.put("stepIndex", s.stepIndex);
            o.put("previousResponse", s.previousResponse == null ? "" : s.previousResponse);
            o.put("autoActor", s.autoActor == null ? JSONObject.NULL : s.autoActor.name());
            o.put("currentActor", s.currentActor == null ? JSONObject.NULL : s.currentActor.name());
            o.put("currentSent", s.currentSent == null ? "" : s.currentSent);
            o.put("stage", (s.stage == null ? Stage.READY_NEXT : s.stage).name());
            o.put("payloadBecameAttachment", s.payloadBecameAttachment);
            o.put("attachmentsDeliveredChatGpt", s.attachmentsDeliveredChatGpt);
            o.put("attachmentsDeliveredClaude", s.attachmentsDeliveredClaude);
            o.put("updatedAt", System.currentTimeMillis());
            o.put("lastError", s.lastError == null ? "" : s.lastError);
            o.put("baselineReply", s.baselineReply == null ? "" : s.baselineReply);
            o.put("baselineResponseActionCount", s.baselineResponseActionCount);
            o.put("promptPreexisted", s.promptPreexisted);
            o.put("sentAnchorConfirmed", s.sentAnchorConfirmed);
            o.put("sentStepConfirmed", s.sentStepConfirmed);
            o.put("preSendFingerprint", s.preSendFingerprint);
            o.put("responseStartedForThisStep", s.responseStartedForThisStep);
            o.put("sawGenerationForThisStep", s.sawGenerationForThisStep);
            o.put("sendVerifiedAt", s.sendVerifiedAt);
            o.put("responseStartedAt", s.responseStartedAt);
            prefs.edit().putString(KEY_ACTIVE_RUN, o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public synchronized Snapshot load() {
        String raw = prefs.getString(KEY_ACTIVE_RUN, "");
        if (raw == null || raw.trim().isEmpty()) return null;
        try {
            JSONObject o = new JSONObject(raw);
            Snapshot s = new Snapshot();
            s.plan = RelayPlan.fromJson(o.getJSONObject("plan"));
            s.stepIndex = o.optInt("stepIndex", 0);
            s.previousResponse = o.optString("previousResponse", "");
            s.autoActor = actorOrNull(o.optString("autoActor", ""));
            s.currentActor = actorOrNull(o.optString("currentActor", ""));
            s.currentSent = o.optString("currentSent", "");
            try {
                s.stage = Stage.valueOf(o.optString("stage", Stage.READY_NEXT.name()));
            } catch (Exception ignored) {
                s.stage = Stage.READY_NEXT;
            }
            s.payloadBecameAttachment = o.optBoolean("payloadBecameAttachment", false);
            s.attachmentsDeliveredChatGpt = o.optBoolean("attachmentsDeliveredChatGpt", false);
            s.attachmentsDeliveredClaude = o.optBoolean("attachmentsDeliveredClaude", false);
            s.updatedAt = o.optLong("updatedAt", 0L);
            s.lastError = o.optString("lastError", "");
            s.baselineReply = o.optString("baselineReply", "");
            s.baselineResponseActionCount = o.optInt("baselineResponseActionCount", 0);
            s.promptPreexisted = o.optBoolean("promptPreexisted", true);
            s.sentAnchorConfirmed = o.optBoolean("sentAnchorConfirmed", false);
            s.sentStepConfirmed = o.optBoolean("sentStepConfirmed", false);
            s.preSendFingerprint = o.optInt("preSendFingerprint", 0);
            s.responseStartedForThisStep = o.optBoolean("responseStartedForThisStep", false);
            s.sawGenerationForThisStep = o.optBoolean("sawGenerationForThisStep", false);
            s.sendVerifiedAt = o.optLong("sendVerifiedAt", 0L);
            s.responseStartedAt = o.optLong("responseStartedAt", 0L);
            return s.plan == null ? null : s;
        } catch (Exception ignored) {
            return null;
        }
    }

    public synchronized boolean hasRecoverable() {
        return load() != null;
    }

    public synchronized void clear() {
        prefs.edit().remove(KEY_ACTIVE_RUN).apply();
    }

    private RelayPlan.Actor actorOrNull(String raw) {
        if (raw == null || raw.isEmpty() || "null".equalsIgnoreCase(raw)) return null;
        try {
            return RelayPlan.Actor.valueOf(raw);
        } catch (Exception ignored) {
            return null;
        }
    }
}
