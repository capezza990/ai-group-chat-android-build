@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  AI GROUP CHAT - ANDROID APK BUILD
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build-apk.ps1"
echo.
pause
