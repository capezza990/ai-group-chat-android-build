@echo off
setlocal
cd /d "%~dp0"
set "ADB=%~dp0.toolchain\android-sdk\platform-tools\adb.exe"
set "APK=%~dp0AI_GROUP_CHAT_ANDROID_M1-debug.apk"

if not exist "%APK%" (
  echo APK not found. Run BUILD_APK.bat first.
  pause
  exit /b 1
)
if not exist "%ADB%" (
  echo Android platform-tools not found. Run BUILD_APK.bat first.
  pause
  exit /b 1
)

echo Connect the Android phone by USB and enable USB debugging.
echo Approve the RSA prompt on the phone if Android asks.
echo.
"%ADB%" devices
echo.
"%ADB%" install -r "%APK%"
echo.
if errorlevel 1 (
  echo Install failed. You can instead copy the APK to your phone and open it there.
) else (
  echo Installed successfully.
)
pause
