# Room Engine P1-A — Engine Lab test order

P1-A is a feasibility lab, not the redesigned room UI yet. The existing M11.7 Accessibility relay remains untouched as the fallback.

## Open the lab
1. Open AI Group Chat.
2. Open More options.
3. Tap **Engine Lab (P1-A, developer)**.

Both provider WebViews load immediately. The **Log** tab is shown by default.

## Test each provider separately
For ChatGPT, then Claude:
1. Tap the provider tab and sign in normally if needed.
2. Open an existing provider conversation manually.
3. Tap **Use this conversation**.
4. Tap **Health**. If the composer is not detected, use **Probe DOM** and stop there; do not run Send test.
5. Tap **Type check**. It must report the composer restored and must not send anything.
6. Tap **Send test**.
7. Tap **Long test**.
8. Tap **Identical x2**.

## Hidden-operation test
With a provider bound and its basic tests passing:
1. Leave **Tests run hidden: ON**.
2. Cycle **Hidden mode** through OBSCURED, OFFSCREEN, ALPHA0, and TINY.
3. Run **Send test** in each mode.
4. The provider should complete while the Log tab remains foreground. Record which modes pass.

## Round-trip test
After both ChatGPT and Claude are bound and pass basic tests:
1. Keep **Tests run hidden: ON**.
2. Tap **Round trip**.
3. P1-A should perform ChatGPT → Claude → ChatGPT while the Log tab remains visible.

## Important
- P1-A intentionally fails closed when selectors, conversation identity, or composer text cannot be proven.
- Do not paste a Probe DOM log publicly without reviewing it; provider button labels may contain conversation titles.
- The lab never logs cookie values, URL query strings, or assistant reply text. Conversation UUIDs are replaced with short fingerprints in the log.
- Google/passkey login may not work in embedded WebView. That is a feasibility result, not something P1-A attempts to bypass.

## Background visibility diagnostic

After a provider passes the normal Long test, start another Long test, leave AI Group Chat for about 30 seconds, then return before the 150-second turn timeout. Check the Engine Lab log for `vis`, push activity, generation state, and whether the turn completed. This does not enable background operation; it only records how Android/WebView behaves when the Activity window is no longer visible.
