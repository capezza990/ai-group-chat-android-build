# M11 validation checklist

1. Existing M9/M10 short and long text relay still works in both directions.
2. Claude large pasted-content TXT conversion still sends exactly once without duplicate attachments.
3. Keyboard opens with only the composer/attachment strip at the bottom; collaboration controls collapse.
4. Navigation buttons do not cover the composer or controls.
5. Draft text survives app switching.
6. Auto Collaborate preserves `[ORIGINAL USER REQUEST]`, follows routing markers, and stops on `[[DONE]]` / `[[NEXT:USER]]` / safety cap.
7. Interrupted relay exposes Resume/Retry in the overflow menu.
8. Select one image with `+`; verify the chip appears in AI Group Chat.
9. Start a collaboration with that image. M11 should share the original attachment to each participating provider once and should not send text without a verified attachment.
10. Diagnostics remain available from the overflow menu for provider UI mapping.

11. M11.3: after a provider reply is captured, verify it appears in the AI Group Chat transcript immediately without closing/reopening the app.
12. Clear the transcript while idle, then run a relay and verify cleared messages do not reappear.
13. Repeat the identical-response test and verify the repeated reply appears exactly once in the live transcript.


14. M11.4 long-Copy test: capture a long ChatGPT reply and verify the clipboard polling path completes without accepting partial text.
15. M11.4 recovery test: force a reply-copy failure after the provider has already answered; Resume must re-capture the existing reply and must not resend the prompt.
16. M11.7 binding setup: in More options choose **Set ChatGPT mapped thread title** and enter the exact unique history title for the intended existing ChatGPT conversation.
17. M11.7 blank-chat restoration: force ChatGPT to show `Ask ChatGPT`; verify the bridge opens Menu/history and clicks only the explicitly mapped title.
18. M11.7 no-probing safety: verify the bridge never opens any other recent conversation when the mapped title fails verification or is unavailable.
19. M11.7 duplicate-title safety: if the mapped title is visible more than once, verify the bridge pauses instead of choosing one.
20. M11.7 correct-thread preservation: begin with the intended conversation already open. Verify the bridge either uses strong current-turn evidence or re-selects only the exact mapped title; it must not cycle away through other chats.
21. M11.7 capture-stage recovery: force clipboard verification into the controlled re-copy path after a long ChatGPT reply. Verify the current reply anchor is still required before Copy and the prompt is never resent.
22. M11.7 manual recovery: manually open the intended ChatGPT thread before Resume. Verify Resume checks the current conversation first and does not relaunch unnecessarily.
23. Repeat equivalent fail-closed checks for Claude (`Reply to Claude` vs `Chat with Claude…`); automatic history restoration remains ChatGPT-specific until Claude navigation is mapped.
24. Only after M11.7 passes, resume the M12-P0 generated-artifact/share diagnostics.
