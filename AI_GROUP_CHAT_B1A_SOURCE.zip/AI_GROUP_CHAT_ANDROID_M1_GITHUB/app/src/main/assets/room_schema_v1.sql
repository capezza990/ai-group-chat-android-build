CREATE TABLE rooms (
  id TEXT PRIMARY KEY,
  routing_mode TEXT NOT NULL CHECK (routing_mode IN ('SINGLE','ASK_ALL','COLLABORATE','AUTO_PICK')),
  routing_arg TEXT NOT NULL DEFAULT '',
  rounds INTEGER NOT NULL DEFAULT 1 CHECK (rounds BETWEEN 1 AND 2),
  created_at INTEGER NOT NULL
)
-- @@
CREATE TABLE provider_bindings (
  provider_id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  restore_locator TEXT NOT NULL,
  display_title TEXT NOT NULL DEFAULT '',
  bound_at INTEGER NOT NULL
)
-- @@
CREATE TABLE participants (
  room_id TEXT NOT NULL REFERENCES rooms(id),
  provider_id TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0,1)),
  position INTEGER NOT NULL,
  context_seq INTEGER NOT NULL DEFAULT 0,
  mirror_state TEXT NOT NULL DEFAULT 'UNKNOWN',
  PRIMARY KEY (room_id, provider_id)
)
-- @@
CREATE TABLE messages (
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  id TEXT NOT NULL UNIQUE,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  author_type TEXT NOT NULL CHECK (author_type IN ('USER','PROVIDER','SYSTEM')),
  author_id TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  reply_to TEXT
)
-- @@
CREATE INDEX messages_room_seq ON messages(room_id, seq)
-- @@
CREATE TRIGGER messages_no_update BEFORE UPDATE ON messages
BEGIN SELECT RAISE(ABORT, 'messages are append-only'); END
-- @@
CREATE TRIGGER messages_no_delete BEFORE DELETE ON messages
BEGIN SELECT RAISE(ABORT, 'messages are append-only'); END
-- @@
CREATE TABLE deliveries (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  trigger_message_id TEXT NOT NULL REFERENCES messages(id),
  provider_id TEXT NOT NULL,
  upto_seq INTEGER NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('PENDING','SENDING','SENT','CAPTURED','FAILED','UNCERTAIN','CANCELLED')),
  provider_user_msg_id TEXT NOT NULL DEFAULT '',
  provider_asst_msg_id TEXT NOT NULL DEFAULT '',
  reply_message_id TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE (trigger_message_id, provider_id)
)
-- @@
CREATE INDEX deliveries_state ON deliveries(state)
