package com.aigroupchat.bridge;

import android.net.Uri;

import org.json.JSONException;
import org.json.JSONObject;

public final class AttachmentRecord {
    public final String uriString;
    public final String displayName;
    public final String mimeType;
    public final long sizeBytes;

    public AttachmentRecord(String uriString, String displayName, String mimeType, long sizeBytes) {
        this.uriString = uriString == null ? "" : uriString;
        this.displayName = displayName == null || displayName.trim().isEmpty() ? "Attachment" : displayName;
        this.mimeType = mimeType == null || mimeType.trim().isEmpty() ? "application/octet-stream" : mimeType;
        this.sizeBytes = Math.max(0L, sizeBytes);
    }

    public Uri uri() {
        return Uri.parse(uriString);
    }

    public boolean isImage() {
        return mimeType.startsWith("image/");
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("uri", uriString);
        o.put("name", displayName);
        o.put("mime", mimeType);
        o.put("size", sizeBytes);
        return o;
    }

    public static AttachmentRecord fromJson(JSONObject o) {
        if (o == null) return null;
        return new AttachmentRecord(
                o.optString("uri", ""),
                o.optString("name", "Attachment"),
                o.optString("mime", "application/octet-stream"),
                o.optLong("size", 0L));
    }
}
