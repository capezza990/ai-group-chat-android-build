package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ChatGptAdapter extends AppAdapter {
    @Override public String packageName() { return "com.openai.chatgpt"; }
    @Override public String displayName() { return "ChatGPT"; }
    @Override protected String[] sendWords() { return new String[]{"send", "send message", "submit", "send to chatgpt", "send to claude"}; }
    @Override protected String[] stopWords() { return new String[]{"stop", "stop generating"}; }
    @Override protected String[] newChatWords() { return new String[]{"new chat", "start new chat"}; }
    @Override protected String[] composerHints() { return new String[]{"Ask ChatGPT", "Reply to ChatGPT"}; }
    @Override protected String[] existingConversationComposerHints() { return new String[]{"Reply to ChatGPT"}; }
    @Override protected String[] blankConversationComposerHints() { return new String[]{"Ask ChatGPT"}; }
    @Override protected String[] attachmentLauncherWords() { return new String[]{"Attachment"}; }
    @Override protected String[] responseActionDescriptions() { return new String[]{"Copy"}; }
    @Override protected String[] ignoredReplyTexts() {
        return new String[]{"Ask ChatGPT", "Reply to ChatGPT", "Full Screen Input", "Attachment", "Dictation"};
    }

    /** M11.6: open ChatGPT's history drawer without ever touching New chat. */
    public boolean clickHistoryMenu(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo menu = NodeUtils.findLastByContentDescriptionExact(root, "Menu");
        return menu != null && NodeUtils.click(menu);
    }

    /** The September 2026 ChatGPT Android history drawer exposes Close + Explore. */
    public boolean historyDrawerVisible(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.findLastByContentDescriptionExact(root, "Close") != null
                && NodeUtils.treeHasExactText(root, "Explore");
    }

    /**
     * Return uniquely named visible recent-conversation rows from the open history drawer.
     * Navigation rows (Images/Library/Projects/Codex/Scheduled/Explore) sit above Explore;
     * actual conversation rows sit below it. Duplicate titles are deliberately omitted so the
     * bridge can never guess between two same-named threads.
     */
    public List<String> visibleUniqueRecentConversationTitles(AccessibilityService service) {
        List<String> raw = new ArrayList<>();
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return raw;

        AccessibilityNodeInfo explore = null;
        AccessibilityNodeInfo close = NodeUtils.findLastByContentDescriptionExact(root, "Close");
        for (AccessibilityNodeInfo node : NodeUtils.flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence t = node.getText();
            if (!TextUtils.isEmpty(t) && NodeUtils.normalize(t.toString()).equals("explore")) {
                explore = node;
                break;
            }
        }
        if (explore == null || close == null) return raw;

        Rect exploreBounds = new Rect();
        Rect closeBounds = new Rect();
        explore.getBoundsInScreen(exploreBounds);
        close.getBoundsInScreen(closeBounds);
        int drawerRight = closeBounds.left;
        int minTop = exploreBounds.bottom;

        for (AccessibilityNodeInfo node : NodeUtils.flatten(root)) {
            if (!node.isVisibleToUser() || node.isEditable()) continue;
            CharSequence t = node.getText();
            if (TextUtils.isEmpty(t)) continue;
            String title = t.toString().trim();
            if (title.isEmpty() || title.length() > 180) continue;
            Rect b = new Rect();
            node.getBoundsInScreen(b);
            if (b.top <= minTop || b.right > drawerRight || b.height() <= 0) continue;
            if (!hasClickableAncestor(node)) continue;
            raw.add(title);
            if (raw.size() >= 12) break;
        }

        Map<String, Integer> counts = new LinkedHashMap<>();
        for (String title : raw) counts.put(title, counts.getOrDefault(title, 0) + 1);
        List<String> unique = new ArrayList<>();
        for (String title : raw) {
            if (counts.get(title) == 1 && !unique.contains(title)) unique.add(title);
        }
        return unique;
    }

    public boolean clickUniqueHistoryConversationTitle(AccessibilityService service, String title) {
        if (title == null || title.trim().isEmpty()) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        AccessibilityNodeInfo explore = null;
        AccessibilityNodeInfo close = NodeUtils.findLastByContentDescriptionExact(root, "Close");
        for (AccessibilityNodeInfo node : NodeUtils.flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence t = node.getText();
            if (!TextUtils.isEmpty(t) && NodeUtils.normalize(t.toString()).equals("explore")) {
                explore = node;
                break;
            }
        }
        if (explore == null || close == null) return false;
        Rect exploreBounds = new Rect();
        Rect closeBounds = new Rect();
        explore.getBoundsInScreen(exploreBounds);
        close.getBoundsInScreen(closeBounds);

        AccessibilityNodeInfo match = null;
        int matches = 0;
        String want = NodeUtils.normalize(title);
        for (AccessibilityNodeInfo node : NodeUtils.flatten(root)) {
            if (!node.isVisibleToUser() || node.isEditable()) continue;
            CharSequence t = node.getText();
            if (TextUtils.isEmpty(t) || !NodeUtils.normalize(t.toString()).equals(want)) continue;
            Rect b = new Rect();
            node.getBoundsInScreen(b);
            if (b.top <= exploreBounds.bottom || b.right > closeBounds.left) continue;
            if (!hasClickableAncestor(node)) continue;
            match = node;
            matches++;
        }
        return matches == 1 && NodeUtils.click(match);
    }

    private boolean hasClickableAncestor(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i < 5 && current != null; i++) {
            if (current.isClickable()
                    || current.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)) {
                return true;
            }
            current = current.getParent();
        }
        return false;
    }

}
