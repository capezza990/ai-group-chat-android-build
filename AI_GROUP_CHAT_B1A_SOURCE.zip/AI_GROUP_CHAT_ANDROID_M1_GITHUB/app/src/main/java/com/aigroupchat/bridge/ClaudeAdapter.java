package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityNodeInfo;

public final class ClaudeAdapter extends AppAdapter {
    @Override public String packageName() { return "com.anthropic.claude"; }
    @Override public String displayName() { return "Claude"; }
    @Override protected String[] sendWords() { return new String[]{"send", "send message", "submit", "send to chatgpt", "send to claude"}; }
    @Override protected String[] stopWords() { return new String[]{"stop", "stop response"}; }
    @Override protected String[] newChatWords() { return new String[]{"new chat", "new conversation", "start new chat"}; }
    @Override protected String[] composerHints() { return new String[]{"Chat with Claude…", "Chat with Claude...", "Reply to Claude…", "Reply to Claude..."}; }
    @Override protected String[] existingConversationComposerHints() { return new String[]{"Reply to Claude…", "Reply to Claude..."}; }
    @Override protected String[] blankConversationComposerHints() { return new String[]{"Chat with Claude…", "Chat with Claude..."}; }
    @Override protected String[] attachmentLauncherWords() { return new String[]{"Add to chat"}; }
    @Override protected String[] responseActionDescriptions() { return new String[]{"Copy message"}; }
    @Override public boolean composerHasAutoPastedAttachment(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        return isActive(root) && NodeUtils.hasClaudePastedContentAttachmentInComposer(root);
    }
    @Override protected String[] ignoredReplyTexts() {
        return new String[]{"Chat with Claude…", "Chat with Claude...", "Reply to Claude…", "Reply to Claude...", "Claude is AI and can make mistakes."};
    }
}
