package com.aigroupchat.bridge;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ConversationStore {
    private static final String PREFS = "ai_group_chat_bridge";
    private static final String KEY_MESSAGES = "messages_json";
    private static final String KEY_DRAFT = "composer_draft";
    private static final String KEY_DRAFT_ATTACHMENTS = "composer_draft_attachments_v11";

    // The Activity and the Accessibility Service each construct their own ConversationStore in the
    // same process. SharedPreferences is the single source of truth: every read and every mutation
    // first re-syncs from it, and one static lock serializes all instances.
    private static final Object LOCK = new Object();

    private final SharedPreferences prefs;
    private final List<Message> messages = new ArrayList<>();
    private String loadedRaw;

    public ConversationStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (LOCK) { syncFromPrefs(); }
    }

    public void add(Message message) {
        synchronized (LOCK) {
            syncFromPrefs();
            messages.add(message);
            save();
        }
    }

    public void clear() {
        synchronized (LOCK) {
            messages.clear();
            save();
        }
    }

    public List<Message> all() {
        synchronized (LOCK) {
            syncFromPrefs();
            return Collections.unmodifiableList(new ArrayList<>(messages));
        }
    }

    public String getDraft() {
        return prefs.getString(KEY_DRAFT, "");
    }

    public void setDraft(String draft) {
        prefs.edit().putString(KEY_DRAFT, draft == null ? "" : draft).apply();
    }

    public void clearDraft() {
        prefs.edit().remove(KEY_DRAFT).apply();
    }

    public List<AttachmentRecord> getDraftAttachments() {
        List<AttachmentRecord> out = new ArrayList<>();
        String raw = prefs.getString(KEY_DRAFT_ATTACHMENTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                AttachmentRecord a = AttachmentRecord.fromJson(arr.optJSONObject(i));
                if (a != null && !a.uriString.isEmpty()) out.add(a);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    public void setDraftAttachments(List<AttachmentRecord> attachments) {
        JSONArray arr = new JSONArray();
        if (attachments != null) {
            for (AttachmentRecord a : attachments) {
                if (a == null) continue;
                try { arr.put(a.toJson()); } catch (Exception ignored) {}
            }
        }
        prefs.edit().putString(KEY_DRAFT_ATTACHMENTS, arr.toString()).apply();
    }

    public void clearDraftAttachments() {
        prefs.edit().remove(KEY_DRAFT_ATTACHMENTS).apply();
    }

    /** Rebuild the in-memory list only if the stored JSON differs from what we last loaded/saved.
     * Caller must hold LOCK. SharedPreferences.apply() updates its in-memory map synchronously,
     * so a same-process reader sees a writer's data immediately. */
    private void syncFromPrefs() {
        String raw = prefs.getString(KEY_MESSAGES, "[]");
        if (raw == null) raw = "[]";
        if (raw.equals(loadedRaw)) return;
        messages.clear();
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                messages.add(Message.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {
            messages.clear();
        }
        loadedRaw = raw;
    }

    private void save() {
        JSONArray arr = new JSONArray();
        for (Message message : messages) {
            try {
                arr.put(message.toJson());
            } catch (JSONException ignored) {
            }
        }
        String out = arr.toString();
        prefs.edit().putString(KEY_MESSAGES, out).apply();
        loadedRaw = out;
    }
}
