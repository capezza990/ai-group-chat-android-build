package com.aigroupchat.bridge;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.UUID;

public final class Message {
    public enum Participant { USER, CHATGPT, CLAUDE, SYSTEM }

    public final String id;
    public final long timestamp;
    public final Participant participant;
    public final String text;

    public Message(String id, long timestamp, Participant participant, String text) {
        this.id = id;
        this.timestamp = timestamp;
        this.participant = participant;
        this.text = text == null ? "" : text;
    }

    public static Message create(Participant participant, String text) {
        return new Message(UUID.randomUUID().toString(), System.currentTimeMillis(), participant, text);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("timestamp", timestamp);
        o.put("participant", participant.name());
        o.put("text", text);
        return o;
    }

    public static Message fromJson(JSONObject o) throws JSONException {
        return new Message(
                o.getString("id"),
                o.getLong("timestamp"),
                Participant.valueOf(o.getString("participant")),
                o.optString("text", "")
        );
    }
}
