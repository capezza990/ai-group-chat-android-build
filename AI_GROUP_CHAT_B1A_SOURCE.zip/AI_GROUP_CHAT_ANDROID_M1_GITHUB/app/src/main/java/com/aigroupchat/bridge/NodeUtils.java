package com.aigroupchat.bridge;

import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class NodeUtils {
    private NodeUtils() {}

    public static List<AccessibilityNodeInfo> flatten(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        if (root == null) return out;
        walk(root, out);
        return out;
    }

    private static void walk(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, out);
        }
    }

    public static List<AccessibilityNodeInfo> visibleEditables(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (node.isVisibleToUser() && node.isEditable()) out.add(node);
        }
        return out;
    }

    /** Strict variant used by the M11.5 conversation guard. Unlike findEditableNearHints(),
     * this never falls back to "the only editable on screen" when none of the hints match. */
    public static boolean hasEditableNearHintsStrict(AccessibilityNodeInfo root, String... hints) {
        if (root == null || hints == null || hints.length == 0) return false;
        for (AccessibilityNodeInfo editable : visibleEditables(root)) {
            if (nearbyContainsAny(editable, 4, hints)) return true;
        }
        return false;
    }

    /**
     * Compare the currently visible provider conversation with the last reply that the bridge
     * captured from that provider. We deliberately use a tail-token anchor rather than exact
     * full-response text because long native replies are virtualized and split across nodes.
     *
     * The last up to 12 distinct words (4+ chars) are used; at least 75% (minimum 4) must be
     * visible. For very short replies, normalized substring matching is used instead.
     */
    public static boolean visibleTextMatchesReplyAnchor(AccessibilityNodeInfo root, String expectedReply) {
        if (root == null || expectedReply == null || expectedReply.trim().isEmpty()) return false;

        StringBuilder visibleBuilder = new StringBuilder();
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser() || node.isEditable()) continue;
            String text = normalize(combinedText(node));
            if (text.isEmpty()) continue;
            if (visibleBuilder.length() > 0) visibleBuilder.append(' ');
            visibleBuilder.append(text);
        }
        String visible = normalize(visibleBuilder.toString());
        String expected = normalize(expectedReply);
        if (visible.isEmpty() || expected.isEmpty()) return false;

        if (expected.length() <= 120 && visible.contains(expected)) return true;

        java.util.LinkedHashSet<String> tail = new java.util.LinkedHashSet<>();
        String[] words = expected.split("[^\\p{L}\\p{N}]+");
        for (int i = words.length - 1; i >= 0 && tail.size() < 12; i--) {
            String w = words[i];
            if (w.length() < 4 || isAnchorStopWord(w)) continue;
            tail.add(w);
        }

        if (tail.size() < 4) return visible.contains(expected);

        java.util.HashSet<String> visibleWords = new java.util.HashSet<>();
        for (String w : visible.split("[^\\p{L}\\p{N}]+")) {
            if (w.length() >= 4) visibleWords.add(w);
        }

        int hits = 0;
        for (String w : tail) if (visibleWords.contains(w)) hits++;
        int required = Math.max(4, (int) Math.ceil(tail.size() * 0.75));
        return hits >= required;
    }

    private static boolean isAnchorStopWord(String w) {
        String n = w.toLowerCase(Locale.US);
        return n.equals("this") || n.equals("that") || n.equals("with") || n.equals("from")
                || n.equals("have") || n.equals("your") || n.equals("will") || n.equals("what")
                || n.equals("when") || n.equals("then") || n.equals("they") || n.equals("them")
                || n.equals("into") || n.equals("only") || n.equals("also") || n.equals("should")
                || n.equals("would") || n.equals("could") || n.equals("there") || n.equals("their")
                || n.equals("about") || n.equals("after") || n.equals("before") || n.equals("because")
                || n.equals("done") || n.equals("next") || n.equals("user") || n.equals("chatgpt")
                || n.equals("claude");
    }

    public static AccessibilityNodeInfo findEditableNearHints(AccessibilityNodeInfo root, String... hints) {
        List<AccessibilityNodeInfo> editables = visibleEditables(root);
        if (editables.isEmpty()) return null;

        for (AccessibilityNodeInfo editable : editables) {
            if (nearbyContainsAny(editable, 4, hints)) return editable;
        }
        return editables.size() == 1 ? editables.get(0) : null;
    }

    public static boolean nearbyContainsAny(AccessibilityNodeInfo node, int maxParents, String... words) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i <= maxParents && current != null; i++) {
            if (subtreeContainsAny(current, words)) return true;
            current = current.getParent();
        }
        return false;
    }

    public static boolean subtreeContainsAny(AccessibilityNodeInfo root, String... words) {
        if (root == null) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            String t = normalize(combinedText(node));
            if (t.isEmpty()) continue;
            for (String word : words) {
                String w = normalize(word);
                if (!w.isEmpty() && (t.equals(w) || t.contains(w))) return true;
            }
        }
        return false;
    }

    public static AccessibilityNodeInfo findLastClickableByExactWords(AccessibilityNodeInfo root, String... words) {
        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = normalize(combinedText(node));
            if (hay.isEmpty()) continue;
            for (String word : words) {
                String w = normalize(word);
                if (w.isEmpty()) continue;
                boolean labelMatch = hay.equals(w) || hay.startsWith(w + " ");
                if (labelMatch && (node.isClickable() || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))) {
                    found = node;
                }
            }
        }
        return found;
    }

    public static AccessibilityNodeInfo findLastNodeByExactOrPrefixWords(AccessibilityNodeInfo root, String... words) {
        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = normalize(combinedText(node));
            if (hay.isEmpty()) continue;
            for (String word : words) {
                String w = normalize(word);
                if (w.isEmpty()) continue;
                if (hay.equals(w) || hay.startsWith(w + " ")) found = node;
            }
        }
        return found;
    }

    public static AccessibilityNodeInfo findLastByContentDescriptionExact(AccessibilityNodeInfo root, String... descriptions) {
        AccessibilityNodeInfo found = null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence desc = node.getContentDescription();
            if (TextUtils.isEmpty(desc)) continue;
            String d = normalize(desc.toString());
            for (String wanted : descriptions) {
                if (d.equals(normalize(wanted))) found = node;
            }
        }
        return found;
    }

    public static AccessibilityNodeInfo findClickableByWords(AccessibilityNodeInfo root, String... words) {
        if (root == null) return null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = combinedText(node).toLowerCase(Locale.US);
            if (hay.isEmpty()) continue;
            for (String word : words) {
                if (hay.contains(word.toLowerCase(Locale.US)) && (node.isClickable() || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))) {
                    return node;
                }
            }
        }
        return null;
    }

    public static AccessibilityNodeInfo findAnyByWords(AccessibilityNodeInfo root, String... words) {
        if (root == null) return null;
        for (AccessibilityNodeInfo node : flatten(root)) {
            String hay = combinedText(node).toLowerCase(Locale.US);
            for (String word : words) {
                if (!word.isEmpty() && hay.contains(word.toLowerCase(Locale.US))) return node;
            }
        }
        return null;
    }




    public static boolean treeContainsVisibleText(AccessibilityNodeInfo root, String expected) {
        if (root == null || expected == null || expected.trim().isEmpty()) return false;
        String needle = normalize(expected);
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = normalize(combinedText(node));
            if (!hay.isEmpty() && hay.contains(needle)) return true;
        }
        return false;
    }

    public static boolean treeContainsAnyVisibleWords(AccessibilityNodeInfo root, String... expected) {
        if (root == null || expected == null) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String hay = normalize(combinedText(node));
            if (hay.isEmpty()) continue;
            for (String e : expected) {
                String needle = normalize(e);
                if (!needle.isEmpty() && hay.contains(needle)) return true;
            }
        }
        return false;
    }



    public static int countVisibleContentDescriptionExact(AccessibilityNodeInfo root, String... descriptions) {
        if (root == null || descriptions == null) return 0;
        int count = 0;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence desc = node.getContentDescription();
            if (TextUtils.isEmpty(desc)) continue;
            String d = normalize(desc.toString());
            for (String wanted : descriptions) {
                if (d.equals(normalize(wanted))) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    public static int countVisibleAttachmentRemovalControls(AccessibilityNodeInfo root) {
        if (root == null) return 0;
        int count = 0;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            String text = normalize(String.valueOf(node.getText()));
            String desc = normalize(String.valueOf(node.getContentDescription()));
            boolean removal = text.equals("remove")
                    || desc.equals("remove")
                    || desc.contains("remove attachment")
                    || desc.contains("remove image")
                    || desc.contains("remove file");
            if (removal) count++;
        }
        return count;
    }

    /**
     * Claude turns sufficiently large pasted text into a native TXT attachment labelled
     * "Pasted content". While that attachment is still in the composer it also exposes
     * a nearby Remove control. Detecting this state lets the relay treat the first paste
     * as successful instead of pasting the same payload repeatedly.
     */
    public static boolean hasClaudePastedContentAttachmentInComposer(AccessibilityNodeInfo root) {
        if (root == null) return false;
        boolean hasPastedContent = false;
        boolean hasTxt = false;
        boolean hasRemove = false;
        boolean hasEditableComposer = false;

        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            if (node.isEditable()) hasEditableComposer = true;

            String text = normalize(String.valueOf(node.getText()));
            String desc = normalize(String.valueOf(node.getContentDescription()));
            if (text.equals("pasted content")) hasPastedContent = true;
            if (text.equals("txt")) hasTxt = true;
            if (text.equals("remove") || desc.equals("remove")) hasRemove = true;
        }

        return hasEditableComposer && hasPastedContent && hasTxt && hasRemove;
    }


    /**
     * Scroll the largest visible vertical/scrollable container toward newer content.
     * ChatGPT and Claude use virtualized Compose lists, so old/new response nodes are
     * not guaranteed to exist in the Accessibility tree until the list is scrolled.
     *
     * We prefer the biggest scroll-capable node on screen to avoid accidentally
     * scrolling a small nested control. At the bottom performAction simply returns
     * false, which is harmless and lets the caller know there was nowhere else to go.
     */
    /** M11.2: cheap fingerprint of visible non-editable text + vertical positions. */
    public static int visibleTextFingerprint(AccessibilityNodeInfo root) {
        if (root == null) return 0;
        int h = 17;
        Rect b = new Rect();
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (node == null || !node.isVisibleToUser() || node.isEditable()) continue;
            CharSequence t = node.getText();
            if (TextUtils.isEmpty(t)) continue;
            node.getBoundsInScreen(b);
            h = 31 * h + t.toString().hashCode();
            h = 31 * h + b.top;
        }
        return h;
    }

    /** Convenience wrapper: true only if a forward scroll was actually performed. */
    public static boolean scrollLargestContainerForward(AccessibilityNodeInfo root) {
        return scrollLargestContainerForwardResult(root) == 1;
    }

    /** M11.2: -1 = no scrollable container found, 0 = refused, 1 = performed. */
    public static int scrollLargestContainerForwardResult(AccessibilityNodeInfo root) {
        if (root == null) return -1;

        AccessibilityNodeInfo best = null;
        long bestArea = -1L;
        int bestDepth = -1;

        for (AccessibilityNodeInfo node : flatten(root)) {
            if (node == null || !node.isVisibleToUser() || node.isEditable()) continue;
            if (!supportsForwardScroll(node)) continue;

            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            long area = Math.max(0, bounds.width()) * (long) Math.max(0, bounds.height());
            int depth = depth(node);

            if (area > bestArea || (area == bestArea && depth > bestDepth)) {
                best = node;
                bestArea = area;
                bestDepth = depth;
            }
        }

        if (best == null) return -1;
        if (best.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return 1;
        return best.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId()) ? 1 : 0;
    }

    private static boolean supportsForwardScroll(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isScrollable()) return true;
        int actions = node.getActions();
        if ((actions & AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) != 0) return true;
        int downId = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId();
        for (AccessibilityNodeInfo.AccessibilityAction action : node.getActionList()) {
            if (action != null && action.getId() == downId) return true;
        }
        return false;
    }

    private static int depth(AccessibilityNodeInfo node) {
        int depth = 0;
        AccessibilityNodeInfo current = node;
        while (current != null && depth < 64) {
            depth++;
            current = current.getParent();
        }
        return depth;
    }

    public static boolean setText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    public static boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i < 5 && current != null; i++) {
            if ((current.isClickable() || current.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))
                    && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            current = current.getParent();
        }
        return node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    public static boolean textEquals(AccessibilityNodeInfo node, String expected) {
        return node != null && normalize(String.valueOf(node.getText())).equals(normalize(expected));
    }

    public static boolean treeHasExactText(AccessibilityNodeInfo root, String expected) {
        String want = normalize(expected);
        if (want.isEmpty()) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence t = node.getText();
            if (!TextUtils.isEmpty(t) && normalize(t.toString()).equals(want)) return true;
        }
        return false;
    }

    public static boolean treeHasExactNonEditableText(AccessibilityNodeInfo root, String expected) {
        String want = normalize(expected);
        if (want.isEmpty()) return false;
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser() || node.isEditable()) continue;
            CharSequence t = node.getText();
            if (!TextUtils.isEmpty(t) && normalize(t.toString()).equals(want)) return true;
        }
        return false;
    }

    public static String extractLatestResponseAnchored(
            AccessibilityNodeInfo root,
            String sentText,
            String[] responseActionDescriptions,
            String[] ignoredTextExact) {
        if (root == null) return "";

        List<AccessibilityNodeInfo> all = flatten(root);
        String sentNorm = normalize(sentText);
        int sentIndex = -1;

        // When looking for a reply to a specific message, the anchor must be the REAL
        // non-editable user bubble. Never treat text inside the composer as a sent message.
        if (!sentNorm.isEmpty()) {
            for (int i = 0; i < all.size(); i++) {
                AccessibilityNodeInfo node = all.get(i);
                if (!node.isVisibleToUser() || node.isEditable()) continue;
                CharSequence t = node.getText();
                if (!TextUtils.isEmpty(t) && normalize(t.toString()).equals(sentNorm)) sentIndex = i;
            }
            // M11.2 STRICT RULE: for a known current prompt, if that prompt bubble is not
            // visible we do not have enough evidence to pick a reply. Never fall back to an
            // arbitrary visible (possibly ancient) assistant message.
            if (sentIndex < 0) return "";
        }

        // M4/M5 primary path: once the exact non-editable user bubble is present, read the
        // response directly from subsequent visible TextViews until the composer begins.
        // This does NOT depend on a Copy/Copy message action row appearing, which proved
        // too brittle on the live ChatGPT app even though the reply itself was visible.
        if (sentIndex >= 0) {
            List<String> streamed = new ArrayList<>();
            for (int i = sentIndex + 1; i < all.size(); i++) {
                AccessibilityNodeInfo node = all.get(i);
                if (!node.isVisibleToUser()) continue;

                // The first editable after the sent bubble is the reply composer. Anything
                // after it is composer chrome/model controls, not the assistant response.
                if (node.isEditable()) break;

                CharSequence raw = node.getText();
                if (TextUtils.isEmpty(raw)) continue;
                CharSequence cls = node.getClassName();
                if (cls == null || !"android.widget.TextView".contentEquals(cls)) continue;

                String text = raw.toString().trim();
                String n = normalize(text);
                if (n.isEmpty() || n.equals(sentNorm)) continue;
                if (isIgnoredExact(n, ignoredTextExact) || isCommonUiText(n)) continue;

                // Ignore labels belonging to clickable controls. Real message text in the
                // mapped ChatGPT/Claude trees is a non-clickable TextView.
                AccessibilityNodeInfo parent = node.getParent();
                if (node.isClickable() || (parent != null && parent.isClickable())) continue;

                if (streamed.isEmpty() || !normalize(streamed.get(streamed.size() - 1)).equals(n)) {
                    streamed.add(text);
                }
            }
            if (!streamed.isEmpty()) return joinDistinct(streamed);
            return "";
        }

        // Baseline snapshots (sentText empty) can still use the provider-specific response
        // action row to identify the most recent existing response before a new send.
        AccessibilityNodeInfo anchor = null;
        int anchorIndex = -1;
        for (int i = 0; i < all.size(); i++) {
            AccessibilityNodeInfo node = all.get(i);
            if (!node.isVisibleToUser()) continue;
            CharSequence desc = node.getContentDescription();
            if (TextUtils.isEmpty(desc)) continue;
            String d = normalize(desc.toString());
            for (String action : responseActionDescriptions) {
                if (d.equals(normalize(action))) {
                    anchor = node;
                    anchorIndex = i;
                }
            }
        }

        if (anchor == null || anchorIndex < 0) return "";

        AccessibilityNodeInfo current = anchor;
        for (int up = 0; up < 10 && current != null; up++) {
            List<String> texts = collectMeaningfulText(current, sentNorm, ignoredTextExact);
            if (!texts.isEmpty()) return joinDistinct(texts);
            current = current.getParent();
        }
        return "";
    }

    private static List<String> collectMeaningfulText(AccessibilityNodeInfo root, String sentNorm, String[] ignoredTextExact) {
        List<String> out = new ArrayList<>();
        for (AccessibilityNodeInfo node : flatten(root)) {
            if (!node.isVisibleToUser()) continue;
            CharSequence raw = node.getText();
            if (TextUtils.isEmpty(raw)) continue;
            String text = raw.toString().trim();
            String n = normalize(text);
            if (n.isEmpty() || n.equals(sentNorm)) continue;
            if (isIgnoredExact(n, ignoredTextExact) || isCommonUiText(n)) continue;
            if (node.isEditable()) continue;
            if (out.isEmpty() || !normalize(out.get(out.size() - 1)).equals(n)) out.add(text);
        }
        return out;
    }

    private static boolean isIgnoredExact(String normalized, String[] ignored) {
        if (ignored == null) return false;
        for (String s : ignored) if (normalized.equals(normalize(s))) return true;
        return false;
    }

    private static boolean isCommonUiText(String n) {
        String[] exact = {
                "copy", "copy message", "share", "good response", "bad response", "read aloud", "narrate",
                "retry message", "more actions", "open menu", "new chat", "edit menu", "menu",
                "add to chat", "start speech input", "voice mode", "attachment", "dictation",
                "ask chatgpt", "reply to chatgpt", "chat with claude…", "reply to claude…",
                "claude is ai and can make mistakes."
        };
        for (String s : exact) if (n.equals(normalize(s))) return true;
        return false;
    }

    private static String joinDistinct(List<String> texts) {
        StringBuilder sb = new StringBuilder();
        String last = "";
        for (String text : texts) {
            String n = normalize(text);
            if (n.isEmpty() || n.equals(last)) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(text.trim());
            last = n;
        }
        return sb.toString().trim();
    }

    public static String text(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        if (!TextUtils.isEmpty(text)) return text.toString();
        CharSequence desc = node.getContentDescription();
        return TextUtils.isEmpty(desc) ? "" : desc.toString();
    }

    public static String combinedText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(node.getText())) sb.append(node.getText()).append(' ');
        if (!TextUtils.isEmpty(node.getContentDescription())) sb.append(node.getContentDescription());
        return sb.toString().trim();
    }

    public static String normalize(String s) {
        return s == null ? "" : s.replaceAll("\\s+", " ").trim().toLowerCase(Locale.US);
    }

    public static String dumpTree(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        dump(root, sb, 0);
        return sb.toString();
    }

    private static void dump(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(node.getClassName())
                .append(" text=").append(String.valueOf(node.getText()))
                .append(" desc=").append(String.valueOf(node.getContentDescription()))
                .append(" id=").append(String.valueOf(node.getViewIdResourceName()))
                .append(" editable=").append(node.isEditable())
                .append(" clickable=").append(node.isClickable())
                .append(" visible=").append(node.isVisibleToUser())
                .append(" bounds=").append(bounds.toShortString())
                .append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) dump(child, sb, depth + 1);
        }
    }
}
