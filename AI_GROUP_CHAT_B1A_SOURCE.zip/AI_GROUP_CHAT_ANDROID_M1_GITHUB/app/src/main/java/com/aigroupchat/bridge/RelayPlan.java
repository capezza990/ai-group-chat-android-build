package com.aigroupchat.bridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class RelayPlan {
    public enum Mode { CHATGPT_ONLY, CLAUDE_ONLY, BOTH, COLLABORATE, AUTO_COLLABORATE }
    public enum Actor { CHATGPT, CLAUDE }

    public static final class Step {
        public final Actor actor;
        public final boolean relayPrevious;
        public final boolean includeOriginalUser;
        public final String label;

        Step(Actor actor, boolean relayPrevious, boolean includeOriginalUser, String label) {
            this.actor = actor;
            this.relayPrevious = relayPrevious;
            this.includeOriginalUser = includeOriginalUser;
            this.label = label;
        }
    }

    public final String userText;
    public final Mode mode;
    public final Actor firstActor;
    public final int rounds;
    public final int maxTurns;
    public final List<Step> steps;
    public final List<AttachmentRecord> attachments;

    private RelayPlan(String userText, Mode mode, Actor firstActor, int rounds, int maxTurns,
                      List<Step> steps, List<AttachmentRecord> attachments) {
        this.userText = userText == null ? "" : userText;
        this.mode = mode;
        this.firstActor = firstActor;
        this.rounds = rounds;
        this.maxTurns = maxTurns;
        this.steps = Collections.unmodifiableList(new ArrayList<>(steps));
        this.attachments = Collections.unmodifiableList(new ArrayList<>(attachments == null
                ? Collections.emptyList() : attachments));
    }

    public static RelayPlan build(String userText, Mode mode, Actor firstActor, int rounds) {
        return build(userText, mode, firstActor, rounds, Collections.emptyList());
    }

    public static RelayPlan build(String userText, Mode mode, Actor firstActor, int rounds,
                                  List<AttachmentRecord> attachments) {
        int safeRounds = Math.max(1, Math.min(2, rounds));
        List<Step> steps = new ArrayList<>();

        switch (mode) {
            case CHATGPT_ONLY:
                steps.add(new Step(Actor.CHATGPT, false, true, "ChatGPT answering"));
                break;
            case CLAUDE_ONLY:
                steps.add(new Step(Actor.CLAUDE, false, true, "Claude answering"));
                break;
            case BOTH:
                steps.add(new Step(Actor.CHATGPT, false, true, "ChatGPT answering independently"));
                steps.add(new Step(Actor.CLAUDE, false, true, "Claude answering independently"));
                break;
            case COLLABORATE:
                Actor second = firstActor == Actor.CHATGPT ? Actor.CLAUDE : Actor.CHATGPT;
                steps.add(new Step(firstActor, false, true, display(firstActor) + " proposing"));
                steps.add(new Step(second, true, true, display(second) + " reviewing"));
                steps.add(new Step(firstActor, true, true, display(firstActor) + " revising"));
                if (safeRounds == 2) {
                    steps.add(new Step(second, true, true, display(second) + " reviewing round 2"));
                    steps.add(new Step(firstActor, true, true, display(firstActor) + " revising round 2"));
                }
                break;
            case AUTO_COLLABORATE:
                return buildAuto(userText, firstActor, 10, attachments);
        }
        return new RelayPlan(userText, mode, firstActor, safeRounds, 0, steps, attachments);
    }

    public static RelayPlan buildAuto(String userText, Actor firstActor, int maxTurns) {
        return buildAuto(userText, firstActor, maxTurns, Collections.emptyList());
    }

    public static RelayPlan buildAuto(String userText, Actor firstActor, int maxTurns,
                                      List<AttachmentRecord> attachments) {
        int safeMaxTurns = Math.max(3, Math.min(20, maxTurns));
        return new RelayPlan(
                userText,
                Mode.AUTO_COLLABORATE,
                firstActor,
                0,
                safeMaxTurns,
                new ArrayList<>(),
                attachments);
    }

    public boolean isAutoCollaborate() {
        return mode == Mode.AUTO_COLLABORATE;
    }

    public boolean hasAttachments() {
        return !attachments.isEmpty();
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("userText", userText);
            o.put("mode", mode.name());
            o.put("firstActor", firstActor.name());
            o.put("rounds", rounds);
            o.put("maxTurns", maxTurns);
            JSONArray arr = new JSONArray();
            for (AttachmentRecord attachment : attachments) arr.put(attachment.toJson());
            o.put("attachments", arr);
        } catch (Exception ignored) {
        }
        return o;
    }

    public static RelayPlan fromJson(JSONObject o) {
        if (o == null) return null;
        try {
            String userText = o.optString("userText", "");
            Mode mode = Mode.valueOf(o.optString("mode", Mode.CHATGPT_ONLY.name()));
            Actor firstActor = Actor.valueOf(o.optString("firstActor", Actor.CHATGPT.name()));
            List<AttachmentRecord> attachments = new ArrayList<>();
            JSONArray arr = o.optJSONArray("attachments");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    AttachmentRecord a = AttachmentRecord.fromJson(arr.optJSONObject(i));
                    if (a != null && !a.uriString.isEmpty()) attachments.add(a);
                }
            }
            if (mode == Mode.AUTO_COLLABORATE) {
                return buildAuto(userText, firstActor, o.optInt("maxTurns", 10), attachments);
            }
            return build(userText, mode, firstActor, o.optInt("rounds", 1), attachments);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String display(Actor actor) {
        return actor == Actor.CHATGPT ? "ChatGPT" : "Claude";
    }
}
