package com.aigroupchat.bridge.engine;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.Random;

/**
 * P1-A "Engine Lab": developer-only screen hosting ChatGPT and Claude web surfaces simultaneously.
 * It tests login persistence, conversation binding, sending, structural reply identity, and attached-but-hidden
 * operation. It is intentionally NOT the final room UI.
 */
public class EngineLabActivity extends Activity {
    private static final String[] MODE_NAMES = {"OBSCURED", "OFFSCREEN", "ALPHA0", "TINY"};

    private WebProviderSurface chatgpt;
    private WebProviderSurface claude;
    private FrameLayout stage;
    private ScrollView logScroll;
    private TextView logView;
    private Button modeBtn;
    private Button hiddenRunBtn;
    private int tab = 2;          // 0 ChatGPT, 1 Claude, 2 Log
    private int selected = 0;     // which provider tool buttons act on
    private int hideMode = 0;
    private boolean hiddenRuns = true;
    private boolean busy;
    private boolean refreshPending;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF111418);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });

        TextView title = new TextView(this);
        title.setText("Engine Lab (P1-A) - developer only");
        title.setTextColor(0xFFE8EAED);
        title.setTextSize(15f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(24, 12, 24, 4);
        root.addView(title);

        LinearLayout tabs = new LinearLayout(this);
        tabs.addView(button("ChatGPT", v -> { selected = 0; showTab(0); }), weight());
        tabs.addView(button("Claude", v -> { selected = 1; showTab(1); }), weight());
        tabs.addView(button("Log", v -> showTab(2)), weight());
        root.addView(tabs);

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        LinearLayout tools = new LinearLayout(this);
        scroller.addView(tools);
        tools.addView(button("Load", v -> selectedSurface().load()));
        tools.addView(button("Session?", v -> logSession()));
        tools.addView(button("Use this conversation", v -> bind()));
        tools.addView(button("Return to bound", v -> guard()));
        tools.addView(button("Health", v -> health()));
        tools.addView(button("Probe DOM", v -> probe()));
        tools.addView(button("Type check", v -> typeCheck()));
        tools.addView(button("Send test", v -> sendTest(false)));
        tools.addView(button("Long test", v -> sendTest(true)));
        tools.addView(button("Identical x2", v -> identicalTwice()));
        tools.addView(button("Round trip", v -> roundTrip()));
        modeBtn = button("", v -> { hideMode = (hideMode + 1) % MODE_NAMES.length; applyLayout(); });
        tools.addView(modeBtn);
        hiddenRunBtn = button("", v -> { hiddenRuns = !hiddenRuns; applyLayout(); });
        tools.addView(hiddenRunBtn);
        tools.addView(button("Copy log", v -> copyLog()));
        tools.addView(button("Clear log", v -> EngineLog.clear()));
        root.addView(scroller);

        stage = new FrameLayout(this);
        chatgpt = new WebProviderSurface(this, ProviderSpec.CHATGPT);
        claude = new WebProviderSurface(this, ProviderSpec.CLAUDE);
        stage.addView(chatgpt.view(), full());
        stage.addView(claude.view(), full());

        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(10f);
        logView.setTextColor(0xFFC8CDD3);
        logView.setPadding(16, 12, 16, 12);
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.setBackgroundColor(0xFF0B0D10); // opaque cover for OBSCURED mode
        logScroll.addView(logView);
        stage.addView(logScroll, full());

        root.addView(stage, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        EngineLog.setListener(this::scheduleLogRefresh);
        EngineLog.add("lab", "Engine Lab started. Android SDK " + Build.VERSION.SDK_INT + ", " + Build.MANUFACTURER);
        chatgpt.load();
        claude.load();
        applyLayout();
        scheduleLogRefresh();
    }

    // ------------------------------------------------------------------ layout / modes

    private void showTab(int t) {
        tab = t;
        applyLayout();
    }

    private void applyLayout() {
        WebProviderSurface[] all = {chatgpt, claude};
        for (int i = 0; i < 2; i++) {
            View v = all[i].view();
            boolean shown = tab == i;
            FrameLayout.LayoutParams lp = full();
            v.setAlpha(1f);
            v.setTranslationX(0f);
            if (!shown) {
                switch (hideMode) {
                    case 1: v.setTranslationX(-4000f); break;       // OFFSCREEN: full size, moved away
                    case 2: v.setAlpha(0f); break;                  // ALPHA0: full size, transparent
                    case 3: lp = new FrameLayout.LayoutParams(1, 1); break; // TINY: attached 1x1 px
                    default: break;                                 // OBSCURED: full size, covered
                }
            }
            v.setLayoutParams(lp);
        }

        logScroll.setVisibility(tab == 2 ? View.VISIBLE : View.GONE);
        if (tab == 0) stage.bringChildToFront(chatgpt.view());
        else if (tab == 1) stage.bringChildToFront(claude.view());
        else stage.bringChildToFront(logScroll);

        modeBtn.setText("Hidden mode: " + MODE_NAMES[hideMode]);
        hiddenRunBtn.setText("Tests run hidden: " + (hiddenRuns ? "ON" : "OFF"));
        EngineLog.add("lab", "layout tab=" + tab + " hideMode=" + MODE_NAMES[hideMode]);
    }

    private WebProviderSurface selectedSurface() { return selected == 0 ? chatgpt : claude; }

    private void prepareRun() { if (hiddenRuns) showTab(2); }

    // ------------------------------------------------------------------ tools

    private void logSession() {
        EngineLog.add("lab", "session cookie present: chatgpt=" + chatgpt.sessionCookiePresent()
                + " claude=" + claude.sessionCookiePresent() + " (presence only; values never logged)");
    }

    private void bind() {
        ProviderBinding b = selectedSurface().bindCurrentConversation();
        toast(b == null ? "Open a conversation first, then press this." : "Bound: " + b.displayTitle);
    }

    private void guard() {
        WebProviderSurface s = selectedSurface();
        s.restoreBound(ok -> EngineLog.add("lab", "thread guard " + s.spec.id + ": "
                + (ok ? "SETTLED on bound conversation" : "NOT settled (or no binding)")));
    }

    private void health() {
        WebProviderSurface s = selectedSurface();
        s.health(h -> EngineLog.add(s.spec.id, "HEALTH " + h));
    }

    private void typeCheck() {
        WebProviderSurface s = selectedSurface();
        s.typeCheck(h -> EngineLog.add(s.spec.id, "TYPECHECK "
                + (h == null ? "null" : h.optString("typeCheck") + " composer=" + h.optBoolean("composer"))));
    }

    /** DOM inventory for correcting candidate selectors from evidence instead of guesses. */
    private void probe() {
        WebProviderSurface s = selectedSurface();
        s.probe(o -> {
            if (o == null) { EngineLog.add(s.spec.id, "PROBE null"); return; }
            EngineLog.add(s.spec.id, "PROBE (button labels can include conversation titles: review before sharing)");
            EngineLog.add(s.spec.id, "PROBE counts " + o.optJSONObject("counts"));
            logArray(s, "editable", o.optJSONArray("editables"));
            logArray(s, "button", o.optJSONArray("buttons"));
        });
    }

    private void logArray(WebProviderSurface s, String label, JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) EngineLog.add(s.spec.id, "PROBE " + label + ": " + a.optString(i));
    }

    private String token(WebProviderSurface s) {
        return "P1A_" + s.spec.id.toUpperCase() + "_" + (1000 + random.nextInt(9000));
    }

    private void sendTest(boolean lng) {
        if (busy) { toast("A test is already running."); return; }
        prepareRun();
        WebProviderSurface s = selectedSurface();
        String t = token(s);
        String prompt = lng
                ? "Write four short paragraphs about lighthouses. End your reply with the exact token " + t + "."
                : "P1A test " + t + ". Reply with the single word OK followed by the token.";
        runTurn(s, prompt, t, null);
    }

    /** The second identical response must be a distinct proven turn and have the same captured reply hash. */
    private void identicalTwice() {
        if (busy) { toast("A test is already running."); return; }
        prepareRun();
        WebProviderSurface s = selectedSurface();
        String prompt = "Reply with exactly the single word: OK";
        busy = true;
        EngineLog.add("lab", "IDENTICAL x2 start " + s.spec.id);
        s.runTurn(prompt, null, 150000L, first -> {
            if (!first.ok) {
                busy = false;
                EngineLog.add("lab", "IDENTICAL-REPLY FAIL first turn: " + first.summary);
                return;
            }
            s.runTurn(prompt, null, 150000L, second -> {
                busy = false;
                boolean secondIsNew = second.ok && second.identityProven
                        && second.newUserBubbles > 0 && second.newAssistantNodes > 0;
                boolean sameHash = secondIsNew && !first.replyHash.isEmpty()
                        && first.replyHash.equals(second.replyHash);
                EngineLog.add("lab", (secondIsNew && sameHash ? "IDENTICAL-REPLY PASS" : "IDENTICAL-REPLY FAIL")
                        + " provider=" + s.spec.id
                        + " firstHash=" + first.replyHash + " secondHash=" + second.replyHash
                        + " secondNewU=" + second.newUserBubbles + " secondNewA=" + second.newAssistantNodes
                        + " secondIdentity=" + second.identityProven);
            });
        });
    }

    /** ChatGPT -> Claude -> ChatGPT while the log/room stand-in remains foreground when hiddenRuns is ON. */
    private void roundTrip() {
        if (busy) { toast("A test is already running."); return; }
        if (chatgpt.binding() == null || claude.binding() == null) {
            toast("Bind BOTH conversations first.");
            return;
        }
        prepareRun();
        String t1 = "P1A_RT1_" + (1000 + random.nextInt(9000));
        String t2 = "P1A_RT2_" + (1000 + random.nextInt(9000));
        String t3 = "P1A_RT3_" + (1000 + random.nextInt(9000));
        runTurn(chatgpt,
                "Round trip step 1. Reply with one short sentence that contains the token " + t1 + ".",
                t1,
                a -> runTurn(claude,
                        "Round trip step 2. Another AI said: \"" + oneLine(a) + "\" Reply with one short sentence containing the token " + t2 + ".",
                        t2,
                        b -> runTurn(chatgpt,
                                "Round trip step 3. Another AI said: \"" + oneLine(b) + "\" Reply with one short sentence containing the token " + t3 + ".",
                                t3,
                                null)));
    }

    private interface Next { void run(String reply); }

    private void runTurn(WebProviderSurface s, String prompt, String token, Next next) {
        busy = true;
        EngineLog.add("lab", "TURN start " + s.spec.id + (token == null ? "" : " token=" + token));
        s.runTurn(prompt, token, 150000L, r -> {
            busy = false;
            EngineLog.add("lab", (r.ok ? "TURN PASS " : "TURN FAIL ") + s.spec.id + ": " + r.summary);
            if (r.ok && next != null) next.run(r.fullText);
        });
    }

    private static String oneLine(String s) {
        String t = s == null ? "" : s.replace('\n', ' ').replace('"', '\'').trim();
        return t.length() > 400 ? t.substring(0, 400) : t;
    }

    // ------------------------------------------------------------------ log view

    private void scheduleLogRefresh() {
        if (refreshPending) return;
        refreshPending = true;
        main.postDelayed(() -> {
            refreshPending = false;
            if (logView == null) return;
            logView.setText(EngineLog.dump());
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        }, 250L);
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Engine Lab log", EngineLog.dump()));
        toast("Log copied. No cookies or URL queries are logged, but review Probe output before sharing.");
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------------ small view helpers

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12f);
        b.setOnClickListener(l);
        return b;
    }

    private static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private static FrameLayout.LayoutParams full() {
        return new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    }

    // ------------------------------------------------------------------ lifecycle
    // WebView.onPause()/onResume() are deliberately not called in P1-A: hidden-operation behavior is what we measure.

    @Override
    protected void onPause() {
        EngineLog.add("lab", "activity paused");
        chatgpt.flushCookies();
        claude.flushCookies();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        EngineLog.add("lab", "activity resumed");
    }

    @Override
    public void onBackPressed() {
        if (tab == 0 && chatgpt.goBackIfPossible()) return;
        if (tab == 1 && claude.goBackIfPossible()) return;
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        EngineLog.setListener(null);
        main.removeCallbacksAndMessages(null);
        chatgpt.destroy();
        claude.destroy();
        super.onDestroy();
    }
}
