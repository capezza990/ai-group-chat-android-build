package com.aigroupchat.bridge.engine;

import android.os.Handler;
import android.os.Looper;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** In-memory diagnostic log for the P1-A engine lab. Never stores cookies, tokens or URL queries. */
public final class EngineLog {
    private static final int MAX_LINES = 700;
    private static final ArrayDeque<String> LINES = new ArrayDeque<>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static Runnable listener;
    private static final Pattern UUID_RE = Pattern.compile(
            "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");

    public static String fingerprint(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest((s == null ? "" : s).getBytes("UTF-8"));
            return String.format(Locale.US, "%02x%02x%02x", d[0], d[1], d[2]);
        } catch (Exception e) {
            return "??????";
        }
    }

    public static String redactIds(String s) {
        if (s == null) return "";
        Matcher m = UUID_RE.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement("#" + fingerprint(m.group())));
        m.appendTail(sb);
        return sb.toString();
    }

    private EngineLog() {}

    public static synchronized void add(String tag, String msg) {
        String m = redactIds(msg);
        if (m.length() > 900) m = m.substring(0, 900) + "…";
        LINES.addLast(FMT.format(new Date()) + " [" + tag + "] " + m);
        while (LINES.size() > MAX_LINES) LINES.removeFirst();
        if (listener != null) MAIN.post(listener);
    }

    public static synchronized String dump() {
        StringBuilder sb = new StringBuilder();
        for (String l : LINES) sb.append(l).append('\n');
        return sb.toString();
    }

    public static synchronized void clear() { LINES.clear(); if (listener != null) MAIN.post(listener); }

    public static synchronized void setListener(Runnable r) { listener = r; }
}
