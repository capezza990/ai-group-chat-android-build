package com.aigroupchat.bridge.engine;

import android.content.Context;

import org.json.JSONObject;

/** The room never parses URLs: an adapter produces this and the room stores it. The id/locator, not the
 *  title, is the binding. (No cookies or tokens are ever stored here.) */
public final class ProviderBinding {
    public final String providerId;
    public final String providerConversationId;
    public final String restoreLocator;
    public final String displayTitle;
    public final long boundAt;

    public ProviderBinding(String providerId, String conversationId, String restoreLocator, String displayTitle, long boundAt) {
        this.providerId = providerId;
        this.providerConversationId = conversationId;
        this.restoreLocator = restoreLocator;
        this.displayTitle = displayTitle == null ? "" : displayTitle;
        this.boundAt = boundAt;
    }

    public JSONObject toJson() throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("providerId", providerId);
        o.put("conversationId", providerConversationId);
        o.put("restoreLocator", restoreLocator);
        o.put("title", displayTitle);
        o.put("boundAt", boundAt);
        return o;
    }

    public static ProviderBinding fromJson(JSONObject o) {
        if (o == null) return null;
        String id = o.optString("conversationId", "");
        if (id.isEmpty()) return null;
        return new ProviderBinding(o.optString("providerId", ""), id, o.optString("restoreLocator", ""),
                o.optString("title", ""), o.optLong("boundAt", 0L));
    }

    /** Persistence for bindings. Delegates to the canonical room database (single source of truth);
     *  bindings saved by the P1-A build in SharedPreferences are imported once by RoomDb. */
    public static final class Store {
        private final com.aigroupchat.bridge.room.sqlite.RoomDb db;

        public Store(Context c) { db = com.aigroupchat.bridge.room.sqlite.RoomDb.get(c); }

        public ProviderBinding get(String providerId) {
            try { return db.getBinding(providerId); } catch (Exception e) { return null; }
        }

        public void put(ProviderBinding b) {
            try { db.putBinding(b); } catch (Exception ignored) {}
        }

        public void clear(String providerId) {
            try { db.clearBinding(providerId); } catch (Exception ignored) {}
        }
    }
}
