package com.aigroupchat.bridge.engine;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Static description of one web provider: where it lives and which DOM selectors to use.
 *  Selectors are EXACT (no wildcard or generic fallbacks) and are CANDIDATES until verified: the lab's
 *  Health/Probe output is how they get corrected. If a selector is missing or ambiguous, the engine
 *  logs it and stops; it never guesses another element to click. */
public final class ProviderSpec {
    public final String id;
    public final String displayName;
    public final String startUrl;
    public final String[] scriptHosts;
    public final String[] navigationHosts;
    public final Pattern conversationPattern;
    public final String selectorsJson;

    private ProviderSpec(String id, String displayName, String startUrl, String[] scriptHosts,
                         String[] navigationHosts, String conversationRegex, JSONObject selectors) {
        this.id = id;
        this.displayName = displayName;
        this.startUrl = startUrl;
        this.scriptHosts = scriptHosts;
        this.navigationHosts = navigationHosts;
        this.conversationPattern = Pattern.compile(conversationRegex);
        this.selectorsJson = selectors.toString();
    }

    public static final ProviderSpec CHATGPT = new ProviderSpec(
            "chatgpt", "ChatGPT", "https://chatgpt.com/",
            new String[]{"chatgpt.com"},
            new String[]{"chatgpt.com", "openai.com", "auth.openai.com", "accounts.google.com",
                    "appleid.apple.com", "login.microsoftonline.com", "login.live.com"},
            "^https://chatgpt\\.com/(?:g/[^/]+/)?c/([0-9a-fA-F-]{36})",
            selectors(
                    new String[]{"#prompt-textarea"},
                    new String[]{"button[data-testid='send-button']"},
                    new String[]{"button[data-testid='stop-button']"},
                    new String[]{},
                    new String[]{"[data-message-author-role='assistant']"},
                    new String[]{"[data-message-author-role='user']"}));

    public static final ProviderSpec CLAUDE = new ProviderSpec(
            "claude", "Claude", "https://claude.ai/",
            new String[]{"claude.ai"},
            new String[]{"claude.ai", "anthropic.com", "accounts.google.com"},
            "^https://claude\\.ai/chat/([0-9a-fA-F-]{36})",
            selectors(
                    new String[]{"div.ProseMirror[contenteditable='true']"},
                    new String[]{"button[aria-label='Send message']"},
                    new String[]{"button[aria-label='Stop response']"},
                    new String[]{"[data-is-streaming='true']"},
                    new String[]{"[data-testid='assistant-message']"},
                    new String[]{"[data-testid='user-message']"}));

    private static JSONObject selectors(String[] composer, String[] send, String[] stop, String[] streaming,
                                        String[] assistant, String[] user) {
        try {
            JSONObject o = new JSONObject();
            o.put("composer", new JSONArray(java.util.Arrays.asList(composer)));
            o.put("send", new JSONArray(java.util.Arrays.asList(send)));
            o.put("stop", new JSONArray(java.util.Arrays.asList(stop)));
            o.put("streaming", new JSONArray(java.util.Arrays.asList(streaming)));
            o.put("assistant", new JSONArray(java.util.Arrays.asList(assistant)));
            o.put("user", new JSONArray(java.util.Arrays.asList(user)));
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public boolean isNavigationAllowed(String host) { return hostIn(host, navigationHosts); }

    public boolean isScriptHost(String host) { return hostIn(host, scriptHosts); }

    private static boolean hostIn(String host, String[] list) {
        if (host == null) return false;
        String h = host.toLowerCase(java.util.Locale.ROOT);
        for (String allowed : list) if (h.equals(allowed) || h.endsWith("." + allowed)) return true;
        return false;
    }

    /** Returns the conversation id if the URL is a conversation page, else null. */
    public String conversationIdOf(String url) {
        if (url == null) return null;
        Matcher m = conversationPattern.matcher(url);
        return m.find() ? m.group(1) : null;
    }
}
