package com.aigroupchat.bridge.room;

/** One request to one provider, triggered by one canonical message. UNIQUE(triggerMessageId, providerId). */
public final class Delivery {
    public final String id;
    public final String roomId;
    public final String triggerMessageId;
    public final String providerId;
    public final long uptoSeq;            // highest canonical seq INCLUDED in this request's prompt
    public DeliveryState state;
    public String providerUserMsgId = ""; // opaque provider-side ids, used for mirror verification (B3)
    public String providerAsstMsgId = "";
    public String replyMessageId = "";    // canonical message holding the captured reply
    public String error = "";
    public final long createdAt;
    public long updatedAt;

    public Delivery(String id, String roomId, String triggerMessageId, String providerId, long uptoSeq,
                    DeliveryState state, long createdAt, long updatedAt) {
        this.id = id; this.roomId = roomId; this.triggerMessageId = triggerMessageId; this.providerId = providerId;
        this.uptoSeq = uptoSeq; this.state = state; this.createdAt = createdAt; this.updatedAt = updatedAt;
    }

    public Delivery copy() {
        Delivery d = new Delivery(id, roomId, triggerMessageId, providerId, uptoSeq, state, createdAt, updatedAt);
        d.providerUserMsgId = providerUserMsgId; d.providerAsstMsgId = providerAsstMsgId;
        d.replyMessageId = replyMessageId; d.error = error;
        return d;
    }
}
