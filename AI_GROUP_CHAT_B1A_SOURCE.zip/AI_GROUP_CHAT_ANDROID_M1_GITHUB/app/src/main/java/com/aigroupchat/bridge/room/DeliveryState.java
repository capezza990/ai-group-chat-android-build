package com.aigroupchat.bridge.room;

/** Lifecycle of one provider request. UNCERTAIN is never retried automatically (a duplicate real provider turn is worse than a deliberate recovery). */
public enum DeliveryState {
    PENDING,    // row created, nothing sent
    SENDING,    // persisted BEFORE the provider is asked to send; if we die here the outcome is unknown
    SENT,       // provider confirmed the request was actually submitted
    CAPTURED,   // the reply was captured and persisted as a room message
    FAILED,     // provably not submitted; safe to retry
    UNCERTAIN,  // may or may not have been submitted / reply not captured; needs a deliberate resync
    CANCELLED;  // never sent

    public boolean isTerminal() { return this == CAPTURED || this == FAILED || this == UNCERTAIN || this == CANCELLED; }
}
