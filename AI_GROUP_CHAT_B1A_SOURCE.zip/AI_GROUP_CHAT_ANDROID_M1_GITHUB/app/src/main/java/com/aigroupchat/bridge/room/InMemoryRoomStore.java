package com.aigroupchat.bridge.room;

import com.aigroupchat.bridge.engine.ProviderBinding;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Reference implementation of RoomStore for the deterministic test harness (mirrors the SQLite constraints). */
public final class InMemoryRoomStore implements RoomStore {
    private final Object lock = new Object();
    private Map<String, RoomSettings> rooms = new LinkedHashMap<>();
    private Map<String, RoomMessage> messages = new LinkedHashMap<>(); // by id, insertion = seq order
    private long nextSeq = 1;
    private Map<String, RoomParticipant> participants = new LinkedHashMap<>(); // key room|provider
    private Map<String, Delivery> deliveries = new LinkedHashMap<>();
    private Map<String, ProviderBinding> bindings = new LinkedHashMap<>();
    private int depth;

    @Override
    public <T> T atomic(Supplier<T> body) {
        synchronized (lock) {
            if (depth > 0) return body.get();
            // snapshot for rollback
            Map<String, RoomSettings> r = new LinkedHashMap<>(rooms);
            Map<String, RoomMessage> m = new LinkedHashMap<>(messages);
            long seq = nextSeq;
            Map<String, RoomParticipant> p = new LinkedHashMap<>();
            for (Map.Entry<String, RoomParticipant> e : participants.entrySet()) p.put(e.getKey(), e.getValue().copy());
            Map<String, Delivery> d = new LinkedHashMap<>();
            for (Map.Entry<String, Delivery> e : deliveries.entrySet()) d.put(e.getKey(), e.getValue().copy());
            Map<String, ProviderBinding> b = new LinkedHashMap<>(bindings);
            depth++;
            try {
                return body.get();
            } catch (RuntimeException ex) {
                rooms = r; messages = m; nextSeq = seq; participants = p; deliveries = d; bindings = b;
                throw ex;
            } finally {
                depth--;
            }
        }
    }

    private static String pk(String room, String provider) { return room + "|" + provider; }

    @Override public RoomSettings ensureRoom(String roomId, long now) {
        synchronized (lock) {
            RoomSettings s = rooms.get(roomId);
            if (s == null) { s = new RoomSettings(roomId, RoutingMode.AUTO_PICK, "", 1, now); rooms.put(roomId, s); }
            return s;
        }
    }

    @Override public RoomSettings getRoom(String roomId) { synchronized (lock) { return rooms.get(roomId); } }

    @Override public void saveRoomSettings(RoomSettings s) {
        synchronized (lock) {
            if (!rooms.containsKey(s.roomId)) throw new IllegalStateException("FK: unknown room " + s.roomId);
            rooms.put(s.roomId, s);
        }
    }

    @Override public void upsertParticipant(String roomId, String providerId, int position) {
        synchronized (lock) {
            if (!rooms.containsKey(roomId)) throw new IllegalStateException("FK: unknown room " + roomId);
            RoomParticipant p = participants.get(pk(roomId, providerId));
            if (p == null) participants.put(pk(roomId, providerId), new RoomParticipant(roomId, providerId, true, position, 0L, "UNKNOWN"));
            else p.enabled = true;
        }
    }

    @Override public void setParticipantEnabled(String roomId, String providerId, boolean enabled) {
        synchronized (lock) {
            RoomParticipant p = participants.get(pk(roomId, providerId));
            if (p != null) p.enabled = enabled;
        }
    }

    @Override public List<RoomParticipant> participants(String roomId) {
        synchronized (lock) {
            List<RoomParticipant> out = new ArrayList<>();
            for (RoomParticipant p : participants.values()) if (p.roomId.equals(roomId)) out.add(p.copy());
            out.sort((a, b) -> a.position != b.position ? Integer.compare(a.position, b.position) : a.providerId.compareTo(b.providerId));
            return out;
        }
    }

    @Override public void advanceContextSeq(String roomId, String providerId, long seq) {
        synchronized (lock) {
            RoomParticipant p = participants.get(pk(roomId, providerId));
            if (p != null && seq > p.contextSeq) p.contextSeq = seq;
        }
    }

    @Override public RoomMessage appendMessage(String roomId, String id, String authorType, String authorId, String text, String replyTo, long now) {
        synchronized (lock) {
            RoomMessage existing = messages.get(id);
            if (existing != null) return existing;
            if (!rooms.containsKey(roomId)) throw new IllegalStateException("FK: unknown room " + roomId);
            RoomMessage m = new RoomMessage(nextSeq++, id, roomId, authorType, authorId, text, now, replyTo);
            messages.put(id, m);
            return m;
        }
    }

    @Override public RoomMessage getMessage(String id) { synchronized (lock) { return messages.get(id); } }

    @Override public List<RoomMessage> messagesBetween(String roomId, long afterSeq, long uptoSeq) {
        synchronized (lock) {
            List<RoomMessage> out = new ArrayList<>();
            for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId) && m.seq > afterSeq && m.seq <= uptoSeq) out.add(m);
            return out;
        }
    }

    @Override public List<RoomMessage> latestMessages(String roomId, int limit) {
        synchronized (lock) {
            List<RoomMessage> all = new ArrayList<>();
            for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId)) all.add(m);
            return new ArrayList<>(all.subList(Math.max(0, all.size() - limit), all.size()));
        }
    }

    @Override public long latestSeq(String roomId) {
        synchronized (lock) {
            long max = 0;
            for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId) && m.seq > max) max = m.seq;
            return max;
        }
    }

    @Override public Delivery createDelivery(String deliveryId, String roomId, String triggerMessageId, String providerId, long uptoSeq, long now) {
        synchronized (lock) {
            for (Delivery d : deliveries.values()) {
                if (d.triggerMessageId.equals(triggerMessageId) && d.providerId.equals(providerId)) return d.copy();
            }
            if (!messages.containsKey(triggerMessageId)) throw new IllegalStateException("FK: unknown trigger message");
            Delivery d = new Delivery(deliveryId, roomId, triggerMessageId, providerId, uptoSeq, DeliveryState.PENDING, now, now);
            deliveries.put(deliveryId, d);
            return d.copy();
        }
    }

    @Override public Delivery getDelivery(String id) { synchronized (lock) { Delivery d = deliveries.get(id); return d == null ? null : d.copy(); } }

    @Override public boolean transition(String deliveryId, DeliveryState[] from, DeliveryState to, String error, long now) {
        synchronized (lock) {
            Delivery d = deliveries.get(deliveryId);
            if (d == null) return false;
            boolean ok = false;
            for (DeliveryState f : from) if (d.state == f) ok = true;
            if (!ok) return false;
            d.state = to;
            if (error != null) d.error = error;
            d.updatedAt = now;
            return true;
        }
    }

    @Override public void recordProviderIds(String deliveryId, String providerUserMsgId, String providerAsstMsgId) {
        synchronized (lock) {
            Delivery d = deliveries.get(deliveryId);
            if (d == null) return;
            if (providerUserMsgId != null && !providerUserMsgId.isEmpty()) d.providerUserMsgId = providerUserMsgId;
            if (providerAsstMsgId != null && !providerAsstMsgId.isEmpty()) d.providerAsstMsgId = providerAsstMsgId;
        }
    }

    @Override public void setDeliveryReply(String deliveryId, String replyMessageId) {
        synchronized (lock) {
            Delivery d = deliveries.get(deliveryId);
            if (d == null) return;
            if (!messages.containsKey(replyMessageId)) throw new IllegalStateException("FK: unknown reply message");
            d.replyMessageId = replyMessageId;
        }
    }

    @Override public List<Delivery> deliveriesInState(DeliveryState state) {
        synchronized (lock) {
            List<Delivery> out = new ArrayList<>();
            for (Delivery d : deliveries.values()) if (d.state == state) out.add(d.copy());
            return out;
        }
    }

    @Override public int markInFlightUncertain(long now) {
        synchronized (lock) {
            int n = 0;
            for (Delivery d : deliveries.values()) {
                if (d.state == DeliveryState.SENDING || d.state == DeliveryState.SENT) {
                    d.state = DeliveryState.UNCERTAIN; d.error = "interrupted (app restart)"; d.updatedAt = now; n++;
                }
            }
            return n;
        }
    }

    @Override public ProviderBinding getBinding(String providerId) { synchronized (lock) { return bindings.get(providerId); } }
    @Override public void putBinding(ProviderBinding b) { synchronized (lock) { bindings.put(b.providerId, b); } }
    @Override public void clearBinding(String providerId) { synchronized (lock) { bindings.remove(providerId); } }
}
