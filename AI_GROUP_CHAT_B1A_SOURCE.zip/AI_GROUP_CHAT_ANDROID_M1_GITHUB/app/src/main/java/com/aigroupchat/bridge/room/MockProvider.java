package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Deterministic fake AI for the test harness and the UI milestone. No network, no accounts. */
public final class MockProvider implements RoomProvider {
    public enum Behavior { REPLY, FAIL_BEFORE_SEND, FAIL_AFTER_ACCEPT, DUPLICATE_REPLY, NEVER_REPLY, SILENT, EMPTY_REPLY }

    public interface Scheduler {
        void post(Runnable r, long delayMs);
        Scheduler IMMEDIATE = (r, d) -> r.run();
    }

    private final String id, name;
    private final Scheduler scheduler;
    public volatile Behavior behavior = Behavior.REPLY;
    public volatile long delayMs;
    public volatile Consumer<String> onSend; // test hook: runs synchronously inside send(), before any callback
    public final List<String> prompts = Collections.synchronizedList(new ArrayList<>());
    private volatile boolean cancelled;
    private int n;

    public MockProvider(String id, String name, Scheduler scheduler) { this.id = id; this.name = name; this.scheduler = scheduler; }

    @Override public String id() { return id; }
    @Override public String displayName() { return name; }
    @Override public Set<String> capabilities() { return Collections.singleton("GENERAL"); }
    @Override public boolean isAvailable() { return true; }
    @Override public void cancel() { cancelled = true; }

    @Override
    public void send(String prompt, Listener l) {
        final int k;
        synchronized (this) { k = ++n; }
        cancelled = false;
        prompts.add(prompt);
        Consumer<String> hook = onSend;
        if (hook != null) hook.accept(prompt);
        scheduler.post(() -> {
            if (cancelled) return;
            switch (behavior) {
                case FAIL_BEFORE_SEND:
                    l.onError("mock refused before send", false);
                    break;
                case SILENT:       // no callback at all: the delivery stays SENDING
                    break;
                case NEVER_REPLY:  // accepted, but the reply never arrives: the delivery stays SENT
                    l.onAccepted(id + "-u" + k);
                    break;
                case EMPTY_REPLY:
                    l.onAccepted(id + "-u" + k);
                    l.onReply("   ", id + "-a" + k);
                    break;
                case FAIL_AFTER_ACCEPT:
                    l.onAccepted(id + "-u" + k);
                    l.onError("mock lost the reply", true);
                    break;
                case DUPLICATE_REPLY:
                    l.onAccepted(id + "-u" + k);
                    l.onReply(name + " reply #" + k, id + "-a" + k);
                    l.onReply(name + " reply #" + k, id + "-a" + k);
                    l.onAccepted(id + "-u" + k);
                    break;
                case REPLY:
                default:
                    l.onAccepted(id + "-u" + k);
                    l.onReply(name + " reply #" + k, id + "-a" + k);
                    break;
            }
        }, delayMs);
    }
}
