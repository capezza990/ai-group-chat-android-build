package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * Owns the canonical room flow. Rules:
 *  1. The user message is persisted BEFORE anything is dispatched.
 *  2. A delivery is persisted as SENDING BEFORE the provider is asked to send. A crash there leaves UNCERTAIN, never an auto-resend.
 *  3. A provider reply is persisted (idempotent id "reply:<deliveryId>") BEFORE the next provider sees it.
 *  4. Provider context progress (contextSeq) advances only to what was actually included in a request the provider accepted.
 *  5. Duplicate / late / stale provider callbacks change nothing.
 * Thread-safe: state changes happen under one lock; provider calls and UI events run after the lock is released.
 */
public final class RoomController {
    public interface Events {
        default void onMessage(RoomMessage m) {}
        default void onDelivery(Delivery d) {}
        default void onRunFinished(String summary) {}
    }

    private static final class Run {
        List<RoomRouter.Step> steps;
        int index;
        String userMessageId;
        String lastMessageId;   // trigger for the next step
        Delivery active;        // current delivery (null between steps)
        RoomProvider activeProvider;
        RoomRouter.Role activeRole;
    }

    private final RoomStore store;
    private final String roomId;
    private final Map<String, RoomProvider> providers = new LinkedHashMap<>();
    private final Map<String, String> names = new LinkedHashMap<>();
    private final LongSupplier clock;
    private final Supplier<String> ids;
    private final Events events;
    private final Object lock = new Object();
    private Run run;

    public RoomController(RoomStore store, String roomId, Events events) {
        this(store, roomId, events, System::currentTimeMillis, () -> UUID.randomUUID().toString());
    }

    public RoomController(RoomStore store, String roomId, Events events, LongSupplier clock, Supplier<String> ids) {
        this.store = store; this.roomId = roomId; this.events = events == null ? new Events() {} : events;
        this.clock = clock; this.ids = ids;
        store.ensureRoom(roomId, clock.getAsLong());
    }

    // ------------------------------------------------------------------ setup / membership

    public void registerProvider(RoomProvider p) {
        synchronized (lock) { providers.put(p.id(), p); names.put(p.id(), p.displayName()); }
    }

    public void addParticipant(String providerId) {
        synchronized (lock) {
            store.atomic(() -> { store.upsertParticipant(roomId, providerId, store.participants(roomId).size()); return null; });
        }
    }

    /** One-tap remove: history and provider binding are kept; re-adding restores the same context position. */
    public void removeParticipant(String providerId) {
        Runnable after = null;
        synchronized (lock) {
            store.atomic(() -> { store.setParticipantEnabled(roomId, providerId, false); return null; });
            if (run != null && run.active != null && run.active.providerId.equals(providerId)) after = stopLocked("participant removed");
        }
        if (after != null) after.run();
    }

    public List<RoomParticipant> participants() { return store.participants(roomId); }

    public void setRouting(RoutingMode mode, String arg, int rounds) {
        synchronized (lock) { store.saveRoomSettings(store.getRoom(roomId).with(mode, arg, rounds)); }
    }

    /** Call once at startup: anything that was SENDING/SENT when the process died becomes UNCERTAIN. Never resends. */
    public int recoverOnStart() { return store.markInFlightUncertain(clock.getAsLong()); }

    public boolean isBusy() { synchronized (lock) { return run != null; } }

    // ------------------------------------------------------------------ user message

    /** Persists the user message first, then plans and dispatches. Returns null if empty or a run is already active. */
    public RoomMessage submitUserMessage(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        RoomMessage msg;
        Runnable after;
        synchronized (lock) {
            if (run != null) return null;
            msg = store.atomic(() -> store.appendMessage(roomId, ids.get(), RoomMessage.USER, "user", text, null, clock.getAsLong()));
            List<RoomRouter.Step> steps = RoomRouter.plan(store.getRoom(roomId), store.participants(roomId));
            run = new Run();
            run.steps = steps;
            run.userMessageId = msg.id;
            run.lastMessageId = msg.id;
            after = steps.isEmpty() ? finishLocked("no enabled participant to answer") : startStepLocked();
        }
        events.onMessage(msg);
        if (after != null) after.run();
        return msg;
    }

    public void stop() {
        Runnable after;
        synchronized (lock) { after = stopLocked("stopped by user"); }
        if (after != null) after.run();
    }

    // ------------------------------------------------------------------ stepping (caller holds lock; returns an action to run AFTER unlocking)

    private Runnable startStepLocked() {
        final Run r = run;
        while (r.index < r.steps.size()) {
            RoomRouter.Step step = r.steps.get(r.index);
            RoomProvider provider = providers.get(step.providerId);
            RoomParticipant me = participant(step.providerId);
            if (me == null || !me.enabled) { r.index++; continue; } // removed mid-run: skip its turn
            if (provider == null || !provider.isAvailable()) return finishLocked(step.providerId + " is unavailable");

            final RoomMessage trigger = step.role == RoomRouter.Role.INDEPENDENT || step.role == RoomRouter.Role.ANSWER
                    ? store.getMessage(r.userMessageId) : store.getMessage(r.lastMessageId);
            final String prompt;
            final Delivery d;
            try {
                final long upto = step.role == RoomRouter.Role.INDEPENDENT ? trigger.seq : store.latestSeq(roomId);
                final long now = clock.getAsLong();
                Object[] out = store.atomic(() -> {
                    Delivery created = store.createDelivery(ids.get(), roomId, trigger.id, step.providerId, upto, now);
                    if (created.state != DeliveryState.PENDING) return new Object[]{created, null};
                    if (!store.transition(created.id, new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, now)) {
                        return new Object[]{created, null};
                    }
                    Delivery sending = store.getDelivery(created.id);
                    String p = RoomPromptBuilder.build(store, roomId, me, sending, trigger, step.role, names, false);
                    return new Object[]{sending, p};
                });
                d = (Delivery) out[0];
                prompt = (String) out[1];
            } catch (RuntimeException e) {
                return finishLocked("storage error before send: " + e.getMessage());
            }
            if (prompt == null) return finishLocked("a request for " + step.providerId + " already exists in state " + d.state + "; not re-sending");

            r.active = d;
            r.activeProvider = provider;
            r.activeRole = step.role;
            final DeliveryListener listener = new DeliveryListener(d.id);
            final Delivery snapshot = d;
            return () -> {
                events.onDelivery(snapshot);
                provider.send(prompt, listener); // outside the lock; state already persisted as SENDING
            };
        }
        return finishLocked(null);
    }

    private RoomParticipant participant(String providerId) {
        for (RoomParticipant p : store.participants(roomId)) if (p.providerId.equals(providerId)) return p;
        return null;
    }

    private Runnable finishLocked(String problem) {
        run = null;
        final String summary = problem == null ? "done" : problem;
        return () -> events.onRunFinished(summary);
    }

    private Runnable stopLocked(String why) {
        if (run == null) return null;
        final RoomProvider p = run.activeProvider;
        final Delivery a = run.active;
        if (a != null) {
            store.atomic(() -> {
                long now = clock.getAsLong();
                if (!store.transition(a.id, new DeliveryState[]{DeliveryState.SENDING, DeliveryState.SENT}, DeliveryState.UNCERTAIN, why, now)) {
                    store.transition(a.id, new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.CANCELLED, why, now);
                }
                return null;
            });
        }
        final Runnable fin = finishLocked(why);
        return () -> { if (p != null) p.cancel(); fin.run(); };
    }

    // ------------------------------------------------------------------ provider callbacks (idempotent, any thread)

    private final class DeliveryListener implements RoomProvider.Listener {
        private final String deliveryId;
        DeliveryListener(String deliveryId) { this.deliveryId = deliveryId; }

        @Override public void onAccepted(String providerUserMsgId) {
            synchronized (lock) {
                if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // stale
                store.atomic(() -> {
                    long now = clock.getAsLong();
                    if (store.transition(deliveryId, new DeliveryState[]{DeliveryState.SENDING}, DeliveryState.SENT, null, now)) {
                        store.recordProviderIds(deliveryId, providerUserMsgId, null);
                        Delivery d = store.getDelivery(deliveryId);
                        store.advanceContextSeq(roomId, d.providerId, d.uptoSeq); // provider accepted exactly what the prompt contained
                    }
                    return null;
                });
            }
        }

        @Override public void onReply(String text, String providerAsstMsgId) {
            RoomMessage reply;
            Runnable after;
            synchronized (lock) {
                if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // stale
                if (text == null || text.trim().isEmpty()) { after = failLocked("empty reply", true); reply = null; }
                else {
                    reply = store.atomic(() -> {
                        long now = clock.getAsLong();
                        Delivery before = store.getDelivery(deliveryId);
                        boolean wasSending = before.state == DeliveryState.SENDING;
                        if (!store.transition(deliveryId, new DeliveryState[]{DeliveryState.SENDING, DeliveryState.SENT}, DeliveryState.CAPTURED, null, now)) {
                            return null; // already captured / failed: duplicate callback
                        }
                        if (wasSending) store.advanceContextSeq(roomId, before.providerId, before.uptoSeq); // a reply proves acceptance
                        RoomMessage m = store.appendMessage(roomId, "reply:" + deliveryId, RoomMessage.PROVIDER, before.providerId, text, before.triggerMessageId, now);
                        store.recordProviderIds(deliveryId, null, providerAsstMsgId);
                        store.setDeliveryReply(deliveryId, m.id);
                        return m;
                    });
                    if (reply == null) return;
                    run.lastMessageId = reply.id;
                    run.active = null;
                    run.index++;
                    after = startStepLocked();
                }
            }
            if (reply != null) events.onMessage(reply);
            if (after != null) after.run();
        }

        @Override public void onError(String reason, boolean maybeSubmitted) {
            Runnable after;
            synchronized (lock) {
                if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // stale
                after = failLocked(reason, maybeSubmitted);
            }
            if (after != null) after.run();
        }
    }

    private Runnable failLocked(String reason, boolean maybeSubmitted) {
        final Delivery a = run.active;
        final String pid = a.providerId;
        store.atomic(() -> {
            long now = clock.getAsLong();
            if (!store.transition(a.id, new DeliveryState[]{DeliveryState.SENDING}, maybeSubmitted ? DeliveryState.UNCERTAIN : DeliveryState.FAILED, reason, now)) {
                store.transition(a.id, new DeliveryState[]{DeliveryState.SENT}, DeliveryState.UNCERTAIN, reason, now);
            }
            return null;
        });
        return finishLocked(pid + ": " + reason);
    }
}
