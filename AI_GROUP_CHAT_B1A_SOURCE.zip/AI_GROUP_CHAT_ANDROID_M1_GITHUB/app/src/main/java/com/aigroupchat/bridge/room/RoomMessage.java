package com.aigroupchat.bridge.room;

/** Canonical room message. Immutable and append-only: text is never updated or deleted. */
public final class RoomMessage {
    public static final String USER = "USER", PROVIDER = "PROVIDER", SYSTEM = "SYSTEM";

    public final long seq;          // monotonic per store, assigned on insert
    public final String id;         // globally unique; also the idempotency key
    public final String roomId;
    public final String authorType; // USER | PROVIDER | SYSTEM
    public final String authorId;   // "user" or a provider id
    public final String text;
    public final long createdAt;
    public final String replyTo;    // id of the message that triggered this one (nullable)

    public RoomMessage(long seq, String id, String roomId, String authorType, String authorId, String text, long createdAt, String replyTo) {
        this.seq = seq; this.id = id; this.roomId = roomId; this.authorType = authorType;
        this.authorId = authorId; this.text = text; this.createdAt = createdAt; this.replyTo = replyTo;
    }
}
