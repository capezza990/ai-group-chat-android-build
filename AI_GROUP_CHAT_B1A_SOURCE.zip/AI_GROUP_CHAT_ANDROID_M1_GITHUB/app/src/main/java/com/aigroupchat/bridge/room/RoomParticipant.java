package com.aigroupchat.bridge.room;

public final class RoomParticipant {
    public final String roomId;
    public final String providerId;
    public boolean enabled;
    public int position;
    /** Highest canonical seq known to have been incorporated into a request this provider actually accepted. */
    public long contextSeq;
    public String mirrorState; // UNKNOWN for now; B3 uses it for UNSYNCED / VERIFIED

    public RoomParticipant(String roomId, String providerId, boolean enabled, int position, long contextSeq, String mirrorState) {
        this.roomId = roomId; this.providerId = providerId; this.enabled = enabled;
        this.position = position; this.contextSeq = contextSeq; this.mirrorState = mirrorState;
    }

    public RoomParticipant copy() { return new RoomParticipant(roomId, providerId, enabled, position, contextSeq, mirrorState); }
}
