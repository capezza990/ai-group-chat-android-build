package com.aigroupchat.bridge.room;

import java.util.Set;

/** An AI participant endpoint (embedded web surface, mock, later Gemini...). Callbacks may arrive on any thread and may repeat. */
public interface RoomProvider {
    interface Listener {
        /** The provider CONFIRMED the request was actually submitted (e.g. our user bubble proven on the page). */
        void onAccepted(String providerUserMsgId);
        /** The complete reply was captured. */
        void onReply(String text, String providerAsstMsgId);
        /** maybeSubmitted=false only when the request provably never left (safe to retry); otherwise true. */
        void onError(String reason, boolean maybeSubmitted);
    }

    String id();
    String displayName();
    Set<String> capabilities();
    boolean isAvailable();
    void send(String prompt, Listener listener);
    void cancel();
}
