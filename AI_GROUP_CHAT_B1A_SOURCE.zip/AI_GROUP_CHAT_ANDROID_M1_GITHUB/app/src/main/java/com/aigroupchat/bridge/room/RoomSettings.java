package com.aigroupchat.bridge.room;

public final class RoomSettings {
    public static final int MAX_ROUNDS = 2; // same clamp as the legacy relay (1 or 2 review rounds)

    public final String roomId;
    public final RoutingMode mode;
    public final String modeArg; // SINGLE: provider id; COLLABORATE: first provider id; otherwise ""
    public final int rounds;
    public final long createdAt;

    public RoomSettings(String roomId, RoutingMode mode, String modeArg, int rounds, long createdAt) {
        this.roomId = roomId;
        this.mode = mode;
        this.modeArg = modeArg == null ? "" : modeArg;
        this.rounds = Math.max(1, Math.min(MAX_ROUNDS, rounds));
        this.createdAt = createdAt;
    }

    public RoomSettings with(RoutingMode m, String arg, int r) { return new RoomSettings(roomId, m, arg, r, createdAt); }
}
