package com.aigroupchat.bridge.room;

import com.aigroupchat.bridge.engine.ProviderBinding;

import java.util.List;
import java.util.function.Supplier;

/** Persistence contract for the canonical room. Implementations: RoomDb (SQLite) and InMemoryRoomStore (tests). */
public interface RoomStore {
    /** Runs body atomically; any RuntimeException rolls everything back. Re-entrant (nested calls join the outer one). */
    <T> T atomic(Supplier<T> body);

    // ---- rooms
    RoomSettings ensureRoom(String roomId, long now);
    RoomSettings getRoom(String roomId);
    void saveRoomSettings(RoomSettings s);

    // ---- participants (binding lives separately in provider_bindings)
    void upsertParticipant(String roomId, String providerId, int position); // re-enable keeps contextSeq and position
    void setParticipantEnabled(String roomId, String providerId, boolean enabled);
    List<RoomParticipant> participants(String roomId);                       // ordered by position
    void advanceContextSeq(String roomId, String providerId, long seq);      // monotonic: never moves backwards

    // ---- messages (append-only)
    /** Idempotent on id: inserting an existing id returns the stored message and changes nothing. */
    RoomMessage appendMessage(String roomId, String id, String authorType, String authorId, String text, String replyTo, long now);
    RoomMessage getMessage(String id);
    List<RoomMessage> messagesBetween(String roomId, long afterSeq, long uptoSeq); // afterSeq < seq <= uptoSeq, ascending
    List<RoomMessage> latestMessages(String roomId, int limit);                    // latest N, ascending
    long latestSeq(String roomId);

    // ---- deliveries
    /** Idempotent on (triggerMessageId, providerId): returns the existing row unchanged if present. */
    Delivery createDelivery(String deliveryId, String roomId, String triggerMessageId, String providerId, long uptoSeq, long now);
    Delivery getDelivery(String id);
    /** Compare-and-set: moves to `to` only if the current state is one of `from`. Returns whether it moved. */
    boolean transition(String deliveryId, DeliveryState[] from, DeliveryState to, String error, long now);
    void recordProviderIds(String deliveryId, String providerUserMsgId, String providerAsstMsgId);
    void setDeliveryReply(String deliveryId, String replyMessageId);
    List<Delivery> deliveriesInState(DeliveryState state);
    /** After a restart: SENDING and SENT deliveries become UNCERTAIN ("interrupted"). Returns how many. */
    int markInFlightUncertain(long now);

    // ---- provider bindings (single source of truth; ProviderBinding.Store delegates here)
    ProviderBinding getBinding(String providerId);
    void putBinding(ProviderBinding binding);
    void clearBinding(String providerId);
}
