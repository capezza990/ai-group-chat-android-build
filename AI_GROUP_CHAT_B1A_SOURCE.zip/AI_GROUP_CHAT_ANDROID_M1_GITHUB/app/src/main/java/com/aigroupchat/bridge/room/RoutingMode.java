package com.aigroupchat.bridge.room;

/** SINGLE = one chosen AI; ASK_ALL = every enabled AI answers independently; COLLABORATE = propose/review/revise;
 *  AUTO_PICK = first enabled AI for now (capability routing plugs in here later). */
public enum RoutingMode { SINGLE, ASK_ALL, COLLABORATE, AUTO_PICK }
