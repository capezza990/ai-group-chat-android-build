package com.aigroupchat.bridge.room.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.Delivery;
import com.aigroupchat.bridge.room.DeliveryState;
import com.aigroupchat.bridge.room.RoomMessage;
import com.aigroupchat.bridge.room.RoomParticipant;
import com.aigroupchat.bridge.room.RoomSettings;
import com.aigroupchat.bridge.room.RoomStore;
import com.aigroupchat.bridge.room.RoutingMode;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

/**
 * SQLite-backed canonical room (framework SQLite, no new dependency). Schema lives in assets/room_schema_v1.sql
 * (messages are append-only via triggers; UNIQUE ids; foreign keys on). All access is serialized by one static lock
 * and every public operation runs inside atomic(), which nests.
 */
public final class RoomDb extends SQLiteOpenHelper implements RoomStore {
    private static final String DB_NAME = "room.db";
    private static final int DB_VERSION = 1;
    private static final String STMT_SEPARATOR = "\n-- @@\n";
    private static final Object LOCK = new Object();
    private static RoomDb instance;

    private final Context appContext;
    private int txDepth;

    public static synchronized RoomDb get(Context c) {
        if (instance == null) {
            instance = new RoomDb(c.getApplicationContext());
            instance.importLegacyBindingsOnce();
        }
        return instance;
    }

    private RoomDb(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
        this.appContext = c;
    }

    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }

    @Override public void onCreate(SQLiteDatabase db) {
        for (String stmt : readSchema().split(STMT_SEPARATOR)) {
            String s = stmt.trim();
            if (!s.isEmpty()) db.execSQL(s);
        }
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { /* v1 only */ }

    private String readSchema() {
        try (InputStream in = appContext.getAssets().open("room_schema_v1.sql")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8").replace("\r\n", "\n");
        } catch (Exception e) {
            throw new IllegalStateException("room schema missing", e);
        }
    }

    // ------------------------------------------------------------------ transactions

    @Override
    public <T> T atomic(Supplier<T> body) {
        synchronized (LOCK) {
            SQLiteDatabase db = getWritableDatabase();
            boolean outer = txDepth == 0;
            if (outer) db.beginTransactionNonExclusive();
            txDepth++;
            try {
                T r = body.get();
                if (outer) db.setTransactionSuccessful();
                return r;
            } finally {
                txDepth--;
                if (outer) db.endTransaction();
            }
        }
    }

    private SQLiteDatabase db() { return getWritableDatabase(); }

    // ------------------------------------------------------------------ rooms

    @Override public RoomSettings ensureRoom(String roomId, long now) {
        return atomic(() -> {
            RoomSettings s = getRoom(roomId);
            if (s != null) return s;
            ContentValues cv = new ContentValues();
            cv.put("id", roomId); cv.put("routing_mode", RoutingMode.AUTO_PICK.name());
            cv.put("routing_arg", ""); cv.put("rounds", 1); cv.put("created_at", now);
            db().insertOrThrow("rooms", null, cv);
            return getRoom(roomId);
        });
    }

    @Override public RoomSettings getRoom(String roomId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT routing_mode, routing_arg, rounds, created_at FROM rooms WHERE id=?", new String[]{roomId})) {
                if (!c.moveToFirst()) return null;
                return new RoomSettings(roomId, RoutingMode.valueOf(c.getString(0)), c.getString(1), c.getInt(2), c.getLong(3));
            }
        });
    }

    @Override public void saveRoomSettings(RoomSettings s) {
        atomic(() -> {
            ContentValues cv = new ContentValues();
            cv.put("routing_mode", s.mode.name()); cv.put("routing_arg", s.modeArg); cv.put("rounds", s.rounds);
            if (db().update("rooms", cv, "id=?", new String[]{s.roomId}) != 1) throw new IllegalStateException("unknown room " + s.roomId);
            return null;
        });
    }

    // ------------------------------------------------------------------ participants

    @Override public void upsertParticipant(String roomId, String providerId, int position) {
        atomic(() -> {
            db().execSQL("INSERT OR IGNORE INTO participants(room_id, provider_id, enabled, position) VALUES (?,?,1,?)",
                    new Object[]{roomId, providerId, position});
            db().execSQL("UPDATE participants SET enabled=1 WHERE room_id=? AND provider_id=?", new Object[]{roomId, providerId});
            return null;
        });
    }

    @Override public void setParticipantEnabled(String roomId, String providerId, boolean enabled) {
        atomic(() -> {
            db().execSQL("UPDATE participants SET enabled=? WHERE room_id=? AND provider_id=?",
                    new Object[]{enabled ? 1 : 0, roomId, providerId});
            return null;
        });
    }

    @Override public List<RoomParticipant> participants(String roomId) {
        return atomic(() -> {
            List<RoomParticipant> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT provider_id, enabled, position, context_seq, mirror_state FROM participants "
                    + "WHERE room_id=? ORDER BY position, provider_id", new String[]{roomId})) {
                while (c.moveToNext()) out.add(new RoomParticipant(roomId, c.getString(0), c.getInt(1) == 1, c.getInt(2), c.getLong(3), c.getString(4)));
            }
            return out;
        });
    }

    @Override public void advanceContextSeq(String roomId, String providerId, long seq) {
        atomic(() -> {
            db().execSQL("UPDATE participants SET context_seq=? WHERE room_id=? AND provider_id=? AND context_seq < ?",
                    new Object[]{seq, roomId, providerId, seq});
            return null;
        });
    }

    // ------------------------------------------------------------------ messages

    private static RoomMessage readMessage(Cursor c) {
        return new RoomMessage(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4),
                c.getString(5), c.getLong(6), c.isNull(7) ? null : c.getString(7));
    }

    private static final String MSG_COLS = "seq, id, room_id, author_type, author_id, text, created_at, reply_to";

    @Override public RoomMessage appendMessage(String roomId, String id, String authorType, String authorId, String text, String replyTo, long now) {
        return atomic(() -> {
            RoomMessage existing = getMessage(id);
            if (existing != null) return existing; // idempotent: a repeated callback cannot create a second message
            ContentValues cv = new ContentValues();
            cv.put("id", id); cv.put("room_id", roomId); cv.put("author_type", authorType); cv.put("author_id", authorId);
            cv.put("text", text); cv.put("created_at", now);
            if (replyTo != null) cv.put("reply_to", replyTo);
            db().insertOrThrow("messages", null, cv);
            return getMessage(id);
        });
    }

    @Override public RoomMessage getMessage(String id) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + MSG_COLS + " FROM messages WHERE id=?", new String[]{id})) {
                return c.moveToFirst() ? readMessage(c) : null;
            }
        });
    }

    @Override public List<RoomMessage> messagesBetween(String roomId, long afterSeq, long uptoSeq) {
        return atomic(() -> {
            List<RoomMessage> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + MSG_COLS + " FROM messages WHERE room_id=? AND seq>? AND seq<=? ORDER BY seq",
                    new String[]{roomId, String.valueOf(afterSeq), String.valueOf(uptoSeq)})) {
                while (c.moveToNext()) out.add(readMessage(c));
            }
            return out;
        });
    }

    @Override public List<RoomMessage> latestMessages(String roomId, int limit) {
        return atomic(() -> {
            List<RoomMessage> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + MSG_COLS + " FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT ?",
                    new String[]{roomId, String.valueOf(limit)})) {
                while (c.moveToNext()) out.add(readMessage(c));
            }
            Collections.reverse(out);
            return out;
        });
    }

    @Override public long latestSeq(String roomId) {
        return atomic(() -> DatabaseUtils.longForQuery(db(), "SELECT COALESCE(MAX(seq),0) FROM messages WHERE room_id=?", new String[]{roomId}));
    }

    // ------------------------------------------------------------------ deliveries

    private static final String DEL_COLS = "id, room_id, trigger_message_id, provider_id, upto_seq, state, "
            + "provider_user_msg_id, provider_asst_msg_id, reply_message_id, error, created_at, updated_at";

    private static Delivery readDelivery(Cursor c) {
        Delivery d = new Delivery(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4),
                DeliveryState.valueOf(c.getString(5)), c.getLong(10), c.getLong(11));
        d.providerUserMsgId = c.getString(6); d.providerAsstMsgId = c.getString(7);
        d.replyMessageId = c.getString(8); d.error = c.getString(9);
        return d;
    }

    @Override public Delivery createDelivery(String deliveryId, String roomId, String triggerMessageId, String providerId, long uptoSeq, long now) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + DEL_COLS + " FROM deliveries WHERE trigger_message_id=? AND provider_id=?",
                    new String[]{triggerMessageId, providerId})) {
                if (c.moveToFirst()) return readDelivery(c); // idempotent on (trigger, provider)
            }
            ContentValues cv = new ContentValues();
            cv.put("id", deliveryId); cv.put("room_id", roomId); cv.put("trigger_message_id", triggerMessageId);
            cv.put("provider_id", providerId); cv.put("upto_seq", uptoSeq); cv.put("state", DeliveryState.PENDING.name());
            cv.put("created_at", now); cv.put("updated_at", now);
            db().insertOrThrow("deliveries", null, cv);
            return getDelivery(deliveryId);
        });
    }

    @Override public Delivery getDelivery(String id) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + DEL_COLS + " FROM deliveries WHERE id=?", new String[]{id})) {
                return c.moveToFirst() ? readDelivery(c) : null;
            }
        });
    }

    @Override public boolean transition(String deliveryId, DeliveryState[] from, DeliveryState to, String error, long now) {
        return atomic(() -> {
            StringBuilder where = new StringBuilder("id=? AND state IN (");
            String[] args = new String[from.length + 1];
            args[0] = deliveryId;
            for (int i = 0; i < from.length; i++) { where.append(i == 0 ? "?" : ",?"); args[i + 1] = from[i].name(); }
            where.append(')');
            ContentValues cv = new ContentValues();
            cv.put("state", to.name()); cv.put("updated_at", now);
            if (error != null) cv.put("error", error);
            return db().update("deliveries", cv, where.toString(), args) == 1;
        });
    }

    @Override public void recordProviderIds(String deliveryId, String providerUserMsgId, String providerAsstMsgId) {
        atomic(() -> {
            if (providerUserMsgId != null && !providerUserMsgId.isEmpty())
                db().execSQL("UPDATE deliveries SET provider_user_msg_id=? WHERE id=?", new Object[]{providerUserMsgId, deliveryId});
            if (providerAsstMsgId != null && !providerAsstMsgId.isEmpty())
                db().execSQL("UPDATE deliveries SET provider_asst_msg_id=? WHERE id=?", new Object[]{providerAsstMsgId, deliveryId});
            return null;
        });
    }

    @Override public void setDeliveryReply(String deliveryId, String replyMessageId) {
        atomic(() -> { db().execSQL("UPDATE deliveries SET reply_message_id=? WHERE id=?", new Object[]{replyMessageId, deliveryId}); return null; });
    }

    @Override public List<Delivery> deliveriesInState(DeliveryState state) {
        return atomic(() -> {
            List<Delivery> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + DEL_COLS + " FROM deliveries WHERE state=? ORDER BY created_at", new String[]{state.name()})) {
                while (c.moveToNext()) out.add(readDelivery(c));
            }
            return out;
        });
    }

    @Override public int markInFlightUncertain(long now) {
        return atomic(() -> {
            ContentValues cv = new ContentValues();
            cv.put("state", DeliveryState.UNCERTAIN.name()); cv.put("error", "interrupted (app restart)"); cv.put("updated_at", now);
            return db().update("deliveries", cv, "state IN ('SENDING','SENT')", null);
        });
    }

    // ------------------------------------------------------------------ provider bindings (single source of truth)

    @Override public ProviderBinding getBinding(String providerId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT conversation_id, restore_locator, display_title, bound_at FROM provider_bindings WHERE provider_id=?",
                    new String[]{providerId})) {
                return c.moveToFirst() ? new ProviderBinding(providerId, c.getString(0), c.getString(1), c.getString(2), c.getLong(3)) : null;
            }
        });
    }

    @Override public void putBinding(ProviderBinding b) {
        atomic(() -> {
            db().execSQL("INSERT OR REPLACE INTO provider_bindings(provider_id, conversation_id, restore_locator, display_title, bound_at) VALUES (?,?,?,?,?)",
                    new Object[]{b.providerId, b.providerConversationId, b.restoreLocator, b.displayTitle, b.boundAt});
            return null;
        });
    }

    @Override public void clearBinding(String providerId) {
        atomic(() -> { db().execSQL("DELETE FROM provider_bindings WHERE provider_id=?", new Object[]{providerId}); return null; });
    }

    // ------------------------------------------------------------------ one-time import of the P1-A SharedPreferences bindings

    private void importLegacyBindingsOnce() {
        SharedPreferences meta = appContext.getSharedPreferences("room_meta", Context.MODE_PRIVATE);
        if (meta.getBoolean("bindings_imported_v1", false)) return;
        SharedPreferences legacy = appContext.getSharedPreferences("engine_bindings", Context.MODE_PRIVATE);
        try {
            for (String providerId : new String[]{"chatgpt", "claude"}) {
                if (getBinding(providerId) != null) continue;
                String json = legacy.getString(providerId, null);
                if (json == null) continue;
                ProviderBinding b = ProviderBinding.fromJson(new JSONObject(json));
                if (b != null && providerId.equals(b.providerId)) putBinding(b);
            }
            meta.edit().putBoolean("bindings_imported_v1", true).apply(); // legacy prefs are left untouched for rollback
        } catch (Exception ignored) {
        }
    }
}
