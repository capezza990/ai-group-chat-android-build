package com.aigroupchat.bridge.room.sqlite;

import android.content.Context;

import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.Delivery;
import com.aigroupchat.bridge.room.DeliveryState;
import com.aigroupchat.bridge.room.MockProvider;
import com.aigroupchat.bridge.room.RoomController;
import com.aigroupchat.bridge.room.RoomMessage;
import com.aigroupchat.bridge.room.RoutingMode;

import java.util.List;

/**
 * On-device smoke test for the REAL SQLite store (the JVM harness can only test the in-memory twin).
 * Runs in its own throwaway room id, never in the default room. Uses MockProvider only: no network, no accounts.
 */
public final class RoomSelfCheck {
    private RoomSelfCheck() {}

    public static String run(Context context) {
        StringBuilder out = new StringBuilder();
        int[] fails = {0};
        RoomDb db = RoomDb.get(context);
        final String room = "selfcheck-" + System.currentTimeMillis();
        try {
            // 1. collaborate through the real database
            MockProvider a = new MockProvider("mock-a", "Mock A", MockProvider.Scheduler.IMMEDIATE);
            MockProvider b = new MockProvider("mock-b", "Mock B", MockProvider.Scheduler.IMMEDIATE);
            RoomController c = new RoomController(db, room, null);
            c.registerProvider(a); c.registerProvider(b);
            c.addParticipant("mock-a"); c.addParticipant("mock-b");
            c.setRouting(RoutingMode.COLLABORATE, "mock-a", 1);
            final boolean[] persistedFirst = {false};
            a.onSend = p -> persistedFirst[0] = db.latestSeq(room) >= 1 && !db.deliveriesInState(DeliveryState.SENDING).isEmpty();
            c.submitUserMessage("self-check question");
            List<RoomMessage> msgs = db.messagesBetween(room, 0, Long.MAX_VALUE);
            check(out, fails, persistedFirst[0], "user message + SENDING delivery were stored before the provider was called");
            check(out, fails, msgs.size() == 4, "collaborate stored 4 messages (user, propose, review, revise), got " + msgs.size());
            check(out, fails, b.prompts.size() == 1 && b.prompts.get(0).contains("Mock A reply #1"), "provider B's prompt carried A's stored reply");

            // 2. duplicate callback: one message only
            a.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            c.setRouting(RoutingMode.SINGLE, "mock-a", 1);
            long before = db.messagesBetween(room, 0, Long.MAX_VALUE).size();
            c.submitUserMessage("dup test");
            long after = db.messagesBetween(room, 0, Long.MAX_VALUE).size();
            check(out, fails, after - before == 2, "duplicate provider callback stored exactly one reply (user + 1), got " + (after - before));

            // 3. restart recovery: SILENT provider leaves SENDING, a new controller marks it UNCERTAIN, nothing resent
            a.behavior = MockProvider.Behavior.SILENT;
            c.submitUserMessage("restart test");
            check(out, fails, db.deliveriesInState(DeliveryState.SENDING).size() >= 1, "delivery is SENDING while the provider is silent");
            int sent = a.prompts.size();
            RoomController c2 = new RoomController(db, room, null);
            c2.registerProvider(a); c2.registerProvider(b);
            int recovered = c2.recoverOnStart();
            check(out, fails, recovered >= 1 && a.prompts.size() == sent, "restart marked " + recovered + " in-flight delivery UNCERTAIN and resent nothing");
            boolean anyUncertain = false;
            for (Delivery d : db.deliveriesInState(DeliveryState.UNCERTAIN)) if (d.roomId.equals(room)) anyUncertain = true;
            check(out, fails, anyUncertain, "UNCERTAIN row present");

            // 4. database constraints
            boolean updateBlocked = false, dupBlocked = false, rolledBack = false;
            try { db.getWritableDatabase().execSQL("UPDATE messages SET text='x' WHERE room_id=?", new Object[]{room}); } catch (Exception e) { updateBlocked = true; }
            check(out, fails, updateBlocked, "messages are append-only (UPDATE blocked by trigger)");
            try {
                db.getWritableDatabase().execSQL("INSERT INTO deliveries(id, room_id, trigger_message_id, provider_id, upto_seq, state, created_at, updated_at) "
                        + "SELECT 'dupcheck', room_id, trigger_message_id, provider_id, upto_seq, 'PENDING', 1, 1 FROM deliveries WHERE room_id=? LIMIT 1", new Object[]{room});
            } catch (Exception e) { dupBlocked = true; }
            check(out, fails, dupBlocked, "UNIQUE(trigger_message_id, provider_id) enforced");
            try {
                db.atomic(() -> { db.appendMessage(room, "rollback-probe", "USER", "user", "x", null, 1L); throw new IllegalStateException("probe"); });
            } catch (IllegalStateException expected) { rolledBack = db.getMessage("rollback-probe") == null; }
            check(out, fails, rolledBack, "atomic() rolled the insert back");

            // 5. bindings: single source of truth
            db.putBinding(new ProviderBinding("selfcheck", "00000000-0000-0000-0000-000000000000", "https://example.invalid/c/0", "t", 1L));
            ProviderBinding got = db.getBinding("selfcheck");
            check(out, fails, got != null && "00000000-0000-0000-0000-000000000000".equals(got.providerConversationId), "binding round-trip");
            db.clearBinding("selfcheck");
            check(out, fails, db.getBinding("selfcheck") == null, "binding cleared");
        } catch (Throwable t) {
            fails[0]++;
            out.append("EXCEPTION: ").append(t).append('\n');
        }
        out.insert(0, fails[0] == 0 ? "ALL PASS\n" : fails[0] + " FAILURE(S)\n");
        out.append("\n(throwaway room ").append(room).append("; the default room was not touched)");
        return out.toString();
    }

    private static void check(StringBuilder out, int[] fails, boolean ok, String what) {
        if (!ok) fails[0]++;
        out.append(ok ? "PASS  " : "FAIL  ").append(what).append('\n');
    }
}
