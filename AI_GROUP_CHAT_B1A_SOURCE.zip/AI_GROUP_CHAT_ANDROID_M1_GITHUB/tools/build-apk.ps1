$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$Tools = Join-Path $Root '.toolchain'
$Sdk = Join-Path $Tools 'android-sdk'
$GradleHome = Join-Path $Tools 'gradle-9.6.0'
$Downloads = Join-Path $Tools 'downloads'
$CmdZip = Join-Path $Downloads 'commandlinetools-win-15859902_latest.zip'
$GradleZip = Join-Path $Downloads 'gradle-9.6.0-bin.zip'
$OutApk = Join-Path $Root 'AI_GROUP_CHAT_ANDROID_M1-debug.apk'

Write-Host ''
Write-Host 'AI Group Chat Android builder' -ForegroundColor Cyan
Write-Host 'This first build downloads the official Android command-line tools, SDK packages, Gradle, and Android Gradle Plugin dependencies.'
Write-Host ''

$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) {
    throw 'Java was not found. Install a JDK 17 or newer (Android Studio also includes a suitable JDK), then run BUILD_APK.bat again.'
}
& java -version

New-Item -ItemType Directory -Force -Path $Tools, $Downloads, $Sdk | Out-Null

function Download-IfMissing([string]$Url, [string]$Path) {
    if (Test-Path $Path) { return }
    Write-Host "Downloading $Url" -ForegroundColor Yellow
    Invoke-WebRequest -Uri $Url -OutFile $Path -UseBasicParsing
}

# Current Android command-line tools listed by Android Developers as of 2026-09.
Download-IfMissing 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' $CmdZip
$expected = '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'
$actual = (Get-FileHash $CmdZip -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) {
    throw "Android command-line tools checksum mismatch. Expected $expected, got $actual"
}

$SdkManager = Join-Path $Sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
if (-not (Test-Path $SdkManager)) {
    Write-Host 'Installing Android command-line tools...' -ForegroundColor Yellow
    $tmp = Join-Path $Tools 'cmdline-tools-temp'
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    Expand-Archive -Path $CmdZip -DestinationPath $tmp -Force
    $latest = Join-Path $Sdk 'cmdline-tools\latest'
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $latest) | Out-Null
    if (Test-Path $latest) { Remove-Item $latest -Recurse -Force }
    Move-Item (Join-Path $tmp 'cmdline-tools') $latest
    Remove-Item $tmp -Recurse -Force
}

$env:ANDROID_HOME = $Sdk
$env:ANDROID_SDK_ROOT = $Sdk

Write-Host 'Android SDK components require accepting Google's Android SDK license.' -ForegroundColor Yellow
$agree = Read-Host 'Type I AGREE to continue with Android SDK license acceptance'
if ($agree -ne 'I AGREE') { throw 'Android SDK license was not accepted. Build cancelled.' }
1..50 | ForEach-Object { 'y' } | & $SdkManager --sdk_root=$Sdk --licenses | Out-Host

Write-Host 'Installing Android SDK 36, Build Tools 36.0.0, and platform-tools...' -ForegroundColor Yellow
& $SdkManager --sdk_root=$Sdk 'platforms;android-36' 'build-tools;36.0.0' 'platform-tools'
if ($LASTEXITCODE -ne 0) { throw 'Android SDK package installation failed.' }

Download-IfMissing 'https://services.gradle.org/distributions/gradle-9.6.0-bin.zip' $GradleZip
if (-not (Test-Path (Join-Path $GradleHome 'bin\gradle.bat'))) {
    Write-Host 'Installing Gradle 9.6.0...' -ForegroundColor Yellow
    Expand-Archive -Path $GradleZip -DestinationPath $Tools -Force
}

$Gradle = Join-Path $GradleHome 'bin\gradle.bat'
Write-Host ''
Write-Host 'Building debug APK...' -ForegroundColor Cyan
Push-Location $Root
try {
    & $Gradle --no-daemon --stacktrace :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE" }
} finally {
    Pop-Location
}

$built = Join-Path $Root 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $built)) { throw 'Gradle reported success, but the expected APK was not found.' }
Copy-Item $built $OutApk -Force

Write-Host ''
Write-Host 'BUILD SUCCESSFUL' -ForegroundColor Green
Write-Host "APK: $OutApk" -ForegroundColor Green
Write-Host ''
Write-Host 'You can copy that APK to your Android phone and open it, or use INSTALL_APK_USB.bat with USB debugging enabled.'
