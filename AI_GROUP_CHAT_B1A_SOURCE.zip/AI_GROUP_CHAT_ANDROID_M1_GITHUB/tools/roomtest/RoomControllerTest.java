import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Deterministic harness for the canonical-room core (no Android, no network). Run: tools/roomtest/run_tests.sh */
public final class RoomControllerTest {
    static int checks, failures;
    static final String ROOM = "default";

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) { failures++; System.out.println("    FAIL: " + what); }
    }

    static final class Fixture {
        final InMemoryRoomStore store = new InMemoryRoomStore();
        final MockProvider a = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
        final MockProvider b = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
        final List<String> finished = new ArrayList<>();
        final List<RoomMessage> seen = new ArrayList<>();
        final AtomicInteger clock = new AtomicInteger(1000);
        RoomController c;

        Fixture() { c = controller(); c.addParticipant("chatgpt"); c.addParticipant("claude"); }

        RoomController controller() {
            RoomController rc = new RoomController(store, ROOM, new RoomController.Events() {
                @Override public void onMessage(RoomMessage m) { seen.add(m); }
                @Override public void onRunFinished(String s) { finished.add(s); }
            }, () -> clock.incrementAndGet(), new java.util.function.Supplier<String>() {
                int n; public String get() { return "id" + (++n) + "-" + System.nanoTime(); }
            });
            rc.registerProvider(a);
            rc.registerProvider(b);
            return rc;
        }

        List<RoomMessage> all() { return store.messagesBetween(ROOM, 0, Long.MAX_VALUE); }
        long count(String type) { return all().stream().filter(m -> m.authorType.equals(type)).count(); }
        RoomParticipant part(String id) { return store.participants(ROOM).stream().filter(p -> p.providerId.equals(id)).findFirst().get(); }
    }

    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }

    public static void main(String[] args) {
        test("user message is persisted before dispatch; delivery is SENDING at send time", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.a.onSend = prompt -> {
                boolean userSaved = f.store.latestMessages(ROOM, 5).stream().anyMatch(m -> m.authorType.equals("USER") && m.text.equals("hello"));
                boolean sending = f.store.deliveriesInState(DeliveryState.SENDING).size() == 1;
                ok[0] = userSaved && sending;
            };
            f.c.submitUserMessage("hello");
            check(ok[0], "at send(): user message saved and delivery SENDING");
            check(f.count("PROVIDER") == 1, "reply stored");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 1, "delivery CAPTURED");
        });

        test("provider failure leaves the canonical user message intact and the delivery FAILED", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.FAIL_BEFORE_SEND;
            f.c.submitUserMessage("keep me");
            check(f.count("USER") == 1 && f.count("PROVIDER") == 0, "user message kept, no reply");
            check(f.store.deliveriesInState(DeliveryState.FAILED).size() == 1, "delivery FAILED (safe to retry)");
            check(f.part("chatgpt").contextSeq == 0, "context not advanced by a failed request");
            check(!f.c.isBusy(), "run cleared");
            f.a.behavior = MockProvider.Behavior.REPLY;
            check(f.c.submitUserMessage("again") != null, "next message accepted after a failure");
            check(f.count("PROVIDER") == 1, "next message answered");
        });

        test("captured reply is persisted before the next provider receives it (collaborate)", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.b.onSend = prompt -> {
                boolean stored = f.store.latestMessages(ROOM, 10).stream().anyMatch(m -> m.authorType.equals("PROVIDER") && m.authorId.equals("chatgpt"));
                ok[0] = stored && prompt.contains("ChatGPT reply #1");
            };
            f.c.submitUserMessage("design X");
            check(ok[0], "ChatGPT's reply was already stored and is in Claude's prompt");
            check(f.count("PROVIDER") == 3, "propose, review, revise = 3 provider messages");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 3, "3 deliveries CAPTURED");
            check(f.finished.size() == 1 && f.finished.get(0).equals("done"), "run finished cleanly");
        });

        test("restart: SENDING and SENT become UNCERTAIN and nothing is auto-resent", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("one");
            check(f.store.deliveriesInState(DeliveryState.SENDING).size() == 1, "stuck in SENDING");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            g.c.submitUserMessage("two");
            check(g.store.deliveriesInState(DeliveryState.SENT).size() == 1, "stuck in SENT");
            // "restart": a brand-new controller on the same stores
            RoomController f2 = f.controller();
            check(f2.recoverOnStart() == 1, "f: one delivery recovered");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "f: now UNCERTAIN");
            check(f.store.deliveriesInState(DeliveryState.SENDING).isEmpty(), "f: no SENDING left");
            check(f.a.prompts.size() == 1, "f: no automatic resend (still exactly 1 prompt)");
            RoomController g2 = g.controller();
            check(g2.recoverOnStart() == 1 && g.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "g: SENT -> UNCERTAIN");
            check(g.count("USER") == 1, "canonical user message survived the restart");
        });

        test("disabled participant keeps history and binding; re-adding restores context position", () -> {
            Fixture f = new Fixture();
            f.store.putBinding(new ProviderBinding("claude", "conv-1", "https://claude.ai/chat/conv-1", "t", 5L));
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("q1");
            long ctx = f.part("claude").contextSeq;
            check(ctx > 0, "claude accepted a request, context advanced");
            int bPrompts = f.b.prompts.size();
            f.c.removeParticipant("claude");
            check(!f.part("claude").enabled, "claude disabled");
            check(f.store.getBinding("claude") != null, "binding kept");
            check(f.count("PROVIDER") == 2, "old replies kept");
            f.c.submitUserMessage("q2");
            check(f.b.prompts.size() == bPrompts, "disabled participant receives nothing");
            f.c.addParticipant("claude");
            check(f.part("claude").enabled && f.part("claude").contextSeq == ctx, "re-enabled with the same context position");
        });

        test("duplicate provider callbacks create one message", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            f.c.submitUserMessage("dup?");
            check(f.count("PROVIDER") == 1, "exactly one provider message");
            RoomMessage m = f.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get();
            RoomMessage again = f.store.appendMessage(ROOM, m.id, "PROVIDER", "chatgpt", "different", null, 9L);
            check(again.seq == m.seq && again.text.equals(m.text), "appendMessage is idempotent on id and never rewrites text");
            check(f.count("PROVIDER") == 1, "still one after re-append");
        });

        test("router: collaborate sequences match the legacy relay", () -> {
            List<RoomParticipant> two = new ArrayList<>();
            two.add(new RoomParticipant(ROOM, "chatgpt", true, 0, 0, "UNKNOWN"));
            two.add(new RoomParticipant(ROOM, "claude", true, 1, 0, "UNKNOWN"));
            RoomSettings s1 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "chatgpt", 1, 0);
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "1 round = propose, review, revise");
            RoomSettings s2 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "claude", 2, 0);
            check(RoomRouter.plan(s2, two).toString().equals("[claude:ANSWER, chatgpt:REVIEW, claude:REVISE, chatgpt:REVIEW, claude:REVISE]"), "2 rounds, Claude first = 5 steps");
            check(new RoomSettings(ROOM, RoutingMode.COLLABORATE, "x", 9, 0).rounds == 2, "rounds clamp at 2 like the legacy control");
            List<RoomParticipant> three = new ArrayList<>(two);
            three.add(new RoomParticipant(ROOM, "gemini", true, 2, 0, "UNKNOWN"));
            check(RoomRouter.plan(s1, three).toString().equals("[chatgpt:ANSWER, claude:REVIEW, gemini:REVIEW, chatgpt:REVISE]"), "3 AIs: every other AI reviews in order");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.ASK_ALL, "", 1, 0), two).toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "ask all = independent");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.SINGLE, "claude", 1, 0), two).toString().equals("[claude:ANSWER]"), "single");
            two.get(1).enabled = false;
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER]"), "disabled AI is skipped; lone AI just answers");
            two.get(0).enabled = false;
            check(RoomRouter.plan(s1, two).isEmpty(), "nobody enabled = empty plan");
        });

        test("independent prompts exclude the other AI's reply; later prompts include what the AI has not seen", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("first question");
            check(!f.b.prompts.get(0).contains("ChatGPT reply #1"), "Claude's independent answer did not see ChatGPT's reply");
            f.c.submitUserMessage("second question");
            String p = f.a.prompts.get(1);
            check(p.contains("Claude reply #1") && p.contains("ROOM CONTEXT"), "ChatGPT's next prompt includes Claude's earlier reply as context");
            check(!p.contains("ChatGPT reply #1"), "ChatGPT's own earlier reply is not echoed back");
            check(p.contains("REQUEST") && p.contains("[User] second question"), "request clearly separated from context");
        });

        test("context only advances for requests the provider accepted", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("a");
            check(f.part("chatgpt").contextSeq == 0, "SILENT (never accepted) leaves context at 0");
            f.c.stop();
            f.a.behavior = MockProvider.Behavior.REPLY;
            f.c.submitUserMessage("b");
            check(f.part("chatgpt").contextSeq > 0, "accepted request advances context");
        });

        test("store: createDelivery idempotent, transition is compare-and-set, atomic rolls back", () -> {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.ensureRoom(ROOM, 1L);
            RoomMessage m = s.appendMessage(ROOM, "m1", "USER", "user", "x", null, 1L);
            Delivery d1 = s.createDelivery("d1", ROOM, m.id, "chatgpt", m.seq, 1L);
            Delivery d2 = s.createDelivery("d2", ROOM, m.id, "chatgpt", m.seq, 2L);
            check(d1.id.equals(d2.id), "same (trigger, provider) returns the same delivery");
            check(s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 2L), "PENDING -> SENDING");
            check(!s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 3L), "second PENDING -> SENDING is refused");
            try {
                s.atomic(() -> { s.appendMessage(ROOM, "m2", "USER", "user", "y", null, 2L); throw new IllegalStateException("boom"); });
            } catch (IllegalStateException expected) { }
            check(s.getMessage("m2") == null, "rolled back: m2 does not exist");
            check(s.appendMessage(ROOM, "m3", "USER", "user", "z", null, 3L).seq == 2, "seq not consumed by the rolled-back insert");
        });

        test("stop mid-run marks the delivery UNCERTAIN and dispatches nothing further", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("long task");
            check(f.c.isBusy(), "busy while waiting");
            check(f.c.submitUserMessage("interrupt") == null, "a second message is refused while busy");
            f.c.stop();
            check(!f.c.isBusy(), "not busy after stop");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "active delivery UNCERTAIN");
            check(f.b.prompts.isEmpty(), "Claude was never asked");
            check(f.count("USER") == 1, "only the first user message exists");
        });

        test("participant removed mid-run is skipped without a crash", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.onSend = p -> { if (f.a.prompts.size() == 1) f.c.removeParticipant("claude"); };
            f.c.submitUserMessage("go");
            check(f.b.prompts.isEmpty(), "Claude's review turn was skipped");
            check(f.count("PROVIDER") >= 1 && !f.c.isBusy(), "run completed");
        });

        test("empty reply is UNCERTAIN, not stored, and ends the run", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.EMPTY_REPLY;
            f.c.submitUserMessage("hi");
            check(f.count("PROVIDER") == 0, "blank reply not stored");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "delivery UNCERTAIN");
        });

        test("no enabled participants: the user message is still saved", () -> {
            Fixture f = new Fixture();
            f.c.removeParticipant("chatgpt");
            f.c.removeParticipant("claude");
            RoomMessage m = f.c.submitUserMessage("anyone there?");
            check(m != null && f.count("USER") == 1, "user message persisted");
            check(f.finished.size() == 1 && f.finished.get(0).startsWith("no enabled"), "run reports nobody to answer");
        });

        System.out.println("\n" + checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
