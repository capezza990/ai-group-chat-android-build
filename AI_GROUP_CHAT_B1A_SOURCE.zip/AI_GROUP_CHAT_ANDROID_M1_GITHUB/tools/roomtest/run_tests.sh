#!/usr/bin/env bash
# Runs the canonical-room core tests (pure Java) and the SQLite schema tests.
# Needs a JDK. The Android stub jar is only needed because ProviderBinding references android classes;
# none of them is called by the tests. Override with ANDROID_JAR=/path/to/android.jar.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../../app/src/main/java"
ANDROID_JAR="${ANDROID_JAR:-/usr/share/java/com.android.android-23.jar}"
OUT="$(mktemp -d)"
javac -encoding UTF-8 -d "$OUT" -cp "$ANDROID_JAR" -sourcepath "$SRC" \
  "$SRC"/com/aigroupchat/bridge/room/*.java "$HERE/RoomControllerTest.java"
java -cp "$OUT:$ANDROID_JAR" RoomControllerTest
python3 "$HERE/schema_test.py"
