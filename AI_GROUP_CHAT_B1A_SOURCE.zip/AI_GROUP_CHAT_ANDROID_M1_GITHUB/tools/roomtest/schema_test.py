"""Applies the real assets/room_schema_v1.sql to SQLite and checks the constraints the Java code relies on."""
import os, sqlite3, sys

schema_path = os.path.join(os.path.dirname(__file__), "..", "..", "app", "src", "main", "assets", "room_schema_v1.sql")
schema = open(schema_path, encoding="utf-8").read().replace("\r\n", "\n")
db = sqlite3.connect(":memory:", isolation_level=None)  # autocommit: explicit BEGIN/ROLLBACK below
db.execute("PRAGMA foreign_keys=ON")
for stmt in schema.split("\n-- @@\n"):
    if stmt.strip():
        db.execute(stmt.strip())

fails = 0
def check(ok, what):
    global fails
    if not ok:
        fails += 1
        print("    FAIL:", what)

def raises(sql, args=()):
    try:
        db.execute(sql, args)
        return False
    except sqlite3.DatabaseError:
        return True

db.execute("INSERT INTO rooms(id, routing_mode, created_at) VALUES ('r','AUTO_PICK',1)")
db.execute("INSERT INTO messages(id, room_id, author_type, author_id, text, created_at) VALUES ('m1','r','USER','user','hi',1)")
db.execute("INSERT INTO messages(id, room_id, author_type, author_id, text, created_at) VALUES ('m2','r','PROVIDER','chatgpt','yo',2)")
seqs = [r[0] for r in db.execute("SELECT seq FROM messages ORDER BY seq")]
check(seqs == [1, 2], "AUTOINCREMENT seq is monotonic")
check(raises("INSERT INTO messages(id, room_id, author_type, author_id, text, created_at) VALUES ('m1','r','USER','user','dup',3)"), "duplicate message id rejected")
check(raises("UPDATE messages SET text='edited' WHERE id='m1'"), "messages are append-only (update blocked)")
check(raises("DELETE FROM messages WHERE id='m1'"), "messages are append-only (delete blocked)")
check(raises("INSERT INTO messages(id, room_id, author_type, author_id, text, created_at) VALUES ('m3','nope','USER','user','x',3)"), "foreign key: unknown room rejected")
check(raises("INSERT INTO messages(id, room_id, author_type, author_id, text, created_at) VALUES ('m4','r','ROBOT','x','x',3)"), "author_type CHECK")
db.execute("INSERT INTO deliveries(id, room_id, trigger_message_id, provider_id, upto_seq, state, created_at, updated_at) VALUES ('d1','r','m1','chatgpt',1,'PENDING',1,1)")
check(raises("INSERT INTO deliveries(id, room_id, trigger_message_id, provider_id, upto_seq, state, created_at, updated_at) VALUES ('d2','r','m1','chatgpt',1,'PENDING',1,1)"), "UNIQUE(trigger_message_id, provider_id)")
db.execute("INSERT INTO deliveries(id, room_id, trigger_message_id, provider_id, upto_seq, state, created_at, updated_at) VALUES ('d3','r','m1','claude',1,'PENDING',1,1)")
check(raises("INSERT INTO deliveries(id, room_id, trigger_message_id, provider_id, upto_seq, state, created_at, updated_at) VALUES ('d4','r','ghost','claude',1,'PENDING',1,1)"), "foreign key: unknown trigger message rejected")
check(raises("UPDATE deliveries SET state='WEIRD' WHERE id='d1'"), "state CHECK")
cur = db.execute("UPDATE deliveries SET state='SENDING' WHERE id='d1' AND state IN ('PENDING')")
check(cur.rowcount == 1, "CAS PENDING->SENDING applies once")
cur = db.execute("UPDATE deliveries SET state='SENDING' WHERE id='d1' AND state IN ('PENDING')")
check(cur.rowcount == 0, "second CAS matches nothing")
db.execute("INSERT INTO participants(room_id, provider_id, position) VALUES ('r','chatgpt',0)")
db.execute("UPDATE participants SET context_seq=5 WHERE room_id='r' AND provider_id='chatgpt' AND context_seq < 5")
db.execute("UPDATE participants SET context_seq=3 WHERE room_id='r' AND provider_id='chatgpt' AND context_seq < 3")
check(db.execute("SELECT context_seq FROM participants").fetchone()[0] == 5, "context_seq never moves backwards")
check(raises("INSERT INTO participants(room_id, provider_id, position) VALUES ('ghost','x',0)"), "foreign key: participant needs a room")
n = db.execute("UPDATE deliveries SET state='UNCERTAIN' WHERE state IN ('SENDING','SENT')").rowcount
check(n == 1, "markInFlightUncertain statement")
db.execute("BEGIN")
db.execute("INSERT INTO messages(id, room_id, author_type, author_id, text, created_at) VALUES ('m9','r','USER','user','tx',9)")
db.execute("ROLLBACK")
check(db.execute("SELECT COUNT(*) FROM messages WHERE id='m9'").fetchone()[0] == 0, "transaction rollback removes the insert")
db.execute("INSERT INTO provider_bindings(provider_id, conversation_id, restore_locator, bound_at) VALUES ('claude','c','https://claude.ai/chat/c',1)")
db.execute("INSERT OR REPLACE INTO provider_bindings(provider_id, conversation_id, restore_locator, display_title, bound_at) VALUES ('claude','c2','https://claude.ai/chat/c2','t',2)")
check(db.execute("SELECT conversation_id FROM provider_bindings").fetchone()[0] == "c2", "binding upsert")
print("%s  SQLite schema (%s)" % ("PASS" if fails == 0 else "FAIL", "all constraints hold" if fails == 0 else "%d failures" % fails))
sys.exit(1 if fails else 0)
