from __future__ import annotations
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

required_files = [
    'settings.gradle',
    'build.gradle',
    'app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/res/xml/accessibility_service_config.xml',
    'app/src/main/java/com/aigroupchat/bridge/MainActivity.java',
    'app/src/main/java/com/aigroupchat/bridge/BridgeAccessibilityService.java',
    'app/src/main/java/com/aigroupchat/bridge/RelayCoordinator.java',
]

for rel in required_files:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'MISSING: {rel}')

for rel in [
    'app/src/main/AndroidManifest.xml',
    'app/src/main/res/xml/accessibility_service_config.xml',
    'app/src/main/res/values/strings.xml',
    'app/src/main/res/values/styles.xml',
]:
    ET.parse(ROOT / rel)

all_text = ''
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.java', '.xml', '.gradle', '.ps1', '.bat'}:
        all_text += p.read_text(errors='ignore') + '\n'

for needle in [
    'com.openai.chatgpt',
    'com.anthropic.claude',
    'BIND_ACCESSIBILITY_SERVICE',
    'canRetrieveWindowContent',
    'TYPE_ACCESSIBILITY_OVERLAY',
    'COLLABORATE',
    'STOP',
]:
    assert needle in all_text, f'Missing required wiring: {needle}'

for forbidden in ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'sk-proj-', 'sk-ant-']:
    assert forbidden not in all_text, f'Unexpected secret/API-key marker: {forbidden}'

print('Project structure PASS')
print('XML parse PASS')
print('Required wiring PASS')
print('No API-key configuration PASS')
