package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Deterministic fake AI for the test harness and the UI milestone. No network, no accounts. */
public final class MockProvider implements RoomProvider {
    public enum Behavior { REPLY, FAIL_BEFORE_SEND, FAIL_AFTER_ACCEPT, DUPLICATE_REPLY, LATE_DUPLICATE, NEVER_REPLY, SILENT, EMPTY_REPLY }

    public interface Scheduler {
        void post(Runnable r, long delayMs);
        Scheduler IMMEDIATE = (r, d) -> r.run();
    }

    private final String id, name;
    private final Scheduler scheduler;
    public volatile Behavior behavior = Behavior.REPLY;
    public volatile long delayMs;
    public volatile Consumer<String> onSend; // test hook: runs synchronously inside send(), before any callback
    public final List<String> prompts = Collections.synchronizedList(new ArrayList<>());
    private volatile boolean cancelled;
    private int n;

    public MockProvider(String id, String name, Scheduler scheduler) { this.id = id; this.name = name; this.scheduler = scheduler; }

    /** Deterministic, readable reply: "<Name> reply #k [role] re: <start of the request>". */
    private String replyText(String prompt, int k) {
        String role = "answer";
        if (prompt.contains("review this message critically")) role = "review";
        else if (prompt.contains("revise your earlier answer")) role = "revise";
        else if (prompt.contains("answer independently")) role = "independent";
        String request = "";
        int i = prompt.lastIndexOf("REQUEST (");
        if (i >= 0) {
            int nl = prompt.indexOf('\n', i);
            if (nl >= 0) request = prompt.substring(nl + 1).replaceAll("^\\[[^\\]]*\\]\\s*", "").replace('\n', ' ').trim();
        }
        if (request.length() > 40) request = request.substring(0, 40) + "…";
        return name + " reply #" + k + " [" + role + "]" + (request.isEmpty() ? "" : " re: " + request);
    }

    @Override public String id() { return id; }
    @Override public String displayName() { return name; }
    @Override public Set<String> capabilities() { return Collections.singleton("GENERAL"); }
    @Override public boolean isAvailable() { return true; }
    @Override public void cancel() { cancelled = true; }

    @Override
    public void send(String prompt, Listener l) {
        final int k;
        synchronized (this) { k = ++n; }
        cancelled = false;
        prompts.add(prompt);
        Consumer<String> hook = onSend;
        if (hook != null) hook.accept(prompt);
        scheduler.post(() -> {
            if (cancelled) return;
            switch (behavior) {
                case FAIL_BEFORE_SEND:
                    l.onError("mock refused before send", false);
                    break;
                case SILENT:       // no callback at all: the delivery stays SENDING
                    break;
                case NEVER_REPLY:  // accepted, but the reply never arrives: the delivery stays SENT
                    l.onAccepted(id + "-u" + k);
                    break;
                case EMPTY_REPLY:
                    l.onAccepted(id + "-u" + k);
                    l.onReply("   ", id + "-a" + k);
                    break;
                case FAIL_AFTER_ACCEPT:
                    l.onAccepted(id + "-u" + k);
                    l.onError("mock lost the reply", true);
                    break;
                case DUPLICATE_REPLY:
                    l.onAccepted(id + "-u" + k);
                    l.onReply(replyText(prompt, k), id + "-a" + k);
                    l.onReply(replyText(prompt, k), id + "-a" + k);
                    l.onAccepted(id + "-u" + k);
                    break;
                case LATE_DUPLICATE: { // a correct reply, then the SAME reply again later (after the run has moved on)
                    final String text = replyText(prompt, k);
                    l.onAccepted(id + "-u" + k);
                    l.onReply(text, id + "-a" + k);
                    scheduler.post(() -> { if (!cancelled) l.onReply(text, id + "-a" + k); }, delayMs + 2500L);
                    break;
                }
                case REPLY:
                default:
                    l.onAccepted(id + "-u" + k);
                    l.onReply(replyText(prompt, k), id + "-a" + k);
                    break;
            }
        }, delayMs);
    }
}
