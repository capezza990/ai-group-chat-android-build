package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** The AIs the room knows how to add. The room UI reads this list instead of hard-coding two providers:
 *  adding an entry here is all it takes for "+ Add AI" to offer it. In B1B every entry is backed by a MockProvider. */
public final class ProviderCatalog {
    public static final class Entry {
        public final String id, name, note;
        Entry(String id, String name, String note) { this.id = id; this.name = name; this.note = note; }
    }

    private static final List<Entry> ENTRIES;
    static {
        List<Entry> l = new ArrayList<>();
        l.add(new Entry("chatgpt", "ChatGPT", "mock"));
        l.add(new Entry("claude", "Claude", "mock"));
        l.add(new Entry("gemini", "Gemini", "mock placeholder"));
        l.add(new Entry("mock-delta", "Mock Delta", "extra mock AI"));
        ENTRIES = Collections.unmodifiableList(l);
    }

    private ProviderCatalog() {}

    public static List<Entry> all() { return ENTRIES; }

    public static String nameOf(String id) {
        for (Entry e : ENTRIES) if (e.id.equals(id)) return e.name;
        return id;
    }
}
