package com.aigroupchat.bridge.room.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Round participant avatar (glyph placeholder, no brand artwork) with an optional status dot. */
final class AvatarView extends View {
    private final ProviderStyle style;
    private int dotColor;
    private boolean showDot;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyphPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();

    AvatarView(Context c, ProviderStyle style, boolean showDot, int dotColor) {
        super(c);
        this.style = style;
        this.showDot = showDot;
        this.dotColor = dotColor;
        fill.setColor(style.avatarBg);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(0x33FFFFFF);
        glyphPaint.setColor(style.glyphColor);
        glyphPaint.setTextAlign(Paint.Align.CENTER);
        dotPaint.setColor(dotColor);
        dotRing.setStyle(Paint.Style.STROKE);
        dotRing.setColor(0xFF0A0F1C);
    }

    void setDotColor(int color) { dotColor = color; dotPaint.setColor(color); invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = Math.min(w, h) / 2f - 1f;
        float cx = w / 2f, cy = h / 2f;
        canvas.drawCircle(cx, cy, r, fill);
        ring.setStrokeWidth(Math.max(1f, r * 0.05f));
        canvas.drawCircle(cx, cy, r, ring);
        if (style.glyph == null) { // person silhouette for "You"
            canvas.save();
            clip.reset();
            clip.addCircle(cx, cy, r - 1f, Path.Direction.CW);
            canvas.clipPath(clip);
            Paint p = glyphPaint;
            canvas.drawCircle(cx, cy - r * 0.18f, r * 0.30f, p);
            canvas.drawOval(new RectF(cx - r * 0.62f, cy + r * 0.22f, cx + r * 0.62f, cy + r * 1.15f), p);
            canvas.restore();
        } else {
            glyphPaint.setTextSize(r * 1.05f);
            Paint.FontMetrics fm = glyphPaint.getFontMetrics();
            canvas.drawText(style.glyph, cx, cy - (fm.ascent + fm.descent) / 2f, glyphPaint);
        }
        if (showDot) {
            float dr = Math.max(4f, r * 0.24f);
            float dx = cx + r * 0.72f, dy = cy + r * 0.72f;
            dotRing.setStrokeWidth(Math.max(2f, dr * 0.45f));
            canvas.drawCircle(dx, dy, dr, dotRing);
            canvas.drawCircle(dx, dy, dr, dotPaint);
        }
    }
}
