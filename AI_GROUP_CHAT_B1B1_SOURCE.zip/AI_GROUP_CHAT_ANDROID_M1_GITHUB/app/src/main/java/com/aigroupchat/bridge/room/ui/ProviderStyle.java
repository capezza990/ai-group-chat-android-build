package com.aigroupchat.bridge.room.ui;

/** Version 3 look per participant. Identity colors only: green/yellow/red STATUS dots are a separate concept. */
final class ProviderStyle {
    final int accent, cardColor, cardStroke, avatarBg, glyphColor;
    final String glyph; // null = draw the person silhouette (the user)

    private ProviderStyle(int accent, int cardColor, int cardStroke, int avatarBg, String glyph, int glyphColor) {
        this.accent = accent; this.cardColor = cardColor; this.cardStroke = cardStroke;
        this.avatarBg = avatarBg; this.glyph = glyph; this.glyphColor = glyphColor;
    }

    static ProviderStyle of(String key) {
        switch (key == null ? "" : key) {
            case "user":
                return new ProviderStyle(0xFF8AB4F8, 0xFF123A78, 0xFF2A5AA8, 0xFF1E3A66, null, 0xFF7FB2FF);
            case "chatgpt":
                return new ProviderStyle(0xFFEDEFF3, 0xFF1A2130, 0xFF2A3347, 0xFF161C28, "\u273A", 0xFFFFFFFF);
            case "claude":
                return new ProviderStyle(0xFFFF9B62, 0xFF3A2314, 0xFF5A3720, 0xFFE8743B, "\u273B", 0xFFFFFFFF);
            case "gemini":
                return new ProviderStyle(0xFFB794F6, 0xFF1E2050, 0xFF34388A, 0xFF171A3B, "\u2726", 0xFF8AB4F8);
            case "mock-delta":
                return new ProviderStyle(0xFF5FD7C8, 0xFF10373A, 0xFF1D5E60, 0xFF0F4B4A, "\u25C6", 0xFF5FD7C8);
            default:
                return new ProviderStyle(0xFFCBD0D8, 0xFF1F2430, 0xFF2E3544, 0xFF232A38, "\u25CF", 0xFFCBD0D8);
        }
    }
}
