package com.aigroupchat.bridge.room.ui;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aigroupchat.bridge.room.Delivery;
import com.aigroupchat.bridge.room.DeliveryState;
import com.aigroupchat.bridge.room.MockProvider;
import com.aigroupchat.bridge.room.ProviderCatalog;
import com.aigroupchat.bridge.room.RoomController;
import com.aigroupchat.bridge.room.RoomMessage;
import com.aigroupchat.bridge.room.RoomParticipant;
import com.aigroupchat.bridge.room.RoomSettings;
import com.aigroupchat.bridge.room.RoutingMode;
import com.aigroupchat.bridge.room.ScrollFollow;
import com.aigroupchat.bridge.room.sqlite.RoomDb;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * B1B.1: the shared room in the frozen "Version 3" look, on the same canonical SQLite room and MockProvider logic that
 * passed on-device in B1B. Behavior is unchanged; this class only presents it. The transcript is append-only, so rows are
 * added incrementally from RoomDb and never rebuilt.
 */
public class RoomActivity extends Activity {
    private static final String PREFS = "room_b1b";
    private static final String KEY_ROOM = "room_id";
    private static final String KEY_RAIL_COMPACT = "rail_compact";
    private static final String DEFAULT_MOCK_ROOM = "mock-room";

    private static final String[] MODE_LABELS = {"Single AI", "Ask everyone", "Collaborate", "Auto (first available)"};
    private static final RoutingMode[] MODES = {RoutingMode.SINGLE, RoutingMode.ASK_ALL, RoutingMode.COLLABORATE, RoutingMode.AUTO_PICK};
    private static final String[] ROUND_LABELS = {"1 review round", "2 review rounds"};
    private static final String[] BEHAVIOR_LABELS = {"Normal", "Duplicate replies", "Late duplicate (+2.5 s)",
            "Fail before send", "Accepted, never replies", "Silent (no callback)"};
    private static final MockProvider.Behavior[] BEHAVIORS = {MockProvider.Behavior.REPLY, MockProvider.Behavior.DUPLICATE_REPLY,
            MockProvider.Behavior.LATE_DUPLICATE, MockProvider.Behavior.FAIL_BEFORE_SEND, MockProvider.Behavior.NEVER_REPLY,
            MockProvider.Behavior.SILENT};
    private static final String[] DELAY_LABELS = {"Instant", "1.5 s per reply", "4 s per reply"};
    private static final long[] DELAYS = {0L, 1500L, 4000L};

    private static final int BG = 0xFF0A0F1C, RAIL = 0xFF111827, PANEL = 0xFF0D1424, PILL = 0xFF121A2B, LINE = 0xFF1E2A44;
    private static final int TEXT = 0xFFE8EAED, MUTED = 0xFF9AA3B5, BLUE = 0xFF2F7CF6;
    private static final int DOT_READY = 0xFF4ADE80, DOT_WORKING = 0xFFFFC857, DOT_PROBLEM = 0xFFF87171;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final MockProvider.Scheduler scheduler = (r, delay) -> main.postDelayed(r, delay);
    private final Map<String, MockProvider> mocks = new LinkedHashMap<>();
    private final ScrollFollow follow = new ScrollFollow();
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("h:mm a", Locale.getDefault());

    private RoomDb db;
    private RoomController controller;
    private String roomId;
    private String lastSummary = "";
    private String startupNote = "";
    private String undoProviderId;
    private int behaviorIdx = 0, delayIdx = 1;
    private boolean railCompact;

    private TextView subtitleView, undoText, typingText, typingDots, collapseBtn, sendBtn;
    private LinearLayout railPanel, railList, transcriptBox, typingRow, undoBar;
    private ScrollView transcriptScroll;
    private EditText input;
    private View jumpBtn;
    private AvatarView typingAvatar;
    private String typingKey = "";
    private ObjectAnimator dotsAnim;

    private long renderedSeq = 0;
    private View emptyHint;
    private boolean scrollPending;
    private int scrollToken;
    private final Map<Long, View> rows = new HashMap<>();
    private final Map<String, List<AvatarView>> chatAvatars = new HashMap<>();
    private String lastQuery = "";
    private int searchPos = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        roomId = prefs.getString(KEY_ROOM, DEFAULT_MOCK_ROOM);
        railCompact = prefs.getBoolean(KEY_RAIL_COMPACT, false);
        db = RoomDb.get(this);

        controller = new RoomController(db, roomId, new RoomController.Events() {
            @Override public void onMessage(RoomMessage m) { main.post(RoomActivity.this::refreshAll); }
            @Override public void onDelivery(Delivery d) { main.post(RoomActivity.this::refreshAll); }
            @Override public void onRunFinished(String summary) { main.post(() -> runFinished(summary)); }
        });
        for (ProviderCatalog.Entry e : ProviderCatalog.all()) {
            MockProvider m = new MockProvider(e.id, e.name, scheduler);
            m.delayMs = DELAYS[delayIdx];
            mocks.put(e.id, m);
            controller.registerProvider(m);
        }
        if (controller.participants().isEmpty()) { // fresh room: ChatGPT + Claude, collaborate with ChatGPT first
            controller.addParticipant("chatgpt");
            controller.addParticipant("claude");
            controller.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
        }
        int recovered = controller.recoverOnStart();
        if (recovered > 0) startupNote = recovered + " request(s) from the last session were interrupted and marked UNCERTAIN (nothing was resent).";

        setContentView(buildUi());
        refreshAll();
    }

    // ------------------------------------------------------------------ construction (Version 3 layout)

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // header: title + "N members • Shared Room", search, Room tools
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(8), dp(12), dp(6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("AI Group Chat", 22, TEXT, true));
        subtitleView = text("", 12, MUTED, false);
        titles.addView(subtitleView);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView search = new ImageView(this);
        search.setImageResource(android.R.drawable.ic_menu_search);
        search.setColorFilter(TEXT);
        search.setPadding(dp(11), dp(11), dp(11), dp(11));
        search.setBackground(shape(PILL, 22, LINE, 1));
        search.setContentDescription("Search the transcript");
        search.setOnClickListener(v -> showSearchDialog());
        header.addView(search, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setPadding(dp(14), 0, dp(12), 0);
        tools.setBackground(shape(PILL, 22, LINE, 1));
        tools.addView(text("\u2699", 16, TEXT, false));
        TextView toolsLabel = text("  Room tools  \u25BE", 14, TEXT, false);
        tools.addView(toolsLabel);
        tools.setContentDescription("Room tools");
        tools.setOnClickListener(v -> showRoomTools(v));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        tlp.leftMargin = dp(8);
        header.addView(tools, tlp);
        col.addView(header);

        // body: participant rail + chat panel
        LinearLayout body = new LinearLayout(this);
        body.setPadding(dp(8), dp(4), dp(8), dp(4));
        col.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        railPanel = new LinearLayout(this);
        railPanel.setOrientation(LinearLayout.VERTICAL);
        railPanel.setGravity(Gravity.CENTER_HORIZONTAL);
        railPanel.setBackground(shape(RAIL, 22, LINE, 1));
        ScrollView railScroll = new ScrollView(this); // the rail scrolls, so any number of AIs fits without covering the chat
        railScroll.setVerticalScrollBarEnabled(false);
        railScroll.setFocusable(false);
        railList = new LinearLayout(this);
        railList.setOrientation(LinearLayout.VERTICAL);
        railList.setGravity(Gravity.CENTER_HORIZONTAL);
        railScroll.addView(railList);
        railPanel.addView(railScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView add = text("+", 24, MUTED, false);
        add.setGravity(Gravity.CENTER);
        GradientDrawable dashed = new GradientDrawable();
        dashed.setShape(GradientDrawable.OVAL);
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(dp(2), 0xFF3A4766, dp(4), dp(4));
        add.setBackground(dashed);
        add.setContentDescription("Add an AI to this chat");
        add.setOnClickListener(v -> showAddDialog());
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(44), dp(44));
        alp.topMargin = dp(6);
        railPanel.addView(add, alp);
        View divider = new View(this);
        divider.setBackgroundColor(LINE);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(36), dp(1));
        dlp.topMargin = dp(8); dlp.bottomMargin = dp(8);
        railPanel.addView(divider, dlp);
        collapseBtn = text(railCompact ? "\u203A" : "\u2039", 24, TEXT, false);
        collapseBtn.setGravity(Gravity.CENTER);
        collapseBtn.setBackground(shape(PILL, 22, LINE, 1));
        collapseBtn.setContentDescription("Collapse or expand the participant list");
        collapseBtn.setOnClickListener(v -> toggleRail());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(44), dp(44));
        clp.bottomMargin = dp(8);
        railPanel.addView(collapseBtn, clp);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(railCompact ? 58 : 76), ViewGroup.LayoutParams.MATCH_PARENT);
        rlp.rightMargin = dp(6);
        body.addView(railPanel, rlp);

        FrameLayout chatPanel = new FrameLayout(this);
        chatPanel.setBackground(shape(PANEL, 22, LINE, 1));
        body.addView(chatPanel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        LinearLayout chatCol = new LinearLayout(this);
        chatCol.setOrientation(LinearLayout.VERTICAL);
        chatPanel.addView(chatCol, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        transcriptScroll = new ScrollView(this);
        transcriptScroll.setFocusable(false);
        transcriptScroll.setFocusableInTouchMode(false);
        transcriptScroll.setVerticalScrollBarEnabled(false);
        transcriptBox = new LinearLayout(this);
        transcriptBox.setOrientation(LinearLayout.VERTICAL);
        transcriptBox.setPadding(dp(8), dp(8), dp(8), dp(8));
        transcriptScroll.addView(transcriptBox);
        chatCol.addView(transcriptScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // typing indicator (only while an AI is working)
        typingRow = new LinearLayout(this);
        typingRow.setGravity(Gravity.CENTER_VERTICAL);
        typingRow.setPadding(dp(10), dp(4), dp(10), dp(8));
        typingAvatar = new AvatarView(this, ProviderStyle.of(null), false, 0);
        typingRow.addView(typingAvatar, new LinearLayout.LayoutParams(dp(28), dp(28)));
        typingText = text("", 13, TEXT, false);
        typingText.setPadding(dp(8), 0, dp(6), 0);
        typingText.setSingleLine(true);
        typingText.setEllipsize(TextUtils.TruncateAt.END);
        typingRow.addView(typingText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        typingDots = text("\u25CF \u25CF \u25CF", 9, 0xFF6EA8FF, false);
        typingRow.addView(typingDots);
        typingRow.setVisibility(View.GONE);
        chatCol.addView(typingRow);

        // overlays (do not reflow the transcript): undo bar, jump-to-latest
        undoBar = new LinearLayout(this);
        undoBar.setGravity(Gravity.CENTER_VERTICAL);
        undoBar.setBackground(shape(0xF21B2436, 16, 0xFF33415F, 1));
        undoBar.setPadding(dp(14), 0, dp(4), 0);
        undoText = text("", 14, TEXT, false);
        undoBar.addView(undoText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView undoBtn = text("UNDO", 14, 0xFF8AB4F8, true);
        undoBtn.setGravity(Gravity.CENTER);
        undoBtn.setPadding(dp(14), 0, dp(14), 0);
        undoBtn.setOnClickListener(v -> undoRemove());
        undoBar.addView(undoBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        undoBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams ulp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48), Gravity.TOP);
        ulp.setMargins(dp(10), dp(10), dp(10), 0);
        chatPanel.addView(undoBar, ulp);

        TextView jump = text("\u2193", 20, Color.WHITE, true);
        jump.setGravity(Gravity.CENTER);
        jump.setBackground(shape(BLUE, 20, 0, 0));
        jump.setContentDescription("Jump to the newest message");
        jump.setOnClickListener(v -> { follow.onUserSent(); scrollNow(); updateJump(); });
        jump.setVisibility(View.GONE);
        jumpBtn = jump;
        FrameLayout.LayoutParams jlp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM | Gravity.END);
        jlp.setMargins(0, 0, dp(12), dp(52));
        chatPanel.addView(jump, jlp);

        // composer pill: attach, text, send/stop
        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setBackground(shape(PILL, 28, LINE, 1));
        composer.setPadding(dp(12), dp(4), dp(6), dp(4));
        TextView clip = text("\uD83D\uDCCE", 20, MUTED, false);
        clip.setGravity(Gravity.CENTER);
        clip.setContentDescription("Attach");
        clip.setOnClickListener(v -> toast("Attachments arrive in a later build."));
        composer.addView(clip, new LinearLayout.LayoutParams(dp(36), dp(44)));
        input = new EditText(this);
        input.setHint("Message the room\u2026");
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(16);
        input.setMaxLines(5);
        input.setBackground(null);
        input.setPadding(dp(6), dp(8), dp(6), dp(8));
        composer.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        sendBtn = text("\u27A4", 20, Color.WHITE, true);
        sendBtn.setGravity(Gravity.CENTER);
        sendBtn.setBackground(shape(BLUE, 24, 0, 0));
        sendBtn.setOnClickListener(v -> { if (controller.isBusy()) { controller.stop(); refreshAll(); } else send(); });
        composer.addView(sendBtn, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        colp.setMargins(dp(10), dp(4), dp(10), dp(10));
        col.addView(composer, colp);

        // follow policy: following while near the bottom, free reading when scrolled up
        transcriptScroll.setOnScrollChangeListener((v, x, y, ox, oy) -> { follow.onScrolled(isNearBottom()); updateJump(); });
        transcriptBox.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (scrollPending) { scrollPending = false; scrollNow(); }
        });
        transcriptScroll.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (follow.shouldFollowNewContent() && (b - t) != (ob - ot)) scrollNow(); // keyboard opened/closed
        });
        return root;
    }

    // ------------------------------------------------------------------ actions (unchanged behavior from B1B)

    private void send() {
        String text = input.getText().toString();
        if (text.trim().isEmpty()) return;
        follow.onUserSent();
        RoomMessage m = controller.submitUserMessage(text);
        if (m == null) { toast(controller.isBusy() ? "A run is in progress. Wait, or tap Stop." : "Nothing to send."); return; }
        input.setText("");
        refreshAll(); // the user message is already in SQLite, so it is on screen before any mock reply
    }

    private void removeAi(String providerId) {
        controller.removeParticipant(providerId); // one tap, no confirmation: history and binding are kept
        undoProviderId = providerId;
        undoText.setText("Removed " + ProviderCatalog.nameOf(providerId));
        undoBar.setVisibility(View.VISIBLE);
        main.removeCallbacks(hideUndo);
        main.postDelayed(hideUndo, 6000L);
        refreshAll();
    }

    private final Runnable hideUndo = () -> { if (undoBar != null) undoBar.setVisibility(View.GONE); undoProviderId = null; };

    private void undoRemove() {
        if (undoProviderId == null) return;
        controller.addParticipant(undoProviderId); // re-enables the same participant row, context position intact
        main.removeCallbacks(hideUndo);
        hideUndo.run();
        refreshAll();
    }

    private void showAddDialog() {
        List<String> ids = new ArrayList<>(), names = new ArrayList<>(), enabled = new ArrayList<>();
        for (RoomParticipant p : controller.participants()) if (p.enabled) enabled.add(p.providerId);
        for (ProviderCatalog.Entry e : ProviderCatalog.all()) {
            if (enabled.contains(e.id)) continue;
            ids.add(e.id);
            names.add(e.name + "  (" + e.note + ")");
        }
        if (ids.isEmpty()) { toast("Every AI the room knows is already in this chat."); return; }
        new AlertDialog.Builder(this)
                .setTitle("Add an AI to this chat")
                .setItems(names.toArray(new String[0]), (d, which) -> { controller.addParticipant(ids.get(which)); refreshAll(); })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void runFinished(String summary) {
        lastSummary = summary;
        if (!"done".equals(summary)) { // keep an audit line in the canonical room
            db.appendMessage(roomId, "sys-" + UUID.randomUUID(), RoomMessage.SYSTEM, "system", "Run ended early: " + summary, null, System.currentTimeMillis());
        }
        refreshAll();
    }

    private void toggleRail() {
        railCompact = !railCompact;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RAIL_COMPACT, railCompact).apply();
        railPanel.getLayoutParams().width = dp(railCompact ? 58 : 76);
        railPanel.requestLayout();
        collapseBtn.setText(railCompact ? "\u203A" : "\u2039");
        refreshAll();
    }

    // ------------------------------------------------------------------ Room tools (routing, mock test mode, state, ...)

    private void showRoomTools(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 1, 1, "Routing & rounds\u2026");
        menu.getMenu().add(0, 2, 2, "Mock test mode\u2026");
        menu.getMenu().add(0, 3, 3, "Room state\u2026");
        menu.getMenu().add(0, 4, 4, "Copy transcript");
        menu.getMenu().add(0, 5, 5, "New mock room\u2026");
        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: showRoutingDialog(); return true;
                case 2: showMockDialog(); return true;
                case 3: showState(); return true;
                case 4: copyTranscript(); return true;
                case 5: confirmNewRoom(); return true;
                default: return false;
            }
        });
        menu.show();
    }

    private void showRoutingDialog() {
        RoomSettings s = db.getRoom(roomId);
        List<String> ids = new ArrayList<>(), names = new ArrayList<>();
        for (RoomParticipant p : controller.participants()) if (p.enabled) { ids.add(p.providerId); names.add(ProviderCatalog.nameOf(p.providerId)); }
        if (names.isEmpty()) names.add("-");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        int mi = 0;
        for (int i = 0; i < MODES.length; i++) if (MODES[i] == s.mode) mi = i;
        Spinner modeS = dialogSpinner(MODE_LABELS, mi);
        TextView firstL = new TextView(this);
        Spinner firstS = dialogSpinner(names.toArray(new String[0]), Math.max(0, ids.indexOf(s.modeArg)));
        TextView roundsL = new TextView(this);
        roundsL.setText("Review rounds");
        Spinner roundsS = dialogSpinner(ROUND_LABELS, Math.max(0, Math.min(1, s.rounds - 1)));
        TextView modeL = new TextView(this);
        modeL.setText("How the room answers");
        box.addView(modeL); box.addView(modeS); box.addView(firstL); box.addView(firstS); box.addView(roundsL); box.addView(roundsS);
        Runnable vis = () -> {
            RoutingMode m = MODES[modeS.getSelectedItemPosition()];
            boolean picks = m == RoutingMode.SINGLE || m == RoutingMode.COLLABORATE;
            firstL.setText(m == RoutingMode.SINGLE ? "Which AI" : "Who goes first");
            firstL.setVisibility(picks ? View.VISIBLE : View.GONE);
            firstS.setVisibility(picks ? View.VISIBLE : View.GONE);
            roundsL.setVisibility(m == RoutingMode.COLLABORATE ? View.VISIBLE : View.GONE);
            roundsS.setVisibility(m == RoutingMode.COLLABORATE ? View.VISIBLE : View.GONE);
        };
        vis.run();
        modeS.setOnItemSelectedListener(new SimpleSelect(vis));
        new AlertDialog.Builder(this)
                .setTitle("Routing & rounds")
                .setView(box)
                .setPositiveButton("Apply", (d, w) -> {
                    RoutingMode m = MODES[modeS.getSelectedItemPosition()];
                    int fi = firstS.getSelectedItemPosition();
                    boolean picks = m == RoutingMode.SINGLE || m == RoutingMode.COLLABORATE;
                    controller.setRouting(m, picks && fi >= 0 && fi < ids.size() ? ids.get(fi) : "", roundsS.getSelectedItemPosition() + 1);
                    refreshAll();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showMockDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView bl = new TextView(this);
        bl.setText("Mock AI behavior");
        Spinner bs = dialogSpinner(BEHAVIOR_LABELS, behaviorIdx);
        TextView dl = new TextView(this);
        dl.setText("Reply delay");
        Spinner ds = dialogSpinner(DELAY_LABELS, delayIdx);
        box.addView(bl); box.addView(bs); box.addView(dl); box.addView(ds);
        new AlertDialog.Builder(this)
                .setTitle("Mock test mode")
                .setView(box)
                .setPositiveButton("Apply", (d, w) -> {
                    behaviorIdx = bs.getSelectedItemPosition();
                    delayIdx = ds.getSelectedItemPosition();
                    for (MockProvider m : mocks.values()) { m.behavior = BEHAVIORS[behaviorIdx]; m.delayMs = DELAYS[delayIdx]; }
                    toast("Mock: " + BEHAVIOR_LABELS[behaviorIdx] + ", " + DELAY_LABELS[delayIdx]);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmNewRoom() {
        new AlertDialog.Builder(this)
                .setTitle("Start a new mock room?")
                .setMessage("Messages are append-only, so a new room is how you start clean. The current mock room stays in the database.")
                .setPositiveButton("New room", (d, w) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ROOM, "mock-" + System.currentTimeMillis()).apply();
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showState() {
        RoomSettings s = db.getRoom(roomId);
        StringBuilder sb = new StringBuilder();
        sb.append("Room: ").append(roomId).append("\nMessages: ").append(db.latestSeq(roomId))
                .append("\nRouting: ").append(s.mode.name().toLowerCase(Locale.US)).append(s.modeArg.isEmpty() ? "" : " (" + s.modeArg + ")")
                .append(", rounds ").append(s.rounds).append("\n\nParticipants:\n");
        for (RoomParticipant p : controller.participants()) {
            sb.append("\u2022 ").append(ProviderCatalog.nameOf(p.providerId)).append(p.enabled ? "  [in chat]" : "  [removed]")
                    .append("  context up to message ").append(p.contextSeq).append('\n');
        }
        sb.append("\nRequests (this room):\n");
        for (DeliveryState st : DeliveryState.values()) {
            int n = 0;
            for (Delivery d : db.deliveriesInState(st)) if (d.roomId.equals(roomId)) n++;
            if (n > 0) sb.append("\u2022 ").append(st.name()).append(": ").append(n).append('\n');
        }
        if (!lastSummary.isEmpty()) sb.append("\nLast run: ").append(lastSummary).append('\n');
        if (!startupNote.isEmpty()) sb.append('\n').append(startupNote).append('\n');
        new AlertDialog.Builder(this).setTitle("Room state (from SQLite)").setMessage(sb.toString()).setPositiveButton("Close", null).show();
    }

    private void copyTranscript() {
        StringBuilder sb = new StringBuilder();
        for (RoomMessage m : db.messagesBetween(roomId, 0, Long.MAX_VALUE)) {
            sb.append(timeFmt.format(m.createdAt)).append("  ").append(nameOf(m)).append(": ").append(stripMarkers(m.text)).append("\n\n");
        }
        copy(sb.toString().trim());
        toast("Transcript copied");
    }

    private void showSearchDialog() {
        EditText q = new EditText(this);
        q.setHint("Find in this chat");
        q.setSingleLine(true);
        q.setText(lastQuery);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(q);
        new AlertDialog.Builder(this)
                .setTitle("Search")
                .setView(box)
                .setPositiveButton("Find", (d, w) -> doSearch(q.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void doSearch(String query) {
        if (query.isEmpty()) return;
        List<Long> hits = new ArrayList<>();
        String needle = query.toLowerCase(Locale.getDefault());
        for (RoomMessage m : db.messagesBetween(roomId, 0, Long.MAX_VALUE)) {
            if (stripMarkers(m.text).toLowerCase(Locale.getDefault()).contains(needle) && rows.containsKey(m.seq)) hits.add(m.seq);
        }
        if (hits.isEmpty()) { toast("No match for \"" + query + "\""); return; }
        searchPos = query.equals(lastQuery) ? (searchPos + 1) % hits.size() : 0;
        lastQuery = query;
        final View row = rows.get(hits.get(searchPos));
        follow.onScrolled(false); // reading: do not snap back down
        transcriptScroll.smoothScrollTo(0, Math.max(0, row.getTop() - dp(8)));
        row.animate().alpha(0.35f).setDuration(220).withEndAction(() -> row.animate().alpha(1f).setDuration(220).start()).start();
        toast("Match " + (searchPos + 1) + " of " + hits.size() + " (tap Find again for the next)");
    }

    // ------------------------------------------------------------------ rendering (everything is read from RoomDb)

    private void refreshAll() {
        if (db == null || transcriptBox == null) return;
        List<RoomParticipant> ps = controller.participants();
        List<RoomMessage> all = renderedSeq == 0 ? db.messagesBetween(roomId, 0, Long.MAX_VALUE) : null;
        Set<String> problems = providersWithProblems(all);
        String active = controller.activeProviderId();
        boolean busy = controller.isBusy();

        int enabledAis = 0;
        for (RoomParticipant p : ps) if (p.enabled) enabledAis++;
        subtitleView.setText((enabledAis + 1) + " members  \u2022  Shared Room");

        renderRail(ps, active, problems);
        appendNewMessages(all);
        updateChatDots(active, problems);

        sendBtn.setText(busy ? "\u25A0" : "\u27A4");
        sendBtn.setContentDescription(busy ? "Stop" : "Send");
        sendBtn.setBackground(shape(busy ? 0xFFB3475A : BLUE, 24, 0, 0));
        renderTyping(busy, active);
        updateJump();
    }

    /** Red status = a request in the latest run ended FAILED/UNCERTAIN. */
    private Set<String> providersWithProblems(List<RoomMessage> all) {
        Set<String> out = new HashSet<>();
        long lastUser = 0;
        List<RoomMessage> recent = all != null ? all : db.latestMessages(roomId, 40);
        for (RoomMessage m : recent) if (RoomMessage.USER.equals(m.authorType) && m.createdAt > lastUser) lastUser = m.createdAt;
        for (DeliveryState st : new DeliveryState[]{DeliveryState.FAILED, DeliveryState.UNCERTAIN}) {
            for (Delivery d : db.deliveriesInState(st)) if (d.roomId.equals(roomId) && d.updatedAt >= lastUser) out.add(d.providerId);
        }
        return out;
    }

    private int dot(String providerId, String active, Set<String> problems) {
        if (providerId.equals(active)) return DOT_WORKING;
        return problems.contains(providerId) ? DOT_PROBLEM : DOT_READY;
    }

    private void renderRail(List<RoomParticipant> ps, String active, Set<String> problems) {
        railList.removeAllViews();
        railList.addView(railCell("user", "You", null, DOT_READY));
        for (RoomParticipant p : ps) {
            if (p.enabled) railList.addView(railCell(p.providerId, ProviderCatalog.nameOf(p.providerId), p.providerId, dot(p.providerId, active, problems)));
        }
    }

    private View railCell(String key, String label, String removableId, int dotColor) {
        int av = dp(railCompact ? 38 : 46);
        FrameLayout cell = new FrameLayout(this);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER_HORIZONTAL);
        inner.setPadding(0, dp(8), 0, dp(4));
        inner.addView(new AvatarView(this, ProviderStyle.of(key), true, dotColor), new LinearLayout.LayoutParams(av, av));
        if (!railCompact) {
            TextView name = text(label, 11, TEXT, false);
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            inner.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        cell.addView(inner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (removableId != null) { // direct one-tap remove: a 44 dp touch target around a small "−" badge on the avatar
            FrameLayout hit = new FrameLayout(this);
            hit.setContentDescription("Remove " + label + " from this chat");
            hit.setOnClickListener(v -> removeAi(removableId));
            TextView disc = text("\u2212", 15, TEXT, true);
            disc.setGravity(Gravity.CENTER);
            disc.setIncludeFontPadding(false);
            disc.setBackground(shape(0xFF2B3550, 11, 0xFF55648A, 1));
            hit.addView(disc, new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
            cell.addView(hit, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END));
        }
        cell.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return cell;
    }

    /** The transcript is append-only, so only rows newer than what is already drawn are added. */
    private void appendNewMessages(List<RoomMessage> preloaded) {
        List<RoomMessage> fresh = preloaded != null ? preloaded : db.messagesBetween(roomId, renderedSeq, Long.MAX_VALUE);
        if (fresh.isEmpty()) {
            if (renderedSeq == 0 && emptyHint == null) {
                emptyHint = text("Say hello \u2014 the AIs in this chat will answer.", 14, MUTED, false);
                emptyHint.setPadding(dp(8), dp(16), dp(8), 0);
                transcriptBox.addView(emptyHint);
            }
            return;
        }
        if (emptyHint != null) { transcriptBox.removeView(emptyHint); emptyHint = null; }
        boolean wasFollowing = follow.shouldFollowNewContent();
        for (RoomMessage m : fresh) {
            View row = messageRow(m);
            rows.put(m.seq, row);
            transcriptBox.addView(row);
            renderedSeq = Math.max(renderedSeq, m.seq);
        }
        if (wasFollowing) scrollSoon(); // never yanks someone who scrolled up to read
    }

    private View messageRow(RoomMessage m) {
        boolean user = RoomMessage.USER.equals(m.authorType), system = RoomMessage.SYSTEM.equals(m.authorType);
        String body = stripMarkers(m.text);
        if (system) {
            TextView t = text(body, 12, MUTED, false);
            t.setGravity(Gravity.CENTER);
            t.setBackground(shape(0xFF182033, 12, 0, 0));
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_HORIZONTAL;
            lp.topMargin = dp(8); lp.bottomMargin = dp(4);
            t.setLayoutParams(lp);
            return t;
        }
        String key = user ? "user" : m.authorId;
        ProviderStyle st = ProviderStyle.of(key);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(5), 0, dp(5));

        AvatarView av = new AvatarView(this, st, true, DOT_READY);
        chatAvatars.computeIfAbsent(key, k -> new ArrayList<>()).add(av);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(34), dp(34));
        alp.rightMargin = dp(6);
        row.addView(av, alp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(shape(st.cardColor, 18, st.cardStroke, 1));
        card.setPadding(dp(12), dp(8), dp(12), dp(10));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(user ? "You" : ProviderCatalog.nameOf(m.authorId), 14, st.accent, true);
        head.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(text(timeFmt.format(m.createdAt), 11, 0xFF8E98AD, false));
        card.addView(head);
        TextView tv = text(body, 15, TEXT, false);
        tv.setLineSpacing(0f, 1.15f);
        tv.setMaxLines(Integer.MAX_VALUE); // full message, never clipped
        tv.setEllipsize(null);
        tv.setHorizontallyScrolling(false);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(2);
        card.addView(tv, blp);
        card.setOnLongClickListener(v -> { copy(body); toast("Message copied"); return true; });
        row.addView(card, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private void updateChatDots(String active, Set<String> problems) {
        for (Map.Entry<String, List<AvatarView>> e : chatAvatars.entrySet()) {
            int c = e.getKey().equals("user") ? DOT_READY : dot(e.getKey(), active, problems);
            for (AvatarView a : e.getValue()) a.setDotColor(c);
        }
    }

    private void renderTyping(boolean busy, String active) {
        if (!busy) {
            typingRow.setVisibility(View.GONE);
            if (dotsAnim != null) { dotsAnim.cancel(); dotsAnim = null; }
            return;
        }
        String status = controller.runStatus();
        String step = status.contains(":") ? "  (" + status.substring(0, status.indexOf(':')) + ")" : "";
        typingText.setText(active == null ? "Working\u2026" + step : ProviderCatalog.nameOf(active) + " is typing\u2026" + step);
        String key = active == null ? "" : active;
        if (!key.equals(typingKey)) { // show the avatar of whoever is working right now
            typingKey = key;
            typingRow.removeViewAt(0);
            typingAvatar = new AvatarView(this, ProviderStyle.of(active), false, 0);
            typingRow.addView(typingAvatar, 0, new LinearLayout.LayoutParams(dp(28), dp(28)));
        }
        typingAvatar.setVisibility(active == null ? View.INVISIBLE : View.VISIBLE);
        typingRow.setVisibility(View.VISIBLE);
        if (dotsAnim == null) {
            dotsAnim = ObjectAnimator.ofFloat(typingDots, "alpha", 0.25f, 1f);
            dotsAnim.setDuration(550);
            dotsAnim.setRepeatCount(ObjectAnimator.INFINITE);
            dotsAnim.setRepeatMode(ObjectAnimator.REVERSE);
            dotsAnim.start();
        }
        if (follow.shouldFollowNewContent()) scrollSoon();
    }

    // ------------------------------------------------------------------ scrolling (positional: never touches focus)

    private boolean isNearBottom() {
        View c = transcriptScroll.getChildAt(0);
        if (c == null) return true;
        int remaining = c.getBottom() + transcriptScroll.getPaddingBottom() - (transcriptScroll.getScrollY() + transcriptScroll.getHeight());
        return remaining <= dp(72);
    }

    /** New rows are not laid out yet when they are added, so wait for the next layout pass before scrolling. */
    private void scrollSoon() {
        scrollPending = true;
        final int token = ++scrollToken;
        transcriptBox.requestLayout();
        main.postDelayed(() -> { if (token == scrollToken) scrollPending = false; }, 500L);
    }

    private void scrollNow() {
        View c = transcriptScroll.getChildAt(0);
        if (c == null) return;
        int target = Math.max(0, c.getHeight() + transcriptScroll.getPaddingTop() + transcriptScroll.getPaddingBottom() - transcriptScroll.getHeight());
        transcriptScroll.scrollTo(0, target);
    }

    private void updateJump() {
        if (jumpBtn != null) jumpBtn.setVisibility(follow.isFollowing() ? View.GONE : View.VISIBLE);
    }

    // ------------------------------------------------------------------ helpers

    private String nameOf(RoomMessage m) {
        return RoomMessage.USER.equals(m.authorType) ? "You" : RoomMessage.SYSTEM.equals(m.authorType) ? "System" : ProviderCatalog.nameOf(m.authorId);
    }

    /** Routing markers are never part of this product; if one ever appears in text it is hidden from the transcript. */
    static String stripMarkers(String t) {
        return t == null ? "" : t.replaceAll("(?im)^[ \\t]*\\[\\[(NEXT:[A-Z]+|DONE)\\]\\][ \\t]*$\\n?", "").trim();
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("AI Group Chat", s));
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable shape(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private Spinner dialogSpinner(String[] items, int selected) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(selected);
        return s;
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private static final class SimpleSelect implements AdapterView.OnItemSelectedListener {
        private final Runnable action;
        SimpleSelect(Runnable action) { this.action = action; }
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { action.run(); }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    @Override
    protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (dotsAnim != null) dotsAnim.cancel();
        if (controller != null && controller.isBusy()) controller.stop(); // closing mid-run = stop; completed messages stay
        super.onDestroy();
    }
}
