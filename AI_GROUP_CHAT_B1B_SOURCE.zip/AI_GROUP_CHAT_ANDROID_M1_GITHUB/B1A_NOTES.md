# B1a - canonical room foundation (0.12.1-b1a, versionCode 20)

Built on AI_GROUP_CHAT_P1A_FINAL_SOURCE.zip. No Accessibility / M11.7 relay file was touched.
No UI redesign yet (that is B1b). This milestone is the data layer, controller, router and MockProvider.

## New files (com.aigroupchat.bridge.room)
- `DeliveryState`, `RoutingMode`, `RoomSettings`, `RoomMessage`, `RoomParticipant`, `Delivery` - model (pure Java)
- `RoomStore` - persistence contract (atomic(), idempotent appends, compare-and-set transitions)
- `InMemoryRoomStore` - reference implementation used by the JVM test harness
- `RoomRouter` - deterministic provider sequence (legacy-compatible rounds)
- `RoomPromptBuilder` - provider prompt from CANONICAL messages (context vs request, speaker labels)
- `RoomProvider` - provider interface (Listener: onAccepted / onReply / onError(reason, maybeSubmitted))
- `MockProvider` - deterministic fake AI (REPLY, FAIL_BEFORE_SEND, FAIL_AFTER_ACCEPT, DUPLICATE_REPLY, NEVER_REPLY, SILENT, EMPTY_REPLY)
- `RoomController` - persist-before-dispatch, capture-first replies, single-flight run, stop, recovery
- `sqlite/RoomDb` - SQLiteOpenHelper + RoomStore (framework SQLite, no new dependency)
- `sqlite/RoomSelfCheck` - on-device smoke test of the real database (menu: "Room database self-check (B1a)")
- `assets/room_schema_v1.sql` - schema (append-only messages via triggers, UNIQUE ids, foreign keys, CHECKs)
- `tools/roomtest/` - `run_tests.sh`, `RoomControllerTest.java` (61 checks), `schema_test.py` (real SQLite, constraints)

## Changed files
- `engine/ProviderBinding.java` - `Store` now delegates to RoomDb.provider_bindings (single source of truth);
  P1-A SharedPreferences bindings are imported once (legacy prefs left untouched for rollback)
- `MainActivity.java` - one menu item (id 40) for the self-check
- `app/build.gradle` - version 0.12.1-b1a / 20

## Transaction boundaries (RoomController)
1. `submitUserMessage`: one transaction appends the USER message. Nothing is dispatched until it commits.
2. `startStepLocked` (per provider step): ONE transaction does createDelivery (idempotent on trigger+provider),
   CAS PENDING->SENDING, and builds the prompt from the stored messages. Only after it commits is `provider.send` called
   (outside the controller lock). A crash after this commit leaves SENDING -> UNCERTAIN on restart, never an automatic resend.
3. `onAccepted`: CAS SENDING->SENT + record provider user-message id + advance participants.context_seq to the
   delivery's upto_seq (what the prompt actually contained).
4. `onReply`: ONE transaction does CAS SENDING|SENT->CAPTURED, appends the PROVIDER message with the idempotent id
   `reply:<deliveryId>`, records the provider assistant id, links reply_message_id. The next provider is only started
   after this commits, so it always sees the stored reply.
5. `onError(reason, maybeSubmitted)`: SENDING->FAILED if provably not sent, else UNCERTAIN; SENT->UNCERTAIN.
6. Stale, duplicate or late callbacks are ignored (active-delivery check + CAS + idempotent message id).

## Routing state
Run plan is in memory (list of steps + index). Persisted truth = messages + deliveries. After a restart nothing resumes
automatically; UNCERTAIN deliveries wait for a deliberate resync (B3).
COLLABORATE generalizes the legacy relay: 2 AIs, 1 round = propose, review, revise; 2 rounds = 5 steps (clamped at 2).
ASK_ALL steps are INDEPENDENT: their prompts exclude the other AIs' replies (context capped at the user message).

## Not in B1a
UI (B1b), WebRoomProvider / binding flow / auth recovery (B2), mirror verification / branch detection / resync (B3),
capability routing (AUTO_PICK = first enabled for now), attachments.

---
# B1A.1-diag (0.12.2-b1a1-diag, versionCode 21)
DIAGNOSTICS ONLY. The single change is in `RelayCoordinator.evaluateResponseAfterScroll()`: the overlay now shows the detector flags
while waiting, and a SYSTEM line "Detector state at 60s: ..." is written once when the existing 60 s warning fires.
No relay behavior changed; every other legacy file is byte-identical to M11.7.

---
# B1A.2 (0.12.3-b1a2, versionCode 22) - Stop-detection fix for the legacy relay
Cause of the "Waiting for ChatGPT" hang (found with the B1A.1 diagnostics: gen=true while the reply was finished):
`NodeUtils.findLastNodeByExactOrPrefixWords` treated ANY visible text equal to, or starting with, "stop " as ChatGPT's Stop button.
A reply containing a list item such as "Stop during an active mock collaboration;" therefore kept generationAppearsActive() true forever,
so generationDone / turn proof / completion never happened.
Fix: Stop is now found with `NodeUtils.findControlByShortLabel` - label <= 24 chars (pure-Java `LabelMatch`, unit-tested with the strings
from the failing reply) AND the node or one of its 3 nearest ancestors must be clickable. Used by generationAppearsActive() and clickStop().
The B1A.1 overlay stays, and now also shows which control was treated as Stop: gen=true(stop="stop").
Not changed: send/attachment-launcher matching (same helper family; reviewed, left alone to keep this hotfix small).

---
# B1B (0.13.0-b1b, versionCode 23) - shared-room UI on the canonical database, mock AIs only
Built on B1A.2 (Stop-detection fix carried forward). No live WebViews, no accounts, no B2 work.
Uses its own mock room id ("mock-room", "New room" makes "mock-<time>") so the default room stays clean for B2.

## Changed / new files
- NEW  `room/ui/RoomActivity.java` - the room screen (strip with direct "-" per AI, "+ Add AI", routing + rounds, mock test mode, transcript from RoomDb, composer, Send/Stop, Undo bar, State dialog)
- NEW  `room/ProviderCatalog.java` - data-driven list of AIs the room can add (ChatGPT, Claude, Gemini placeholder, Mock Delta)
- EDIT `room/MockProvider.java` - role-aware readable replies; new LATE_DUPLICATE behavior
- EDIT `room/RoomController.java` - `activeProviderId()` and `runStatus()` for the UI
- EDIT `MainActivity.java` - overflow item "Room (B1B, mock AIs)" (id 41)
- EDIT `AndroidManifest.xml` - registers RoomActivity
- EDIT `app/build.gradle` - 0.13.0-b1b / 23
- EDIT `tools/roomtest/RoomControllerTest.java` - +2 tests (73 checks pass), run via tools/roomtest/run_tests.sh
