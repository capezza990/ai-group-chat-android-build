package com.aigroupchat.bridge.room.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aigroupchat.bridge.room.Delivery;
import com.aigroupchat.bridge.room.DeliveryState;
import com.aigroupchat.bridge.room.MockProvider;
import com.aigroupchat.bridge.room.ProviderCatalog;
import com.aigroupchat.bridge.room.RoomController;
import com.aigroupchat.bridge.room.RoomMessage;
import com.aigroupchat.bridge.room.RoomParticipant;
import com.aigroupchat.bridge.room.RoomSettings;
import com.aigroupchat.bridge.room.RoutingMode;
import com.aigroupchat.bridge.room.sqlite.RoomDb;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * B1B: the shared-room UI on the canonical SQLite room, with MockProvider participants only (no WebViews, no accounts).
 * It uses its own mock room id so the default room stays clean for the live providers in B2.
 * Every row on screen is read back from RoomDb; the UI keeps no transcript state of its own.
 */
public class RoomActivity extends Activity {
    private static final String PREFS = "room_b1b";
    private static final String KEY_ROOM = "room_id";
    private static final String DEFAULT_MOCK_ROOM = "mock-room";

    private static final String[] MODE_LABELS = {"Single AI", "Ask everyone", "Collaborate", "Auto (first available)"};
    private static final RoutingMode[] MODES = {RoutingMode.SINGLE, RoutingMode.ASK_ALL, RoutingMode.COLLABORATE, RoutingMode.AUTO_PICK};
    private static final String[] ROUND_LABELS = {"1 review round", "2 review rounds"};
    private static final String[] BEHAVIOR_LABELS = {"Normal", "Duplicate replies", "Late duplicate (+2.5 s)",
            "Fail before send", "Accepted, never replies", "Silent (no callback)"};
    private static final MockProvider.Behavior[] BEHAVIORS = {MockProvider.Behavior.REPLY, MockProvider.Behavior.DUPLICATE_REPLY,
            MockProvider.Behavior.LATE_DUPLICATE, MockProvider.Behavior.FAIL_BEFORE_SEND, MockProvider.Behavior.NEVER_REPLY,
            MockProvider.Behavior.SILENT};
    private static final String[] DELAY_LABELS = {"Instant", "1.5 s per reply", "4 s per reply"};
    private static final long[] DELAYS = {0L, 1500L, 4000L};

    private static final int TEXT = 0xFFE8EAED, MUTED = 0xFF9AA0A6, PANEL = 0xFF1B1F24, BG = 0xFF111418;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final MockProvider.Scheduler scheduler = (r, delay) -> main.postDelayed(r, delay);
    private final Map<String, MockProvider> mocks = new LinkedHashMap<>();

    private RoomDb db;
    private RoomController controller;
    private String roomId;
    private String lastSummary = "";
    private String startupNote = "";
    private String undoProviderId;
    private boolean suppressSpinners;
    private boolean firstRender = true;

    private LinearLayout strip, transcriptBox, undoBar;
    private ScrollView transcriptScroll;
    private TextView statusView, undoText, firstLabel;
    private Spinner modeSp, firstSp, roundsSp;
    private EditText input;
    private Button sendBtn, stopBtn;
    private final List<String> firstIds = new ArrayList<>();
    private List<String> lastFirstNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        roomId = prefs.getString(KEY_ROOM, DEFAULT_MOCK_ROOM);
        db = RoomDb.get(this);

        controller = new RoomController(db, roomId, new RoomController.Events() {
            @Override public void onMessage(RoomMessage m) { main.post(RoomActivity.this::refreshAll); }
            @Override public void onDelivery(Delivery d) { main.post(RoomActivity.this::refreshAll); }
            @Override public void onRunFinished(String summary) { main.post(() -> runFinished(summary)); }
        });
        for (ProviderCatalog.Entry e : ProviderCatalog.all()) {
            MockProvider m = new MockProvider(e.id, e.name, scheduler);
            m.delayMs = 1500L;
            mocks.put(e.id, m);
            controller.registerProvider(m);
        }
        if (controller.participants().isEmpty()) { // fresh room: ChatGPT + Claude, collaborate with ChatGPT first
            controller.addParticipant("chatgpt");
            controller.addParticipant("claude");
            controller.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
        }
        int recovered = controller.recoverOnStart();
        if (recovered > 0) startupNote = recovered + " request(s) from the last session were interrupted and marked UNCERTAIN (nothing was resent).";

        setContentView(buildUi());
        refreshAll();
    }

    // ------------------------------------------------------------------ UI construction

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });

        // title + state / new-room tools
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("AI Group Chat — Room (B1B, mock AIs)", 15, TEXT, true);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(smallButton("State", v -> showState()));
        titleRow.addView(smallButton("New room", v -> confirmNewRoom()));
        titleRow.setPadding(dp(12), dp(8), dp(8), 0);
        root.addView(titleRow);

        // "In this chat" strip with direct − buttons and + Add AI
        root.addView(label("In this chat", 12, MUTED, false), pad(dp(12), dp(6), dp(12), 0));
        LinearLayout stripRow = new LinearLayout(this);
        stripRow.setGravity(Gravity.CENTER_VERTICAL);
        HorizontalScrollView stripScroll = new HorizontalScrollView(this);
        stripScroll.setHorizontalScrollBarEnabled(false);
        strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        stripScroll.addView(strip);
        stripRow.addView(stripScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button add = smallButton("+ Add AI", v -> showAddDialog());
        stripRow.addView(add);
        stripRow.setPadding(dp(8), 0, dp(8), 0);
        root.addView(stripRow);

        // routing controls (mirror the legacy bridge: who answers, who goes first, how many review rounds)
        LinearLayout routeRow = new LinearLayout(this);
        routeRow.setGravity(Gravity.CENTER_VERTICAL);
        routeRow.setPadding(dp(8), dp(4), dp(8), 0);
        modeSp = spinner(MODE_LABELS);
        firstLabel = label("First:", 12, MUTED, false);
        firstSp = spinner(new String[]{"-"});
        roundsSp = spinner(ROUND_LABELS);
        routeRow.addView(modeSp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f));
        routeRow.addView(firstLabel);
        routeRow.addView(firstSp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        routeRow.addView(roundsSp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f));
        root.addView(routeRow);
        AdapterView.OnItemSelectedListener routingListener = new SimpleSelect(this::applyRouting);
        modeSp.setOnItemSelectedListener(routingListener);
        firstSp.setOnItemSelectedListener(routingListener);
        roundsSp.setOnItemSelectedListener(routingListener);

        // mock test mode (to exercise duplicate/late callbacks, failures and Stop on a phone)
        LinearLayout testRow = new LinearLayout(this);
        testRow.setGravity(Gravity.CENTER_VERTICAL);
        testRow.setPadding(dp(8), 0, dp(8), 0);
        testRow.addView(label("Mock:", 12, MUTED, false));
        Spinner behaviorSp = spinner(BEHAVIOR_LABELS);
        Spinner delaySp = spinner(DELAY_LABELS);
        delaySp.setSelection(1);
        testRow.addView(behaviorSp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
        testRow.addView(delaySp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(testRow);
        behaviorSp.setOnItemSelectedListener(new SimpleSelect(() -> {
            for (MockProvider m : mocks.values()) m.behavior = BEHAVIORS[behaviorSp.getSelectedItemPosition()];
        }));
        delaySp.setOnItemSelectedListener(new SimpleSelect(() -> {
            for (MockProvider m : mocks.values()) m.delayMs = DELAYS[delaySp.getSelectedItemPosition()];
        }));

        statusView = label("", 12, MUTED, false);
        root.addView(statusView, pad(dp(12), dp(4), dp(12), dp(2)));

        // undo bar for the one-tap remove
        undoBar = new LinearLayout(this);
        undoBar.setGravity(Gravity.CENTER_VERTICAL);
        undoBar.setBackgroundColor(0xFF2B3138);
        undoBar.setPadding(dp(12), 0, dp(4), 0);
        undoText = label("", 13, TEXT, false);
        undoBar.addView(undoText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        undoBar.addView(smallButton("Undo", v -> undoRemove()));
        undoBar.setVisibility(View.GONE);
        root.addView(undoBar);

        // transcript (always re-read from the database)
        transcriptScroll = new ScrollView(this);
        transcriptScroll.setFocusable(false);
        transcriptScroll.setFocusableInTouchMode(false);
        transcriptBox = new LinearLayout(this);
        transcriptBox.setOrientation(LinearLayout.VERTICAL);
        transcriptBox.setPadding(dp(8), dp(4), dp(8), dp(8));
        transcriptScroll.addView(transcriptBox);
        root.addView(transcriptScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // composer
        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(8), dp(4), dp(8), dp(8));
        input = new EditText(this);
        input.setHint("Message the room…");
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setMaxLines(5);
        input.setBackgroundColor(PANEL);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        composer.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        stopBtn = button("Stop", v -> { controller.stop(); refreshAll(); });
        sendBtn = button("Send", v -> send());
        composer.addView(stopBtn);
        composer.addView(sendBtn);
        root.addView(composer);
        return root;
    }

    // ------------------------------------------------------------------ actions

    private void send() {
        String text = input.getText().toString();
        if (text.trim().isEmpty()) return;
        RoomMessage m = controller.submitUserMessage(text);
        if (m == null) { toast(controller.isBusy() ? "A run is in progress. Wait, or tap Stop." : "Nothing to send."); return; }
        input.setText("");
        refreshAll(); // the user message is already in SQLite, so it is on screen before any mock reply
    }

    private void removeAi(String providerId) {
        controller.removeParticipant(providerId); // one tap, no confirmation: history and binding are kept
        undoProviderId = providerId;
        undoText.setText("Removed " + ProviderCatalog.nameOf(providerId) + " from this chat");
        undoBar.setVisibility(View.VISIBLE);
        main.removeCallbacks(hideUndo);
        main.postDelayed(hideUndo, 6000L);
        refreshAll();
    }

    private final Runnable hideUndo = () -> { if (undoBar != null) undoBar.setVisibility(View.GONE); undoProviderId = null; };

    private void undoRemove() {
        if (undoProviderId == null) return;
        controller.addParticipant(undoProviderId); // re-enables the same participant row, context position intact
        main.removeCallbacks(hideUndo);
        hideUndo.run();
        refreshAll();
    }

    private void showAddDialog() {
        List<String> ids = new ArrayList<>(), names = new ArrayList<>();
        List<String> enabled = new ArrayList<>();
        for (RoomParticipant p : controller.participants()) if (p.enabled) enabled.add(p.providerId);
        for (ProviderCatalog.Entry e : ProviderCatalog.all()) {
            if (enabled.contains(e.id)) continue;
            ids.add(e.id);
            names.add(e.name + "  (" + e.note + ")");
        }
        if (ids.isEmpty()) { toast("Every AI the room knows is already in this chat."); return; }
        new AlertDialog.Builder(this)
                .setTitle("Add an AI to this chat")
                .setItems(names.toArray(new String[0]), (d, which) -> { controller.addParticipant(ids.get(which)); refreshAll(); })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void applyRouting() {
        if (suppressSpinners) return;
        RoutingMode mode = MODES[modeSp.getSelectedItemPosition()];
        int fi = firstSp.getSelectedItemPosition();
        String arg = (mode == RoutingMode.SINGLE || mode == RoutingMode.COLLABORATE) && fi >= 0 && fi < firstIds.size() ? firstIds.get(fi) : "";
        int rounds = roundsSp.getSelectedItemPosition() + 1;
        RoomSettings cur = db.getRoom(roomId);
        // Spinner callbacks fire asynchronously, also after our own setSelection(): without this check they would
        // write the same value back and trigger another refresh forever.
        if (cur != null && cur.mode == mode && cur.modeArg.equals(arg) && cur.rounds == rounds) return;
        controller.setRouting(mode, arg, rounds);
        main.post(this::refreshAll);
    }

    private void runFinished(String summary) {
        lastSummary = summary;
        if (!"done".equals(summary)) { // keep an audit line in the canonical room
            db.appendMessage(roomId, "sys-" + UUID.randomUUID(), RoomMessage.SYSTEM, "system", "Run ended early: " + summary, null, System.currentTimeMillis());
        }
        refreshAll();
    }

    private void confirmNewRoom() {
        new AlertDialog.Builder(this)
                .setTitle("Start a new mock room?")
                .setMessage("Messages are append-only, so a new room is how you start clean. The current mock room stays in the database.")
                .setPositiveButton("New room", (d, w) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ROOM, "mock-" + System.currentTimeMillis()).apply();
                    recreate();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showState() {
        StringBuilder sb = new StringBuilder();
        sb.append("Room: ").append(roomId).append("\nMessages: ").append(db.latestSeq(roomId)).append("\n\nParticipants:\n");
        for (RoomParticipant p : controller.participants()) {
            sb.append("• ").append(ProviderCatalog.nameOf(p.providerId)).append(p.enabled ? "  [in chat]" : "  [removed]")
                    .append("  context up to message ").append(p.contextSeq).append('\n');
        }
        sb.append("\nRequests (this room):\n");
        for (DeliveryState st : DeliveryState.values()) {
            int n = 0;
            for (Delivery d : db.deliveriesInState(st)) if (d.roomId.equals(roomId)) n++;
            if (n > 0) sb.append("• ").append(st.name()).append(": ").append(n).append('\n');
        }
        new AlertDialog.Builder(this).setTitle("Room state (from SQLite)").setMessage(sb.toString()).setPositiveButton("Close", null).show();
    }

    // ------------------------------------------------------------------ rendering (all state comes from RoomDb)

    private void refreshAll() {
        if (db == null || strip == null) return;
        List<RoomParticipant> ps = controller.participants();
        RoomSettings settings = db.getRoom(roomId);
        renderStrip(ps);
        renderRouting(ps, settings);
        renderTranscript();
        boolean busy = controller.isBusy();
        sendBtn.setEnabled(!busy);
        stopBtn.setVisibility(busy ? View.VISIBLE : View.GONE);
        String top = busy ? "Running — " + controller.runStatus()
                : (lastSummary.isEmpty() ? "Idle" : "Last run: " + lastSummary);
        statusView.setText(top + (startupNote.isEmpty() ? "" : "\n" + startupNote));
    }

    private void renderStrip(List<RoomParticipant> ps) {
        strip.removeAllViews();
        String active = controller.activeProviderId();
        int shown = 0;
        for (RoomParticipant p : ps) {
            if (!p.enabled) continue;
            shown++;
            LinearLayout chip = new LinearLayout(this);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(PANEL);
            bg.setCornerRadius(dp(20));
            chip.setBackground(bg);
            chip.setPadding(dp(12), 0, 0, 0);
            boolean working = p.providerId.equals(active);
            TextView name = label("● " + ProviderCatalog.nameOf(p.providerId) + (working ? " — working…" : ""), 14, TEXT, false);
            name.setTextColor(TEXT);
            chip.addView(name);
            Button minus = new Button(this);
            minus.setText("−");
            minus.setTextSize(22);
            minus.setAllCaps(false);
            minus.setTextColor(TEXT);
            minus.setBackgroundColor(0x00000000);
            minus.setMinWidth(dp(48));
            minus.setMinimumWidth(dp(48));
            minus.setMinHeight(dp(48));
            minus.setMinimumHeight(dp(48));
            minus.setContentDescription("Remove " + ProviderCatalog.nameOf(p.providerId) + " from this chat");
            minus.setOnClickListener(v -> removeAi(p.providerId));
            chip.addView(minus, new LinearLayout.LayoutParams(dp(48), dp(48)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            strip.addView(chip, lp);
        }
        if (shown == 0) strip.addView(label("No AI in this chat. Tap + Add AI.", 13, MUTED, false));
    }

    private void renderRouting(List<RoomParticipant> ps, RoomSettings s) {
        suppressSpinners = true;
        try {
            int mi = 0;
            for (int i = 0; i < MODES.length; i++) if (MODES[i] == s.mode) mi = i;
            modeSp.setSelection(mi);
            firstIds.clear();
            List<String> names = new ArrayList<>();
            for (RoomParticipant p : ps) if (p.enabled) { firstIds.add(p.providerId); names.add(ProviderCatalog.nameOf(p.providerId)); }
            if (names.isEmpty()) names.add("-");
            if (!names.equals(lastFirstNames)) { // only rebuild when the set of AIs changed
                firstSp.setAdapter(adapter(names.toArray(new String[0])));
                lastFirstNames = names;
            }
            int fi = firstIds.indexOf(s.modeArg);
            firstSp.setSelection(fi < 0 ? 0 : fi);
            roundsSp.setSelection(Math.max(0, Math.min(1, s.rounds - 1)));
            boolean picksAi = s.mode == RoutingMode.SINGLE || s.mode == RoutingMode.COLLABORATE;
            firstLabel.setText(s.mode == RoutingMode.SINGLE ? "Who:" : "First:");
            firstLabel.setVisibility(picksAi ? View.VISIBLE : View.GONE);
            firstSp.setVisibility(picksAi ? View.VISIBLE : View.GONE);
            roundsSp.setVisibility(s.mode == RoutingMode.COLLABORATE ? View.VISIBLE : View.GONE);
        } finally {
            main.post(() -> suppressSpinners = false); // spinner callbacks fire asynchronously after setSelection
        }
    }

    private void renderTranscript() {
        View content = transcriptScroll.getChildAt(0);
        boolean nearBottom = firstRender || content.getBottom() - (transcriptScroll.getScrollY() + transcriptScroll.getHeight()) < dp(140);
        transcriptBox.removeAllViews();
        List<RoomMessage> msgs = db.messagesBetween(roomId, 0, Long.MAX_VALUE);
        if (msgs.isEmpty()) transcriptBox.addView(label("Send a message to start. Replies come from mock AIs.", 13, MUTED, false), pad(dp(4), dp(12), 0, 0));
        for (RoomMessage m : msgs) transcriptBox.addView(bubble(m));
        if (nearBottom) {
            firstRender = false;
            transcriptBox.post(() -> transcriptScroll.scrollTo(0, transcriptBox.getBottom())); // positional: never steals composer focus
        }
    }

    private View bubble(RoomMessage m) {
        boolean user = RoomMessage.USER.equals(m.authorType), system = RoomMessage.SYSTEM.equals(m.authorType);
        String who = user ? "You" : system ? "System" : ProviderCatalog.nameOf(m.authorId);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(user ? 0xFF1F3A5F : system ? 0xFF262A30 : PANEL);
        bg.setCornerRadius(dp(10));
        box.setBackground(bg);
        box.setPadding(dp(10), dp(6), dp(10), dp(8));
        TextView head = label(who + "  ·  #" + m.seq, 11, system ? MUTED : accent(m.authorId, user), true);
        TextView body = label(stripMarkers(m.text), 15, system ? MUTED : TEXT, false);
        box.addView(head);
        box.addView(body);
        final String copy = stripMarkers(m.text);
        box.setOnLongClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("message", copy));
            toast("Message copied");
            return true;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        box.setLayoutParams(lp);
        return box;
    }

    /** Routing markers are never part of this product; if one ever appears in text it is hidden from the transcript. */
    static String stripMarkers(String t) {
        return t == null ? "" : t.replaceAll("(?im)^[ \\t]*\\[\\[(NEXT:[A-Z]+|DONE)\\]\\][ \\t]*$\\n?", "").trim();
    }

    private static int accent(String providerId, boolean user) {
        if (user) return 0xFF8AB4F8;
        int[] colors = {0xFF81C995, 0xFFF28B82, 0xFFFDD663, 0xFFC58AF9, 0xFF78D9EC};
        int i = 0;
        for (ProviderCatalog.Entry e : ProviderCatalog.all()) { if (e.id.equals(providerId)) break; i++; }
        return colors[i % colors.length];
    }

    // ------------------------------------------------------------------ small view helpers

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static LinearLayout.LayoutParams pad(int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(l, t, r, b);
        return lp;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private Button smallButton(String text, View.OnClickListener l) {
        Button b = button(text, l);
        b.setTextSize(13);
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        return b;
    }

    private ArrayAdapter<String> adapter(String[] items) {
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(TEXT);
                t.setTextSize(13);
                return t;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent);
                t.setTextColor(TEXT);
                t.setBackgroundColor(0xFF2B3138);
                t.setPadding(dp(12), dp(10), dp(12), dp(10));
                return t;
            }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    private Spinner spinner(String[] items) {
        Spinner s = new Spinner(this);
        s.setAdapter(adapter(items));
        return s;
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    /** Fires the action on every real selection change (programmatic changes are filtered by the caller). */
    private static final class SimpleSelect implements AdapterView.OnItemSelectedListener {
        private final Runnable action;
        SimpleSelect(Runnable action) { this.action = action; }
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { action.run(); }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    @Override
    protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (controller != null && controller.isBusy()) controller.stop(); // closing mid-run = stop; completed messages stay
        super.onDestroy();
    }
}
