package com.aigroupchat.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public abstract class AppAdapter {
    public abstract String packageName();
    public abstract String displayName();

    protected abstract String[] sendWords();
    protected abstract String[] stopWords();
    protected abstract String[] newChatWords();
    protected abstract String[] composerHints();
    /** Strict hints that identify a composer inside an existing provider conversation. */
    protected String[] existingConversationComposerHints() { return new String[0]; }
    /** Strict hints that identify the provider's blank/new-conversation composer. */
    protected String[] blankConversationComposerHints() { return new String[0]; }
    protected abstract String[] attachmentLauncherWords();
    protected abstract String[] responseActionDescriptions();
    protected abstract String[] ignoredReplyTexts();

    public boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName());
        if (intent == null) return false;
        // IMPORTANT: normal launch only. Do not use ACTION_SEND here. ACTION_SEND lets the
        // provider choose a destination and ChatGPT was observed creating a brand-new chat.
        // REORDER_TO_FRONT asks Android to bring the provider's existing activity/task state
        // forward when possible instead of constructing another launcher instance. The relay still
        // verifies the conversation before touching the composer; this flag is only a preservation aid.
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        context.startActivity(intent);
        return true;
    }

    /**
     * M11.1 in-thread attachment spike.
     *
     * Keep the already-open provider conversation active, put each content URI on the
     * clipboard temporarily, focus that conversation's mapped composer, and ask the
     * composer to paste the rich clipboard item. This is deliberately conservative:
     * if the native composer does not accept URI paste, we return false and the relay
     * stops before any associated text is sent. Most importantly, this path never fires
     * ACTION_SEND and therefore never grants permission to create a new provider chat.
     */
    public boolean pasteSharedAttachmentsIntoCurrentComposer(
            AccessibilityService service,
            List<AttachmentRecord> attachments) {
        if (attachments == null || attachments.isEmpty()) return true;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        if (composer == null) return false;

        ClipboardManager clipboard = (ClipboardManager) service.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) return false;
        ClipData previous = null;
        try {
            if (clipboard.hasPrimaryClip()) previous = clipboard.getPrimaryClip();
        } catch (Exception ignored) {}

        boolean allAccepted = true;
        try {
            for (AttachmentRecord attachment : attachments) {
                Uri uri = attachment.uri();
                try {
                    service.grantUriPermission(packageName(), uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                ClipData clip = ClipData.newUri(
                        service.getContentResolver(),
                        attachment.displayName == null ? "AI Group Chat attachment" : attachment.displayName,
                        uri);
                clipboard.setPrimaryClip(clip);
                composer.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                NodeUtils.click(composer);
                boolean accepted = composer.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                allAccepted &= accepted;
                if (!accepted) break;
            }
        } catch (Exception e) {
            allAccepted = false;
        } finally {
            try {
                if (previous != null) clipboard.setPrimaryClip(previous);
                else clipboard.setPrimaryClip(ClipData.newPlainText("", ""));
            } catch (Exception ignored) {}
        }
        return allAccepted;
    }

    public boolean composerHasSharedAttachments(AccessibilityService service, List<AttachmentRecord> attachments) {
        if (attachments == null || attachments.isEmpty()) return true;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;

        int namedMatches = 0;
        for (AttachmentRecord a : attachments) {
            if (NodeUtils.treeContainsVisibleText(root, a.displayName)) namedMatches++;
        }
        if (namedMatches == attachments.size()) return true;

        // Many native image chips hide the original filename but expose one Remove action
        // per attachment. This is safer than matching the generic "Attachment" add button,
        // which exists even when the composer is empty.
        return NodeUtils.countVisibleAttachmentRemovalControls(root) >= attachments.size();
    }

    public boolean clickNativeAttachmentLauncher(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findLastNodeByExactOrPrefixWords(root, attachmentLauncherWords());
        if (node == null) node = NodeUtils.findClickableByWords(root, attachmentLauncherWords());
        return node != null && NodeUtils.click(node);
    }

    public boolean clickNativeFileSourceIfVisible(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root,
                "files", "file", "upload file", "choose file", "documents", "document");
        return node != null && NodeUtils.click(node);
    }

    public boolean clickPickerItemByName(AccessibilityService service, String displayName) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null || displayName == null || displayName.trim().isEmpty()) return false;
        AccessibilityNodeInfo node = NodeUtils.findAnyByWords(root, displayName);
        return node != null && NodeUtils.click(node);
    }

    public boolean providerIsForeground(AccessibilityService service) {
        return isActive(service.getRootInActiveWindow());
    }

    /**
     * M11.5 conversation guard. A package match and a visible EditText are not enough: the
     * provider may have opened its blank/new-chat screen. These checks use strict composer hints
     * and existing response actions as evidence without ever clicking New Chat.
     */
    public boolean looksLikeBlankNewConversation(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        String[] blankHints = blankConversationComposerHints();
        if (blankHints == null || blankHints.length == 0) return false;
        boolean blankComposer = NodeUtils.hasEditableNearHintsStrict(root, blankHints);
        // An existing thread can occasionally expose changed placeholder wording. A visible
        // provider response action is stronger evidence that conversation history exists.
        boolean hasVisibleResponse = NodeUtils.countVisibleContentDescriptionExact(
                root, responseActionDescriptions()) > 0;
        return blankComposer && !hasVisibleResponse;
    }

    public boolean hasExistingConversationEvidence(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        String[] existingHints = existingConversationComposerHints();
        if (existingHints != null && existingHints.length > 0
                && NodeUtils.hasEditableNearHintsStrict(root, existingHints)) return true;
        return NodeUtils.countVisibleContentDescriptionExact(root, responseActionDescriptions()) > 0;
    }

    public boolean visibleConversationMatchesReply(AccessibilityService service, String expectedReply) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        return isActive(root) && NodeUtils.visibleTextMatchesReplyAnchor(root, expectedReply);
    }

    public boolean isActive(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null && packageName().contentEquals(root.getPackageName());
    }

    protected AccessibilityNodeInfo findComposer(AccessibilityNodeInfo root) {
        if (!isActive(root)) return null;
        return NodeUtils.findEditableNearHints(root, composerHints());
    }

    public boolean fillComposer(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        return composer != null && NodeUtils.setText(composer, text);
    }

    public boolean composerContains(AccessibilityService service, String text) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        AccessibilityNodeInfo composer = findComposer(root);
        if (composer == null || TextUtils.isEmpty(composer.getText())) return false;
        return NodeUtils.normalize(composer.getText().toString()).equals(NodeUtils.normalize(text));
    }

    public boolean composerHasAutoPastedAttachment(AccessibilityService service) {
        return false;
    }

    public boolean clickSend(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastNodeByExactOrPrefixWords(root, sendWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean sendAppearsComplete(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo composer = findComposer(root);
        boolean composerStillContainsExactSentText = composer != null
                && !TextUtils.isEmpty(composer.getText())
                && NodeUtils.normalize(String.valueOf(composer.getText())).equals(NodeUtils.normalize(sentText));
        if (composerStillContainsExactSentText) return false;
        if (NodeUtils.treeHasExactNonEditableText(root, sentText)) return true;
        return composer != null;
    }

    public boolean hasSentMessageAnchor(AccessibilityService service, String sentText) {
        if (sentText == null || sentText.trim().isEmpty()) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        return isActive(root) && NodeUtils.treeHasExactNonEditableText(root, sentText);
    }

    public int responseActionCount(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return 0;
        return NodeUtils.countVisibleContentDescriptionExact(root, responseActionDescriptions());
    }

    public String captureLatestAnchoredReply(AccessibilityService service, String sentText) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return "";
        return NodeUtils.extractLatestResponseAnchored(root, sentText, responseActionDescriptions(), ignoredReplyTexts());
    }

    public int scrollConversationTowardBottomResult(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return -1;
        return NodeUtils.scrollLargestContainerForwardResult(root);
    }

    public int visibleFingerprint(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return 0;
        return NodeUtils.visibleTextFingerprint(root);
    }

    public boolean scrollConversationTowardBottom(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.scrollLargestContainerForward(root);
    }

    public boolean copyControlVisible(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.findLastByContentDescriptionExact(root, responseActionDescriptions()) != null;
    }

    public boolean clickCopyLatestResponse(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findLastByContentDescriptionExact(root, responseActionDescriptions());
        return labelled != null && NodeUtils.click(labelled);
    }

    public boolean clickStop(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo labelled = NodeUtils.findControlByShortLabel(root, STOP_LABEL_MAX_CHARS, stopWords());
        return labelled != null && NodeUtils.click(labelled);
    }

    /** A real Stop control has a label like "Stop" / "Stop generating"; reply text starting with "Stop ..." is longer. */
    protected static final int STOP_LABEL_MAX_CHARS = 24;

    public boolean generationAppearsActive(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        return NodeUtils.findControlByShortLabel(root, STOP_LABEL_MAX_CHARS, stopWords()) != null;
    }

    /** B1A.2 diagnostics: the short label of the control currently treated as "Stop", or "-". */
    public String stopControlLabel(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return "-";
        AccessibilityNodeInfo n = NodeUtils.findControlByShortLabel(root, STOP_LABEL_MAX_CHARS, stopWords());
        if (n == null) return "-";
        String l = LabelMatch.norm(NodeUtils.combinedText(n));
        return l.length() > STOP_LABEL_MAX_CHARS ? l.substring(0, STOP_LABEL_MAX_CHARS) : l;
    }

    public boolean tryNewChat(AccessibilityService service) {
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (!isActive(root)) return false;
        AccessibilityNodeInfo node = NodeUtils.findClickableByWords(root, newChatWords());
        return node != null && NodeUtils.click(node);
    }
}
