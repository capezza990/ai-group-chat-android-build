package com.aigroupchat.bridge;

import java.util.Locale;

/** Pure-Java label matching (unit-tested off-device). Used to recognise short control labels such as "Stop". */
public final class LabelMatch {
    private LabelMatch() {}

    public static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.US).replaceAll("\\s+", " ").trim();
    }

    /**
     * True only if the whole label is short (<= maxLen after normalizing) AND equals one of the words or starts with
     * "word ". Long text that merely BEGINS with the word, e.g. a reply list item "Stop during a run -> ...", never matches.
     */
    public static boolean matchesShort(String label, int maxLen, String... words) {
        String hay = norm(label);
        if (hay.isEmpty() || hay.length() > maxLen) return false;
        for (String word : words) {
            String w = norm(word);
            if (w.isEmpty()) continue;
            if (hay.equals(w) || hay.startsWith(w + " ")) return true;
        }
        return false;
    }
}
