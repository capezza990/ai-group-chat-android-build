package com.aigroupchat.bridge.room;

/** Tracks how long the APP (not a web page) has been in the background. Pure Java, unit-tested. */
public final class BackgroundTracker {
    private boolean foreground = true;
    private long backgroundStart;
    private long accumulated;

    public synchronized void setForeground(boolean fg, long now) {
        if (fg == foreground) return;
        if (!fg) backgroundStart = now;
        else accumulated += now - backgroundStart;
        foreground = fg;
    }

    public synchronized boolean isForeground() { return foreground; }

    /** Total milliseconds spent in the background so far, including an interval that is still open. */
    public synchronized long totalBackgroundMs(long now) { return accumulated + (foreground ? 0 : now - backgroundStart); }
}
