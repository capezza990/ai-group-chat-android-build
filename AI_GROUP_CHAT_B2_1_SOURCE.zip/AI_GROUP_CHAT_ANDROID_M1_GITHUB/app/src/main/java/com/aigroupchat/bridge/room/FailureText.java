package com.aigroupchat.bridge.room;

import java.util.Locale;

/**
 * Turns raw provider diagnostics (which can contain whole JSON payloads) into one short, human-readable clause.
 * Only this short text may reach the canonical room, the database error column and future provider prompts;
 * the full diagnostic goes to the debug log. Pure Java, unit-tested.
 */
public final class FailureText {
    private FailureText() {}

    public static String shorten(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "failed";
        String r = raw.trim();
        String l = r.toLowerCase(Locale.US);
        if (l.startsWith("timeout after")) return "timed out while waiting for the reply";
        if (l.contains("unhealthy provider surface")) return "page isn't ready";
        if (l.startsWith("could not settle")) return "couldn't open its connected conversation";
        if (l.startsWith("composer already holds text")) return "message box already has text";
        if (l.startsWith("provider is busy")) return "is still busy generating";
        if (l.startsWith("engine unavailable")) return "page script isn't available";
        if (l.startsWith("no bound conversation")) return "isn't connected to a conversation";
        if (l.startsWith("renderer gone")) return "page crashed";
        if (l.startsWith("conversation changed")) return "page moved to a different conversation";
        if (l.startsWith("send failed") || l.startsWith("send refused")) {
            int i = r.indexOf(':');
            String code = i >= 0 ? r.substring(i + 1).trim() : "";
            int brace = code.indexOf('{');
            if (brace >= 0) code = code.substring(0, brace).trim();
            return code.isEmpty() ? "couldn't send" : "couldn't send (" + code + ")";
        }
        if (l.equals("cancelled")) return "cancelled";
        int brace = r.indexOf('{');
        if (brace > 0) r = r.substring(0, brace).trim();
        else if (brace == 0) return "failed";
        while (r.endsWith(":") || r.endsWith(";")) r = r.substring(0, r.length() - 1).trim();
        if (r.length() > 100) r = r.substring(0, 100).trim();
        return r.isEmpty() ? "failed" : r;
    }
}
