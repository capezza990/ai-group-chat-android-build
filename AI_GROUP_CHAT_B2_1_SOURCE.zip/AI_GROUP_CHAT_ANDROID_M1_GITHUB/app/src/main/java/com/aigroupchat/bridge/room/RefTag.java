package com.aigroupchat.bridge.room;

import java.util.regex.Pattern;

/** The short unique tag placed at the start of each prompt SENT TO A PROVIDER PAGE so the page can find our own message.
 *  It exists only on the provider page: canonical room messages never contain it, and it is stripped from any echoed reply. */
public final class RefTag {
    public static final Pattern PATTERN = Pattern.compile("\\[ref [0-9a-f]{6}\\]\\s*");

    private RefTag() {}

    public static String tag(String nonce, String text) { return "[ref " + nonce + "] " + text; }

    public static String strip(String text) { return text == null ? "" : PATTERN.matcher(text).replaceAll(""); }
}
