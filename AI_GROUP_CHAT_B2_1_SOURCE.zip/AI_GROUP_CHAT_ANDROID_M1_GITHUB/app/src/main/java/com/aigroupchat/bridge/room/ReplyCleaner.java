package com.aigroupchat.bridge.room;

import java.util.regex.Pattern;

/** Cleans a reply read from a provider page before it becomes a canonical room message (pure Java, unit-tested). */
public final class ReplyCleaner {
    /** A hidden screen-reader block some pages expose: "<Name> said:" / "Claude responded: <start of the reply>" on its own first line. */
    private static final Pattern HEADING = Pattern.compile(
            "^(?:ChatGPT|Claude|Gemini|Assistant)\\s+(?:said|responded|replied|wrote)\\s*:?[ \\t]*([^\\n]*)\\n+([\\s\\S]*)$", Pattern.CASE_INSENSITIVE);

    private static final Pattern INVISIBLE = Pattern.compile("[\\u200B-\\u200D\\u2060\\uFEFF]");

    private ReplyCleaner() {}

    public static String clean(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\r\n", "\n").replace('\r', '\n');
        s = INVISIBLE.matcher(s).replaceAll("");
        s = RefTag.strip(s); // an echoed prompt tag never reaches the canonical room
        s = s.trim();
        java.util.regex.Matcher m = HEADING.matcher(s);
        if (m.matches()) { // drop the hidden heading line; keep the real reply (or, if nothing follows, the heading's own text)
            String rest = m.group(2).trim();
            s = rest.isEmpty() ? m.group(1).trim() : rest;
        }
        s = s.replaceAll("\\n{3,}", "\n\n");
        return s.trim();
    }
}
