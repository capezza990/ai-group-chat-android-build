package com.aigroupchat.bridge.room;

import java.util.regex.Pattern;

/**
 * The legacy bridge's routing-marker line. Tolerates harmless trailing decoration that Accessibility can append
 * (for example a circled digit after a file reference) but still requires a valid marker ALONE on its line:
 * "see [[NEXT:CLAUDE]]" and "[[NEXT:CLAUDE]] and some words" are rejected.
 */
public final class RoutingMarkers {
    public static final Pattern PATTERN = Pattern.compile(
            "(?im)^[\\t \\u00A0]*\\[\\[(NEXT:CHATGPT|NEXT:CLAUDE|NEXT:USER|DONE)\\]\\][\\t \\u00A0]*"
                    + "(?:[\\p{So}\\p{No}\\p{Sk}\\p{Cf}\\uFE0F][\\t \\u00A0]*){0,4}$");

    private RoutingMarkers() {}
}
