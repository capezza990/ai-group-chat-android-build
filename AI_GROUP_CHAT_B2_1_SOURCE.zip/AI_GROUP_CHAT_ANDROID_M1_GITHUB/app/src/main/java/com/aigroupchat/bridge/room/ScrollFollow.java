package com.aigroupchat.bridge.room;

/**
 * Transcript follow policy (pure Java, unit-tested): follow new content while the user is at the bottom, never yank
 * someone who scrolled up to read, and always follow again after the user sends a message or returns near the bottom.
 */
public final class ScrollFollow {
    private boolean following = true;

    /** Called whenever the scroll position changes; nearBottom is computed by the view. */
    public void onScrolled(boolean nearBottom) { following = nearBottom; }

    /** The user sent a message: jump to and follow the conversation again. */
    public void onUserSent() { following = true; }

    public boolean shouldFollowNewContent() { return following; }

    public boolean isFollowing() { return following; }
}
