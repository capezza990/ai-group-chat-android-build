package com.aigroupchat.bridge.room;

/** What a participant's status dot means. Red is reserved for real failures; a stop or removal by the user is neutral. */
public final class StatusRules {
    public enum Status { READY, WORKING, PROBLEM, NEUTRAL, NOT_CONNECTED }

    private StatusRules() {}

    /** Errors the user (or the app lifecycle) caused on purpose: never a failure. */
    public static boolean isNeutralInterruption(String error) {
        return error != null && (error.startsWith("stopped by user") || error.startsWith("participant removed")
                || error.startsWith("interrupted (app restart)"));
    }

    public static boolean isRealFailure(DeliveryState state, String error) {
        return state == DeliveryState.FAILED || (state == DeliveryState.UNCERTAIN && !isNeutralInterruption(error));
    }

    public static boolean isNeutralStop(DeliveryState state, String error) {
        return state == DeliveryState.UNCERTAIN && isNeutralInterruption(error);
    }

    public static Status of(boolean working, boolean connected, boolean realProblem, boolean neutralStop) {
        if (working) return Status.WORKING;
        if (!connected) return Status.NOT_CONNECTED;
        if (realProblem) return Status.PROBLEM;
        if (neutralStop) return Status.NEUTRAL;
        return Status.READY;
    }
}
