package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;

/** In-transcript search (pure Java, unit-tested): case-insensitive, non-overlapping matches, wrap-around navigation. */
public final class TranscriptSearch {
    public static final class Match {
        public final long seq;
        public final int start, end;
        public Match(long seq, int start, int end) { this.seq = seq; this.start = start; this.end = end; }
    }

    private TranscriptSearch() {}

    public static List<Match> find(List<RoomMessage> msgs, String query, Function<RoomMessage, String> textOf) {
        List<Match> out = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) return out;
        String needle = query.trim().toLowerCase(Locale.ROOT);
        for (RoomMessage m : msgs) {
            String hay = textOf.apply(m);
            if (hay == null) continue;
            String lower = hay.toLowerCase(Locale.ROOT);
            if (lower.length() != hay.length()) continue; // case mapping changed the length: skip rather than mis-highlight
            int from = 0, i;
            while ((i = lower.indexOf(needle, from)) >= 0) {
                out.add(new Match(m.seq, i, i + needle.length()));
                from = i + needle.length();
            }
        }
        return out;
    }

    public static int next(int current, int size) { return size == 0 ? -1 : (current + 1) % size; }

    public static int prev(int current, int size) { return size == 0 ? -1 : (current <= 0 ? size - 1 : current - 1); }
}
