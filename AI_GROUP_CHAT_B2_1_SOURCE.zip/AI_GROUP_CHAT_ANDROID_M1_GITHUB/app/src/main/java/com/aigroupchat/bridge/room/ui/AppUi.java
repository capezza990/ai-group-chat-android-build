package com.aigroupchat.bridge.room.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** App-owned dark/rounded dialogs, menus and option controls (replace the stock gray Android ones). */
final class AppUi {
    static final int CARD = 0xFF121A2B, STROKE = 0xFF2A3656, TEXT = 0xFFE8EAED, MUTED = 0xFF9AA3B5, BLUE = 0xFF2F7CF6, ROW = 0xFF182238;

    private AppUi() {}

    static int dp(Context c, float v) { return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics())); }

    static GradientDrawable shape(Context c, int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** A ScrollView that never grows past maxPx, so tall dialog content scrolls instead of leaving the screen. */
    static final class MaxHeightScroll extends ScrollView {
        private final int maxPx;
        MaxHeightScroll(Context c, int maxPx) { super(c); this.maxPx = maxPx; setVerticalScrollBarEnabled(false); }
        @Override protected void onMeasure(int w, int h) { super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST)); }
    }

    /** Dark rounded dialog: title, optional message, custom content, and text buttons. */
    static final class AppDialog {
        private final Activity act;
        private final Dialog dialog;
        private final LinearLayout card;
        private final LinearLayout content;
        private final LinearLayout buttons;

        AppDialog(Activity a) {
            act = a;
            dialog = new Dialog(a, android.R.style.Theme_Translucent_NoTitleBar);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            FrameLayout root = new FrameLayout(a);
            root.setBackgroundColor(0xAA000000);
            root.setOnClickListener(v -> dialog.dismiss());
            card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(shape(a, CARD, 24, STROKE, 1));
            card.setPadding(dp(a, 20), dp(a, 18), dp(a, 20), dp(a, 12));
            card.setClickable(true);
            content = new LinearLayout(a);
            content.setOrientation(LinearLayout.VERTICAL);
            buttons = new LinearLayout(a);
            buttons.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            int maxW = Math.min(a.getResources().getDisplayMetrics().widthPixels - dp(a, 40), dp(a, 420));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(maxW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
            root.addView(card, lp);
            dialog.setContentView(root);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        AppDialog title(String t) {
            TextView v = text(act, t, 18, TEXT, true);
            v.setPadding(0, 0, 0, dp(act, 10));
            card.addView(v, 0);
            return this;
        }

        AppDialog message(String m) {
            TextView v = text(act, m, 14, MUTED, false);
            v.setLineSpacing(0f, 1.15f);
            content.addView(v);
            return this;
        }

        AppDialog content(View v) { content.addView(v); return this; }

        /** Scrollable monospace-ish text block (state dumps etc.). */
        AppDialog scrollText(String s) {
            MaxHeightScroll sc = new MaxHeightScroll(act, act.getResources().getDisplayMetrics().heightPixels / 2);
            TextView t = text(act, s, 13, TEXT, false);
            t.setTypeface(Typeface.MONOSPACE);
            t.setLineSpacing(0f, 1.1f);
            sc.addView(t);
            content.addView(sc);
            return this;
        }

        AppDialog button(String label, boolean primary, Runnable action) {
            TextView b = text(act, label, 14, primary ? Color.WHITE : MUTED, primary);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(act, 16), 0, dp(act, 16), 0);
            if (primary) b.setBackground(shape(act, BLUE, 18, 0, 0));
            b.setOnClickListener(v -> { dialog.dismiss(); if (action != null) action.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(act, 40));
            lp.leftMargin = dp(act, 8);
            buttons.addView(b, lp);
            return this;
        }

        void show() {
            card.addView(content);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            blp.topMargin = dp(act, 14);
            card.addView(buttons, blp);
            dialog.show();
        }

        void dismiss() { dialog.dismiss(); }
    }

    /** Anchored dark rounded menu (does not reflow anything behind it). */
    static void menu(Activity a, View anchor, String[] labels, Runnable[] actions) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackground(shape(a, CARD, 18, STROKE, 1));
        col.setPadding(0, dp(a, 6), 0, dp(a, 6));
        final PopupWindow pw = new PopupWindow(col, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        for (int i = 0; i < labels.length; i++) {
            final Runnable action = actions[i];
            TextView t = text(a, labels[i], 15, TEXT, false);
            t.setPadding(dp(a, 18), dp(a, 13), dp(a, 22), dp(a, 13));
            t.setMinWidth(dp(a, 220));
            t.setOnClickListener(v -> { pw.dismiss(); if (action != null) action.run(); });
            col.addView(t);
        }
        pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pw.setElevation(dp(a, 14));
        pw.showAsDropDown(anchor, 0, dp(a, 6), Gravity.END);
    }

    /** Vertical single-select list of rows (radio style). */
    static final class RadioList extends LinearLayout {
        private final List<TextView> rows = new java.util.ArrayList<>();
        private int selected;
        private final Runnable onChange;

        RadioList(Context c, String[] labels, int selected, Runnable onChange) {
            super(c);
            setOrientation(VERTICAL);
            this.selected = selected;
            this.onChange = onChange;
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView t = text(c, labels[i], 15, TEXT, false);
                t.setPadding(dp(c, 14), 0, dp(c, 14), 0);
                t.setGravity(Gravity.CENTER_VERTICAL);
                t.setOnClickListener(v -> { this.selected = idx; paint(); if (this.onChange != null) this.onChange.run(); });
                LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 46));
                lp.topMargin = dp(c, 4);
                addView(t, lp);
                rows.add(t);
            }
            paint();
        }

        int selected() { return selected; }

        private void paint() {
            for (int i = 0; i < rows.size(); i++) {
                boolean on = i == selected;
                TextView t = rows.get(i);
                String base = t.getText().toString().replaceFirst("^[\u25CF\u25CB] ", "");
                t.setText((on ? "\u25CF " : "\u25CB ") + base);
                t.setBackground(shape(getContext(), on ? 0xFF1B3358 : ROW, 14, on ? BLUE : 0, on ? 1 : 0));
                t.setTextColor(on ? Color.WHITE : TEXT);
            }
        }
    }

    /** Horizontal single-select chips. */
    static final class ChipRow extends LinearLayout {
        private final List<TextView> chips = new java.util.ArrayList<>();
        private int selected;

        ChipRow(Context c, String[] labels, int selected) {
            super(c);
            this.selected = selected;
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView t = text(c, labels[i], 14, TEXT, false);
                t.setGravity(Gravity.CENTER);
                t.setPadding(dp(c, 14), 0, dp(c, 14), 0);
                t.setOnClickListener(v -> { this.selected = idx; paint(); });
                LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(c, 40));
                lp.rightMargin = dp(c, 6);
                addView(t, lp);
                chips.add(t);
            }
            paint();
        }

        int selected() { return selected; }

        private void paint() {
            for (int i = 0; i < chips.size(); i++) {
                boolean on = i == selected;
                chips.get(i).setBackground(shape(getContext(), on ? 0xFF1B3358 : ROW, 20, on ? BLUE : 0, on ? 1 : 0));
                chips.get(i).setTextColor(on ? Color.WHITE : TEXT);
            }
        }
    }
}
