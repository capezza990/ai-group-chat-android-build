package com.aigroupchat.bridge.room.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Round participant avatar with an optional status dot. Uses the participant's real installed-app icon when available;
 *  otherwise a neutral monogram (never an approximated logo). */
final class AvatarView extends View {
    private final ProviderStyle style;
    private final Drawable icon; // nullable, private instance
    private final boolean showDot;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();

    AvatarView(Context c, ProviderStyle style, Drawable icon, boolean showDot, int dotColor) {
        super(c);
        this.style = style;
        this.icon = icon;
        this.showDot = showDot;
        fill.setColor(style.avatarBg);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(0x33FFFFFF);
        textPaint.setColor(style.monoColor);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        dotPaint.setColor(dotColor);
        dotRing.setStyle(Paint.Style.STROKE);
        dotRing.setColor(0xFF0A0F1C);
    }

    void setDotColor(int color) { dotPaint.setColor(color); invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = Math.min(w, h) / 2f - 1f;
        float cx = w / 2f, cy = h / 2f;
        canvas.drawCircle(cx, cy, r, fill);
        if (icon != null) {
            canvas.save();
            clip.reset();
            clip.addCircle(cx, cy, r, Path.Direction.CW);
            canvas.clipPath(clip);
            icon.setBounds(Math.round(cx - r), Math.round(cy - r), Math.round(cx + r), Math.round(cy + r));
            icon.draw(canvas);
            canvas.restore();
        } else if (style.person) {
            canvas.save();
            clip.reset();
            clip.addCircle(cx, cy, r - 1f, Path.Direction.CW);
            canvas.clipPath(clip);
            textPaint.setColor(style.monoColor);
            canvas.drawCircle(cx, cy - r * 0.18f, r * 0.30f, textPaint);
            canvas.drawOval(new RectF(cx - r * 0.62f, cy + r * 0.22f, cx + r * 0.62f, cy + r * 1.15f), textPaint);
            canvas.restore();
        } else {
            textPaint.setTextSize(style.monogram.length() > 1 ? r * 0.62f : r * 1.0f);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            canvas.drawText(style.monogram, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint);
        }
        ring.setStrokeWidth(Math.max(1f, r * 0.05f));
        canvas.drawCircle(cx, cy, r, ring);
        if (showDot) {
            float dr = Math.max(4f, r * 0.24f);
            float dx = cx + r * 0.72f, dy = cy + r * 0.72f;
            dotRing.setStrokeWidth(Math.max(2f, dr * 0.45f));
            canvas.drawCircle(dx, dy, dr, dotRing);
            canvas.drawCircle(dx, dy, dr, dotPaint);
        }
    }
}
