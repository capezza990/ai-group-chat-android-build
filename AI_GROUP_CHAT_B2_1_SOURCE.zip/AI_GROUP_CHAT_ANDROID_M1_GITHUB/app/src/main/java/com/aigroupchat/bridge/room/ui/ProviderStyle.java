package com.aigroupchat.bridge.room.ui;

/** Version 3 look per participant. Identity colors only: green/yellow/red/gray STATUS dots are a separate concept.
 *  Avatar artwork comes from the real app icon installed on the phone (when present); otherwise a neutral monogram. */
final class ProviderStyle {
    final int accent, cardColor, cardStroke, avatarBg, monoColor;
    final String monogram;     // neutral fallback when no app icon is available
    final String packageName;  // installed app whose launcher icon is the avatar (nullable)
    final boolean person;      // the user: draw the person silhouette

    private ProviderStyle(int accent, int cardColor, int cardStroke, int avatarBg, String monogram, int monoColor,
                          String packageName, boolean person) {
        this.accent = accent; this.cardColor = cardColor; this.cardStroke = cardStroke; this.avatarBg = avatarBg;
        this.monogram = monogram; this.monoColor = monoColor; this.packageName = packageName; this.person = person;
    }

    static ProviderStyle of(String key) {
        switch (key == null ? "" : key) {
            case "user":
                return new ProviderStyle(0xFF8AB4F8, 0xFF123A78, 0xFF2A5AA8, 0xFF1E3A66, "", 0xFF7FB2FF, null, true);
            case "chatgpt":
                return new ProviderStyle(0xFFEDEFF3, 0xFF1A2130, 0xFF2A3347, 0xFF161C28, "GPT", 0xFFFFFFFF, "com.openai.chatgpt", false);
            case "claude":
                return new ProviderStyle(0xFFFF9B62, 0xFF3A2314, 0xFF5A3720, 0xFF2A1A12, "Cl", 0xFFFF9B62, "com.anthropic.claude", false);
            case "gemini":
                return new ProviderStyle(0xFFB794F6, 0xFF1E2050, 0xFF34388A, 0xFF171A3B, "Gem", 0xFFB794F6, "com.google.android.apps.bard", false);
            case "mock-delta":
                return new ProviderStyle(0xFF5FD7C8, 0xFF10373A, 0xFF1D5E60, 0xFF0F4B4A, "\u0394", 0xFF5FD7C8, null, false);
            default:
                return new ProviderStyle(0xFFCBD0D8, 0xFF1F2430, 0xFF2E3544, 0xFF232A38, "?", 0xFFCBD0D8, null, false);
        }
    }
}
