import com.aigroupchat.bridge.LabelMatch;

/** Regression test for the "reply text mistaken for the Stop button" bug (B1A.2). Run via run_tests.sh. */
public final class LabelMatchTest {
    static int fails;
    static void check(boolean ok, String what) { if (!ok) { fails++; System.out.println("    FAIL: " + what); } }
    static final String[] STOP = {"stop", "stop generating"};

    public static void main(String[] args) {
        // real controls must still match
        check(LabelMatch.matchesShort("Stop", 24, STOP), "\"Stop\" is a control");
        check(LabelMatch.matchesShort("  stop  ", 24, STOP), "case/space insensitive");
        check(LabelMatch.matchesShort("Stop generating", 24, STOP), "\"Stop generating\"");
        check(LabelMatch.matchesShort("Stop streaming", 24, STOP), "\"Stop streaming\" (prefix word)");
        check(LabelMatch.matchesShort("Stop response", 24, "stop", "stop response"), "Claude \"Stop response\"");
        // the exact strings that froze the relay: reply text that merely STARTS with "Stop"
        check(!LabelMatch.matchesShort("Stop during an active mock collaboration;", 24, STOP), "bullet from the failing reply");
        check(!LabelMatch.matchesShort("Stop during a run → already-completed canonical messages remain and later mock handoff stops.", 24, STOP), "numbered item from the failing reply");
        check(!LabelMatch.matchesShort("Stopped", 24, STOP), "\"Stopped\" is not Stop");
        check(!LabelMatch.matchesShort("Stopwatch", 24, STOP), "\"Stopwatch\" is not Stop");
        check(!LabelMatch.matchesShort("", 24, STOP) && !LabelMatch.matchesShort(null, 24, STOP), "empty / null");
        System.out.println((fails == 0 ? "PASS  " : "FAIL  ") + "Stop label matcher (" + (fails == 0 ? "all checks" : fails + " failures") + ")");
        System.exit(fails == 0 ? 0 : 1);
    }
}
