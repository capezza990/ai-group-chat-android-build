import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Deterministic harness for the canonical-room core (no Android, no network). Run: tools/roomtest/run_tests.sh */
public final class RoomControllerTest {
    static int checks, failures;
    static final String ROOM = "default";

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) { failures++; System.out.println("    FAIL: " + what); }
    }

    static final class Fixture {
        final InMemoryRoomStore store = new InMemoryRoomStore();
        final MockProvider a = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
        final MockProvider b = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
        final List<String> finished = new ArrayList<>();
        final List<RoomMessage> seen = new ArrayList<>();
        final AtomicInteger clock = new AtomicInteger(1000);
        RoomController c;

        Fixture() { c = controller(); c.addParticipant("chatgpt"); c.addParticipant("claude"); }

        RoomController controller() {
            RoomController rc = new RoomController(store, ROOM, new RoomController.Events() {
                @Override public void onMessage(RoomMessage m) { seen.add(m); }
                @Override public void onRunFinished(String s) { finished.add(s); }
            }, () -> clock.incrementAndGet(), new java.util.function.Supplier<String>() {
                int n; public String get() { return "id" + (++n) + "-" + System.nanoTime(); }
            });
            rc.registerProvider(a);
            rc.registerProvider(b);
            return rc;
        }

        List<RoomMessage> all() { return store.messagesBetween(ROOM, 0, Long.MAX_VALUE); }
        long count(String type) { return all().stream().filter(m -> m.authorType.equals(type)).count(); }
        RoomParticipant part(String id) { return store.participants(ROOM).stream().filter(p -> p.providerId.equals(id)).findFirst().get(); }
    }

    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }

    public static void main(String[] args) {
        test("user message is persisted before dispatch; delivery is SENDING at send time", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.a.onSend = prompt -> {
                boolean userSaved = f.store.latestMessages(ROOM, 5).stream().anyMatch(m -> m.authorType.equals("USER") && m.text.equals("hello"));
                boolean sending = f.store.deliveriesInState(DeliveryState.SENDING).size() == 1;
                ok[0] = userSaved && sending;
            };
            f.c.submitUserMessage("hello");
            check(ok[0], "at send(): user message saved and delivery SENDING");
            check(f.count("PROVIDER") == 1, "reply stored");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 1, "delivery CAPTURED");
        });

        test("provider failure leaves the canonical user message intact and the delivery FAILED", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.FAIL_BEFORE_SEND;
            f.c.submitUserMessage("keep me");
            check(f.count("USER") == 1 && f.count("PROVIDER") == 0, "user message kept, no reply");
            check(f.store.deliveriesInState(DeliveryState.FAILED).size() == 1, "delivery FAILED (safe to retry)");
            check(f.part("chatgpt").contextSeq == 0, "context not advanced by a failed request");
            check(!f.c.isBusy(), "run cleared");
            f.a.behavior = MockProvider.Behavior.REPLY;
            check(f.c.submitUserMessage("again") != null, "next message accepted after a failure");
            check(f.count("PROVIDER") == 1, "next message answered");
        });

        test("captured reply is persisted before the next provider receives it (collaborate)", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.b.onSend = prompt -> {
                boolean stored = f.store.latestMessages(ROOM, 10).stream().anyMatch(m -> m.authorType.equals("PROVIDER") && m.authorId.equals("chatgpt"));
                ok[0] = stored && prompt.contains("ChatGPT reply #1");
            };
            f.c.submitUserMessage("design X");
            check(ok[0], "ChatGPT's reply was already stored and is in Claude's prompt");
            check(f.count("PROVIDER") == 3, "propose, review, revise = 3 provider messages");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 3, "3 deliveries CAPTURED");
            check(f.finished.size() == 1 && f.finished.get(0).equals("done"), "run finished cleanly");
        });

        test("restart: SENDING and SENT become UNCERTAIN and nothing is auto-resent", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("one");
            check(f.store.deliveriesInState(DeliveryState.SENDING).size() == 1, "stuck in SENDING");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            g.c.submitUserMessage("two");
            check(g.store.deliveriesInState(DeliveryState.SENT).size() == 1, "stuck in SENT");
            // "restart": a brand-new controller on the same stores
            RoomController f2 = f.controller();
            check(f2.recoverOnStart() == 1, "f: one delivery recovered");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "f: now UNCERTAIN");
            check(f.store.deliveriesInState(DeliveryState.SENDING).isEmpty(), "f: no SENDING left");
            check(f.a.prompts.size() == 1, "f: no automatic resend (still exactly 1 prompt)");
            RoomController g2 = g.controller();
            check(g2.recoverOnStart() == 1 && g.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "g: SENT -> UNCERTAIN");
            check(g.count("USER") == 1, "canonical user message survived the restart");
        });

        test("disabled participant keeps history and binding; re-adding restores context position", () -> {
            Fixture f = new Fixture();
            f.store.putBinding(new ProviderBinding("claude", "conv-1", "https://claude.ai/chat/conv-1", "t", 5L));
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("q1");
            long ctx = f.part("claude").contextSeq;
            check(ctx > 0, "claude accepted a request, context advanced");
            int bPrompts = f.b.prompts.size();
            f.c.removeParticipant("claude");
            check(!f.part("claude").enabled, "claude disabled");
            check(f.store.getBinding("claude") != null, "binding kept");
            check(f.count("PROVIDER") == 2, "old replies kept");
            f.c.submitUserMessage("q2");
            check(f.b.prompts.size() == bPrompts, "disabled participant receives nothing");
            f.c.addParticipant("claude");
            check(f.part("claude").enabled && f.part("claude").contextSeq == ctx, "re-enabled with the same context position");
        });

        test("duplicate provider callbacks create one message", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            f.c.submitUserMessage("dup?");
            check(f.count("PROVIDER") == 1, "exactly one provider message");
            RoomMessage m = f.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get();
            RoomMessage again = f.store.appendMessage(ROOM, m.id, "PROVIDER", "chatgpt", "different", null, 9L);
            check(again.seq == m.seq && again.text.equals(m.text), "appendMessage is idempotent on id and never rewrites text");
            check(f.count("PROVIDER") == 1, "still one after re-append");
        });

        test("router: collaborate sequences match the legacy relay", () -> {
            List<RoomParticipant> two = new ArrayList<>();
            two.add(new RoomParticipant(ROOM, "chatgpt", true, 0, 0, "UNKNOWN"));
            two.add(new RoomParticipant(ROOM, "claude", true, 1, 0, "UNKNOWN"));
            RoomSettings s1 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "chatgpt", 1, 0);
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "1 round = propose, review, revise");
            RoomSettings s2 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "claude", 2, 0);
            check(RoomRouter.plan(s2, two).toString().equals("[claude:ANSWER, chatgpt:REVIEW, claude:REVISE, chatgpt:REVIEW, claude:REVISE]"), "2 rounds, Claude first = 5 steps");
            check(new RoomSettings(ROOM, RoutingMode.COLLABORATE, "x", 9, 0).rounds == 2, "rounds clamp at 2 like the legacy control");
            List<RoomParticipant> three = new ArrayList<>(two);
            three.add(new RoomParticipant(ROOM, "gemini", true, 2, 0, "UNKNOWN"));
            check(RoomRouter.plan(s1, three).toString().equals("[chatgpt:ANSWER, claude:REVIEW, gemini:REVIEW, chatgpt:REVISE]"), "3 AIs: every other AI reviews in order");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.ASK_ALL, "", 1, 0), two).toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "ask all = independent");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.SINGLE, "claude", 1, 0), two).toString().equals("[claude:ANSWER]"), "single");
            two.get(1).enabled = false;
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER]"), "disabled AI is skipped; lone AI just answers");
            two.get(0).enabled = false;
            check(RoomRouter.plan(s1, two).isEmpty(), "nobody enabled = empty plan");
        });

        test("independent prompts exclude the other AI's reply; later prompts include what the AI has not seen", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("first question");
            check(!f.b.prompts.get(0).contains("ChatGPT reply #1"), "Claude's independent answer did not see ChatGPT's reply");
            f.c.submitUserMessage("second question");
            String p = f.a.prompts.get(1);
            check(p.contains("Claude reply #1") && p.contains("ROOM CONTEXT"), "ChatGPT's next prompt includes Claude's earlier reply as context");
            check(!p.contains("ChatGPT reply #1"), "ChatGPT's own earlier reply is not echoed back");
            check(p.contains("REQUEST") && p.contains("[User] second question"), "request clearly separated from context");
        });

        test("context only advances for requests the provider accepted", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("a");
            check(f.part("chatgpt").contextSeq == 0, "SILENT (never accepted) leaves context at 0");
            f.c.stop();
            f.a.behavior = MockProvider.Behavior.REPLY;
            f.c.submitUserMessage("b");
            check(f.part("chatgpt").contextSeq > 0, "accepted request advances context");
        });

        test("store: createDelivery idempotent, transition is compare-and-set, atomic rolls back", () -> {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.ensureRoom(ROOM, 1L);
            RoomMessage m = s.appendMessage(ROOM, "m1", "USER", "user", "x", null, 1L);
            Delivery d1 = s.createDelivery("d1", ROOM, m.id, "chatgpt", m.seq, 1L);
            Delivery d2 = s.createDelivery("d2", ROOM, m.id, "chatgpt", m.seq, 2L);
            check(d1.id.equals(d2.id), "same (trigger, provider) returns the same delivery");
            check(s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 2L), "PENDING -> SENDING");
            check(!s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 3L), "second PENDING -> SENDING is refused");
            try {
                s.atomic(() -> { s.appendMessage(ROOM, "m2", "USER", "user", "y", null, 2L); throw new IllegalStateException("boom"); });
            } catch (IllegalStateException expected) { }
            check(s.getMessage("m2") == null, "rolled back: m2 does not exist");
            check(s.appendMessage(ROOM, "m3", "USER", "user", "z", null, 3L).seq == 2, "seq not consumed by the rolled-back insert");
        });

        test("stop mid-run marks the delivery UNCERTAIN and dispatches nothing further", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("long task");
            check(f.c.isBusy(), "busy while waiting");
            check(f.c.submitUserMessage("interrupt") == null, "a second message is refused while busy");
            f.c.stop();
            check(!f.c.isBusy(), "not busy after stop");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "active delivery UNCERTAIN");
            check(f.b.prompts.isEmpty(), "Claude was never asked");
            check(f.count("USER") == 1, "only the first user message exists");
        });

        test("participant removed mid-run is skipped without a crash", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.onSend = p -> { if (f.a.prompts.size() == 1) f.c.removeParticipant("claude"); };
            f.c.submitUserMessage("go");
            check(f.b.prompts.isEmpty(), "Claude's review turn was skipped");
            check(f.count("PROVIDER") >= 1 && !f.c.isBusy(), "run completed");
        });

        test("empty reply is UNCERTAIN, not stored, and ends the run", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.EMPTY_REPLY;
            f.c.submitUserMessage("hi");
            check(f.count("PROVIDER") == 0, "blank reply not stored");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "delivery UNCERTAIN");
        });

        test("no enabled participants: the user message is still saved", () -> {
            Fixture f = new Fixture();
            f.c.removeParticipant("chatgpt");
            f.c.removeParticipant("claude");
            RoomMessage m = f.c.submitUserMessage("anyone there?");
            check(m != null && f.count("USER") == 1, "user message persisted");
            check(f.finished.size() == 1 && f.finished.get(0).startsWith("no enabled"), "run reports nobody to answer");
        });

        test("late duplicate callbacks after the run moved on change nothing (queued scheduler, like the phone)", () -> {
            final java.util.ArrayDeque<Runnable> queue = new java.util.ArrayDeque<>();
            MockProvider.Scheduler q = (r, d) -> queue.add(r);
            InMemoryRoomStore store = new InMemoryRoomStore();
            MockProvider a = new MockProvider("chatgpt", "ChatGPT", q), b = new MockProvider("claude", "Claude", q);
            a.behavior = MockProvider.Behavior.LATE_DUPLICATE;
            b.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            RoomController c = new RoomController(store, "r", null);
            c.registerProvider(a); c.registerProvider(b);
            c.addParticipant("chatgpt"); c.addParticipant("claude");
            c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 2);
            c.submitUserMessage("two rounds");
            check(c.isBusy() && c.activeProviderId().equals("chatgpt"), "A is working after submit");
            check(c.runStatus().equals("step 1 of 5: ChatGPT (answer)"), "run status reads \"" + c.runStatus() + "\"");
            int guard = 0;
            while (!queue.isEmpty() && guard++ < 100) queue.poll().run();
            long providerMsgs = store.messagesBetween("r", 0, Long.MAX_VALUE).stream().filter(m -> m.authorType.equals("PROVIDER")).count();
            check(!c.isBusy(), "run finished");
            check(providerMsgs == 5, "2 rounds = 5 provider messages exactly (no duplicates), got " + providerMsgs);
            check(store.deliveriesInState(DeliveryState.CAPTURED).size() == 5, "5 CAPTURED deliveries");
            String order = "";
            for (RoomMessage m : store.messagesBetween("r", 0, Long.MAX_VALUE)) if (m.authorType.equals("PROVIDER")) order += m.authorId.charAt(1) + ",";
            check(order.equals("h,l,h,l,h,"), "legacy 2-round order chatgpt,claude,chatgpt,claude,chatgpt, got " + order);
            check(c.runStatus().isEmpty() && c.activeProviderId() == null, "idle status is empty");
        });

        test("provider catalog is data-driven and has more than two AIs", () -> {
            check(ProviderCatalog.all().size() >= 4, "catalog offers at least 4 AIs");
            check(ProviderCatalog.nameOf("gemini").equals("Gemini") && ProviderCatalog.nameOf("unknown-x").equals("unknown-x"), "nameOf");
            Fixture f = new Fixture();
            MockProvider delta = new MockProvider("mock-delta", "Mock Delta", MockProvider.Scheduler.IMMEDIATE);
            f.c.registerProvider(delta);
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.c.submitUserMessage("two AIs");
            long before = f.count("PROVIDER");
            f.c.addParticipant("mock-delta");
            check(f.store.participants(ROOM).size() == 3, "a third AI joins the same room");
            f.c.submitUserMessage("three AIs");
            check(f.count("PROVIDER") - before == 4, "3 AIs, 1 round = propose, 2 reviews, revise (4 messages)");
            check(f.count("USER") == 2 && before == 3, "earlier history untouched by adding an AI");
        });

        test("scroll follow: follows at the bottom, never yanks a reader, resumes on send or return", () -> {
            ScrollFollow f = new ScrollFollow();
            check(f.shouldFollowNewContent(), "starts following");
            f.onScrolled(false);
            check(!f.shouldFollowNewContent() && !f.isFollowing(), "user scrolled up: new replies do not move the view");
            f.onScrolled(false);
            check(!f.shouldFollowNewContent(), "still reading");
            f.onUserSent();
            check(f.shouldFollowNewContent(), "sending a message follows the conversation again");
            f.onScrolled(false);
            f.onScrolled(true);
            check(f.shouldFollowNewContent(), "returning near the bottom resumes following");
        });

        test("reply cleaner strips hidden speaker headings and invisible characters", () -> {
            check(ReplyCleaner.clean("ChatGPT said:\nHello there").equals("Hello there"), "removes the hidden \"ChatGPT said:\" heading");
            check(ReplyCleaner.clean("Claude said\n\nHi").equals("Hi"), "heading without colon");
            check(ReplyCleaner.clean("  a\u200Bb\r\n\r\n\r\n\r\nc  ").equals("ab\n\nc"), "zero-width chars, CRLF and blank-line runs");
            check(ReplyCleaner.clean("Mention that ChatGPT said: nothing special").equals("Mention that ChatGPT said: nothing special"), "only a LEADING heading is removed");
            check(ReplyCleaner.clean(null).isEmpty(), "null is empty");
        });

        test("routing marker tolerates trailing decoration but rejects prose and mid-line markers", () -> {
            java.util.function.Function<String, Boolean> m = t -> RoutingMarkers.PATTERN.matcher(t).find();
            check(m.apply("text\n[[NEXT:CLAUDE]]"), "plain marker");
            check(m.apply("text\n[[NEXT:CLAUDE]] \u2776"), "marker + circled digit (the Accessibility attachment decoration)");
            check(m.apply("text\n  [[DONE]] \u2460"), "indented DONE + decoration");
            check(m.apply("[[NEXT:USER]]\u200B"), "marker + zero-width character");
            check(m.apply("a\n[[NEXT:CHATGPT]]\u2776 \u2777\nmore"), "decoration on a middle line, marker still alone on its line");
            check(!m.apply("see [[NEXT:CLAUDE]]"), "mid-line marker rejected");
            check(!m.apply("[[NEXT:CLAUDE]] and some words"), "prose after the marker rejected");
            check(!m.apply("[[NEXT:BOB]]"), "unknown target rejected");
            check(!m.apply("[[NEXT:CLAUDE]] \u2776 text"), "decoration followed by prose rejected");
            check(!m.apply("no marker here"), "no marker");
            String cleaned = RoutingMarkers.PATTERN.matcher("answer\n[[NEXT:CLAUDE]] \u2776").replaceAll("");
            check(cleaned.trim().equals("answer"), "the whole marker line including the decoration is removed from the text");
        });

        test("transcript search: counts, order, wrap-around, case-insensitive", () -> {
            java.util.List<RoomMessage> msgs = new java.util.ArrayList<>();
            msgs.add(new RoomMessage(1, "a", "r", "USER", "user", "Test the test", 1, null));
            msgs.add(new RoomMessage(2, "b", "r", "PROVIDER", "claude", "no hit here", 2, null));
            msgs.add(new RoomMessage(3, "c", "r", "PROVIDER", "chatgpt", "TEST again", 3, null));
            java.util.List<TranscriptSearch.Match> hits = TranscriptSearch.find(msgs, "test", m -> m.text);
            check(hits.size() == 3, "3 matches across messages, got " + hits.size());
            check(hits.get(0).seq == 1 && hits.get(0).start == 0 && hits.get(1).start == 9 && hits.get(2).seq == 3, "positions and order");
            check(TranscriptSearch.find(msgs, "  ", m -> m.text).isEmpty() && TranscriptSearch.find(msgs, "zzz", m -> m.text).isEmpty(), "blank / missing query");
            check(TranscriptSearch.next(2, 3) == 0 && TranscriptSearch.next(-1, 3) == 0 && TranscriptSearch.prev(0, 3) == 2 && TranscriptSearch.prev(-1, 3) == 2, "next/prev wrap");
            check(TranscriptSearch.next(0, 0) == -1, "no matches: no position");
        });

        test("status rules: stop/removal are neutral, only real failures are red", () -> {
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "stopped by user"), "user stop is not a failure");
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "participant removed"), "removal is not a failure");
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "interrupted (app restart)"), "restart interruption is not a failure");
            check(StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "timeout after 240s"), "an unexplained UNCERTAIN is a real problem");
            check(StatusRules.isRealFailure(DeliveryState.FAILED, "composer not empty"), "FAILED is a real failure");
            check(StatusRules.of(false, true, false, true) == StatusRules.Status.NEUTRAL, "neutral stop shows neutral");
            check(StatusRules.of(true, true, true, true) == StatusRules.Status.WORKING, "working wins");
            check(StatusRules.of(false, false, true, false) == StatusRules.Status.NOT_CONNECTED, "not connected wins over problems");
            check(StatusRules.of(false, true, true, true) == StatusRules.Status.PROBLEM, "a real problem outranks neutral");
        });

        test("long requests are shortened with a visible notice; short ones are untouched; mock never fakes an ellipsis", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            StringBuilder big = new StringBuilder();
            for (int i = 0; i < 6000; i++) big.append("word").append(i).append(' ');
            f.c.submitUserMessage(big.toString());
            String p = f.a.prompts.get(0);
            check(p.length() < 20000, "prompt capped, got " + p.length());
            check(p.contains("characters omitted by AI Group Chat"), "visible omission notice");
            check(p.contains("word0 ") && p.contains("word5999"), "start and end of the request are kept");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.c.submitUserMessage("short message");
            check(!g.a.prompts.get(0).contains("omitted"), "short request untouched");
            String reply = g.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get().text;
            check(!reply.contains("\u2026") && !reply.contains("...") && reply.endsWith("short message"), "mock reply is complete with no ellipsis: " + reply);
        });

        test("B2.1: Claude 'responded' block and ref tags are removed from captured replies", () -> {
            check(ReplyCleaner.clean("Claude responded: ok\n\nok").equals("ok"), "the exact captured form from the video");
            check(ReplyCleaner.clean("Claude responded: The sentence is accurate and clear.\n\nThe sentence is accurate and clear. A few improvements:\n1. x")
                    .equals("The sentence is accurate and clear. A few improvements:\n1. x"), "long reply: hidden summary line dropped, real reply kept intact");
            check(ReplyCleaner.clean("Claude responded:\nHello").equals("Hello"), "heading with nothing after the colon");
            check(ReplyCleaner.clean("ChatGPT said:\nHi there").equals("Hi there"), "ChatGPT heading still handled");
            check(ReplyCleaner.clean("Claude responded: only this").equals("Claude responded: only this"), "a lone line is left alone (nothing to separate)");
            check(ReplyCleaner.clean("[ref 7f3a9c] Sure thing").equals("Sure thing"), "echoed ref tag removed");
            check(ReplyCleaner.clean("Answer mentions that Claude responded: to the user").equals("Answer mentions that Claude responded: to the user"), "only a LEADING heading is removed");
        });

        test("B2.1: failure text is short and never carries a JSON diagnostic", () -> {
            String blob = "unhealthy provider surface: {\"url\":\"https://chatgpt.com/c/6abe\",\"healthy\":false,\"composer\":false}";
            check(FailureText.shorten(blob).equals("page isn't ready"), "unhealthy surface -> " + FailureText.shorten(blob));
            check(FailureText.shorten("timeout after 240s; last poll {\"sendResult\":\"clicked\"}").equals("timed out while waiting for the reply"), "timeout");
            check(FailureText.shorten("could not settle on the bound conversation").startsWith("couldn't open"), "settle");
            check(FailureText.shorten("send failed: no-unique-send-button").equals("couldn't send (no-unique-send-button)"), "send failed code");
            check(FailureText.shorten("something odd: {\"a\":1,\"b\":2}").equals("something odd"), "unknown + JSON: JSON dropped");
            check(!FailureText.shorten("{\"only\":\"json\"}").contains("{"), "pure JSON becomes a short word");
            check(FailureText.shorten(null).equals("failed") && FailureText.shorten("  ").equals("failed"), "null/blank");
            String longTxt = "x".repeat(500);
            check(FailureText.shorten(longTxt).length() <= 100, "length capped");
        });

        test("B2.1: system audit lines never become provider context", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            f.store.appendMessage(ROOM, "sys1", "SYSTEM", "system", "Run ended early: ChatGPT: unhealthy provider surface: {\"huge\":\"blob\"}", null, 5L);
            f.c.submitUserMessage("hello");
            String p = f.b.prompts.get(0);
            check(!p.contains("unhealthy") && !p.contains("blob") && !p.contains("[System]"), "no system line in the prompt");
            check(p.contains("[User] hello"), "request intact");
        });

        test("B2.1: only APP background time pauses a turn timeout; a hidden page under the foreground room does not", () -> {
            long t0 = 1_000_000L, timeout = 240_000L, cap = 20L * 60_000L;
            BackgroundTracker bg = new BackgroundTracker();
            TurnClock clock = new TurnClock(t0, timeout, cap, bg.totalBackgroundMs(t0));
            check(!clock.expired(t0 + 239_000L, bg.totalBackgroundMs(t0 + 239_000L)), "foreground: not expired at 239 s");
            check(clock.expired(t0 + 241_000L, bg.totalBackgroundMs(t0 + 241_000L)), "foreground (page may report hidden): expires at 241 s, NOT extended");
            BackgroundTracker b2 = new BackgroundTracker();
            TurnClock c2 = new TurnClock(t0, timeout, cap, b2.totalBackgroundMs(t0));
            b2.setForeground(false, t0 + 60_000L);
            check(b2.totalBackgroundMs(t0 + 120_000L) == 60_000L, "an open background interval counts up to now");
            b2.setForeground(true, t0 + 360_000L);
            check(b2.totalBackgroundMs(t0 + 360_000L) == 300_000L, "closed background interval is 300 s");
            check(!c2.expired(t0 + 400_000L, b2.totalBackgroundMs(t0 + 400_000L)), "300 s in the background is excluded: active time only 100 s");
            check(c2.expired(t0 + 600_000L, b2.totalBackgroundMs(t0 + 600_000L)), "after enough foreground time it expires");
            BackgroundTracker b3 = new BackgroundTracker();
            TurnClock c3 = new TurnClock(t0, timeout, cap, 0);
            b3.setForeground(false, t0 + 1_000L);
            check(c3.expired(t0 + cap + 1L, b3.totalBackgroundMs(t0 + cap + 1L)), "hard 20-minute cap always applies, even in the background");
            BackgroundTracker b4 = new BackgroundTracker();
            b4.setForeground(false, 5_000L); b4.setForeground(true, 9_000L);
            TurnClock c4 = new TurnClock(10_000L, timeout, cap, b4.totalBackgroundMs(10_000L));
            check(c4.activeMs(20_000L, b4.totalBackgroundMs(20_000L)) == 10_000L, "background before the turn started is not subtracted from it");
        });

        test("B2.1: the prompt tag exists only on the provider page and is stripped everywhere it could echo", () -> {
            String tagged = RefTag.tag("7f3a9c", "hello there");
            check(tagged.equals("[ref 7f3a9c] hello there"), "tag format");
            check(RefTag.strip(tagged).equals("hello there"), "strip restores the original");
            check(ReplyCleaner.clean("Sure. You wrote [ref 7f3a9c] hello there, and I agree.").equals("Sure. You wrote hello there, and I agree."), "a tag echoed in the MIDDLE of a reply is removed");
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.c.submitUserMessage("plain user text");
            boolean clean = true;
            for (RoomMessage m : f.all()) if (m.text.contains("[ref ")) clean = false;
            check(clean, "no canonical room message contains a ref tag");
        });

        test("B2.1: nonce identity is accepted even when legacy counts are negative (the real Claude virtualization case)", () -> {
            check(TurnAcceptance.accept("Real reply text", true, true, "nonce", -2, -3), "mode=nonce identity=true newA=-2 newU=-3 -> ACCEPTED");
            check(TurnAcceptance.accept("Real reply text", true, true, "nonce", 0, 0), "nonce with zero counts -> accepted");
            check(!TurnAcceptance.accept("Real reply text", true, false, "nonce", 1, 1), "nonce but identity NOT proven -> rejected (fails closed)");
            check(!TurnAcceptance.accept("", true, true, "nonce", -2, -3), "empty reply -> rejected");
            check(!TurnAcceptance.accept("   \n ", true, true, "nonce", 2, 2), "whitespace-only reply -> rejected");
            check(!TurnAcceptance.accept("Real reply text", false, true, "nonce", 2, 2), "expected token missing -> rejected");
            check(!TurnAcceptance.accept("Real reply text", true, true, "counts", -2, -3), "legacy counts mode with negative growth -> rejected");
            check(!TurnAcceptance.accept("Real reply text", true, true, "ids", 0, 1), "legacy ids mode still needs new assistant growth");
            check(TurnAcceptance.accept("Real reply text", true, true, "ids", 1, 1), "legacy ids mode with growth -> accepted (ChatGPT unchanged)");
            check(TurnAcceptance.accept("Real reply text", true, true, "counts", 1, 1), "legacy counts mode with growth -> accepted");
            check(!TurnAcceptance.accept(null, true, true, "nonce", 1, 1), "null reply -> rejected");
            BackgroundTracker bg = new BackgroundTracker();
            TurnClock clock = new TurnClock(10_000L, 240_000L, 1_200_000L, bg.totalBackgroundMs(10_000L));
            bg.setForeground(false, 40_000L);
            check(clock.backgroundDuringTurnMs(bg.totalBackgroundMs(100_000L)) == 60_000L, "diagnostic background duration is correct while an interval is still open");
        });

        System.out.println("\n" + checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
