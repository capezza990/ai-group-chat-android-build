# B1a - canonical room foundation (0.12.1-b1a, versionCode 20)

Built on AI_GROUP_CHAT_P1A_FINAL_SOURCE.zip. No Accessibility / M11.7 relay file was touched.
No UI redesign yet (that is B1b). This milestone is the data layer, controller, router and MockProvider.

## New files (com.aigroupchat.bridge.room)
- `DeliveryState`, `RoutingMode`, `RoomSettings`, `RoomMessage`, `RoomParticipant`, `Delivery` - model (pure Java)
- `RoomStore` - persistence contract (atomic(), idempotent appends, compare-and-set transitions)
- `InMemoryRoomStore` - reference implementation used by the JVM test harness
- `RoomRouter` - deterministic provider sequence (legacy-compatible rounds)
- `RoomPromptBuilder` - provider prompt from CANONICAL messages (context vs request, speaker labels)
- `RoomProvider` - provider interface (Listener: onAccepted / onReply / onError(reason, maybeSubmitted))
- `MockProvider` - deterministic fake AI (REPLY, FAIL_BEFORE_SEND, FAIL_AFTER_ACCEPT, DUPLICATE_REPLY, NEVER_REPLY, SILENT, EMPTY_REPLY)
- `RoomController` - persist-before-dispatch, capture-first replies, single-flight run, stop, recovery
- `sqlite/RoomDb` - SQLiteOpenHelper + RoomStore (framework SQLite, no new dependency)
- `sqlite/RoomSelfCheck` - on-device smoke test of the real database (menu: "Room database self-check (B1a)")
- `assets/room_schema_v1.sql` - schema (append-only messages via triggers, UNIQUE ids, foreign keys, CHECKs)
- `tools/roomtest/` - `run_tests.sh`, `RoomControllerTest.java` (61 checks), `schema_test.py` (real SQLite, constraints)

## Changed files
- `engine/ProviderBinding.java` - `Store` now delegates to RoomDb.provider_bindings (single source of truth);
  P1-A SharedPreferences bindings are imported once (legacy prefs left untouched for rollback)
- `MainActivity.java` - one menu item (id 40) for the self-check
- `app/build.gradle` - version 0.12.1-b1a / 20

## Transaction boundaries (RoomController)
1. `submitUserMessage`: one transaction appends the USER message. Nothing is dispatched until it commits.
2. `startStepLocked` (per provider step): ONE transaction does createDelivery (idempotent on trigger+provider),
   CAS PENDING->SENDING, and builds the prompt from the stored messages. Only after it commits is `provider.send` called
   (outside the controller lock). A crash after this commit leaves SENDING -> UNCERTAIN on restart, never an automatic resend.
3. `onAccepted`: CAS SENDING->SENT + record provider user-message id + advance participants.context_seq to the
   delivery's upto_seq (what the prompt actually contained).
4. `onReply`: ONE transaction does CAS SENDING|SENT->CAPTURED, appends the PROVIDER message with the idempotent id
   `reply:<deliveryId>`, records the provider assistant id, links reply_message_id. The next provider is only started
   after this commits, so it always sees the stored reply.
5. `onError(reason, maybeSubmitted)`: SENDING->FAILED if provably not sent, else UNCERTAIN; SENT->UNCERTAIN.
6. Stale, duplicate or late callbacks are ignored (active-delivery check + CAS + idempotent message id).

## Routing state
Run plan is in memory (list of steps + index). Persisted truth = messages + deliveries. After a restart nothing resumes
automatically; UNCERTAIN deliveries wait for a deliberate resync (B3).
COLLABORATE generalizes the legacy relay: 2 AIs, 1 round = propose, review, revise; 2 rounds = 5 steps (clamped at 2).
ASK_ALL steps are INDEPENDENT: their prompts exclude the other AIs' replies (context capped at the user message).

## Not in B1a
UI (B1b), WebRoomProvider / binding flow / auth recovery (B2), mirror verification / branch detection / resync (B3),
capability routing (AUTO_PICK = first enabled for now), attachments.

---
# B1A.1-diag (0.12.2-b1a1-diag, versionCode 21)
DIAGNOSTICS ONLY. The single change is in `RelayCoordinator.evaluateResponseAfterScroll()`: the overlay now shows the detector flags
while waiting, and a SYSTEM line "Detector state at 60s: ..." is written once when the existing 60 s warning fires.
No relay behavior changed; every other legacy file is byte-identical to M11.7.

---
# B1A.2 (0.12.3-b1a2, versionCode 22) - Stop-detection fix for the legacy relay
Cause of the "Waiting for ChatGPT" hang (found with the B1A.1 diagnostics: gen=true while the reply was finished):
`NodeUtils.findLastNodeByExactOrPrefixWords` treated ANY visible text equal to, or starting with, "stop " as ChatGPT's Stop button.
A reply containing a list item such as "Stop during an active mock collaboration;" therefore kept generationAppearsActive() true forever,
so generationDone / turn proof / completion never happened.
Fix: Stop is now found with `NodeUtils.findControlByShortLabel` - label <= 24 chars (pure-Java `LabelMatch`, unit-tested with the strings
from the failing reply) AND the node or one of its 3 nearest ancestors must be clickable. Used by generationAppearsActive() and clickStop().
The B1A.1 overlay stays, and now also shows which control was treated as Stop: gen=true(stop="stop").
Not changed: send/attachment-launcher matching (same helper family; reviewed, left alone to keep this hotfix small).

---
# B1B (0.13.0-b1b, versionCode 23) - shared-room UI on the canonical database, mock AIs only
Built on B1A.2 (Stop-detection fix carried forward). No live WebViews, no accounts, no B2 work.
Uses its own mock room id ("mock-room", "New room" makes "mock-<time>") so the default room stays clean for B2.

## Changed / new files
- NEW  `room/ui/RoomActivity.java` - the room screen (strip with direct "-" per AI, "+ Add AI", routing + rounds, mock test mode, transcript from RoomDb, composer, Send/Stop, Undo bar, State dialog)
- NEW  `room/ProviderCatalog.java` - data-driven list of AIs the room can add (ChatGPT, Claude, Gemini placeholder, Mock Delta)
- EDIT `room/MockProvider.java` - role-aware readable replies; new LATE_DUPLICATE behavior
- EDIT `room/RoomController.java` - `activeProviderId()` and `runStatus()` for the UI
- EDIT `MainActivity.java` - overflow item "Room (B1B, mock AIs)" (id 41)
- EDIT `AndroidManifest.xml` - registers RoomActivity
- EDIT `app/build.gradle` - 0.13.0-b1b / 23
- EDIT `tools/roomtest/RoomControllerTest.java` - +2 tests (73 checks pass), run via tools/roomtest/run_tests.sh

---
# B1B.1 (0.13.1-b1b1, versionCode 24) - Version 3 UI on the passing B1B room
Presentation only. RoomController, RoomRouter, RoomDb, MockProvider logic, the B1A2 Stop fix and the legacy bridge are unchanged.

## Changed / new files
- REWRITE `room/ui/RoomActivity.java` - Version 3 layout: header (title, "N members • Shared Room", search, Room tools), participant rail
  (scrolls, "+" add, collapse), chat panel with avatar + colored cards + times, typing indicator, composer pill (attach, send/stop)
- NEW `room/ui/ProviderStyle.java`, `room/ui/AvatarView.java` - per-participant colors/glyph avatars and status dots
- NEW `room/ScrollFollow.java` - follow policy (pure Java, unit-tested)
- EDIT `MainActivity.java` - menu label "Room (B1B.1, mock AIs)"
- EDIT `app/build.gradle` - 0.13.1-b1b1 / 24
- EDIT `tools/roomtest/RoomControllerTest.java` - +1 test (78 checks total pass)

## Fixes
- Readable messages: full-width wrapped cards with no line limit; the mock/test spinners no longer eat the screen.
- Auto-scroll: B1B scrolled before new rows were laid out. Now scrolls after layout, follows only while near the bottom,
  never yanks a reader who scrolled up, resumes on Send or on returning to the bottom; "↓" jump button when reading above.
- Participant overflow: the rail scrolls vertically; "+" and collapse are fixed at its bottom, so nothing covers the chat.
- Transcript is append-only, so rows are added incrementally instead of rebuilt.
- Routing/rounds, mock test mode, state, copy transcript, new mock room moved into "Room tools".

---
# B2 (0.14.0-b2, versionCode 25) - live ChatGPT + Claude in the canonical room, plus the B1B.1 UI corrections
Built on B1B.1. Controller / router / database / schema are unchanged (the deliveries table already had the provider message-id
columns, so there is NO schema change and an upgrade from B1B.1 keeps transcript, participants, bindings and deliveries).
The B1A2 Stop-detector fix (NodeUtils / AppAdapter) is byte-identical to B1A2.

## Live providers
- NEW `engine/WebRoomProvider` adapts an embedded `WebProviderSurface` to `RoomProvider`.
- `WebProviderSurface.sendTurn(...)`: phased callbacks onSubmitted / onReply / onFailed(reason, maybeSubmitted); `cancelTurn()`; `reloadHome()`.
  Failure before the send click = FAILED (retry-safe); after the click = UNCERTAIN; never auto-resent.
- `agc_engine.js`: user bubble proven independently ("submitted"), opportunistic provider message ids (ids mode), and if a send is refused
  after insertion it clears exactly the text it inserted (no stale draft left in the provider composer).
- NEW `room/ReplyCleaner`: strips hidden "ChatGPT said:" headings / zero-width characters from captured replies.
- `RoomPromptBuilder`: requests over 16,000 chars keep start+end with a visible omission notice.
- RoomActivity hosts both provider pages attached, full size, under the opaque room UI (never GONE). Tap an avatar to bring a page forward:
  sign in, open a conversation, "Use this chat" (binds by URL id). Bindings from the Engine Lab carry over (one binding table).
- Live room id = "default". Developer mode (Room tools) switches to a separate mock room with the mock AIs and test controls.

## Bridge marker hardening (separate from the Stop fix)
- NEW `room/RoutingMarkers`; `RelayCoordinator` uses it. Accepts a valid marker alone on its line followed by harmless decoration
  (e.g. a circled digit); still rejects mid-line markers, unknown targets and prose after the marker.

## UI corrections
- Participant list collapses completely (chat reclaims the width); a compact avatar/status cluster stays in the header subtitle to expand it.
- The "-" remove badge sits at the cell's top-right corner, clear of the artwork (still one tap, Undo overlay).
- App-owned dark rounded dialogs and menu (`room/ui/AppUi`) replace the stock Android ones.
- Search is a persistent bar: query, "k of N", previous/next, close, highlighted matches (active match stronger).
- Stop / removal / app-restart interruptions show a neutral gray dot; red is only for real failures; gray-blue = not connected.
- Jump-to-latest moved into the bottom strip (in layout, no longer over message text). Mock replies no longer end in a fake "...".
- Avatars use the real launcher icon of the installed ChatGPT / Claude / Gemini app when present, else a neutral monogram (no approximated logos).

## Tests
`tools/roomtest/run_tests.sh`: 113 checks (adds reply cleaner, marker matcher, search, status rules, prompt cap) + schema test.

---
# B2.1 (0.14.1-b2-1, versionCode 26) - provider durability / capture fixes found in the live B2 test
Evidence: AI_GROUP_CHAT_B2_TEST_EVIDENCE_FOR_CLAUDE (screenshots/videos). Room / router / database / schema / Stop behavior are unchanged.

## 1. Claude reply capture no longer depends on message counts
Cause (from the timeout diagnostic): mode "counts", baseline a:4 u:4 -> later a:2 u:1 (newA -2, newU -3). Claude's message list is virtualized, so counts and
nodes are recycled; the count-based identity could never be proven even though Claude had finished.
Fix: every prompt now starts with a short unique tag "[ref xxxxxx]". The page finds OUR user bubble by that tag and takes the first assistant node AFTER
it in document order. Counts and node objects no longer matter, and an older answer can never match (it precedes our bubble). If our bubble cannot be
found the turn still fails closed. ChatGPT's stable-id identity remains a second accepted proof. The page also scrolls the chat to the end each poll
so the newest rows stay rendered.
Timeout accounting (revised after review): only time the APP spent in the background (Activity paused) is excluded from the 240 s timeout, tracked by
`BackgroundTracker`/`TurnClock` (pure Java, unit-tested). A provider page that merely reports document.visibilityState "hidden" underneath the
foreground room still counts in full, so a stuck capture cannot become a long hang. Hard cap: 20 minutes. While the page reports hidden and the app is
foreground the surface is nudged awake (onResume / resumeTimers); the timeout writes appForeground / viewShown / windowVisibility / size to the log.
Scrolling: the chat is nudged to its end only when our [ref] bubble or the reply is NOT currently rendered, and at most every 2 s.
Acceptance rule (found in review): a captured reply is accepted by `TurnAcceptance.accept` (pure Java, used by production code). In "nonce" mode the
count deltas are diagnostic only, so a virtualized page showing newA:-2 / newU:-3 no longer rejects a correctly identified reply; legacy ids/counts
modes keep their count evidence. A regression test reproduces the real failure (nonce, identity true, newA -2, newU -3 -> accepted).
The [ref xxxxxx] tag exists only on the provider page: canonical room messages never contain it, an echoed tag is stripped from replies (RefTag), and
the delivery row's provider-id column may hold "ref:xxxxxx" (not message text, never used in prompts).

## 2. "Claude responded:" block
The page exposes a visually-hidden screen-reader block ("Claude responded: <start of the reply>") that was captured. Reply text is now read with
sr-only / visually-hidden descendants removed; ReplyCleaner also drops a leading "<Name> said|responded|replied|wrote:" line and any echoed [ref xxxxxx].

## 3. Status dots follow current health
The room checks each connected provider page every 20 s (read-only health call; two bad snapshots in a row before red). A healthy check
(automatic or the Provider connections -> Check button) clears a red dot that came from an earlier failure. Stop / removal stay neutral gray.

## 4. Pre-turn preflight / recovery (before anything is submitted)
bound conversation -> wake -> re-check the DOM up to 4 times -> reload the bound chat (up to 2 times) -> only then submit. All pre-submit, so a failure is
retry-safe and nothing is ever resent.

## 5. Short messages, diagnostics out of the AI context
`FailureText.shorten` turns raw provider diagnostics into one short clause ("page isn't ready", "timed out while waiting for the reply", ...). Only that
text reaches the room, the database and prompts. System audit lines are never included in provider prompts. Full diagnostics go to the debug log
(Room tools -> Copy diagnostics log).

## Tests
`tools/roomtest/run_tests.sh`: 154 checks (adds the Claude heading/duplication cases from the video, FailureText, system-line exclusion, timeout accounting, ref-tag handling).

---
# B2.2A (0.14.2-b2-2a, versionCode 27) - recipient routing + natural conversation
Scope: routing only. NO database or schema change (room_schema_v1.sql identical), NO artifact work.
All B2.1 provider-engine files are byte-identical (WebProviderSurface, WebRoomProvider, agc_engine.js, RoomDb, ReplyCleaner, TurnAcceptance, TurnClock,
ProviderBinding, RelayCoordinator, NodeUtils/AppAdapter with the B1A2 Stop fix). The only core files touched are RoomRouter (one new enum value),
RoomController (one overload taking a pre-built plan; the one-argument call is unchanged), RoomPromptBuilder (one instruction), MockProvider, ProviderCatalog.

## New
- `room/RecipientParser` (pure Java): deterministic address detection. An AI is ADDRESSED only by an opening address ("Claude, ...", "hey Claude ..."),
  an @mention, ask/tell/have + name, or a trailing vocative (", Claude?"). A name merely mentioned in a sentence ("what does Claude think about this?") is NOT an address.
  Group: two names ("Claude and ChatGPT ..."), "both of you", "you guys", "you two", "you all", "everyone,". Independent: "each", "you each", "separately", "independently".
- `room/RunPlanner` (pure Java, sits ABOVE RoomRouter): direct address = exactly one step from the named AI in ANY room style; group = natural chain (or structured if that is
  the room style); each/separately = one independent answer per AI; no address = the room's style. The composer override beats the parser.
- Natural conversation = a bounded chain of CONVERSE turns (default AIs+1, max 4; two AIs: ChatGPT -> Claude -> ChatGPT). Each turn's request is the immediately preceding
  canonical message, so the last ChatGPT turn reacts to Claude and does not re-answer the user. No propose/review/revise wording.
- Structured collaboration (propose/review/revise) is unchanged and available as a conversation style.

## UI
- Routing chip above the message box ("Routing: ChatGPT -> Claude -> ChatGPT"): live as you type, and an OVERRIDE (Auto / Only <AI> / Both in conversation / Each separately) for the next message.
- Room tools -> Conversation style: Natural conversation (default; reuses AUTO_PICK, so no schema change), Structured, Single AI, Ask everyone separately.
  Natural length (Auto/2/3/4) is an app preference for now and moves into the database with B2.2B.
- Fresh rooms start natural; an existing room still on the old default (structured) is switched to natural once.

## Tests
`tools/roomtest/run_tests.sh`: 223 checks (+69): 34-row recipient phrase table, planner (direct bypass in every room style, natural 3-turn CONVERSE plan, last turn receives
Claude's message and not the user's, independent/"each", named-group order, structured unchanged, override beats parser, absent AI falls back with a note), Stop in natural mode.
