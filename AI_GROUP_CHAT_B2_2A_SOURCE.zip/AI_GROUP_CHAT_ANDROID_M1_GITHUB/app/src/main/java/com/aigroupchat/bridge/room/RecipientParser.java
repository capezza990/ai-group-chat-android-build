package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deterministic "who is the user talking to?" detection (pure Java, no model involved).
 * An AI counts as ADDRESSED only when its name is used as an address: as the opener ("Claude, ...", "hey Claude ..."),
 * as an @mention, after ask/tell/have, or as a trailing vocative (", Claude?"). A name merely mentioned inside a sentence
 * ("what does Claude think about this?") is NOT an address.
 */
public final class RecipientParser {
    public enum Kind { NONE, DIRECT, GROUP, INDEPENDENT }

    public static final class Result {
        public final Kind kind;
        public final List<String> ids; // DIRECT: the one addressed AI; GROUP/INDEPENDENT: the named AIs, or empty = everyone
        Result(Kind kind, List<String> ids) { this.kind = kind; this.ids = Collections.unmodifiableList(ids); }
    }

    private static final Result NONE = new Result(Kind.NONE, new ArrayList<>());

    private static final Pattern GREETING = Pattern.compile("^(?:hey there|hey|hi|hello|hiya|yo|ok|okay|so|and|um|uh|well|alright)(?:[,!.\\s]+|$)");
    private static final Pattern SEPARATOR = Pattern.compile("\\s*(?:,|&|\\+|\\band\\b)\\s*");
    private static final Pattern FOLLOW_WORD = Pattern.compile(
            "^\\s+(?:what|which|who|when|where|why|how|can|could|would|will|should|please|tell|explain|give|show|help|write|make|create|"
                    + "review|check|summari[sz]e|describe|list|compare|think|thoughts|do you|did you|are you|each|both)\\b");
    private static final Pattern IMPERATIVE = Pattern.compile("^(?:ask|tell|have|let|get|ping)\\s+");
    private static final Pattern GROUP_WORDS = Pattern.compile(
            "\\b(?:you guys|you all|y'all|all of you|both of you|you both|you two|you folks|you each|each of you)\\b");
    private static final Pattern VOCATIVE_GROUP = Pattern.compile("^(?:everyone|everybody|all)\\s*[,:]");
    private static final Pattern INDEPENDENT_WORDS = Pattern.compile(
            "\\b(?:you each|each of you|each of the ais|separately|independently|individually|on your own)\\b");

    private RecipientParser() {}

    public static Result parse(String text, Map<String, String[]> aliases) {
        if (text == null || text.trim().isEmpty() || aliases == null || aliases.isEmpty()) return NONE;

        Map<String, String> aliasToId = new LinkedHashMap<>();
        for (Map.Entry<String, String[]> e : aliases.entrySet()) for (String a : e.getValue()) aliasToId.put(a.toLowerCase(Locale.ROOT), e.getKey());
        List<String> sorted = new ArrayList<>(aliasToId.keySet());
        sorted.sort((a, b) -> Integer.compare(b.length(), a.length())); // longest alias first ("chat gpt" before "gpt")
        StringBuilder alt = new StringBuilder();
        for (String a : sorted) { if (alt.length() > 0) alt.append('|'); alt.append(Pattern.quote(a)); }
        Pattern name = Pattern.compile("@?(" + alt + ")(?![a-z0-9])");

        String s = text.trim().toLowerCase(Locale.ROOT);
        int nl = s.indexOf('\n');
        String line = nl >= 0 ? s.substring(0, nl) : s;
        String head = line.length() > 200 ? line.substring(0, 200) : line;

        String core = head;
        while (true) { // strip leading greetings: "hey", "hi", "ok so", ...
            Matcher g = GREETING.matcher(core);
            if (g.find() && g.end() > 0) core = core.substring(g.end()); else break;
        }

        List<String> names = new ArrayList<>();

        // 1. leading address: "claude, ..." / "claude and chatgpt: ..." / "@claude what ..."
        List<String> lead = readNames(core, 0, name, aliasToId);
        if (!lead.isEmpty()) {
            int end = namesEnd(core, 0, name);
            String rest = core.substring(end);
            boolean follows = rest.trim().isEmpty() || rest.matches("(?s)^\\s*[,:;\\-\\u2013\\u2014?!.].*") || FOLLOW_WORD.matcher(rest).find();
            if (follows) names = lead;
        }

        // 2. imperative: "ask claude ...", "tell chatgpt and claude ..."
        if (names.isEmpty()) {
            Matcher im = IMPERATIVE.matcher(core);
            if (im.find()) names = readNames(core, im.end(), name, aliasToId);
        }

        // 3. @mentions anywhere in the first line
        if (names.isEmpty()) {
            Matcher at = Pattern.compile("@(" + alt + ")(?![a-z0-9])").matcher(head);
            while (at.find()) { String id = aliasToId.get(at.group(1)); if (!names.contains(id)) names.add(id); }
        }

        // 4. trailing vocative on the last line: "..., claude?"
        if (names.isEmpty()) {
            String last = s.substring(s.lastIndexOf('\n') + 1).trim();
            Matcher tv = Pattern.compile(",\\s*((?:" + name.pattern() + ")(?:\\s*(?:,|&|\\+|\\band\\b)\\s*(?:" + name.pattern() + "))*)\\s*[?!.]*$").matcher(last);
            if (tv.find()) names = readNames(tv.group(1), 0, name, aliasToId);
        }

        boolean group = GROUP_WORDS.matcher(head).find() || VOCATIVE_GROUP.matcher(core).find();
        boolean independent = INDEPENDENT_WORDS.matcher(head).find();

        if (names.size() == 1 && !group) return new Result(Kind.DIRECT, names);
        if (names.size() >= 2 || (names.isEmpty() && group)) {
            return new Result(independent ? Kind.INDEPENDENT : Kind.GROUP, names);
        }
        if (names.size() == 1) return new Result(Kind.DIRECT, names); // "claude, you guys..." -> still the named one
        if (independent) return new Result(Kind.INDEPENDENT, new ArrayList<>());
        return NONE;
    }

    /** Reads "name (, | and | & | +) name ..." starting at pos; returns distinct provider ids in order. */
    private static List<String> readNames(String s, int pos, Pattern name, Map<String, String> aliasToId) {
        List<String> out = new ArrayList<>();
        Matcher m = name.matcher(s);
        m.region(pos, s.length());
        while (m.lookingAt()) {
            String id = aliasToId.get(m.group(1));
            if (!out.contains(id)) out.add(id);
            int next = m.end();
            Matcher sep = SEPARATOR.matcher(s);
            sep.region(next, s.length());
            if (!sep.lookingAt()) break;
            Matcher nm = name.matcher(s);
            nm.region(sep.end(), s.length());
            if (!nm.lookingAt()) break;
            m = nm;
        }
        return out;
    }

    private static int namesEnd(String s, int pos, Pattern name) {
        Matcher m = name.matcher(s);
        m.region(pos, s.length());
        int end = pos;
        while (m.lookingAt()) {
            end = m.end();
            Matcher sep = SEPARATOR.matcher(s);
            sep.region(end, s.length());
            if (!sep.lookingAt()) break;
            Matcher nm = name.matcher(s);
            nm.region(sep.end(), s.length());
            if (!nm.lookingAt()) break;
            m = nm;
        }
        return end;
    }
}
