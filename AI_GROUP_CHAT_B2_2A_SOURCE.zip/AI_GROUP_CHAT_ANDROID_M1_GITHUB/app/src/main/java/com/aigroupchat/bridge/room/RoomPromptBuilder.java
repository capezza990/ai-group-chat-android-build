package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Builds the text sent to one provider from CANONICAL room messages. Distinguishes room context from the request,
 *  and user from AI authors, so three or more AIs stay unambiguous. */
public final class RoomPromptBuilder {
    public static final int MAX_CONTEXT_CHARS = 12000;
    public static final int RESTORE_MESSAGES = 12;
    /** Longest request text sent as-is; longer ones keep their start and end with a visible notice (web composers have limits). */
    public static final int MAX_REQUEST_CHARS = 16000;

    private RoomPromptBuilder() {}

    public static String build(RoomStore store, String roomId, RoomParticipant me, Delivery d, RoomMessage trigger,
                               RoomRouter.Role role, Map<String, String> names, boolean restore) {
        String myName = name(names, me.providerId);
        // context = canonical messages this provider has not yet accepted, up to what this request includes
        List<RoomMessage> ctx = new ArrayList<>();
        List<RoomMessage> raw = restore
                ? store.latestMessages(roomId, RESTORE_MESSAGES)
                : store.messagesBetween(roomId, me.contextSeq, d.uptoSeq);
        for (RoomMessage m : raw) {
            if (m.id.equals(trigger.id)) continue;
            if (RoomMessage.SYSTEM.equals(m.authorType)) continue; // UI audit lines ("Run ended early...") are never provider context
            if (m.seq > d.uptoSeq) continue;
            if (RoomMessage.PROVIDER.equals(m.authorType) && me.providerId.equals(m.authorId)) continue; // my own replies are already in my thread
            if (restore && m.seq > trigger.seq) continue;
            ctx.add(m);
        }
        int omitted = 0, chars = 0;
        List<String> lines = new ArrayList<>();
        for (int i = ctx.size() - 1; i >= 0; i--) { // keep the newest within the cap
            String line = label(ctx.get(i), names) + " " + ctx.get(i).text;
            if (chars + line.length() > MAX_CONTEXT_CHARS && !lines.isEmpty()) { omitted = i + 1; break; }
            chars += line.length();
            lines.add(0, line);
        }

        StringBuilder sb = new StringBuilder();
        sb.append("[AI GROUP CHAT ROOM] You are ").append(myName)
                .append(", one participant in a shared room with the user and other AIs.\n");
        if (!lines.isEmpty()) {
            sb.append(restore ? "\nROOM CONTEXT RESTORE (recent room history; your own thread may be missing it):\n"
                              : "\nROOM CONTEXT (messages you have not seen yet; background only, do not answer them individually):\n");
            if (omitted > 0) sb.append("(").append(omitted).append(" older messages omitted)\n");
            for (String l : lines) sb.append(l).append('\n');
        }
        sb.append("\nREQUEST (").append(instruction(role)).append("):\n");
        sb.append(label(trigger, names)).append(' ').append(fit(trigger.text));
        return sb.toString();
    }

    static String fit(String text) {
        if (text == null || text.length() <= MAX_REQUEST_CHARS) return text == null ? "" : text;
        int head = 11000, tail = 4000;
        int omitted = text.length() - head - tail;
        return text.substring(0, head) + "\n[... " + omitted + " characters omitted by AI Group Chat to fit the provider's message limit ...]\n"
                + text.substring(text.length() - tail);
    }

    static String instruction(RoomRouter.Role role) {
        switch (role) {
            case REVIEW: return "review this message critically and suggest concrete improvements";
            case REVISE: return "revise your earlier answer, taking the review(s) above into account";
            case INDEPENDENT: return "answer independently";
            case CONVERSE: return "reply naturally as one participant in a group conversation: react to this latest message, add something new if you can, and don't repeat what you've already said";
            case ANSWER:
            default: return "respond to this message";
        }
    }

    static String label(RoomMessage m, Map<String, String> names) {
        if (RoomMessage.USER.equals(m.authorType)) return "[User]";
        if (RoomMessage.SYSTEM.equals(m.authorType)) return "[System]";
        return "[" + name(names, m.authorId) + "]";
    }

    private static String name(Map<String, String> names, String id) {
        String n = names == null ? null : names.get(id);
        return n == null || n.isEmpty() ? id : n;
    }
}
