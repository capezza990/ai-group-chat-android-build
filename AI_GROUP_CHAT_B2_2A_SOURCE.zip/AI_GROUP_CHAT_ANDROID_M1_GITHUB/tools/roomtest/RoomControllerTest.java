import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Deterministic harness for the canonical-room core (no Android, no network). Run: tools/roomtest/run_tests.sh */
public final class RoomControllerTest {
    static int checks, failures;
    static final String ROOM = "default";

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) { failures++; System.out.println("    FAIL: " + what); }
    }

    static final class Fixture {
        final InMemoryRoomStore store = new InMemoryRoomStore();
        final MockProvider a = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
        final MockProvider b = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
        final List<String> finished = new ArrayList<>();
        final List<RoomMessage> seen = new ArrayList<>();
        final AtomicInteger clock = new AtomicInteger(1000);
        RoomController c;

        Fixture() { c = controller(); c.addParticipant("chatgpt"); c.addParticipant("claude"); }

        RoomController controller() {
            RoomController rc = new RoomController(store, ROOM, new RoomController.Events() {
                @Override public void onMessage(RoomMessage m) { seen.add(m); }
                @Override public void onRunFinished(String s) { finished.add(s); }
            }, () -> clock.incrementAndGet(), new java.util.function.Supplier<String>() {
                int n; public String get() { return "id" + (++n) + "-" + System.nanoTime(); }
            });
            rc.registerProvider(a);
            rc.registerProvider(b);
            return rc;
        }

        List<RoomMessage> all() { return store.messagesBetween(ROOM, 0, Long.MAX_VALUE); }
        long count(String type) { return all().stream().filter(m -> m.authorType.equals(type)).count(); }
        RoomParticipant part(String id) { return store.participants(ROOM).stream().filter(p -> p.providerId.equals(id)).findFirst().get(); }
    }

    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }

    public static void main(String[] args) {
        test("user message is persisted before dispatch; delivery is SENDING at send time", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.a.onSend = prompt -> {
                boolean userSaved = f.store.latestMessages(ROOM, 5).stream().anyMatch(m -> m.authorType.equals("USER") && m.text.equals("hello"));
                boolean sending = f.store.deliveriesInState(DeliveryState.SENDING).size() == 1;
                ok[0] = userSaved && sending;
            };
            f.c.submitUserMessage("hello");
            check(ok[0], "at send(): user message saved and delivery SENDING");
            check(f.count("PROVIDER") == 1, "reply stored");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 1, "delivery CAPTURED");
        });

        test("provider failure leaves the canonical user message intact and the delivery FAILED", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.FAIL_BEFORE_SEND;
            f.c.submitUserMessage("keep me");
            check(f.count("USER") == 1 && f.count("PROVIDER") == 0, "user message kept, no reply");
            check(f.store.deliveriesInState(DeliveryState.FAILED).size() == 1, "delivery FAILED (safe to retry)");
            check(f.part("chatgpt").contextSeq == 0, "context not advanced by a failed request");
            check(!f.c.isBusy(), "run cleared");
            f.a.behavior = MockProvider.Behavior.REPLY;
            check(f.c.submitUserMessage("again") != null, "next message accepted after a failure");
            check(f.count("PROVIDER") == 1, "next message answered");
        });

        test("captured reply is persisted before the next provider receives it (collaborate)", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.b.onSend = prompt -> {
                boolean stored = f.store.latestMessages(ROOM, 10).stream().anyMatch(m -> m.authorType.equals("PROVIDER") && m.authorId.equals("chatgpt"));
                ok[0] = stored && prompt.contains("ChatGPT reply #1");
            };
            f.c.submitUserMessage("design X");
            check(ok[0], "ChatGPT's reply was already stored and is in Claude's prompt");
            check(f.count("PROVIDER") == 3, "propose, review, revise = 3 provider messages");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 3, "3 deliveries CAPTURED");
            check(f.finished.size() == 1 && f.finished.get(0).equals("done"), "run finished cleanly");
        });

        test("restart: SENDING and SENT become UNCERTAIN and nothing is auto-resent", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("one");
            check(f.store.deliveriesInState(DeliveryState.SENDING).size() == 1, "stuck in SENDING");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            g.c.submitUserMessage("two");
            check(g.store.deliveriesInState(DeliveryState.SENT).size() == 1, "stuck in SENT");
            // "restart": a brand-new controller on the same stores
            RoomController f2 = f.controller();
            check(f2.recoverOnStart() == 1, "f: one delivery recovered");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "f: now UNCERTAIN");
            check(f.store.deliveriesInState(DeliveryState.SENDING).isEmpty(), "f: no SENDING left");
            check(f.a.prompts.size() == 1, "f: no automatic resend (still exactly 1 prompt)");
            RoomController g2 = g.controller();
            check(g2.recoverOnStart() == 1 && g.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "g: SENT -> UNCERTAIN");
            check(g.count("USER") == 1, "canonical user message survived the restart");
        });

        test("disabled participant keeps history and binding; re-adding restores context position", () -> {
            Fixture f = new Fixture();
            f.store.putBinding(new ProviderBinding("claude", "conv-1", "https://claude.ai/chat/conv-1", "t", 5L));
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("q1");
            long ctx = f.part("claude").contextSeq;
            check(ctx > 0, "claude accepted a request, context advanced");
            int bPrompts = f.b.prompts.size();
            f.c.removeParticipant("claude");
            check(!f.part("claude").enabled, "claude disabled");
            check(f.store.getBinding("claude") != null, "binding kept");
            check(f.count("PROVIDER") == 2, "old replies kept");
            f.c.submitUserMessage("q2");
            check(f.b.prompts.size() == bPrompts, "disabled participant receives nothing");
            f.c.addParticipant("claude");
            check(f.part("claude").enabled && f.part("claude").contextSeq == ctx, "re-enabled with the same context position");
        });

        test("duplicate provider callbacks create one message", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            f.c.submitUserMessage("dup?");
            check(f.count("PROVIDER") == 1, "exactly one provider message");
            RoomMessage m = f.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get();
            RoomMessage again = f.store.appendMessage(ROOM, m.id, "PROVIDER", "chatgpt", "different", null, 9L);
            check(again.seq == m.seq && again.text.equals(m.text), "appendMessage is idempotent on id and never rewrites text");
            check(f.count("PROVIDER") == 1, "still one after re-append");
        });

        test("router: collaborate sequences match the legacy relay", () -> {
            List<RoomParticipant> two = new ArrayList<>();
            two.add(new RoomParticipant(ROOM, "chatgpt", true, 0, 0, "UNKNOWN"));
            two.add(new RoomParticipant(ROOM, "claude", true, 1, 0, "UNKNOWN"));
            RoomSettings s1 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "chatgpt", 1, 0);
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "1 round = propose, review, revise");
            RoomSettings s2 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "claude", 2, 0);
            check(RoomRouter.plan(s2, two).toString().equals("[claude:ANSWER, chatgpt:REVIEW, claude:REVISE, chatgpt:REVIEW, claude:REVISE]"), "2 rounds, Claude first = 5 steps");
            check(new RoomSettings(ROOM, RoutingMode.COLLABORATE, "x", 9, 0).rounds == 2, "rounds clamp at 2 like the legacy control");
            List<RoomParticipant> three = new ArrayList<>(two);
            three.add(new RoomParticipant(ROOM, "gemini", true, 2, 0, "UNKNOWN"));
            check(RoomRouter.plan(s1, three).toString().equals("[chatgpt:ANSWER, claude:REVIEW, gemini:REVIEW, chatgpt:REVISE]"), "3 AIs: every other AI reviews in order");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.ASK_ALL, "", 1, 0), two).toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "ask all = independent");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.SINGLE, "claude", 1, 0), two).toString().equals("[claude:ANSWER]"), "single");
            two.get(1).enabled = false;
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER]"), "disabled AI is skipped; lone AI just answers");
            two.get(0).enabled = false;
            check(RoomRouter.plan(s1, two).isEmpty(), "nobody enabled = empty plan");
        });

        test("independent prompts exclude the other AI's reply; later prompts include what the AI has not seen", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("first question");
            check(!f.b.prompts.get(0).contains("ChatGPT reply #1"), "Claude's independent answer did not see ChatGPT's reply");
            f.c.submitUserMessage("second question");
            String p = f.a.prompts.get(1);
            check(p.contains("Claude reply #1") && p.contains("ROOM CONTEXT"), "ChatGPT's next prompt includes Claude's earlier reply as context");
            check(!p.contains("ChatGPT reply #1"), "ChatGPT's own earlier reply is not echoed back");
            check(p.contains("REQUEST") && p.contains("[User] second question"), "request clearly separated from context");
        });

        test("context only advances for requests the provider accepted", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("a");
            check(f.part("chatgpt").contextSeq == 0, "SILENT (never accepted) leaves context at 0");
            f.c.stop();
            f.a.behavior = MockProvider.Behavior.REPLY;
            f.c.submitUserMessage("b");
            check(f.part("chatgpt").contextSeq > 0, "accepted request advances context");
        });

        test("store: createDelivery idempotent, transition is compare-and-set, atomic rolls back", () -> {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.ensureRoom(ROOM, 1L);
            RoomMessage m = s.appendMessage(ROOM, "m1", "USER", "user", "x", null, 1L);
            Delivery d1 = s.createDelivery("d1", ROOM, m.id, "chatgpt", m.seq, 1L);
            Delivery d2 = s.createDelivery("d2", ROOM, m.id, "chatgpt", m.seq, 2L);
            check(d1.id.equals(d2.id), "same (trigger, provider) returns the same delivery");
            check(s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 2L), "PENDING -> SENDING");
            check(!s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 3L), "second PENDING -> SENDING is refused");
            try {
                s.atomic(() -> { s.appendMessage(ROOM, "m2", "USER", "user", "y", null, 2L); throw new IllegalStateException("boom"); });
            } catch (IllegalStateException expected) { }
            check(s.getMessage("m2") == null, "rolled back: m2 does not exist");
            check(s.appendMessage(ROOM, "m3", "USER", "user", "z", null, 3L).seq == 2, "seq not consumed by the rolled-back insert");
        });

        test("stop mid-run marks the delivery UNCERTAIN and dispatches nothing further", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("long task");
            check(f.c.isBusy(), "busy while waiting");
            check(f.c.submitUserMessage("interrupt") == null, "a second message is refused while busy");
            f.c.stop();
            check(!f.c.isBusy(), "not busy after stop");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "active delivery UNCERTAIN");
            check(f.b.prompts.isEmpty(), "Claude was never asked");
            check(f.count("USER") == 1, "only the first user message exists");
        });

        test("participant removed mid-run is skipped without a crash", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.onSend = p -> { if (f.a.prompts.size() == 1) f.c.removeParticipant("claude"); };
            f.c.submitUserMessage("go");
            check(f.b.prompts.isEmpty(), "Claude's review turn was skipped");
            check(f.count("PROVIDER") >= 1 && !f.c.isBusy(), "run completed");
        });

        test("empty reply is UNCERTAIN, not stored, and ends the run", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.EMPTY_REPLY;
            f.c.submitUserMessage("hi");
            check(f.count("PROVIDER") == 0, "blank reply not stored");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "delivery UNCERTAIN");
        });

        test("no enabled participants: the user message is still saved", () -> {
            Fixture f = new Fixture();
            f.c.removeParticipant("chatgpt");
            f.c.removeParticipant("claude");
            RoomMessage m = f.c.submitUserMessage("anyone there?");
            check(m != null && f.count("USER") == 1, "user message persisted");
            check(f.finished.size() == 1 && f.finished.get(0).startsWith("no enabled"), "run reports nobody to answer");
        });

        test("late duplicate callbacks after the run moved on change nothing (queued scheduler, like the phone)", () -> {
            final java.util.ArrayDeque<Runnable> queue = new java.util.ArrayDeque<>();
            MockProvider.Scheduler q = (r, d) -> queue.add(r);
            InMemoryRoomStore store = new InMemoryRoomStore();
            MockProvider a = new MockProvider("chatgpt", "ChatGPT", q), b = new MockProvider("claude", "Claude", q);
            a.behavior = MockProvider.Behavior.LATE_DUPLICATE;
            b.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            RoomController c = new RoomController(store, "r", null);
            c.registerProvider(a); c.registerProvider(b);
            c.addParticipant("chatgpt"); c.addParticipant("claude");
            c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 2);
            c.submitUserMessage("two rounds");
            check(c.isBusy() && c.activeProviderId().equals("chatgpt"), "A is working after submit");
            check(c.runStatus().equals("step 1 of 5: ChatGPT (answer)"), "run status reads \"" + c.runStatus() + "\"");
            int guard = 0;
            while (!queue.isEmpty() && guard++ < 100) queue.poll().run();
            long providerMsgs = store.messagesBetween("r", 0, Long.MAX_VALUE).stream().filter(m -> m.authorType.equals("PROVIDER")).count();
            check(!c.isBusy(), "run finished");
            check(providerMsgs == 5, "2 rounds = 5 provider messages exactly (no duplicates), got " + providerMsgs);
            check(store.deliveriesInState(DeliveryState.CAPTURED).size() == 5, "5 CAPTURED deliveries");
            String order = "";
            for (RoomMessage m : store.messagesBetween("r", 0, Long.MAX_VALUE)) if (m.authorType.equals("PROVIDER")) order += m.authorId.charAt(1) + ",";
            check(order.equals("h,l,h,l,h,"), "legacy 2-round order chatgpt,claude,chatgpt,claude,chatgpt, got " + order);
            check(c.runStatus().isEmpty() && c.activeProviderId() == null, "idle status is empty");
        });

        test("provider catalog is data-driven and has more than two AIs", () -> {
            check(ProviderCatalog.all().size() >= 4, "catalog offers at least 4 AIs");
            check(ProviderCatalog.nameOf("gemini").equals("Gemini") && ProviderCatalog.nameOf("unknown-x").equals("unknown-x"), "nameOf");
            Fixture f = new Fixture();
            MockProvider delta = new MockProvider("mock-delta", "Mock Delta", MockProvider.Scheduler.IMMEDIATE);
            f.c.registerProvider(delta);
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.c.submitUserMessage("two AIs");
            long before = f.count("PROVIDER");
            f.c.addParticipant("mock-delta");
            check(f.store.participants(ROOM).size() == 3, "a third AI joins the same room");
            f.c.submitUserMessage("three AIs");
            check(f.count("PROVIDER") - before == 4, "3 AIs, 1 round = propose, 2 reviews, revise (4 messages)");
            check(f.count("USER") == 2 && before == 3, "earlier history untouched by adding an AI");
        });

        test("scroll follow: follows at the bottom, never yanks a reader, resumes on send or return", () -> {
            ScrollFollow f = new ScrollFollow();
            check(f.shouldFollowNewContent(), "starts following");
            f.onScrolled(false);
            check(!f.shouldFollowNewContent() && !f.isFollowing(), "user scrolled up: new replies do not move the view");
            f.onScrolled(false);
            check(!f.shouldFollowNewContent(), "still reading");
            f.onUserSent();
            check(f.shouldFollowNewContent(), "sending a message follows the conversation again");
            f.onScrolled(false);
            f.onScrolled(true);
            check(f.shouldFollowNewContent(), "returning near the bottom resumes following");
        });

        test("reply cleaner strips hidden speaker headings and invisible characters", () -> {
            check(ReplyCleaner.clean("ChatGPT said:\nHello there").equals("Hello there"), "removes the hidden \"ChatGPT said:\" heading");
            check(ReplyCleaner.clean("Claude said\n\nHi").equals("Hi"), "heading without colon");
            check(ReplyCleaner.clean("  a\u200Bb\r\n\r\n\r\n\r\nc  ").equals("ab\n\nc"), "zero-width chars, CRLF and blank-line runs");
            check(ReplyCleaner.clean("Mention that ChatGPT said: nothing special").equals("Mention that ChatGPT said: nothing special"), "only a LEADING heading is removed");
            check(ReplyCleaner.clean(null).isEmpty(), "null is empty");
        });

        test("routing marker tolerates trailing decoration but rejects prose and mid-line markers", () -> {
            java.util.function.Function<String, Boolean> m = t -> RoutingMarkers.PATTERN.matcher(t).find();
            check(m.apply("text\n[[NEXT:CLAUDE]]"), "plain marker");
            check(m.apply("text\n[[NEXT:CLAUDE]] \u2776"), "marker + circled digit (the Accessibility attachment decoration)");
            check(m.apply("text\n  [[DONE]] \u2460"), "indented DONE + decoration");
            check(m.apply("[[NEXT:USER]]\u200B"), "marker + zero-width character");
            check(m.apply("a\n[[NEXT:CHATGPT]]\u2776 \u2777\nmore"), "decoration on a middle line, marker still alone on its line");
            check(!m.apply("see [[NEXT:CLAUDE]]"), "mid-line marker rejected");
            check(!m.apply("[[NEXT:CLAUDE]] and some words"), "prose after the marker rejected");
            check(!m.apply("[[NEXT:BOB]]"), "unknown target rejected");
            check(!m.apply("[[NEXT:CLAUDE]] \u2776 text"), "decoration followed by prose rejected");
            check(!m.apply("no marker here"), "no marker");
            String cleaned = RoutingMarkers.PATTERN.matcher("answer\n[[NEXT:CLAUDE]] \u2776").replaceAll("");
            check(cleaned.trim().equals("answer"), "the whole marker line including the decoration is removed from the text");
        });

        test("transcript search: counts, order, wrap-around, case-insensitive", () -> {
            java.util.List<RoomMessage> msgs = new java.util.ArrayList<>();
            msgs.add(new RoomMessage(1, "a", "r", "USER", "user", "Test the test", 1, null));
            msgs.add(new RoomMessage(2, "b", "r", "PROVIDER", "claude", "no hit here", 2, null));
            msgs.add(new RoomMessage(3, "c", "r", "PROVIDER", "chatgpt", "TEST again", 3, null));
            java.util.List<TranscriptSearch.Match> hits = TranscriptSearch.find(msgs, "test", m -> m.text);
            check(hits.size() == 3, "3 matches across messages, got " + hits.size());
            check(hits.get(0).seq == 1 && hits.get(0).start == 0 && hits.get(1).start == 9 && hits.get(2).seq == 3, "positions and order");
            check(TranscriptSearch.find(msgs, "  ", m -> m.text).isEmpty() && TranscriptSearch.find(msgs, "zzz", m -> m.text).isEmpty(), "blank / missing query");
            check(TranscriptSearch.next(2, 3) == 0 && TranscriptSearch.next(-1, 3) == 0 && TranscriptSearch.prev(0, 3) == 2 && TranscriptSearch.prev(-1, 3) == 2, "next/prev wrap");
            check(TranscriptSearch.next(0, 0) == -1, "no matches: no position");
        });

        test("status rules: stop/removal are neutral, only real failures are red", () -> {
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "stopped by user"), "user stop is not a failure");
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "participant removed"), "removal is not a failure");
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "interrupted (app restart)"), "restart interruption is not a failure");
            check(StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "timeout after 240s"), "an unexplained UNCERTAIN is a real problem");
            check(StatusRules.isRealFailure(DeliveryState.FAILED, "composer not empty"), "FAILED is a real failure");
            check(StatusRules.of(false, true, false, true) == StatusRules.Status.NEUTRAL, "neutral stop shows neutral");
            check(StatusRules.of(true, true, true, true) == StatusRules.Status.WORKING, "working wins");
            check(StatusRules.of(false, false, true, false) == StatusRules.Status.NOT_CONNECTED, "not connected wins over problems");
            check(StatusRules.of(false, true, true, true) == StatusRules.Status.PROBLEM, "a real problem outranks neutral");
        });

        test("long requests are shortened with a visible notice; short ones are untouched; mock never fakes an ellipsis", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            StringBuilder big = new StringBuilder();
            for (int i = 0; i < 6000; i++) big.append("word").append(i).append(' ');
            f.c.submitUserMessage(big.toString());
            String p = f.a.prompts.get(0);
            check(p.length() < 20000, "prompt capped, got " + p.length());
            check(p.contains("characters omitted by AI Group Chat"), "visible omission notice");
            check(p.contains("word0 ") && p.contains("word5999"), "start and end of the request are kept");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.c.submitUserMessage("short message");
            check(!g.a.prompts.get(0).contains("omitted"), "short request untouched");
            String reply = g.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get().text;
            check(!reply.contains("\u2026") && !reply.contains("...") && reply.endsWith("short message"), "mock reply is complete with no ellipsis: " + reply);
        });

        test("B2.1: Claude 'responded' block and ref tags are removed from captured replies", () -> {
            check(ReplyCleaner.clean("Claude responded: ok\n\nok").equals("ok"), "the exact captured form from the video");
            check(ReplyCleaner.clean("Claude responded: The sentence is accurate and clear.\n\nThe sentence is accurate and clear. A few improvements:\n1. x")
                    .equals("The sentence is accurate and clear. A few improvements:\n1. x"), "long reply: hidden summary line dropped, real reply kept intact");
            check(ReplyCleaner.clean("Claude responded:\nHello").equals("Hello"), "heading with nothing after the colon");
            check(ReplyCleaner.clean("ChatGPT said:\nHi there").equals("Hi there"), "ChatGPT heading still handled");
            check(ReplyCleaner.clean("Claude responded: only this").equals("Claude responded: only this"), "a lone line is left alone (nothing to separate)");
            check(ReplyCleaner.clean("[ref 7f3a9c] Sure thing").equals("Sure thing"), "echoed ref tag removed");
            check(ReplyCleaner.clean("Answer mentions that Claude responded: to the user").equals("Answer mentions that Claude responded: to the user"), "only a LEADING heading is removed");
        });

        test("B2.1: failure text is short and never carries a JSON diagnostic", () -> {
            String blob = "unhealthy provider surface: {\"url\":\"https://chatgpt.com/c/6abe\",\"healthy\":false,\"composer\":false}";
            check(FailureText.shorten(blob).equals("page isn't ready"), "unhealthy surface -> " + FailureText.shorten(blob));
            check(FailureText.shorten("timeout after 240s; last poll {\"sendResult\":\"clicked\"}").equals("timed out while waiting for the reply"), "timeout");
            check(FailureText.shorten("could not settle on the bound conversation").startsWith("couldn't open"), "settle");
            check(FailureText.shorten("send failed: no-unique-send-button").equals("couldn't send (no-unique-send-button)"), "send failed code");
            check(FailureText.shorten("something odd: {\"a\":1,\"b\":2}").equals("something odd"), "unknown + JSON: JSON dropped");
            check(!FailureText.shorten("{\"only\":\"json\"}").contains("{"), "pure JSON becomes a short word");
            check(FailureText.shorten(null).equals("failed") && FailureText.shorten("  ").equals("failed"), "null/blank");
            String longTxt = "x".repeat(500);
            check(FailureText.shorten(longTxt).length() <= 100, "length capped");
        });

        test("B2.1: system audit lines never become provider context", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            f.store.appendMessage(ROOM, "sys1", "SYSTEM", "system", "Run ended early: ChatGPT: unhealthy provider surface: {\"huge\":\"blob\"}", null, 5L);
            f.c.submitUserMessage("hello");
            String p = f.b.prompts.get(0);
            check(!p.contains("unhealthy") && !p.contains("blob") && !p.contains("[System]"), "no system line in the prompt");
            check(p.contains("[User] hello"), "request intact");
        });

        test("B2.1: only APP background time pauses a turn timeout; a hidden page under the foreground room does not", () -> {
            long t0 = 1_000_000L, timeout = 240_000L, cap = 20L * 60_000L;
            BackgroundTracker bg = new BackgroundTracker();
            TurnClock clock = new TurnClock(t0, timeout, cap, bg.totalBackgroundMs(t0));
            check(!clock.expired(t0 + 239_000L, bg.totalBackgroundMs(t0 + 239_000L)), "foreground: not expired at 239 s");
            check(clock.expired(t0 + 241_000L, bg.totalBackgroundMs(t0 + 241_000L)), "foreground (page may report hidden): expires at 241 s, NOT extended");
            BackgroundTracker b2 = new BackgroundTracker();
            TurnClock c2 = new TurnClock(t0, timeout, cap, b2.totalBackgroundMs(t0));
            b2.setForeground(false, t0 + 60_000L);
            check(b2.totalBackgroundMs(t0 + 120_000L) == 60_000L, "an open background interval counts up to now");
            b2.setForeground(true, t0 + 360_000L);
            check(b2.totalBackgroundMs(t0 + 360_000L) == 300_000L, "closed background interval is 300 s");
            check(!c2.expired(t0 + 400_000L, b2.totalBackgroundMs(t0 + 400_000L)), "300 s in the background is excluded: active time only 100 s");
            check(c2.expired(t0 + 600_000L, b2.totalBackgroundMs(t0 + 600_000L)), "after enough foreground time it expires");
            BackgroundTracker b3 = new BackgroundTracker();
            TurnClock c3 = new TurnClock(t0, timeout, cap, 0);
            b3.setForeground(false, t0 + 1_000L);
            check(c3.expired(t0 + cap + 1L, b3.totalBackgroundMs(t0 + cap + 1L)), "hard 20-minute cap always applies, even in the background");
            BackgroundTracker b4 = new BackgroundTracker();
            b4.setForeground(false, 5_000L); b4.setForeground(true, 9_000L);
            TurnClock c4 = new TurnClock(10_000L, timeout, cap, b4.totalBackgroundMs(10_000L));
            check(c4.activeMs(20_000L, b4.totalBackgroundMs(20_000L)) == 10_000L, "background before the turn started is not subtracted from it");
        });

        test("B2.1: the prompt tag exists only on the provider page and is stripped everywhere it could echo", () -> {
            String tagged = RefTag.tag("7f3a9c", "hello there");
            check(tagged.equals("[ref 7f3a9c] hello there"), "tag format");
            check(RefTag.strip(tagged).equals("hello there"), "strip restores the original");
            check(ReplyCleaner.clean("Sure. You wrote [ref 7f3a9c] hello there, and I agree.").equals("Sure. You wrote hello there, and I agree."), "a tag echoed in the MIDDLE of a reply is removed");
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.c.submitUserMessage("plain user text");
            boolean clean = true;
            for (RoomMessage m : f.all()) if (m.text.contains("[ref ")) clean = false;
            check(clean, "no canonical room message contains a ref tag");
        });

        test("B2.1: nonce identity is accepted even when legacy counts are negative (the real Claude virtualization case)", () -> {
            check(TurnAcceptance.accept("Real reply text", true, true, "nonce", -2, -3), "mode=nonce identity=true newA=-2 newU=-3 -> ACCEPTED");
            check(TurnAcceptance.accept("Real reply text", true, true, "nonce", 0, 0), "nonce with zero counts -> accepted");
            check(!TurnAcceptance.accept("Real reply text", true, false, "nonce", 1, 1), "nonce but identity NOT proven -> rejected (fails closed)");
            check(!TurnAcceptance.accept("", true, true, "nonce", -2, -3), "empty reply -> rejected");
            check(!TurnAcceptance.accept("   \n ", true, true, "nonce", 2, 2), "whitespace-only reply -> rejected");
            check(!TurnAcceptance.accept("Real reply text", false, true, "nonce", 2, 2), "expected token missing -> rejected");
            check(!TurnAcceptance.accept("Real reply text", true, true, "counts", -2, -3), "legacy counts mode with negative growth -> rejected");
            check(!TurnAcceptance.accept("Real reply text", true, true, "ids", 0, 1), "legacy ids mode still needs new assistant growth");
            check(TurnAcceptance.accept("Real reply text", true, true, "ids", 1, 1), "legacy ids mode with growth -> accepted (ChatGPT unchanged)");
            check(TurnAcceptance.accept("Real reply text", true, true, "counts", 1, 1), "legacy counts mode with growth -> accepted");
            check(!TurnAcceptance.accept(null, true, true, "nonce", 1, 1), "null reply -> rejected");
            BackgroundTracker bg = new BackgroundTracker();
            TurnClock clock = new TurnClock(10_000L, 240_000L, 1_200_000L, bg.totalBackgroundMs(10_000L));
            bg.setForeground(false, 40_000L);
            check(clock.backgroundDuringTurnMs(bg.totalBackgroundMs(100_000L)) == 60_000L, "diagnostic background duration is correct while an interval is still open");
        });


        // ------------------------------------------------------------------ B2.2A: recipient routing + natural conversation
        test("recipient parser: phrase table (direct / group / independent / not an address)", () -> {
            java.util.Map<String, String[]> al = ProviderCatalog.aliases();
            Object[][] table = {
                {"Claude, what do you think about turtles?", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude, what do you think about turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"Hey Claude what do you think about turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"@Claude can you review this?", RecipientParser.Kind.DIRECT, "claude"},
                {"ChatGPT: summarize this", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"chatgpt, write a haiku", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"Hi ChatGPT - how are you", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"ask Claude what he thinks about turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"Tell ChatGPT to write a poem", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"what do you think, Claude?", RecipientParser.Kind.DIRECT, "claude"},
                {"Can you help me with this, ChatGPT?", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"Hello @ChatGPT, thoughts?", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"gpt, what's up", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"Claude", RecipientParser.Kind.DIRECT, "claude"},
                {"What does Claude think about this?", RecipientParser.Kind.NONE, ""},
                {"I asked Claude yesterday and he agreed", RecipientParser.Kind.NONE, ""},
                {"Claude is better than ChatGPT at poetry", RecipientParser.Kind.NONE, ""},
                {"ChatGPT said turtles are reptiles, what do you think?", RecipientParser.Kind.NONE, ""},
                {"What do you think about Claude?", RecipientParser.Kind.NONE, ""},
                {"Compare Claude and ChatGPT on coding", RecipientParser.Kind.NONE, ""},
                {"Please explain how turtles breathe", RecipientParser.Kind.NONE, ""},
                {"Tell me about turtles", RecipientParser.Kind.NONE, ""},
                {"Claude and ChatGPT, what do you think about turtles?", RecipientParser.Kind.GROUP, "claude,chatgpt"},
                {"ChatGPT and Claude: thoughts?", RecipientParser.Kind.GROUP, "chatgpt,claude"},
                {"@Claude and @ChatGPT what do you think", RecipientParser.Kind.GROUP, "claude,chatgpt"},
                {"both of you, what do you think?", RecipientParser.Kind.GROUP, ""},
                {"What do you guys think about turtles?", RecipientParser.Kind.GROUP, ""},
                {"Hey, what do you guys think?", RecipientParser.Kind.GROUP, ""},
                {"you two should discuss this", RecipientParser.Kind.GROUP, ""},
                {"What do you all think?", RecipientParser.Kind.GROUP, ""},
                {"Everyone, what's your favorite color?", RecipientParser.Kind.GROUP, ""},
                {"Claude and ChatGPT, what do you each think?", RecipientParser.Kind.INDEPENDENT, "claude,chatgpt"},
                {"Each of you, give me one sentence about dogs", RecipientParser.Kind.INDEPENDENT, ""},
                {"Answer separately: what is 2+2?", RecipientParser.Kind.INDEPENDENT, ""},
                {"", RecipientParser.Kind.NONE, ""},
            };
            for (Object[] row : table) {
                RecipientParser.Result r = RecipientParser.parse((String) row[0], al);
                String got = String.join(",", r.ids);
                check(r.kind == row[1] && got.equals(row[2]), "\"" + row[0] + "\" -> " + r.kind + " [" + got + "], expected " + row[1] + " [" + row[2] + "]");
            }
            check(RecipientParser.parse(null, al).kind == RecipientParser.Kind.NONE, "null text");
        });

        test("run planner: direct address bypasses every other AI, in any room style", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            for (RoutingMode m : new RoutingMode[]{RoutingMode.AUTO_PICK, RoutingMode.COLLABORATE, RoutingMode.ASK_ALL, RoutingMode.SINGLE}) {
                f.c.setRouting(m, "chatgpt", 1);
                RunPlanner.Plan p = RunPlanner.plan("hey Claude, what do you think about turtles", f.store.getRoom(ROOM), f.store.participants(ROOM),
                        ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
                check(p.steps.size() == 1 && p.steps.get(0).providerId.equals("claude") && p.steps.get(0).role == RoomRouter.Role.ANSWER,
                        m + ": exactly one step, Claude: " + p.steps);
            }
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            f.c.submitUserMessage("hey Claude, what do you think about turtles",
                    RunPlanner.plan("hey Claude, what do you think about turtles", f.store.getRoom(ROOM), f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0).steps);
            check(f.a.prompts.isEmpty(), "ChatGPT was never asked");
            check(f.b.prompts.size() == 1, "Claude was asked once");
            check(f.count("USER") == 1 && f.count("PROVIDER") == 1, "User -> Claude -> done (2 messages)");
            check(f.finished.size() == 1 && f.finished.get(0).equals("done") && !f.c.isBusy(), "run finished cleanly");
        });

        test("run planner: natural group conversation = ChatGPT -> Claude -> ChatGPT, all CONVERSE", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "", 1);
            RunPlanner.Plan p = RunPlanner.plan("What do you guys think about turtles?", f.store.getRoom(ROOM), f.store.participants(ROOM),
                    ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(p.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "default two-AI plan: " + p.steps);
            check(p.label.equals("ChatGPT \u2192 Claude \u2192 ChatGPT"), "chip label: " + p.label);
            f.c.submitUserMessage("What do you guys think about turtles?", p.steps);
            check(f.count("PROVIDER") == 3 && !f.c.isBusy(), "three AI turns, then done");
            String third = f.a.prompts.get(1); // ChatGPT's second turn
            check(third.contains("[Claude] Claude reply #1 [converse]"), "the last ChatGPT turn receives Claude's immediately preceding message as the request: " + third);
            check(!third.contains("[User]"), "...and does NOT re-ask the original user message");
            check(f.b.prompts.get(0).contains("[ChatGPT] ChatGPT reply #1 [converse]") && f.b.prompts.get(0).contains("[User] What do you guys think"),
                    "Claude sees ChatGPT's reply as the request and the user's question as context");
            check(!f.a.prompts.get(0).contains("revise") && !f.a.prompts.get(1).contains("review"), "no propose/review/revise wording anywhere");
        });

        test("run planner: other group shapes and styles", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "", 1);
            RoomSettings st = f.store.getRoom(ROOM);
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            RunPlanner.Plan indep = RunPlanner.plan("Claude and ChatGPT, what do you each think?", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(indep.steps.toString().equals("[claude:INDEPENDENT, chatgpt:INDEPENDENT]"), "'each' = independent answers, not a chain: " + indep.steps);
            RunPlanner.Plan sep = RunPlanner.plan("please answer separately: what is 2+2", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(sep.steps.toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "'separately' with nobody named = everyone independently: " + sep.steps);
            RunPlanner.Plan named = RunPlanner.plan("Claude and ChatGPT, what do you think about turtles?", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(named.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "named group starts with the first name: " + named.steps);
            RunPlanner.Plan plain = RunPlanner.plan("tell me about turtles", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(plain.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "no address in a natural room = natural group: " + plain.steps);
            RunPlanner.Plan two = RunPlanner.plan("hello everyone", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 2);
            check(two.steps.size() == 2, "turn setting 2 gives two turns: " + two.steps);
            RunPlanner.Plan four = RunPlanner.plan("hello everyone", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 4);
            check(four.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "four turns alternate: " + four.steps);
            // structured style keeps today's propose/review/revise for un-addressed and group messages
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            RoomSettings sc = f.store.getRoom(ROOM);
            RunPlanner.Plan structured = RunPlanner.plan("design a cache", sc, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(structured.steps.toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "structured unchanged: " + structured.steps);
            check(structured.label.startsWith("Structured: "), "structured label: " + structured.label);
            RunPlanner.Plan sg = RunPlanner.plan("what do you guys think of this design", sc, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(sg.steps.toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "group message in a structured room stays structured: " + sg.steps);
            // the chip override beats the parser
            RunPlanner.Plan ov = RunPlanner.plan("hey Claude, hi", st, ps, ProviderCatalog.aliases(), names, "chatgpt", 0);
            check(ov.overridden && ov.steps.toString().equals("[chatgpt:ANSWER]"), "override to ChatGPT beats 'hey Claude': " + ov.steps);
            RunPlanner.Plan ovg = RunPlanner.plan("hey Claude, hi", st, ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0);
            check(ovg.overridden && ovg.steps.size() == 3, "override to group beats a direct address: " + ovg.steps);
            RunPlanner.Plan ove = RunPlanner.plan("hey Claude, hi", st, ps, ProviderCatalog.aliases(), names, RunPlanner.EACH, 0);
            check(ove.steps.toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "override to each: " + ove.steps);
            // an addressed AI that is not in the room falls back to the default and says so
            f.c.removeParticipant("claude");
            RunPlanner.Plan gone = RunPlanner.plan("Claude, are you there?", st, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(gone.steps.toString().equals("[chatgpt:CONVERSE]") && gone.note.contains("Claude isn't in this chat"), "absent Claude: " + gone.steps + " / " + gone.note);
            f.c.removeParticipant("chatgpt");
            check(RunPlanner.plan("hi", st, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0).steps.isEmpty(), "nobody in the chat: empty plan");
        });

        test("natural conversation: Stop works, deliveries stay idempotent, structured submit is unchanged", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "", 1);
            f.b.behavior = MockProvider.Behavior.NEVER_REPLY;
            RunPlanner.Plan p = RunPlanner.plan("what do you guys think", f.store.getRoom(ROOM), f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            f.c.submitUserMessage("what do you guys think", p.steps);
            check(f.c.isBusy() && f.count("PROVIDER") == 1, "ChatGPT answered, Claude is pending");
            f.c.stop();
            check(!f.c.isBusy() && f.count("PROVIDER") == 1 && f.a.prompts.size() == 1, "Stop: completed ChatGPT message stays, no third turn starts");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "the stopped delivery is UNCERTAIN, never resent");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            g.c.submitUserMessage("plain old call without a plan");
            check(g.count("PROVIDER") == 3 && g.store.deliveriesInState(DeliveryState.CAPTURED).size() == 3, "the one-argument submit still runs the structured plan");
        });


        // ------------------------------------------------------------------ B2.2A fix: typed order beats the stored first speaker (one run only)
        test("named group: the order the user typed wins over the stored first-speaker preference", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude"); names.put("mock-delta", "Mock Delta");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RunPlanner.Plan a = RunPlanner.plan("Claude and ChatGPT, what do you think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(a.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "preference chatgpt + 'Claude and ChatGPT...' -> Claude first: " + a.steps);
            RunPlanner.Plan a2 = RunPlanner.plan("ChatGPT and Claude, what do you think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(a2.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "preference chatgpt + 'ChatGPT and Claude...' -> ChatGPT first: " + a2.steps);
            f.c.setRouting(RoutingMode.AUTO_PICK, "claude", 1);
            RunPlanner.Plan b = RunPlanner.plan("ChatGPT and Claude, what do you think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(b.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "preference claude + 'ChatGPT and Claude...' -> ChatGPT first: " + b.steps);

            // three named AIs keep the typed order across all four turns
            f.c.registerProvider(new MockProvider("mock-delta", "Mock Delta", MockProvider.Scheduler.IMMEDIATE));
            f.c.addParticipant("mock-delta");
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            java.util.List<RoomParticipant> three = f.store.participants(ROOM);
            RunPlanner.Plan c3 = RunPlanner.plan("Delta, Claude and ChatGPT, thoughts?", f.store.getRoom(ROOM), three, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(c3.steps.toString().equals("[mock-delta:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE, mock-delta:CONVERSE]"), "three named AIs preserve typed order: " + c3.steps);
            // a named subset that does not include the stored preference simply starts with the first name
            RunPlanner.Plan sub = RunPlanner.plan("Claude and Delta, thoughts?", f.store.getRoom(ROOM), three, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(sub.steps.toString().equals("[claude:CONVERSE, mock-delta:CONVERSE, claude:CONVERSE]"), "named subset without the preferred AI: " + sub.steps);
        });

        test("unnamed group and the Both chip still honor the stored first-speaker preference", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "claude", 1);
            RunPlanner.Plan g1 = RunPlanner.plan("What do you guys think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(g1.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "'you guys' + preference claude -> Claude first: " + g1.steps);
            RunPlanner.Plan n1 = RunPlanner.plan("tell me about turtles", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(n1.steps.get(0).providerId.equals("claude"), "no address in a natural room + preference claude -> Claude first: " + n1.steps);
            RunPlanner.Plan chip = RunPlanner.plan("hey Claude, hi", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0);
            check(chip.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "Both chip + preference claude -> Claude first: " + chip.steps);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RunPlanner.Plan chip2 = RunPlanner.plan("hey Claude, hi", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0);
            check(chip2.steps.get(0).providerId.equals("chatgpt"), "Both chip + preference chatgpt -> ChatGPT first: " + chip2.steps);
            RunPlanner.Plan g2 = RunPlanner.plan("What do you guys think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(g2.steps.get(0).providerId.equals("chatgpt"), "'you guys' + preference chatgpt -> ChatGPT first: " + g2.steps);
        });

        test("end to end: the first stored AI message is the first named AI, and the stored preference is never changed", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RoomSettings before = f.store.getRoom(ROOM);
            RunPlanner.Plan p = RunPlanner.plan("Claude and ChatGPT, what do you think?", before, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            f.c.submitUserMessage("Claude and ChatGPT, what do you think?", p.steps);
            StringBuilder order = new StringBuilder();
            for (RoomMessage m : f.all()) if (m.authorType.equals("PROVIDER")) order.append(m.authorId).append(',');
            check(order.toString().equals("claude,chatgpt,claude,"), "stored provider messages in order: " + order);
            check(!f.c.isBusy() && f.finished.get(f.finished.size() - 1).equals("done"), "run finished cleanly");
            RoomSettings after = f.store.getRoom(ROOM);
            check(after.modeArg.equals("chatgpt") && after.mode == before.mode && after.rounds == before.rounds, "planning and submitting did not change the stored preference: " + after.modeArg);
            // the NEXT unaddressed group message still starts with the stored preference
            RunPlanner.Plan next = RunPlanner.plan("What do you guys think now?", after, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(next.steps.get(0).providerId.equals("chatgpt"), "a later unnamed group message starts with ChatGPT again: " + next.steps);
        });

        test("unchanged by the fix: independent answers keep typed order; structured rooms keep today's behavior", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RunPlanner.Plan ind = RunPlanner.plan("Claude and ChatGPT, what do you each think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(ind.steps.toString().equals("[claude:INDEPENDENT, chatgpt:INDEPENDENT]"), "independent order is the typed order: " + ind.steps);
            RunPlanner.Plan dir = RunPlanner.plan("hey Claude, hi", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(dir.steps.toString().equals("[claude:ANSWER]"), "direct address unchanged: " + dir.steps);
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            RunPlanner.Plan st = RunPlanner.plan("Claude and ChatGPT, review this design", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(st.steps.toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "structured room unchanged (named order not applied; separate decision): " + st.steps);
        });

        System.out.println("\n" + checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
