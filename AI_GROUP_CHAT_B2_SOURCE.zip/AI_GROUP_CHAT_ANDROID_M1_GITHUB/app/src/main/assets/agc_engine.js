/* AI Group Chat engine lab (P1-A). Installed into provider pages; idempotent.
 * Read-only except send() and the explicit Type Check. Health/poll/probe never mutate the page. */
(function () {
  if (window.__agc && window.__agc.version === 4) { window.__agc.spec = window.__AGC_SPEC || window.__agc.spec; return; }
  var st = {
    pushes: 0, lastPush: 0, sendResult: 'none', before: { a: 0, u: 0 },
    baseA: null, baseU: null, beforeNodesA: null,
    sentNorm: '', sentFullNorm: '', replyNode: null,
    typeCheck: 'not-run', sendVerified: false, lastBrief: '', ambiguous: {}
  };

  function spec() { return window.__AGC_SPEC || {}; }

  function q(list) {
    list = list || [];
    for (var i = 0; i < list.length; i++) {
      try { var el = document.querySelector(list[i]); if (el) return el; } catch (e) {}
    }
    return null;
  }

  // Exactly one match or nothing. Ambiguity is reported; no alternate element is guessed/clicked.
  function qUnique(list, name) {
    list = list || [];
    delete st.ambiguous[name]; // ambiguity reflects the current DOM, never a stale prior state
    for (var i = 0; i < list.length; i++) {
      try {
        var n = document.querySelectorAll(list[i]);
        if (n.length === 1) { delete st.ambiguous[name]; return n[0]; }
        if (n.length > 1) { st.ambiguous[name] = list[i] + ' x' + n.length; return null; }
      } catch (e) {}
    }
    return null;
  }

  function qa(list) {
    list = list || [];
    for (var i = 0; i < list.length; i++) {
      try { var n = document.querySelectorAll(list[i]); if (n && n.length) return Array.prototype.slice.call(n); } catch (e) {}
    }
    return [];
  }

  function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }

  function composerText(el) {
    return (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') ? (el.value || '') : (el.innerText || el.textContent || '');
  }

  function composerEmpty(el) { return composerText(el).replace(/\s+/g, '') === ''; }

  function generating() { return !!(q(spec().stop) || q(spec().streaming)); }

  function setText(el, text) {
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (!desc || !desc.set) return false;
      desc.set.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    var ok = document.execCommand('insertText', false, text);
    if (!ok) {
      el.textContent = text;
      try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); }
      catch (e) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    return true;
  }

  // Removes content from ONE element with a range scoped to that element. Never document-wide selectAll.
  function deleteAllIn(el) {
    el.focus();
    var sel = window.getSelection(), r = document.createRange();
    r.selectNodeContents(el);
    sel.removeAllRanges(); sel.addRange(r);
    document.execCommand('delete', false, null);
    sel.removeAllRanges();
  }

  function challenge() {
    try {
      var t = (document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 400) : '');
      return /just a moment|verify you are human|checking your browser|unusual activity/i.test(t);
    } catch (e) { return false; }
  }

  // Generic counts for the tiny observer payload.
  function brief() {
    var a = qa(spec().assistant), u = qa(spec().user);
    return { a: a.length, u: u.length, gen: generating(), len: a.length ? (a[a.length - 1].innerText || '').length : 0 };
  }

  // ---- Reply identity. Authority = stable message ids or count growth, never DOM node-object novelty. ----
  function idOf(n) {
    var e = (n.getAttribute && n.getAttribute('data-message-id')) ? n : (n.closest ? n.closest('[data-message-id]') : null);
    return e ? (e.getAttribute('data-message-id') || '') : '';
  }

  // Returns IDs only if EVERY current node exposes a stable id and IDs are unique. Otherwise null.
  function idsOf(nodes) {
    if (!nodes.length) return null;
    var out = [], seen = {};
    for (var i = 0; i < nodes.length; i++) {
      var id = idOf(nodes[i]);
      if (!id || seen[id]) return null;
      seen[id] = true; out.push(id);
    }
    return out;
  }

  function snapshot(list) {
    var nodes = qa(list), ids = idsOf(nodes);
    return { count: nodes.length, ids: ids ? new Set(ids) : null };
  }

  function identify() {
    var res = { mode: 'none', newA: 0, newU: 0, userMatches: false, identity: false, node: null, nodeNovelty: 0, userId: '', asstId: '' };
    if (!st.baseA || !st.baseU) return res;

    var A = qa(spec().assistant), U = qa(spec().user);
    var idsA = idsOf(A), idsU = idsOf(U);
    var lastU = null, lastA = null;
    var ia = -1, iu = -1;

    if (st.baseA.ids && st.baseU.ids && idsA && idsU) {
      res.mode = 'ids';
      for (var i = 0; i < A.length; i++) if (!st.baseA.ids.has(idsA[i])) { res.newA++; ia = i; }
      for (var j = 0; j < U.length; j++) if (!st.baseU.ids.has(idsU[j])) { res.newU++; iu = j; }
      if (ia >= 0) lastA = A[ia];
      if (iu >= 0) lastU = U[iu];
    } else {
      res.mode = 'counts';
      res.newA = A.length - st.baseA.count;
      res.newU = U.length - st.baseU.count;
      if (A.length) lastA = A[A.length - 1];
      if (U.length) lastU = U[U.length - 1];
    }

    if (st.beforeNodesA) res.nodeNovelty = A.filter(function (n) { return !st.beforeNodesA.has(n); }).length; // diagnostic only
    // B2: the user bubble is proven independently of any reply, so "submitted" can be reported as soon as it appears.
    if (res.newU > 0 && lastU) {
      var userIdx = norm(lastU.innerText).indexOf(st.sentNorm);
      res.userMatches = st.sentNorm !== '' && userIdx >= 0 && userIdx <= 16;
      if (res.userMatches && res.mode === 'ids' && iu >= 0) res.userId = idsU[iu];
    }
    if (res.newA <= 0 || res.newU <= 0 || !lastA || !lastU) return res;

    var follows = (lastU.compareDocumentPosition(lastA) & 4) !== 0; // DOCUMENT_POSITION_FOLLOWING
    res.identity = res.userMatches && follows;
    if (res.identity) {
      res.node = lastA;
      if (res.mode === 'ids' && ia >= 0) res.asstId = idsA[ia];
    }
    return res;
  }

  function poll() {
    var id = identify(), b = brief();
    if (id.node) st.replyNode = id.node;
    return JSON.stringify({
      sendResult: st.sendResult, before: st.before, a: b.a, u: b.u, gen: b.gen,
      len: id.node ? (id.node.innerText || '').length : 0,
      mode: id.mode, newA: id.newA, newU: id.newU, nodeNovelty: id.nodeNovelty,
      userMatches: id.userMatches, userProven: id.newU > 0 && id.userMatches, userId: id.userId, asstId: id.asstId,
      identity: id.identity,
      url: location.origin + location.pathname, vis: document.visibilityState,
      pushes: st.pushes, lastPush: st.lastPush
    });
  }

  function health() {
    var b = brief(), comp = qUnique(spec().composer, 'composer');
    var amb = st.ambiguous;
    return JSON.stringify({
      url: location.origin + location.pathname,
      vis: document.visibilityState, hidden: document.hidden,
      healthy: !!comp && Object.keys(amb).length === 0,
      composer: !!comp, composerTag: comp ? comp.tagName : '', composerEmpty: comp ? composerEmpty(comp) : null,
      sendPresent: !!qUnique(spec().send, 'send'), sendVerified: st.sendVerified,
      stopPresent: !!q(spec().stop), ambiguous: amb,
      assistantNodes: b.a, userNodes: b.u, generating: b.gen, challenge: challenge(), typeCheck: st.typeCheck,
      pushes: st.pushes, msSinceLastPush: st.lastPush ? Date.now() - st.lastPush : -1,
      innerW: window.innerWidth, innerH: window.innerHeight
    });
  }

  // Types one harmless character on an EMPTY composer. It clears only if that composer is still exactly x.
  function startTypeCheck() {
    var el = qUnique(spec().composer, 'composer');
    if (!el) { st.typeCheck = 'no-unique-composer'; return 'no-unique-composer'; }
    if (!composerEmpty(el)) { st.typeCheck = 'skipped-composer-not-empty'; return 'skipped'; }
    st.typeCheck = 'running';
    if (!setText(el, 'x')) { st.typeCheck = 'insert-failed'; return 'insert-failed'; }
    setTimeout(function () {
      var s = qUnique(spec().send, 'send');
      var found = s ? ('send-appeared disabled=' + (!!s.disabled || s.getAttribute('aria-disabled') === 'true')) : 'send-NOT-found-after-typing';
      st.sendVerified = !!s;
      if (composerText(el).replace(/\r?\n$/, '') !== 'x') {
        st.typeCheck = found + ' restored=FALSE composer-changed(left-untouched)';
        return;
      }
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') setText(el, ''); else deleteAllIn(el);
      st.typeCheck = found + (composerEmpty(el) ? ' restored=true' : ' restored=FALSE');
    }, 700);
    return 'started';
  }

  function pathHasConversationId(convId) {
    if (!convId) return true;
    return location.pathname.split('/').indexOf(convId) >= 0;
  }

  // If the send is refused after we inserted text, remove exactly that text (never anything else) so no draft is left behind.
  function clearIfOurs(el) {
    try {
      if (norm(composerText(el)) === st.sentFullNorm) {
        if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') setText(el, ''); else deleteAllIn(el);
      }
    } catch (e) {}
  }

  // Inserts into an EMPTY composer, then waits (bounded) for exactly one enabled Send control. Fails closed.
  function send(text, convId) {
    var el = qUnique(spec().composer, 'composer');
    if (!el) { st.sendResult = 'no-unique-composer'; return 'no-unique-composer'; }
    if (!pathHasConversationId(convId)) { st.sendResult = 'wrong-conversation'; return 'wrong-conversation'; }
    if (!composerEmpty(el)) { st.sendResult = 'composer-not-empty'; return 'composer-not-empty'; }
    if (generating()) { st.sendResult = 'busy'; return 'busy'; }

    st.baseA = snapshot(spec().assistant);
    st.baseU = snapshot(spec().user);
    st.beforeNodesA = new Set(qa(spec().assistant)); // diagnostic only
    st.replyNode = null;
    st.before = { a: st.baseA.count, u: st.baseU.count };
    st.sentNorm = norm(text).slice(0, 60);  // prefix: identifies the resulting user bubble
    st.sentFullNorm = norm(text);           // whole text: exact pre-click safety check
    st.sendResult = 'pending';

    if (!setText(el, text)) { st.sendResult = 'insert-failed'; return 'insert-failed'; }
    var deadline = Date.now() + 3000;

    (function waitForSend() {
      if (!pathHasConversationId(convId)) { clearIfOurs(el); st.sendResult = 'wrong-conversation'; return; }
      var s = qUnique(spec().send, 'send');
      if (s && !s.disabled && s.getAttribute('aria-disabled') !== 'true') {
        if (norm(composerText(el)) !== st.sentFullNorm) { st.sendResult = 'composer-content-changed'; return; }
        s.click(); st.sendResult = 'clicked'; return;
      }
      if (Date.now() < deadline) { setTimeout(waitForSend, 150); return; }
      clearIfOurs(el);
      st.sendResult = st.ambiguous.send ? 'send-ambiguous' : (s ? 'send-disabled' : 'no-unique-send-button');
    })();
    return 'inserted';
  }

  // DOM inventory for selector correction. Structure only; no conversation/message body text is intentionally returned.
  function probe() {
    var out = { buttons: [], editables: [], counts: {} }, seen = {};
    Array.prototype.slice.call(document.querySelectorAll('button,[role=button]')).slice(0, 500).forEach(function (b) {
      var tid = b.getAttribute('data-testid') || '', al = b.getAttribute('aria-label') || '';
      var k = tid + ' | ' + al + (tid || al ? '' : ' | text:' + (b.innerText || '').trim().slice(0, 12));
      if (!seen[k] && out.buttons.length < 60) { seen[k] = 1; out.buttons.push(k); }
    });
    Array.prototype.slice.call(document.querySelectorAll('[contenteditable=true],textarea')).slice(0, 10).forEach(function (e) {
      out.editables.push(e.tagName + '#' + (e.id || '') + ' aria=' + (e.getAttribute('aria-label') || '') +
        ' testid=' + (e.getAttribute('data-testid') || '') + ' cls=' + String(e.className).slice(0, 60));
    });
    ['[data-message-author-role]', '[data-message-id]', '[data-is-streaming]', '[data-testid="user-message"]',
      '[data-testid="assistant-message"]', '[data-testid]'].forEach(function (s) {
      try { out.counts[s] = document.querySelectorAll(s).length; } catch (e) {}
    });
    return JSON.stringify(out);
  }

  var timer = null;
  function push() {
    var b = brief(), s = JSON.stringify(b);
    if (s === st.lastBrief) return;
    st.lastBrief = s; st.pushes++; st.lastPush = Date.now();
    try { if (window.AGCBridge) window.AGCBridge.event(s); } catch (e) {}
  }

  var obs = new MutationObserver(function () {
    if (timer) return;
    timer = setTimeout(function () { timer = null; push(); }, 400);
  });

  function start() {
    if (document.body) obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    else setTimeout(start, 200);
  }
  start();

  window.__agc = {
    version: 4,
    spec: spec(),
    health: health,
    poll: poll,
    probe: probe,
    send: send,
    startTypeCheck: startTypeCheck,
    full: function () { return st.replyNode ? (st.replyNode.innerText || '').slice(0, 300000) : ''; }
  };
})();
