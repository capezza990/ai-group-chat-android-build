package com.aigroupchat.bridge.room;

import java.util.regex.Pattern;

/** Cleans a reply read from a provider page before it becomes a canonical room message (pure Java, unit-tested). */
public final class ReplyCleaner {
    private static final Pattern SPEAKER_HEADING = Pattern.compile("^(?:(?:ChatGPT|Claude|Gemini|Assistant)\\s+said\\s*:?)\\s*\\n+", Pattern.CASE_INSENSITIVE);
    private static final Pattern INVISIBLE = Pattern.compile("[\\u200B-\\u200D\\u2060\\uFEFF]");

    private ReplyCleaner() {}

    public static String clean(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\r\n", "\n").replace('\r', '\n');
        s = INVISIBLE.matcher(s).replaceAll("");
        s = s.trim();
        s = SPEAKER_HEADING.matcher(s).replaceFirst(""); // hidden "ChatGPT said:" heading some pages expose to innerText
        s = s.replaceAll("\\n{3,}", "\n\n");
        return s.trim();
    }
}
