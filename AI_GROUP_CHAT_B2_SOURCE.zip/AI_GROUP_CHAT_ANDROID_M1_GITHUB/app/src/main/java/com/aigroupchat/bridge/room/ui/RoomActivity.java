package com.aigroupchat.bridge.room.ui;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.Layout;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.engine.ProviderSpec;
import com.aigroupchat.bridge.engine.WebProviderSurface;
import com.aigroupchat.bridge.engine.WebRoomProvider;
import com.aigroupchat.bridge.room.Delivery;
import com.aigroupchat.bridge.room.DeliveryState;
import com.aigroupchat.bridge.room.MockProvider;
import com.aigroupchat.bridge.room.ProviderCatalog;
import com.aigroupchat.bridge.room.RoomController;
import com.aigroupchat.bridge.room.RoomMessage;
import com.aigroupchat.bridge.room.RoomParticipant;
import com.aigroupchat.bridge.room.RoomProvider;
import com.aigroupchat.bridge.room.RoomSettings;
import com.aigroupchat.bridge.room.RoutingMode;
import com.aigroupchat.bridge.room.ScrollFollow;
import com.aigroupchat.bridge.room.StatusRules;
import com.aigroupchat.bridge.room.TranscriptSearch;
import com.aigroupchat.bridge.room.sqlite.RoomDb;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * B2: the shared room with LIVE ChatGPT + Claude (embedded consumer-account sessions) in the Version 3 look.
 * The room database is the single source of truth; provider conversations are only execution endpoints.
 * Developer mode swaps in mock AIs (separate mock room) for repeatable testing.
 */
public class RoomActivity extends Activity {
    private static final String PREFS = "room_b1b";
    private static final String KEY_ROOM = "room_id";            // current MOCK room id
    private static final String KEY_RAIL_HIDDEN = "rail_hidden";
    private static final String KEY_MODE = "mode";               // "live" (default) or "mock"
    private static final String LIVE_ROOM = "default";
    private static final String DEFAULT_MOCK_ROOM = "mock-room";

    private static final String[] MODE_LABELS = {"Single AI", "Ask everyone", "Collaborate", "Auto (first available)"};
    private static final RoutingMode[] MODES = {RoutingMode.SINGLE, RoutingMode.ASK_ALL, RoutingMode.COLLABORATE, RoutingMode.AUTO_PICK};
    private static final String[] BEHAVIOR_LABELS = {"Normal", "Duplicate replies", "Late duplicate (+2.5 s)",
            "Fail before send", "Accepted, never replies", "Silent (no callback)"};
    private static final MockProvider.Behavior[] BEHAVIORS = {MockProvider.Behavior.REPLY, MockProvider.Behavior.DUPLICATE_REPLY,
            MockProvider.Behavior.LATE_DUPLICATE, MockProvider.Behavior.FAIL_BEFORE_SEND, MockProvider.Behavior.NEVER_REPLY,
            MockProvider.Behavior.SILENT};
    private static final String[] DELAY_LABELS = {"Instant", "1.5 s", "4 s"};
    private static final long[] DELAYS = {0L, 1500L, 4000L};

    private static final int BG = 0xFF0A0F1C, RAIL = 0xFF111827, PANEL = 0xFF0D1424, PILL = 0xFF121A2B, LINE = 0xFF1E2A44;
    private static final int TEXT = 0xFFE8EAED, MUTED = 0xFF9AA3B5, BLUE = 0xFF2F7CF6;
    private static final int DOT_READY = 0xFF4ADE80, DOT_WORKING = 0xFFFFC857, DOT_PROBLEM = 0xFFF87171,
            DOT_NEUTRAL = 0xFF8B94A8, DOT_OFFLINE = 0xFF475569;
    private static final int RAIL_W_DP = 84, BAR_H_DP = 64;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final MockProvider.Scheduler scheduler = (r, delay) -> main.postDelayed(r, delay);
    private final Map<String, MockProvider> mocks = new LinkedHashMap<>();
    private final Map<String, WebProviderSurface> surfaces = new LinkedHashMap<>();
    private final Map<String, RoomProvider> providers = new LinkedHashMap<>();
    private final Map<String, Drawable.ConstantState> iconCache = new HashMap<>();
    private final ScrollFollow follow = new ScrollFollow();
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("h:mm a", Locale.getDefault());

    private RoomDb db;
    private RoomController controller;
    private boolean live;
    private String roomId;
    private String lastSummary = "";
    private String startupNote = "";
    private String undoProviderId;
    private int behaviorIdx = 0, delayIdx = 1;
    private boolean railHidden;

    // views
    private FrameLayout root;
    private LinearLayout col, railPanel, railList, transcriptBox, miniAvatars, undoBar, searchBar, strip, providerBar;
    private ScrollView transcriptScroll;
    private TextView subtitleView, undoText, stripText, stripDots, jumpPill, sendBtn, searchCount, providerTitle;
    private EditText input, searchInput;
    private View railToggleChevron;
    private AvatarView stripAvatar;
    private ObjectAnimator dotsAnim;
    private String stripAvatarKey = "";
    private String hintProviderId;
    private String overlayProviderId;

    // transcript state (append-only rows)
    private long renderedSeq = 0;
    private View emptyHint;
    private boolean scrollPending;
    private int scrollToken;
    private final Map<Long, View> rows = new HashMap<>();
    private final Map<Long, View> cards = new HashMap<>();
    private final Map<Long, TextView> bodyViews = new HashMap<>();
    private final Map<Long, String> bodyText = new HashMap<>();
    private final Map<String, List<AvatarView>> chatAvatars = new HashMap<>();

    // search state
    private boolean searchActive;
    private List<TranscriptSearch.Match> searchMatches = new ArrayList<>();
    private final Map<Long, List<int[]>> matchesBySeq = new HashMap<>();
    private final Set<Long> highlighted = new HashSet<>();
    private int searchPos = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        live = !"mock".equals(prefs.getString(KEY_MODE, "live"));
        roomId = live ? LIVE_ROOM : prefs.getString(KEY_ROOM, DEFAULT_MOCK_ROOM);
        railHidden = prefs.getBoolean(KEY_RAIL_HIDDEN, false);
        db = RoomDb.get(this);

        controller = new RoomController(db, roomId, new RoomController.Events() {
            @Override public void onMessage(RoomMessage m) { main.post(RoomActivity.this::refreshAll); }
            @Override public void onDelivery(Delivery d) { main.post(RoomActivity.this::refreshAll); }
            @Override public void onRunFinished(String summary) { main.post(() -> runFinished(summary)); }
        });
        if (live) {
            addLive("chatgpt", ProviderSpec.CHATGPT);
            addLive("claude", ProviderSpec.CLAUDE);
        } else {
            for (ProviderCatalog.Entry e : ProviderCatalog.all()) {
                MockProvider m = new MockProvider(e.id, e.name, scheduler);
                m.delayMs = DELAYS[delayIdx];
                mocks.put(e.id, m);
                providers.put(e.id, m);
                controller.registerProvider(m);
            }
        }
        if (controller.participants().isEmpty()) { // fresh room: ChatGPT + Claude, collaborate with ChatGPT first
            controller.addParticipant("chatgpt");
            controller.addParticipant("claude");
            controller.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
        }
        int recovered = controller.recoverOnStart();
        if (recovered > 0) startupNote = recovered + " request(s) from the last session were interrupted and marked UNCERTAIN (nothing was resent).";

        setContentView(buildUi());
        for (WebProviderSurface s : surfaces.values()) s.load();
        refreshAll();
    }

    private void addLive(String id, ProviderSpec spec) {
        WebProviderSurface s = new WebProviderSurface(this, spec);
        surfaces.put(id, s);
        WebRoomProvider p = new WebRoomProvider(id, ProviderCatalog.nameOf(id), s);
        providers.put(id, p);
        controller.registerProvider(p);
    }

    // ------------------------------------------------------------------ construction

    private View buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });

        // live provider pages stay attached, full size, UNDER the opaque room UI (never GONE) so their pages keep running
        for (WebProviderSurface s : surfaces.values()) {
            root.addView(s.view(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(BG); // opaque: hides the provider pages beneath
        col.setClickable(true);     // and swallows touches so they never reach a hidden page
        root.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // header
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(8), dp(12), dp(6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("AI Group Chat", 22, TEXT, true));
        LinearLayout subRow = new LinearLayout(this); // compact participant/status control lives here when the list is collapsed
        subRow.setGravity(Gravity.CENTER_VERTICAL);
        miniAvatars = new LinearLayout(this);
        miniAvatars.setGravity(Gravity.CENTER_VERTICAL);
        subRow.addView(miniAvatars);
        subtitleView = text("", 12, MUTED, false);
        subRow.addView(subtitleView);
        TextView chevron = text("  \u25BE", 12, MUTED, false);
        subRow.addView(chevron);
        railToggleChevron = chevron;
        subRow.setOnClickListener(v -> { if (railHidden) toggleRail(); });
        subRow.setMinimumHeight(dp(24));
        titles.addView(subRow);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView search = new ImageView(this);
        search.setImageResource(android.R.drawable.ic_menu_search);
        search.setColorFilter(TEXT);
        search.setPadding(dp(11), dp(11), dp(11), dp(11));
        search.setBackground(shape(PILL, 22, LINE, 1));
        search.setContentDescription("Search the transcript");
        search.setOnClickListener(v -> { if (searchActive) closeSearch(); else openSearch(); });
        header.addView(search, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setPadding(dp(14), 0, dp(12), 0);
        tools.setBackground(shape(PILL, 22, LINE, 1));
        tools.addView(text("\u2699", 16, TEXT, false));
        tools.addView(text("  Room tools  \u25BE", 14, TEXT, false));
        tools.setContentDescription("Room tools");
        tools.setOnClickListener(this::showRoomTools);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        tlp.leftMargin = dp(8);
        header.addView(tools, tlp);
        col.addView(header);

        // body: participant rail (can fully collapse) + chat panel
        LinearLayout body = new LinearLayout(this);
        body.setPadding(dp(8), dp(4), dp(8), dp(4));
        col.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        railPanel = new LinearLayout(this);
        railPanel.setOrientation(LinearLayout.VERTICAL);
        railPanel.setGravity(Gravity.CENTER_HORIZONTAL);
        railPanel.setBackground(shape(RAIL, 22, LINE, 1));
        ScrollView railScroll = new ScrollView(this); // scrolls, so any number of AIs fits without covering the chat
        railScroll.setVerticalScrollBarEnabled(false);
        railScroll.setFocusable(false);
        railList = new LinearLayout(this);
        railList.setOrientation(LinearLayout.VERTICAL);
        railList.setGravity(Gravity.CENTER_HORIZONTAL);
        railScroll.addView(railList);
        railPanel.addView(railScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView add = text("+", 24, MUTED, false);
        add.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable dashed = new android.graphics.drawable.GradientDrawable();
        dashed.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(dp(2), 0xFF3A4766, dp(4), dp(4));
        add.setBackground(dashed);
        add.setContentDescription("Add an AI to this chat");
        add.setOnClickListener(v -> showAddDialog());
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(44), dp(44));
        alp.topMargin = dp(6);
        railPanel.addView(add, alp);
        View divider = new View(this);
        divider.setBackgroundColor(LINE);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(36), dp(1));
        dlp.topMargin = dp(8); dlp.bottomMargin = dp(8);
        railPanel.addView(divider, dlp);
        TextView collapse = text("\u2039", 24, TEXT, false);
        collapse.setGravity(Gravity.CENTER);
        collapse.setBackground(shape(PILL, 22, LINE, 1));
        collapse.setContentDescription("Hide the participant list");
        collapse.setOnClickListener(v -> toggleRail());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(44), dp(44));
        clp.bottomMargin = dp(8);
        railPanel.addView(collapse, clp);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(RAIL_W_DP), ViewGroup.LayoutParams.MATCH_PARENT);
        rlp.rightMargin = dp(6);
        body.addView(railPanel, rlp);
        railPanel.setVisibility(railHidden ? View.GONE : View.VISIBLE); // truly gone: the chat reclaims the width

        FrameLayout chatPanel = new FrameLayout(this);
        chatPanel.setBackground(shape(PANEL, 22, LINE, 1));
        body.addView(chatPanel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        LinearLayout chatCol = new LinearLayout(this);
        chatCol.setOrientation(LinearLayout.VERTICAL);
        chatPanel.addView(chatCol, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        transcriptScroll = new ScrollView(this);
        transcriptScroll.setFocusable(false);
        transcriptScroll.setFocusableInTouchMode(false);
        transcriptScroll.setVerticalScrollBarEnabled(false);
        transcriptBox = new LinearLayout(this);
        transcriptBox.setOrientation(LinearLayout.VERTICAL);
        transcriptBox.setPadding(dp(8), dp(8), dp(8), dp(8));
        transcriptScroll.addView(transcriptBox);
        chatCol.addView(transcriptScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // bottom strip: typing indicator / connect hint (left) and jump-to-latest (right); in flow, never over messages
        strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(10), dp(4), dp(10), dp(8));
        stripAvatar = newAvatar("", false, 0, 28);
        strip.addView(stripAvatar, new LinearLayout.LayoutParams(dp(28), dp(28)));
        stripText = text("", 13, TEXT, false);
        stripText.setPadding(dp(8), 0, dp(6), 0);
        stripText.setSingleLine(true);
        stripText.setEllipsize(TextUtils.TruncateAt.END);
        strip.addView(stripText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        stripDots = text("\u25CF \u25CF \u25CF", 9, 0xFF6EA8FF, false);
        strip.addView(stripDots);
        jumpPill = text("\u2193 Latest", 12, Color.WHITE, true);
        jumpPill.setGravity(Gravity.CENTER);
        jumpPill.setPadding(dp(12), 0, dp(12), 0);
        jumpPill.setBackground(shape(BLUE, 16, 0, 0));
        jumpPill.setContentDescription("Jump to the newest message");
        jumpPill.setOnClickListener(v -> { follow.onUserSent(); scrollNow(); updateStrip(controller.isBusy(), controller.activeProviderId()); });
        LinearLayout.LayoutParams jlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        jlp.leftMargin = dp(8);
        strip.addView(jumpPill, jlp);
        strip.setVisibility(View.GONE);
        strip.setOnClickListener(v -> { if (hintProviderId != null) openProvider(hintProviderId); });
        chatCol.addView(strip);

        // top overlays (do not reflow the transcript): search bar and undo bar
        LinearLayout overlayTop = new LinearLayout(this);
        overlayTop.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams otlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        otlp.setMargins(dp(10), dp(10), dp(10), 0);
        chatPanel.addView(overlayTop, otlp);

        searchBar = new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setBackground(shape(0xF21B2436, 18, 0xFF33415F, 1));
        searchBar.setPadding(dp(14), 0, dp(4), 0);
        searchInput = new EditText(this);
        searchInput.setHint("Search this chat");
        searchInput.setHintTextColor(MUTED);
        searchInput.setTextColor(TEXT);
        searchInput.setTextSize(15);
        searchInput.setSingleLine(true);
        searchInput.setBackground(null);
        searchInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnEditorActionListener((v, actionId, ev) -> { searchStep(1); return true; });
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { recomputeSearch(true); }
        });
        searchBar.addView(searchInput, new LinearLayout.LayoutParams(0, dp(48), 1f));
        searchCount = text("", 13, MUTED, false);
        searchCount.setPadding(dp(6), 0, dp(6), 0);
        searchBar.addView(searchCount);
        searchBar.addView(barButton("\u25B2", "Previous match", v -> searchStep(-1)));
        searchBar.addView(barButton("\u25BC", "Next match", v -> searchStep(1)));
        searchBar.addView(barButton("\u2715", "Close search", v -> closeSearch()));
        searchBar.setVisibility(View.GONE);
        overlayTop.addView(searchBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        undoBar = new LinearLayout(this);
        undoBar.setGravity(Gravity.CENTER_VERTICAL);
        undoBar.setBackground(shape(0xF21B2436, 16, 0xFF33415F, 1));
        undoBar.setPadding(dp(14), 0, dp(4), 0);
        undoText = text("", 14, TEXT, false);
        undoBar.addView(undoText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView undoBtn = text("UNDO", 14, 0xFF8AB4F8, true);
        undoBtn.setGravity(Gravity.CENTER);
        undoBtn.setPadding(dp(14), 0, dp(14), 0);
        undoBtn.setOnClickListener(v -> undoRemove());
        undoBar.addView(undoBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        undoBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        ulp.topMargin = dp(6);
        overlayTop.addView(undoBar, ulp);

        // composer pill
        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setBackground(shape(PILL, 28, LINE, 1));
        composer.setPadding(dp(12), dp(4), dp(6), dp(4));
        TextView clip = text("\uD83D\uDCCE", 20, MUTED, false);
        clip.setGravity(Gravity.CENTER);
        clip.setContentDescription("Attach");
        clip.setOnClickListener(v -> toast("File sharing between the AIs is the next milestone."));
        composer.addView(clip, new LinearLayout.LayoutParams(dp(36), dp(44)));
        input = new EditText(this);
        input.setHint("Message the room\u2026");
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(16);
        input.setMaxLines(5);
        input.setBackground(null);
        input.setPadding(dp(6), dp(8), dp(6), dp(8));
        composer.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        sendBtn = text("\u27A4", 20, Color.WHITE, true);
        sendBtn.setGravity(Gravity.CENTER);
        sendBtn.setBackground(shape(BLUE, 24, 0, 0));
        sendBtn.setOnClickListener(v -> { if (controller.isBusy()) { controller.stop(); refreshAll(); } else send(); });
        composer.addView(sendBtn, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        colp.setMargins(dp(10), dp(4), dp(10), dp(10));
        col.addView(composer, colp);

        // provider connect bar (shown only while a provider page is brought to the front)
        providerBar = new LinearLayout(this);
        providerBar.setGravity(Gravity.CENTER_VERTICAL);
        providerBar.setBackgroundColor(0xFF0E1526);
        providerBar.setPadding(dp(12), dp(6), dp(8), dp(6));
        providerTitle = text("", 13, TEXT, false);
        providerTitle.setMaxLines(2);
        providerBar.addView(providerTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        providerBar.addView(barText("Use this chat", true, v -> useThisConversation()));
        providerBar.addView(barText("Reload", false, v -> { WebProviderSurface s = surfaces.get(overlayProviderId); if (s != null) s.reloadHome(); }));
        providerBar.addView(barText("Close", false, v -> closeProvider()));
        providerBar.setVisibility(View.GONE);
        root.addView(providerBar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(BAR_H_DP), Gravity.BOTTOM));

        // follow policy: following while near the bottom, free reading when scrolled up
        transcriptScroll.setOnScrollChangeListener((v, x, y, ox, oy) -> {
            follow.onScrolled(isNearBottom());
            updateStrip(controller.isBusy(), controller.activeProviderId());
        });
        transcriptBox.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (scrollPending) { scrollPending = false; scrollNow(); }
        });
        transcriptScroll.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (follow.shouldFollowNewContent() && (b - t) != (ob - ot)) scrollNow(); // keyboard / strip appeared
        });
        return root;
    }

    private View barButton(String glyph, String desc, View.OnClickListener l) {
        TextView t = text(glyph, 16, TEXT, false);
        t.setGravity(Gravity.CENTER);
        t.setContentDescription(desc);
        t.setOnClickListener(l);
        t.setMinWidth(dp(40));
        t.setHeight(dp(48));
        return t;
    }

    private View barText(String label, boolean primary, View.OnClickListener l) {
        TextView t = text(label, 13, primary ? Color.WHITE : TEXT, primary);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), 0, dp(12), 0);
        if (primary) t.setBackground(shape(BLUE, 18, 0, 0));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        lp.leftMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    // ------------------------------------------------------------------ actions

    private void send() {
        String text = input.getText().toString();
        if (text.trim().isEmpty()) return;
        follow.onUserSent();
        RoomMessage m = controller.submitUserMessage(text);
        if (m == null) { toast(controller.isBusy() ? "A run is in progress. Wait, or tap Stop." : "Nothing to send."); return; }
        input.setText("");
        refreshAll(); // the user message is already in SQLite, so it is on screen before any reply
    }

    private void removeAi(String providerId) {
        controller.removeParticipant(providerId); // one tap, no confirmation: history and binding are kept
        undoProviderId = providerId;
        undoText.setText("Removed " + ProviderCatalog.nameOf(providerId));
        undoBar.setVisibility(View.VISIBLE);
        main.removeCallbacks(hideUndo);
        main.postDelayed(hideUndo, 6000L);
        refreshAll();
    }

    private final Runnable hideUndo = () -> { if (undoBar != null) undoBar.setVisibility(View.GONE); undoProviderId = null; };

    private void undoRemove() {
        if (undoProviderId == null) return;
        controller.addParticipant(undoProviderId); // re-enables the same participant row, context position intact
        main.removeCallbacks(hideUndo);
        hideUndo.run();
        refreshAll();
    }

    private void toggleRail() {
        railHidden = !railHidden;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RAIL_HIDDEN, railHidden).apply();
        railPanel.setVisibility(railHidden ? View.GONE : View.VISIBLE);
        refreshAll();
    }

    private void runFinished(String summary) {
        lastSummary = summary;
        if (!"done".equals(summary)) { // keep an audit line in the canonical room
            String msg;
            if (summary.endsWith(" is unavailable")) {
                String id = summary.substring(0, summary.length() - " is unavailable".length());
                msg = ProviderCatalog.nameOf(id) + " isn't connected. Tap it in the participant list to sign in and choose a conversation.";
            } else {
                msg = "Run ended early: " + friendly(summary);
            }
            db.appendMessage(roomId, "sys-" + UUID.randomUUID(), RoomMessage.SYSTEM, "system", msg, null, System.currentTimeMillis());
        }
        refreshAll();
    }

    private String friendly(String summary) {
        int i = summary.indexOf(": ");
        if (i > 0) {
            String id = summary.substring(0, i);
            for (ProviderCatalog.Entry e : ProviderCatalog.all()) if (e.id.equals(id)) return e.name + summary.substring(i);
        }
        return summary;
    }

    // ------------------------------------------------------------------ provider connect overlay (login / binding / recovery)

    private void openProvider(String id) {
        WebProviderSurface s = surfaces.get(id);
        if (s == null) { toast(live ? ProviderCatalog.nameOf(id) + " isn't available yet." : "Mock AIs have no sign-in."); return; }
        closeSearch();
        overlayProviderId = id;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) s.view().getLayoutParams();
        lp.bottomMargin = dp(BAR_H_DP);
        s.view().setLayoutParams(lp);
        root.bringChildToFront(s.view());
        providerTitle.setText(ProviderCatalog.nameOf(id) + ": sign in, open the conversation you want, then tap \"Use this chat\".");
        providerBar.setVisibility(View.VISIBLE);
        root.bringChildToFront(providerBar);
    }

    private void closeProvider() {
        WebProviderSurface s = surfaces.get(overlayProviderId);
        if (s != null) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) s.view().getLayoutParams();
            lp.bottomMargin = 0;
            s.view().setLayoutParams(lp);
        }
        overlayProviderId = null;
        providerBar.setVisibility(View.GONE);
        root.bringChildToFront(col); // pages go back beneath the opaque room UI, still attached
        refreshAll();
    }

    private void useThisConversation() {
        WebProviderSurface s = surfaces.get(overlayProviderId);
        if (s == null) return;
        ProviderBinding b = s.bindCurrentConversation();
        if (b == null) { toast("Open an existing conversation first (not the home screen), then tap again."); return; }
        toast(ProviderCatalog.nameOf(overlayProviderId) + " is connected to that conversation.");
        closeProvider();
    }

    @Override
    public void onBackPressed() {
        if (overlayProviderId != null) {
            WebProviderSurface s = surfaces.get(overlayProviderId);
            if (s == null || !s.goBackIfPossible()) closeProvider();
            return;
        }
        if (searchActive) { closeSearch(); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ Room tools, dialogs

    private void showRoomTools(View anchor) {
        List<String> labels = new ArrayList<>();
        List<Runnable> acts = new ArrayList<>();
        labels.add("Routing & rounds\u2026"); acts.add(this::showRoutingDialog);
        if (live) { labels.add("Provider connections\u2026"); acts.add(this::showProvidersDialog); }
        else { labels.add("Mock test mode\u2026"); acts.add(this::showMockDialog); }
        labels.add("Search in chat"); acts.add(this::openSearch);
        labels.add("Room state\u2026"); acts.add(this::showState);
        labels.add("Copy transcript"); acts.add(this::copyTranscript);
        if (!live) { labels.add("New mock room\u2026"); acts.add(this::confirmNewRoom); }
        labels.add(live ? "Developer: use mock AIs" : "Use live ChatGPT + Claude"); acts.add(this::switchMode);
        AppUi.menu(this, anchor, labels.toArray(new String[0]), acts.toArray(new Runnable[0]));
    }

    private void switchMode() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MODE, live ? "mock" : "live").apply();
        recreate();
    }

    private void showAddDialog() {
        final AppUi.AppDialog d = new AppUi.AppDialog(this);
        d.title("Add an AI to this chat");
        Set<String> enabled = new HashSet<>();
        for (RoomParticipant p : controller.participants()) if (p.enabled) enabled.add(p.providerId);
        int shown = 0;
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (ProviderCatalog.Entry e : ProviderCatalog.all()) {
            if (enabled.contains(e.id)) continue;
            shown++;
            boolean usable = !live || e.live;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), 0, dp(10), 0);
            row.setBackground(shape(AppUi.ROW, 14, 0, 0));
            row.addView(newAvatar(e.id, false, 0, 36), new LinearLayout.LayoutParams(dp(36), dp(36)));
            LinearLayout names = new LinearLayout(this);
            names.setOrientation(LinearLayout.VERTICAL);
            names.setPadding(dp(12), 0, 0, 0);
            names.addView(text(e.name, 15, usable ? TEXT : MUTED, true));
            names.addView(text(e.note, 12, MUTED, false));
            row.addView(names, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (usable) row.setOnClickListener(v -> { d.dismiss(); controller.addParticipant(e.id); refreshAll(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
            lp.topMargin = dp(6);
            list.addView(row, lp);
        }
        if (shown == 0) { d.message("Every AI the room knows is already in this chat."); }
        else d.content(list);
        d.button("Cancel", false, null);
        d.show();
    }

    private void showRoutingDialog() {
        RoomSettings s = db.getRoom(roomId);
        List<String> ids = new ArrayList<>(), names = new ArrayList<>();
        for (RoomParticipant p : controller.participants()) if (p.enabled) { ids.add(p.providerId); names.add(ProviderCatalog.nameOf(p.providerId)); }
        if (names.isEmpty()) names.add("-");
        int mi = 0;
        for (int i = 0; i < MODES.length; i++) if (MODES[i] == s.mode) mi = i;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        final TextView firstL = text("", 12, MUTED, false), roundsL = text("Review rounds", 12, MUTED, false);
        final AppUi.ChipRow firstChips = new AppUi.ChipRow(this, names.toArray(new String[0]), Math.max(0, ids.indexOf(s.modeArg)));
        final HorizontalScrollView firstScroll = new HorizontalScrollView(this);
        firstScroll.setHorizontalScrollBarEnabled(false);
        firstScroll.addView(firstChips);
        final AppUi.ChipRow roundChips = new AppUi.ChipRow(this, new String[]{"1 round", "2 rounds"}, Math.max(0, Math.min(1, s.rounds - 1)));
        final AppUi.RadioList[] modeList = new AppUi.RadioList[1];
        Runnable vis = () -> {
            RoutingMode m = MODES[modeList[0].selected()];
            boolean picks = m == RoutingMode.SINGLE || m == RoutingMode.COLLABORATE;
            firstL.setText(m == RoutingMode.SINGLE ? "Which AI answers" : "Who goes first");
            firstL.setVisibility(picks ? View.VISIBLE : View.GONE);
            firstScroll.setVisibility(picks ? View.VISIBLE : View.GONE);
            roundsL.setVisibility(m == RoutingMode.COLLABORATE ? View.VISIBLE : View.GONE);
            roundChips.setVisibility(m == RoutingMode.COLLABORATE ? View.VISIBLE : View.GONE);
        };
        modeList[0] = new AppUi.RadioList(this, MODE_LABELS, mi, vis);
        box.addView(text("How the room answers", 12, MUTED, false));
        box.addView(modeList[0]);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        l1.topMargin = dp(12);
        box.addView(firstL, l1);
        box.addView(firstScroll);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        l2.topMargin = dp(12);
        box.addView(roundsL, l2);
        box.addView(roundChips);
        vis.run();

        new AppUi.AppDialog(this).title("Routing & rounds").content(box)
                .button("Cancel", false, null)
                .button("Apply", true, () -> {
                    RoutingMode m = MODES[modeList[0].selected()];
                    int fi = firstChips.selected();
                    boolean picks = m == RoutingMode.SINGLE || m == RoutingMode.COLLABORATE;
                    controller.setRouting(m, picks && fi >= 0 && fi < ids.size() ? ids.get(fi) : "", roundChips.selected() + 1);
                    refreshAll();
                }).show();
    }

    private void showMockDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(text("Mock AI behavior", 12, MUTED, false));
        final AppUi.RadioList behaviors = new AppUi.RadioList(this, BEHAVIOR_LABELS, behaviorIdx, null);
        box.addView(behaviors);
        TextView dl = text("Reply delay", 12, MUTED, false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(12);
        box.addView(dl, dlp);
        final AppUi.ChipRow delays = new AppUi.ChipRow(this, DELAY_LABELS, delayIdx);
        box.addView(delays);
        AppUi.MaxHeightScroll sc = new AppUi.MaxHeightScroll(this, getResources().getDisplayMetrics().heightPixels / 2);
        sc.addView(box);
        new AppUi.AppDialog(this).title("Mock test mode").content(sc)
                .button("Cancel", false, null)
                .button("Apply", true, () -> {
                    behaviorIdx = behaviors.selected();
                    delayIdx = delays.selected();
                    for (MockProvider m : mocks.values()) { m.behavior = BEHAVIORS[behaviorIdx]; m.delayMs = DELAYS[delayIdx]; }
                    toast("Mock: " + BEHAVIOR_LABELS[behaviorIdx] + ", " + DELAY_LABELS[delayIdx]);
                }).show();
    }

    /** Live providers: connection status, open the sign-in page, and run a page health check (also shows page visibility). */
    private void showProvidersDialog() {
        final AppUi.AppDialog d = new AppUi.AppDialog(this);
        d.title("Provider connections");
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (Map.Entry<String, WebProviderSurface> e : surfaces.entrySet()) {
            final String id = e.getKey();
            final WebProviderSurface s = e.getValue();
            ProviderBinding b = s.binding();
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(shape(AppUi.ROW, 14, 0, 0));
            row.addView(text(ProviderCatalog.nameOf(id), 15, TEXT, true));
            row.addView(text((b == null ? "Not connected to a conversation" : "Connected to a conversation")
                    + (s.sessionCookiePresent() ? "  \u2022  signed in" : "  \u2022  not signed in"), 12, MUTED, false));
            LinearLayout actions = new LinearLayout(this);
            TextView open = text("Open", 13, 0xFF8AB4F8, true);
            open.setPadding(0, dp(10), dp(20), 0);
            open.setOnClickListener(v -> { d.dismiss(); openProvider(id); });
            TextView check = text("Check", 13, 0xFF8AB4F8, true);
            check.setPadding(0, dp(10), dp(20), 0);
            check.setOnClickListener(v -> {
                d.dismiss();
                s.health(h -> new AppUi.AppDialog(RoomActivity.this)
                        .title(ProviderCatalog.nameOf(id) + " health").scrollText(describeHealth(h))
                        .button("Close", true, null).show());
            });
            actions.addView(open);
            actions.addView(check);
            row.addView(actions);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(8);
            list.addView(row, lp);
        }
        d.content(list);
        d.button("Close", true, null);
        d.show();
    }

    private String describeHealth(JSONObject h) {
        if (h == null) return "No response from the page.";
        if (h.has("err")) return "Unavailable: " + h.optString("err");
        return "healthy: " + h.optBoolean("healthy") + "\ncomposer found: " + h.optBoolean("composer")
                + "\ncomposer empty: " + h.optBoolean("composerEmpty") + "\ngenerating: " + h.optBoolean("generating")
                + "\npage visible: " + h.optString("vis") + (h.optBoolean("hidden") ? " (page reports hidden)" : "")
                + "\nambiguous selectors: " + h.optJSONObject("ambiguous");
    }

    private void confirmNewRoom() {
        new AppUi.AppDialog(this).title("Start a new mock room?")
                .message("Messages are append-only, so a new room is how you start clean. The current mock room stays in the database.")
                .button("Cancel", false, null)
                .button("New room", true, () -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ROOM, "mock-" + System.currentTimeMillis()).apply();
                    recreate();
                }).show();
    }

    private void showState() {
        RoomSettings s = db.getRoom(roomId);
        StringBuilder sb = new StringBuilder();
        sb.append("Room: ").append(roomId).append(live ? " (live)" : " (mock)").append("\nMessages: ").append(db.latestSeq(roomId))
                .append("\nRouting: ").append(s.mode.name().toLowerCase(Locale.US)).append(s.modeArg.isEmpty() ? "" : " (" + s.modeArg + ")")
                .append(", rounds ").append(s.rounds).append("\n\nParticipants:\n");
        for (RoomParticipant p : controller.participants()) {
            sb.append("\u2022 ").append(ProviderCatalog.nameOf(p.providerId)).append(p.enabled ? "  [in chat]" : "  [removed]")
                    .append("  context up to message ").append(p.contextSeq).append('\n');
        }
        sb.append("\nRequests (this room):\n");
        for (DeliveryState st : DeliveryState.values()) {
            int n = 0;
            for (Delivery d : db.deliveriesInState(st)) if (d.roomId.equals(roomId)) n++;
            if (n > 0) sb.append("\u2022 ").append(st.name()).append(": ").append(n).append('\n');
        }
        if (!lastSummary.isEmpty()) sb.append("\nLast run: ").append(lastSummary).append('\n');
        if (!startupNote.isEmpty()) sb.append('\n').append(startupNote).append('\n');
        new AppUi.AppDialog(this).title("Room state").scrollText(sb.toString()).button("Close", true, null).show();
    }

    private void copyTranscript() {
        StringBuilder sb = new StringBuilder();
        for (RoomMessage m : db.messagesBetween(roomId, 0, Long.MAX_VALUE)) {
            sb.append(timeFmt.format(m.createdAt)).append("  ").append(nameOf(m)).append(": ").append(stripMarkers(m.text)).append("\n\n");
        }
        copy(sb.toString().trim());
        toast("Transcript copied");
    }

    // ------------------------------------------------------------------ search (persistent bar, highlights, k of N, prev/next)

    private void openSearch() {
        searchActive = true;
        searchBar.setVisibility(View.VISIBLE);
        searchInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT);
        recomputeSearch(true);
    }

    private void closeSearch() {
        if (!searchActive) return;
        searchActive = false;
        searchBar.setVisibility(View.GONE);
        searchInput.setText("");
        searchMatches = new ArrayList<>();
        matchesBySeq.clear();
        searchPos = -1;
        applyHighlights();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
    }

    private void recomputeSearch(boolean jump) {
        if (!searchActive) return;
        String q = searchInput.getText().toString();
        List<RoomMessage> msgs = new ArrayList<>();
        for (RoomMessage m : db.messagesBetween(roomId, 0, Long.MAX_VALUE)) if (bodyViews.containsKey(m.seq)) msgs.add(m);
        List<TranscriptSearch.Match> found = TranscriptSearch.find(msgs, q, m -> stripMarkers(m.text));
        int oldPos = searchPos;
        searchMatches = found;
        matchesBySeq.clear();
        for (int i = 0; i < found.size(); i++) {
            TranscriptSearch.Match m = found.get(i);
            List<int[]> l = matchesBySeq.get(m.seq);
            if (l == null) { l = new ArrayList<>(); matchesBySeq.put(m.seq, l); }
            l.add(new int[]{m.start, m.end, i});
        }
        if (found.isEmpty()) searchPos = -1;
        else if (jump || oldPos < 0 || oldPos >= found.size()) searchPos = found.size() - 1; // start at the newest match
        else searchPos = oldPos;
        applyHighlights();
        updateSearchCount(q);
        if (jump && searchPos >= 0) scrollToMatch();
    }

    private void searchStep(int dir) {
        if (searchMatches.isEmpty()) return;
        searchPos = dir > 0 ? TranscriptSearch.next(searchPos, searchMatches.size()) : TranscriptSearch.prev(searchPos, searchMatches.size());
        applyHighlights();
        updateSearchCount(searchInput.getText().toString());
        scrollToMatch();
    }

    private void updateSearchCount(String q) {
        searchCount.setText(q.trim().isEmpty() ? "" : searchMatches.isEmpty() ? "0 of 0" : (searchPos + 1) + " of " + searchMatches.size());
    }

    private void applyHighlights() {
        for (Map.Entry<Long, TextView> e : bodyViews.entrySet()) {
            long seq = e.getKey();
            TextView tv = e.getValue();
            String orig = bodyText.get(seq);
            List<int[]> ranges = matchesBySeq.get(seq);
            if (ranges == null || ranges.isEmpty()) {
                if (highlighted.remove(seq)) tv.setText(orig);
                continue;
            }
            SpannableString sp = new SpannableString(orig);
            for (int[] r : ranges) {
                boolean active = r[2] == searchPos;
                sp.setSpan(new BackgroundColorSpan(active ? 0xFFFF9F1C : 0x66FFD54A), r[0], r[1], android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                if (active) sp.setSpan(new ForegroundColorSpan(0xFF111418), r[0], r[1], android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            tv.setText(sp);
            highlighted.add(seq);
        }
    }

    private void scrollToMatch() {
        if (searchPos < 0 || searchPos >= searchMatches.size()) return;
        final TranscriptSearch.Match m = searchMatches.get(searchPos);
        final View row = rows.get(m.seq), card = cards.get(m.seq);
        final TextView tv = bodyViews.get(m.seq);
        if (row == null || card == null || tv == null) return;
        follow.onScrolled(false); // reading: never snap back down
        tv.post(() -> {
            Layout lay = tv.getLayout();
            int lineTop = lay == null ? 0 : lay.getLineTop(lay.getLineForOffset(Math.min(m.start, Math.max(0, tv.length() - 1))));
            int y = row.getTop() + card.getTop() + tv.getTop() + lineTop;
            transcriptScroll.smoothScrollTo(0, Math.max(0, y - dp(110)));
        });
    }

    // ------------------------------------------------------------------ rendering (everything comes from RoomDb)

    private void refreshAll() {
        if (db == null || transcriptBox == null) return;
        List<RoomParticipant> ps = controller.participants();
        List<RoomMessage> all = renderedSeq == 0 ? db.messagesBetween(roomId, 0, Long.MAX_VALUE) : null;
        Map<String, StatusRules.Status> status = computeStatus(ps, all);
        String active = controller.activeProviderId();
        boolean busy = controller.isBusy();

        int enabledAis = 0;
        for (RoomParticipant p : ps) if (p.enabled) enabledAis++;
        subtitleView.setText((enabledAis + 1) + " members  \u2022  Shared Room" + (live ? "" : "  \u2022  mock"));
        railToggleChevron.setVisibility(railHidden ? View.VISIBLE : View.GONE);

        renderRail(ps, status);
        renderMiniAvatars(ps, status);
        appendNewMessages(all);
        updateChatDots(status);

        sendBtn.setText(busy ? "\u25A0" : "\u27A4");
        sendBtn.setContentDescription(busy ? "Stop" : "Send");
        sendBtn.setBackground(shape(busy ? 0xFFB3475A : BLUE, 24, 0, 0));
        updateStrip(busy, active);
    }

    private Map<String, StatusRules.Status> computeStatus(List<RoomParticipant> ps, List<RoomMessage> all) {
        long lastUser = 0;
        List<RoomMessage> recent = all != null ? all : db.latestMessages(roomId, 40);
        for (RoomMessage m : recent) if (RoomMessage.USER.equals(m.authorType) && m.createdAt > lastUser) lastUser = m.createdAt;
        Set<String> real = new HashSet<>(), neutral = new HashSet<>();
        for (DeliveryState st : new DeliveryState[]{DeliveryState.FAILED, DeliveryState.UNCERTAIN}) {
            for (Delivery d : db.deliveriesInState(st)) {
                if (!d.roomId.equals(roomId) || d.updatedAt < lastUser) continue;
                if (StatusRules.isRealFailure(st, d.error)) real.add(d.providerId);
                else if (StatusRules.isNeutralStop(st, d.error)) neutral.add(d.providerId);
            }
        }
        String active = controller.activeProviderId();
        Map<String, StatusRules.Status> out = new HashMap<>();
        for (RoomParticipant p : ps) {
            RoomProvider rp = providers.get(p.providerId);
            boolean connected = rp != null && rp.isAvailable();
            out.put(p.providerId, StatusRules.of(p.providerId.equals(active), connected, real.contains(p.providerId), neutral.contains(p.providerId)));
        }
        return out;
    }

    private int dotColor(StatusRules.Status s) {
        switch (s) {
            case WORKING: return DOT_WORKING;
            case PROBLEM: return DOT_PROBLEM;
            case NEUTRAL: return DOT_NEUTRAL;
            case NOT_CONNECTED: return DOT_OFFLINE;
            default: return DOT_READY;
        }
    }

    private void renderRail(List<RoomParticipant> ps, Map<String, StatusRules.Status> status) {
        railList.removeAllViews();
        if (railHidden) return;
        railList.addView(railCell("user", "You", null, DOT_READY));
        for (RoomParticipant p : ps) {
            if (p.enabled) railList.addView(railCell(p.providerId, ProviderCatalog.nameOf(p.providerId), p.providerId, dotColor(status.get(p.providerId))));
        }
    }

    /** Avatar on top, name below; the one-tap "-" sits at the cell's top-right corner, clear of the artwork. */
    private View railCell(String key, String label, String removableId, int dotColor) {
        FrameLayout cell = new FrameLayout(this);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER_HORIZONTAL);
        inner.setPadding(0, dp(14), 0, dp(4));
        AvatarView av = newAvatar(key, true, dotColor, 40);
        if (removableId != null) { av.setOnClickListener(v -> openProvider(removableId)); }
        inner.addView(av, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView name = text(label, 11, TEXT, false);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        inner.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.addView(inner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (removableId != null) {
            FrameLayout hit = new FrameLayout(this);
            hit.setContentDescription("Remove " + label + " from this chat");
            hit.setOnClickListener(v -> removeAi(removableId));
            TextView disc = text("\u2212", 13, TEXT, true);
            disc.setGravity(Gravity.CENTER);
            disc.setIncludeFontPadding(false);
            disc.setBackground(shape(0xFF2B3550, 9, 0xFF55648A, 1));
            hit.addView(disc, new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
            cell.addView(hit, new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.TOP | Gravity.END));
        }
        cell.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return cell;
    }

    /** Compact participant/status control in the header: shown while the participant list is collapsed. */
    private void renderMiniAvatars(List<RoomParticipant> ps, Map<String, StatusRules.Status> status) {
        miniAvatars.removeAllViews();
        if (!railHidden) return;
        List<String> keys = new ArrayList<>();
        keys.add("user");
        for (RoomParticipant p : ps) if (p.enabled) keys.add(p.providerId);
        for (int i = 0; i < keys.size() && i < 5; i++) {
            String k = keys.get(i);
            int dc = k.equals("user") ? DOT_READY : dotColor(status.get(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(22), dp(22));
            if (i > 0) lp.leftMargin = -dp(5);
            miniAvatars.addView(newAvatar(k, true, dc, 22), lp);
        }
        View gap = new View(this);
        miniAvatars.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
    }

    /** The transcript is append-only, so only rows newer than what is already drawn are added. */
    private void appendNewMessages(List<RoomMessage> preloaded) {
        List<RoomMessage> fresh = preloaded != null ? preloaded : db.messagesBetween(roomId, renderedSeq, Long.MAX_VALUE);
        if (fresh.isEmpty()) {
            if (renderedSeq == 0 && emptyHint == null) {
                emptyHint = text("Say hello \u2014 the AIs in this chat will answer.", 14, MUTED, false);
                emptyHint.setPadding(dp(8), dp(16), dp(8), 0);
                transcriptBox.addView(emptyHint);
            }
            return;
        }
        if (emptyHint != null) { transcriptBox.removeView(emptyHint); emptyHint = null; }
        boolean wasFollowing = follow.shouldFollowNewContent();
        for (RoomMessage m : fresh) {
            View row = messageRow(m);
            rows.put(m.seq, row);
            transcriptBox.addView(row);
            renderedSeq = Math.max(renderedSeq, m.seq);
        }
        if (wasFollowing) scrollSoon(); // never yanks someone who scrolled up to read
        if (searchActive) recomputeSearch(false);
    }

    private View messageRow(RoomMessage m) {
        boolean user = RoomMessage.USER.equals(m.authorType), system = RoomMessage.SYSTEM.equals(m.authorType);
        String body = stripMarkers(m.text);
        if (system) {
            TextView t = text(body, 12, MUTED, false);
            t.setGravity(Gravity.CENTER);
            t.setBackground(shape(0xFF182033, 12, 0, 0));
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_HORIZONTAL;
            lp.topMargin = dp(8); lp.bottomMargin = dp(4);
            t.setLayoutParams(lp);
            return t;
        }
        String key = user ? "user" : m.authorId;
        ProviderStyle st = ProviderStyle.of(key);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(5), 0, dp(5));

        AvatarView av = newAvatar(key, true, DOT_READY, 34);
        chatAvatars.computeIfAbsent(key, k -> new ArrayList<>()).add(av);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(34), dp(34));
        alp.rightMargin = dp(6);
        row.addView(av, alp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(shape(st.cardColor, 18, st.cardStroke, 1));
        card.setPadding(dp(12), dp(8), dp(12), dp(10));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text(user ? "You" : ProviderCatalog.nameOf(m.authorId), 14, st.accent, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(text(timeFmt.format(m.createdAt), 11, 0xFF8E98AD, false));
        card.addView(head);
        TextView tv = text(body, 15, TEXT, false);
        tv.setLineSpacing(0f, 1.15f);
        tv.setMaxLines(Integer.MAX_VALUE); // full message, never clipped
        tv.setEllipsize(null);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(2);
        card.addView(tv, blp);
        card.setOnLongClickListener(v -> { copy(body); toast("Message copied"); return true; });
        row.addView(card, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cards.put(m.seq, card);
        bodyViews.put(m.seq, tv);
        bodyText.put(m.seq, body);
        return row;
    }

    private void updateChatDots(Map<String, StatusRules.Status> status) {
        for (Map.Entry<String, List<AvatarView>> e : chatAvatars.entrySet()) {
            StatusRules.Status s = status.get(e.getKey());
            int c = e.getKey().equals("user") || s == null ? DOT_READY : dotColor(s);
            for (AvatarView a : e.getValue()) a.setDotColor(c);
        }
    }

    /** Bottom strip: who is typing, or a connect hint, plus the jump-to-latest pill. Sits in the layout, never over messages. */
    private void updateStrip(boolean busy, String active) {
        hintProviderId = null;
        String hint = null;
        if (live && !busy) {
            for (RoomParticipant p : controller.participants()) {
                RoomProvider rp = providers.get(p.providerId);
                if (p.enabled && rp != null && !rp.isAvailable()) {
                    hint = ProviderCatalog.nameOf(p.providerId) + " isn't connected \u2014 tap here to sign in and choose a conversation.";
                    hintProviderId = p.providerId;
                    break;
                }
            }
        }
        boolean showJump = !follow.isFollowing();
        jumpPill.setVisibility(showJump ? View.VISIBLE : View.GONE);
        if (busy) {
            String status = controller.runStatus();
            String step = status.contains(":") ? "  (" + status.substring(0, status.indexOf(':')) + ")" : "";
            stripText.setText(active == null ? "Working\u2026" + step : ProviderCatalog.nameOf(active) + " is typing\u2026" + step);
            String key = active == null ? "" : active;
            if (!key.equals(stripAvatarKey)) {
                stripAvatarKey = key;
                strip.removeViewAt(0);
                stripAvatar = newAvatar(key, false, 0, 28);
                strip.addView(stripAvatar, 0, new LinearLayout.LayoutParams(dp(28), dp(28)));
            }
            stripAvatar.setVisibility(active == null ? View.INVISIBLE : View.VISIBLE);
            stripDots.setVisibility(View.VISIBLE);
            if (dotsAnim == null) {
                dotsAnim = ObjectAnimator.ofFloat(stripDots, "alpha", 0.25f, 1f);
                dotsAnim.setDuration(550);
                dotsAnim.setRepeatCount(ObjectAnimator.INFINITE);
                dotsAnim.setRepeatMode(ObjectAnimator.REVERSE);
                dotsAnim.start();
            }
            strip.setVisibility(View.VISIBLE);
            if (follow.shouldFollowNewContent()) scrollSoon();
            return;
        }
        if (dotsAnim != null) { dotsAnim.cancel(); dotsAnim = null; }
        stripDots.setVisibility(View.GONE);
        if (hint != null) {
            stripText.setText(hint);
            stripAvatar.setVisibility(View.GONE);
            strip.setVisibility(View.VISIBLE);
        } else if (showJump) {
            stripText.setText("");
            stripAvatar.setVisibility(View.GONE);
            strip.setVisibility(View.VISIBLE);
        } else {
            strip.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------------ scrolling (positional: never touches focus)

    private boolean isNearBottom() {
        View c = transcriptScroll.getChildAt(0);
        if (c == null) return true;
        int remaining = c.getBottom() + transcriptScroll.getPaddingBottom() - (transcriptScroll.getScrollY() + transcriptScroll.getHeight());
        return remaining <= dp(72);
    }

    private void scrollSoon() {
        scrollPending = true;
        final int token = ++scrollToken;
        transcriptBox.requestLayout();
        main.postDelayed(() -> { if (token == scrollToken) scrollPending = false; }, 500L);
    }

    private void scrollNow() {
        View c = transcriptScroll.getChildAt(0);
        if (c == null) return;
        int target = Math.max(0, c.getHeight() + transcriptScroll.getPaddingTop() + transcriptScroll.getPaddingBottom() - transcriptScroll.getHeight());
        transcriptScroll.scrollTo(0, target);
    }

    // ------------------------------------------------------------------ helpers

    /** Avatar using the participant's real installed-app icon when the phone has it, else a neutral monogram. */
    private AvatarView newAvatar(String key, boolean dot, int dotColor, int sizeDp) {
        ProviderStyle st = ProviderStyle.of(key);
        return new AvatarView(this, st, iconFor(st), dot, dotColor);
    }

    private Drawable iconFor(ProviderStyle st) {
        if (st.packageName == null) return null;
        try {
            Drawable.ConstantState cs = iconCache.get(st.packageName);
            if (cs == null) {
                Drawable d = getPackageManager().getApplicationIcon(st.packageName);
                cs = d.getConstantState();
                if (cs == null) return d;
                iconCache.put(st.packageName, cs);
            }
            return cs.newDrawable().mutate();
        } catch (PackageManager.NameNotFoundException e) {
            return null; // not installed: neutral monogram
        }
    }

    private String nameOf(RoomMessage m) {
        return RoomMessage.USER.equals(m.authorType) ? "You" : RoomMessage.SYSTEM.equals(m.authorType) ? "System" : ProviderCatalog.nameOf(m.authorId);
    }

    /** Routing markers are never part of this product; if one ever appears in text it is hidden from the transcript. */
    static String stripMarkers(String t) {
        return t == null ? "" : t.replaceAll("(?im)^[ \\t]*\\[\\[(NEXT:[A-Z]+|DONE)\\]\\][ \\t]*$\\n?", "").trim();
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("AI Group Chat", s));
    }

    private int dp(int v) { return AppUi.dp(this, v); }

    private TextView text(String s, int sp, int color, boolean bold) { return AppUi.text(this, s, sp, color, bold); }

    private android.graphics.drawable.GradientDrawable shape(int color, int radiusDp, int strokeColor, int strokeDp) {
        return AppUi.shape(this, color, radiusDp, strokeColor, strokeDp);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onPause() {
        for (WebProviderSurface s : surfaces.values()) s.flushCookies();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (dotsAnim != null) dotsAnim.cancel();
        if (controller != null && controller.isBusy()) controller.stop(); // closing mid-run = stop; completed messages stay
        for (WebProviderSurface s : surfaces.values()) s.destroy();
        super.onDestroy();
    }
}
