/* AI Group Chat engine lab (P1-A). Installed into provider pages; idempotent.
 * Read-only except explicit send/type-check/attachment operations. Health/poll/probe/attachmentState never mutate the page. */
(function () {
  if (window.__agc && window.__agc.version === 6) { window.__agc.spec = window.__AGC_SPEC || window.__agc.spec; return; }
  var st = {
    pushes: 0, lastPush: 0, sendResult: 'none', before: { a: 0, u: 0 },
    baseA: null, baseU: null, beforeNodesA: null,
    sentNorm: '', sentFullNorm: '', nonce: '', lastScrollAt: 0, replyNode: null,
    typeCheck: 'not-run', sendVerified: false, lastBrief: '', ambiguous: {}
  };

  function spec() { return window.__AGC_SPEC || {}; }

  function q(list) {
    list = list || [];
    for (var i = 0; i < list.length; i++) {
      try { var el = document.querySelector(list[i]); if (el) return el; } catch (e) {}
    }
    return null;
  }

  // Exactly one match or nothing. Ambiguity is reported; no alternate element is guessed/clicked.
  function qUnique(list, name) {
    list = list || [];
    delete st.ambiguous[name]; // ambiguity reflects the current DOM, never a stale prior state
    for (var i = 0; i < list.length; i++) {
      try {
        var n = document.querySelectorAll(list[i]);
        if (n.length === 1) { delete st.ambiguous[name]; return n[0]; }
        if (n.length > 1) { st.ambiguous[name] = list[i] + ' x' + n.length; return null; }
      } catch (e) {}
    }
    return null;
  }

  function qa(list) {
    list = list || [];
    for (var i = 0; i < list.length; i++) {
      try { var n = document.querySelectorAll(list[i]); if (n && n.length) return Array.prototype.slice.call(n); } catch (e) {}
    }
    return [];
  }

  function qaIn(root, list) {
    list = list || [];
    for (var i = 0; i < list.length; i++) {
      try {
        var n = root.querySelectorAll(list[i]);
        if (n && n.length) return Array.prototype.slice.call(n);
      } catch (e) {}
    }
    return [];
  }

  function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }

  function composerText(el) {
    return (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') ? (el.value || '') : (el.innerText || el.textContent || '');
  }

  function composerEmpty(el) { return composerText(el).replace(/\s+/g, '') === ''; }

  // Attachment inspection is deliberately scoped to the configured composer root. It never scans or clicks
  // the whole document, where old message attachments and unrelated close buttons may exist.
  function attachmentRoot(comp) {
    var roots = spec().attachmentRoot || [];
    for (var i = 0; i < roots.length; i++) {
      try { var root = comp.closest(roots[i]); if (root) return root; } catch (e) {}
    }
    return null;
  }

  function inspectAttachments() {
    var comp = qUnique(spec().composer, 'composer');
    if (!comp) return { safe: false, count: 0, removable: 0, error: 'no-unique-composer' };
    var root = attachmentRoot(comp);
    if (!root) return { safe: false, count: 0, removable: 0, error: 'no-attachment-root' };
    var items = qaIn(root, spec().attachment), removes = qaIn(root, spec().attachmentRemove), busy = qaIn(root, spec().attachmentBusy);
    var count = Math.max(items.length, removes.length);
    var safe = count === 0 || (removes.length === count && (!items.length || items.length === count));
    return { safe: safe, ready: safe && busy.length === 0, count: count, removable: removes.length, busy: busy.length,
      error: safe ? '' : 'attachment-controls-do-not-match-visible-items' };
  }

  function attachmentState() { return JSON.stringify(inspectAttachments()); }

  // Removes only the exact controls inside the composer root. Native code polls attachmentState() afterward;
  // a click is not treated as proof that a chip disappeared.
  function cleanupStaleAttachments() {
    var a = inspectAttachments();
    if (!a.safe) return 'refused:' + a.error;
    if (a.count === 0) return 'clean';
    var comp = qUnique(spec().composer, 'composer'), root = comp && attachmentRoot(comp);
    if (!root) return 'refused:no-attachment-root';
    var removes = qaIn(root, spec().attachmentRemove);
    if (removes.length !== a.count) return 'refused:attachment-controls-changed';
    for (var i = 0; i < removes.length; i++) {
      if (removes[i].disabled || removes[i].getAttribute('aria-disabled') === 'true') return 'refused:remove-disabled';
    }
    removes.forEach(function (b) { b.click(); });
    return 'cleanup-started';
  }

  // The page cannot assign FileList safely. It clicks one exact input and WebChromeClient supplies the URI.
  // expectedBefore binds this chooser attempt to the attachment count observed for the current operation.
  function startFileUpload(expectedBefore) {
    var a = inspectAttachments();
    if (!a.safe) return 'refused:' + a.error;
    if (a.count !== expectedBefore) return 'refused:attachment-count-changed';
    var input = qUnique(spec().fileInput, 'fileInput');
    if (!input) return st.ambiguous.fileInput ? 'refused:file-input-ambiguous' : 'refused:no-unique-file-input';
    if (input.disabled || input.getAttribute('aria-disabled') === 'true') return 'refused:file-input-disabled';
    input.click();
    return 'chooser-opened';
  }

  function generating() { return !!(q(spec().stop) || q(spec().streaming)); }

  function setText(el, text) {
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (!desc || !desc.set) return false;
      desc.set.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    var ok = document.execCommand('insertText', false, text);
    if (!ok) {
      el.textContent = text;
      try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); }
      catch (e) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    return true;
  }

  // Removes content from ONE element with a range scoped to that element. Never document-wide selectAll.
  function deleteAllIn(el) {
    el.focus();
    var sel = window.getSelection(), r = document.createRange();
    r.selectNodeContents(el);
    sel.removeAllRanges(); sel.addRange(r);
    document.execCommand('delete', false, null);
    sel.removeAllRanges();
  }

  function challenge() {
    try {
      var t = (document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 400) : '');
      return /just a moment|verify you are human|checking your browser|unusual activity/i.test(t);
    } catch (e) { return false; }
  }

  // Generic counts for the tiny observer payload.
  function brief() {
    var a = qa(spec().assistant), u = qa(spec().user);
    return { a: a.length, u: u.length, gen: generating(), len: a.length ? (a[a.length - 1].innerText || '').length : 0 };
  }

  // ---- Reply identity. Authority = stable message ids or count growth, never DOM node-object novelty. ----
  function idOf(n) {
    var e = (n.getAttribute && n.getAttribute('data-message-id')) ? n : (n.closest ? n.closest('[data-message-id]') : null);
    return e ? (e.getAttribute('data-message-id') || '') : '';
  }

  // Returns IDs only if EVERY current node exposes a stable id and IDs are unique. Otherwise null.
  function idsOf(nodes) {
    if (!nodes.length) return null;
    var out = [], seen = {};
    for (var i = 0; i < nodes.length; i++) {
      var id = idOf(nodes[i]);
      if (!id || seen[id]) return null;
      seen[id] = true; out.push(id);
    }
    return out;
  }

  function snapshot(list) {
    var nodes = qa(list), ids = idsOf(nodes);
    return { count: nodes.length, ids: ids ? new Set(ids) : null };
  }

  function identifyLegacy() {
    var res = { mode: 'none', newA: 0, newU: 0, userMatches: false, identity: false, node: null, nodeNovelty: 0, userId: '', asstId: '' };
    if (!st.baseA || !st.baseU) return res;

    var A = qa(spec().assistant), U = qa(spec().user);
    var idsA = idsOf(A), idsU = idsOf(U);
    var lastU = null, lastA = null;
    var ia = -1, iu = -1;

    if (st.baseA.ids && st.baseU.ids && idsA && idsU) {
      res.mode = 'ids';
      for (var i = 0; i < A.length; i++) if (!st.baseA.ids.has(idsA[i])) { res.newA++; ia = i; }
      for (var j = 0; j < U.length; j++) if (!st.baseU.ids.has(idsU[j])) { res.newU++; iu = j; }
      if (ia >= 0) lastA = A[ia];
      if (iu >= 0) lastU = U[iu];
    } else {
      res.mode = 'counts';
      res.newA = A.length - st.baseA.count;
      res.newU = U.length - st.baseU.count;
      if (A.length) lastA = A[A.length - 1];
      if (U.length) lastU = U[U.length - 1];
    }

    if (st.beforeNodesA) res.nodeNovelty = A.filter(function (n) { return !st.beforeNodesA.has(n); }).length; // diagnostic only
    // B2: the user bubble is proven independently of any reply, so "submitted" can be reported as soon as it appears.
    if (res.newU > 0 && lastU) {
      var userIdx = norm(lastU.innerText).indexOf(st.sentNorm);
      res.userMatches = st.sentNorm !== '' && userIdx >= 0 && userIdx <= 16;
      if (res.userMatches && res.mode === 'ids' && iu >= 0) res.userId = idsU[iu];
    }
    if (res.newA <= 0 || res.newU <= 0 || !lastA || !lastU) return res;

    var follows = (lastU.compareDocumentPosition(lastA) & 4) !== 0; // DOCUMENT_POSITION_FOLLOWING
    res.identity = res.userMatches && follows;
    if (res.identity) {
      res.node = lastA;
      if (res.mode === 'ids' && ia >= 0) res.asstId = idsA[ia];
    }
    return res;
  }

  // ---- B2.1: count-independent identity. Every prompt carries a short unique "[ref xxxxxx]" tag at its start. Our user bubble is
  // the one containing that tag; our reply is the first assistant node AFTER it in document order. This survives virtualized or
  // re-rendered message lists (counts and node objects may change freely) and can never pick an older answer, because an older
  // answer precedes our bubble. If our bubble cannot be found, identity stays false and the turn fails closed.
  function hasText(node, needle) { return norm(node.innerText || node.textContent || '').indexOf(needle) >= 0; }

  // Reply text WITHOUT visually-hidden screen-reader blocks (Claude exposes "Claude responded: <start of the reply>" that way).
  function visibleText(node) {
    if (!node) return '';
    var hidden = [];
    try { hidden = Array.prototype.slice.call(node.querySelectorAll('.sr-only,[class*="sr-only"],.visually-hidden,[class*="visually-hidden"]')); } catch (e) {}
    var saved = hidden.map(function (h) { return h.style.display; });
    hidden.forEach(function (h) { h.style.setProperty('display', 'none', 'important'); });
    var t = node.innerText || '';
    hidden.forEach(function (h, i) { if (saved[i]) h.style.display = saved[i]; else h.style.removeProperty('display'); });
    return t;
  }

  function identifyByNonce() {
    var res = { mode: 'nonce', newA: 0, newU: 0, userMatches: false, identity: false, node: null, nodeNovelty: 0, userId: '', asstId: '' };
    if (!st.nonce) return res;
    var U = qa(spec().user), A = qa(spec().assistant), ourU = null;
    for (var i = U.length - 1; i >= 0; i--) { if (hasText(U[i], st.nonce)) { ourU = U[i]; break; } }
    if (!ourU) return res;
    res.userMatches = true;
    res.userId = idOf(ourU) || '';
    for (var j = 0; j < A.length; j++) {
      if ((ourU.compareDocumentPosition(A[j]) & 4) !== 0) { // first assistant node that FOLLOWS our bubble
        res.identity = true; res.node = A[j]; res.asstId = idOf(A[j]) || '';
        break;
      }
    }
    return res;
  }

  function identify() {
    var leg = identifyLegacy();
    if (!st.nonce) return leg;
    var res = identifyByNonce();
    res.newA = leg.newA; res.newU = leg.newU; res.nodeNovelty = leg.nodeNovelty; // diagnostics only
    if (res.identity) return res;
    if (leg.mode === 'ids' && leg.identity) return leg; // stable provider ids are also trustworthy
    return res;
  }

  // Keep the newest messages rendered: virtualized lists unmount old rows as the bottom grows.
  function scrollToEnd() {
    try {
      var A = qa(spec().assistant), U = qa(spec().user);
      var n = A.length ? A[A.length - 1] : (U.length ? U[U.length - 1] : null);
      var el = n ? n.parentElement : null;
      while (el && el !== document.body && el !== document.documentElement) {
        var cs = getComputedStyle(el);
        if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 4) { el.scrollTop = el.scrollHeight; break; }
        el = el.parentElement;
      }
      window.scrollTo(0, document.documentElement.scrollHeight);
    } catch (e) {}
  }

  function poll() {
    var id = identify(), b = brief();
    // Only nudge the chat to its end when our bubble / the reply are NOT currently rendered, and at most every 2 s, so this does not
    // cause DOM churn of its own.
    if ((st.sendResult === 'pending' || st.sendResult === 'clicked') && st.nonce && !id.identity && Date.now() - st.lastScrollAt > 2000) {
      st.lastScrollAt = Date.now();
      scrollToEnd();
      id = identify();
    }
    if (id.node) st.replyNode = id.node;
    return JSON.stringify({
      sendResult: st.sendResult, before: st.before, a: b.a, u: b.u, gen: b.gen,
      len: id.node ? visibleText(id.node).length : 0,
      mode: id.mode, newA: id.newA, newU: id.newU, nodeNovelty: id.nodeNovelty,
      userMatches: id.userMatches, userProven: !!id.userMatches, userId: id.userId, asstId: id.asstId,
      identity: id.identity,
      url: location.origin + location.pathname, vis: document.visibilityState,
      pushes: st.pushes, lastPush: st.lastPush
    });
  }

  function health() {
    var b = brief(), comp = qUnique(spec().composer, 'composer');
    var amb = st.ambiguous;
    return JSON.stringify({
      url: location.origin + location.pathname,
      vis: document.visibilityState, hidden: document.hidden,
      healthy: !!comp && Object.keys(amb).length === 0,
      composer: !!comp, composerTag: comp ? comp.tagName : '', composerEmpty: comp ? composerEmpty(comp) : null,
      sendPresent: !!qUnique(spec().send, 'send'), sendVerified: st.sendVerified,
      stopPresent: !!q(spec().stop), ambiguous: amb,
      assistantNodes: b.a, userNodes: b.u, generating: b.gen, challenge: challenge(), typeCheck: st.typeCheck,
      pushes: st.pushes, msSinceLastPush: st.lastPush ? Date.now() - st.lastPush : -1,
      innerW: window.innerWidth, innerH: window.innerHeight
    });
  }

  // Types one harmless character on an EMPTY composer. It clears only if that composer is still exactly x.
  function startTypeCheck() {
    var el = qUnique(spec().composer, 'composer');
    if (!el) { st.typeCheck = 'no-unique-composer'; return 'no-unique-composer'; }
    if (!composerEmpty(el)) { st.typeCheck = 'skipped-composer-not-empty'; return 'skipped'; }
    st.typeCheck = 'running';
    if (!setText(el, 'x')) { st.typeCheck = 'insert-failed'; return 'insert-failed'; }
    setTimeout(function () {
      var s = qUnique(spec().send, 'send');
      var found = s ? ('send-appeared disabled=' + (!!s.disabled || s.getAttribute('aria-disabled') === 'true')) : 'send-NOT-found-after-typing';
      st.sendVerified = !!s;
      if (composerText(el).replace(/\r?\n$/, '') !== 'x') {
        st.typeCheck = found + ' restored=FALSE composer-changed(left-untouched)';
        return;
      }
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') setText(el, ''); else deleteAllIn(el);
      st.typeCheck = found + (composerEmpty(el) ? ' restored=true' : ' restored=FALSE');
    }, 700);
    return 'started';
  }

  function pathHasConversationId(convId) {
    if (!convId) return true;
    return location.pathname.split('/').indexOf(convId) >= 0;
  }

  // If the send is refused after we inserted text, remove exactly that text (never anything else) so no draft is left behind.
  function clearIfOurs(el) {
    try {
      if (norm(composerText(el)) === st.sentFullNorm) {
        if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') setText(el, ''); else deleteAllIn(el);
      }
    } catch (e) {}
  }

  // Inserts into an EMPTY composer, then waits (bounded) for exactly one enabled Send control. Fails closed.
  function send(text, convId, nonce) {
    var el = qUnique(spec().composer, 'composer');
    if (!el) { st.sendResult = 'no-unique-composer'; return 'no-unique-composer'; }
    if (!pathHasConversationId(convId)) { st.sendResult = 'wrong-conversation'; return 'wrong-conversation'; }
    if (!composerEmpty(el)) { st.sendResult = 'composer-not-empty'; return 'composer-not-empty'; }
    if (generating()) { st.sendResult = 'busy'; return 'busy'; }

    st.baseA = snapshot(spec().assistant);
    st.baseU = snapshot(spec().user);
    st.beforeNodesA = new Set(qa(spec().assistant)); // diagnostic only
    st.replyNode = null;
    st.before = { a: st.baseA.count, u: st.baseU.count };
    st.nonce = nonce || '';
    st.sentNorm = norm(text).slice(0, 60);  // prefix: identifies the resulting user bubble
    st.sentFullNorm = norm(text);           // whole text: exact pre-click safety check
    st.sendResult = 'pending';

    if (!setText(el, text)) { st.sendResult = 'insert-failed'; return 'insert-failed'; }
    var deadline = Date.now() + 3000;

    (function waitForSend() {
      if (st.sendResult === 'aborted') return; // Stop won: never click after an abort (single-threaded page: no interleaving with the click below)
      if (!pathHasConversationId(convId)) { clearIfOurs(el); st.sendResult = 'wrong-conversation'; return; }
      var s = qUnique(spec().send, 'send');
      if (s && !s.disabled && s.getAttribute('aria-disabled') !== 'true') {
        if (norm(composerText(el)) !== st.sentFullNorm) { st.sendResult = 'composer-content-changed'; return; }
        s.click(); st.sendResult = 'clicked'; return;
      }
      if (Date.now() < deadline) { setTimeout(waitForSend, 150); return; }
      clearIfOurs(el);
      st.sendResult = st.ambiguous.send ? 'send-ambiguous' : (s ? 'send-disabled' : 'no-unique-send-button');
    })();
    return 'inserted';
  }

  // ---- C2: authoritative Stop for a send in progress. Runs on the page's single thread, so it cannot interleave with the click.
  //  'clicked'  -> the click already happened: the message may be on its way / sent (the room drains, never resends)
  //  'aborted'  -> text was inserted but NOT clicked: the click is now blocked and only text equal to what WE inserted is removed
  //  'not-sent' -> the send had already been refused earlier (nothing sent)
  //  anything else ('none', unexpected) -> unknown: the Java side must treat it as possibly sent
  var NOT_SENT = { 'no-unique-composer': 1, 'wrong-conversation': 1, 'composer-not-empty': 1, 'busy': 1, 'insert-failed': 1,
    'composer-content-changed': 1, 'send-ambiguous': 1, 'send-disabled': 1, 'no-unique-send-button': 1, 'aborted': 1 };
  function abortSend() {
    var r = st.sendResult;
    if (r === 'clicked') return 'clicked';
    if (r === 'pending') {
      st.sendResult = 'aborted';
      try { var el = qUnique(spec().composer, 'composer'); if (el) clearIfOurs(el); } catch (e) {}
      return 'aborted';
    }
    if (NOT_SENT[r]) return 'not-sent';
    return r;
  }

  // DOM inventory for selector correction. Structure only; no conversation/message body text is intentionally returned.
  function probe() {
    var out = { buttons: [], editables: [], counts: {} }, seen = {};
    Array.prototype.slice.call(document.querySelectorAll('button,[role=button]')).slice(0, 500).forEach(function (b) {
      var tid = b.getAttribute('data-testid') || '', al = b.getAttribute('aria-label') || '';
      var k = tid + ' | ' + al + (tid || al ? '' : ' | text:' + (b.innerText || '').trim().slice(0, 12));
      if (!seen[k] && out.buttons.length < 60) { seen[k] = 1; out.buttons.push(k); }
    });
    Array.prototype.slice.call(document.querySelectorAll('[contenteditable=true],textarea')).slice(0, 10).forEach(function (e) {
      out.editables.push(e.tagName + '#' + (e.id || '') + ' aria=' + (e.getAttribute('aria-label') || '') +
        ' testid=' + (e.getAttribute('data-testid') || '') + ' cls=' + String(e.className).slice(0, 60));
    });
    ['[data-message-author-role]', '[data-message-id]', '[data-is-streaming]', '[data-testid="user-message"]',
      '[data-testid="assistant-message"]', '[data-testid]'].forEach(function (s) {
      try { out.counts[s] = document.querySelectorAll(s).length; } catch (e) {}
    });
    return JSON.stringify(out);
  }

  // ---------------------------------------------------------------- files an AI offers in its replies, and PULL-based capture
  // scanOffers/fileOffers only READ the page. The bytes of a file are never pushed to the app (the AGCBridge is not origin-authenticated, so a script
  // on the provider's page could otherwise inject a fake file); the APP asks for them chunk by chunk with its own evaluateJavascript calls.
  var OFFER_MESSAGES = 5, MAX_OFFERS = 20, CAP_CHUNK = 262144;

  function offerNameOf(el, kind) {
    var n = '';
    if (kind === 'link') n = el.getAttribute('download') || '';
    if (!n) n = norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.innerText || el.textContent || '');
    n = n.replace(/^download( file)?:?\s*/i, '');
    if (!n && kind === 'link') { try { var p = new URL(el.href).pathname.split('/'); n = decodeURIComponent(p[p.length - 1] || ''); } catch (e) {} }
    return n.slice(0, 300);
  }

  function scanOffers() {
    var asst = qa(spec().assistant), out = [];
    for (var m = asst.length - 1; m >= 0 && asst.length - 1 - m < OFFER_MESSAGES; m--) {
      var fromEnd = asst.length - 1 - m, seen = [], msgId = idOf(asst[m]);   // the page's own stable id of this assistant message ('' when it has none)
      var groups = [['link', qaIn(asst[m], spec().offerLink)], ['button', qaIn(asst[m], spec().offerButton)]];
      for (var g = 0; g < groups.length; g++) {
        for (var k = 0; k < groups[g][1].length; k++) {
          var el = groups[g][1][k];
          if (seen.indexOf(el) >= 0) continue;
          seen.push(el);
          var name = offerNameOf(el, groups[g][0]);
          if (!name) continue;
          out.push({ el: el, name: name, kind: groups[g][0], href: groups[g][0] === 'link' ? String(el.href || '').slice(0, 4000) : '',
            mime: String(el.getAttribute('type') || '').slice(0, 100), fromEnd: fromEnd, msgId: msgId.slice(0, 200) });
        }
      }
    }
    out = out.slice(0, MAX_OFFERS);
    for (var i = 0; i < out.length; i++) out[i].index = i;
    return out;
  }

  function fileOffers() {
    return JSON.stringify(scanOffers().map(function (o) { return { name: o.name, kind: o.kind, href: o.href, index: o.index, fromEnd: o.fromEnd, mime: o.mime, msgId: o.msgId }; }));
  }

  // The app selected ONE offer and describes it completely (fp). Act only if the offer at that place is STILL exactly that one: same index, name, kind,
  // address, position among the messages and reply id. A list that changed between the app's scan and this call is refused, never "closest match".
  function sameOffer(o, fp) {
    return !!(o && fp && o.index === fp.index && o.name === fp.name && o.kind === fp.kind && o.href === fp.href && o.fromEnd === fp.fromEnd && o.msgId === fp.msgId);
  }

  function offerAt(fp) {
    var o = fp ? scanOffers()[fp.index] : null;
    return sameOffer(o, fp) ? o : null;
  }

  // Explicit action, only used while the app holds the capture operation: starts the provider's own download. Only a real button or the provider's own
  // sandbox: link is ever clicked; any other link (javascript:, file:, http: ...) is refused even if the app asked.
  function clickOffer(fp) {
    var o = offerAt(fp);
    if (!o) return JSON.stringify({ ok: false, error: 'offer-changed' });
    if (!(o.kind === 'button' || /^sandbox:/i.test(o.href))) return JSON.stringify({ ok: false, error: 'not-clickable' });
    try { o.el.click(); } catch (e) { return JSON.stringify({ ok: false, error: 'click-failed' }); }
    return JSON.stringify({ ok: true });
  }

  // Never a full address (it can carry a signed token): only the scheme, the host and the file extension.
  function hrefShape(h) {
    h = String(h || '');
    if (!h) return '';
    if (/^blob:/i.test(h)) return 'blob:' + hrefShape(h.slice(5));
    var m = /^([a-z][a-z0-9+.-]*:)(\/\/[^\/?#]*)?/i.exec(h), ext = /\.([a-z0-9]{1,8})(?:[?#]|$)/i.exec(h);
    return (m ? m[1] + (m[2] || '') : '?') + (ext ? ' .' + ext[1].toLowerCase() : '');
  }

  // READ-ONLY inventory for the Engine Lab: do the assistant messages expose stable ids, what do the offer selectors find, and which other
  // download-looking controls are in the newest messages (so the selectors can be corrected from evidence instead of guesses).
  function fileProbe() {
    var asst = qa(spec().assistant), withId = 0, i, k;
    for (i = 0; i < asst.length; i++) if (idOf(asst[i])) withId++;
    var offers = scanOffers().map(function (o) {
      return { name: o.name, kind: o.kind, fromEnd: o.fromEnd, id: o.msgId ? 'yes' : 'no', href: hrefShape(o.href), mime: o.mime };
    });
    var looks = [], seen = [], sel = ['a[download]', 'a[href^="blob:"]', 'a[href^="sandbox:"]', 'a[href]', 'button', '[role="button"]'];
    for (i = asst.length - 1; i >= 0 && i >= asst.length - 2 && looks.length < 15; i--) {
      for (var g = 0; g < sel.length; g++) {
        var found;
        try { found = asst[i].querySelectorAll(sel[g]); } catch (e) { continue; }
        for (k = 0; k < found.length && looks.length < 15; k++) {
          var el = found[k];
          if (seen.indexOf(el) >= 0) continue;
          var label = norm(el.getAttribute('aria-label') || el.getAttribute('title') || el.innerText || el.textContent || '');
          if (!/download|file|save|attach/i.test(label) && !el.hasAttribute('download') && !/^(blob:|sandbox:)/i.test(el.getAttribute('href') || '')) continue;
          seen.push(el);
          looks.push({ fromEnd: asst.length - 1 - i, tag: el.tagName.toLowerCase(), testid: String(el.getAttribute('data-testid') || '').slice(0, 40),
            label: label.slice(0, 60), href: hrefShape(el.getAttribute('href') || '') });
        }
      }
    }
    return JSON.stringify({ assistantNodes: asst.length, withStableId: withId, offerSelectors: { link: (spec().offerLink || []).length, button: (spec().offerButton || []).length },
      offers: offers, lookAlikes: looks });
  }

  var caps = {};
  function urlOk(u) { return /^(https:|blob:|data:)/i.test(String(u)); }

  function captureUrl(id, url, maxBytes) {
    caps = {}; // one capture at a time: the previous one's memory is released
    if (!urlOk(url)) return JSON.stringify({ ok: false, error: 'url-not-allowed' });
    if (typeof fetch !== 'function') return JSON.stringify({ ok: false, error: 'no-fetch' });
    var c = { state: 'pending', error: '', bytes: null, size: 0, mime: '' };
    caps[id] = c;
    try {
      fetch(url, { credentials: 'include' }).then(function (r) {
        if (!r.ok) throw new Error('http-' + r.status);
        var len = Number(r.headers && r.headers.get ? r.headers.get('content-length') : 0);
        if (len > maxBytes) throw new Error('too-large');
        c.mime = String((r.headers && r.headers.get && r.headers.get('content-type')) || '').split(';')[0].trim().toLowerCase();
        return r.arrayBuffer();
      }).then(function (buf) {
        if (buf.byteLength > maxBytes) throw new Error('too-large');
        c.bytes = new Uint8Array(buf); c.size = buf.byteLength; c.state = 'ready';
      })['catch'](function (e) { c.state = 'failed'; c.error = String(e && e.message ? e.message : e).slice(0, 80); c.bytes = null; });
    } catch (e) { c.state = 'failed'; c.error = 'fetch-threw'; }
    return JSON.stringify({ ok: true });
  }

  // The address fetched is the one in the fingerprint (it has just been proven identical to the page's), i.e. exactly the address the app approved.
  function captureBegin(id, fp, maxBytes) {
    var o = offerAt(fp);
    if (!o) return JSON.stringify({ ok: false, error: 'offer-changed' });
    if (!o.href || !urlOk(o.href)) return JSON.stringify({ ok: false, error: (o.kind === 'button' || /^sandbox:/i.test(o.href)) ? 'click-only' : 'not-fetchable' });
    return captureUrl(id, o.href, maxBytes);
  }

  function captureStatus(id) {
    var c = caps[id];
    if (!c) return JSON.stringify({ state: 'none' });
    return JSON.stringify({ state: c.state, size: c.size, mime: c.mime, error: c.error, chunk: CAP_CHUNK, chunks: Math.ceil(c.size / CAP_CHUNK) });
  }

  // One base64 slice per call; '!notready' when there is nothing to read; '' past the end.
  function captureChunk(id, n) {
    var c = caps[id];
    if (!c || c.state !== 'ready' || !c.bytes) return '!notready';
    var start = n * CAP_CHUNK;
    if (!(start >= 0) || start >= c.bytes.length) return '';
    var slice = c.bytes.subarray(start, Math.min(c.bytes.length, start + CAP_CHUNK)), s = '';
    for (var i = 0; i < slice.length; i += 8192) s += String.fromCharCode.apply(null, slice.subarray(i, Math.min(slice.length, i + 8192)));
    return btoa(s);
  }

  function captureEnd(id) { delete caps[id]; return 'ok'; }

  var timer = null;
  function push() {
    var b = brief(), s = JSON.stringify(b);
    if (s === st.lastBrief) return;
    st.lastBrief = s; st.pushes++; st.lastPush = Date.now();
    try { if (window.AGCBridge) window.AGCBridge.event(s); } catch (e) {}
  }

  var obs = new MutationObserver(function () {
    if (timer) return;
    timer = setTimeout(function () { timer = null; push(); }, 400);
  });

  function start() {
    if (document.body) obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    else setTimeout(start, 200);
  }
  start();

  window.__agc = {
    version: 6,
    spec: spec(),
    health: health,
    poll: poll,
    probe: probe,
    attachmentState: attachmentState,
    cleanupStaleAttachments: cleanupStaleAttachments,
    startFileUpload: startFileUpload,
    fileOffers: fileOffers,
    fileProbe: fileProbe,
    clickOffer: clickOffer,
    captureBegin: captureBegin,
    captureUrl: captureUrl,
    captureStatus: captureStatus,
    captureChunk: captureChunk,
    captureEnd: captureEnd,
    send: send,
    abortSend: abortSend,
    startTypeCheck: startTypeCheck,
    full: function () { return st.replyNode ? visibleText(st.replyNode).slice(0, 300000) : ''; }
  };
})();
