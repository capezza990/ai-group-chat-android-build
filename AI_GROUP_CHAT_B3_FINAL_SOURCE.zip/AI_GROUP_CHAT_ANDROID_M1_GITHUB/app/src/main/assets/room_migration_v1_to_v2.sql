-- 1. registry: profiles (a service) and providers (a seat-able instance)
CREATE TABLE provider_profiles (
  id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  origin TEXT NOT NULL DEFAULT '',
  engine TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('CORE','CUSTOM','MOCK')),
  profile_state TEXT NOT NULL DEFAULT 'VERIFIED' CHECK (profile_state IN ('VERIFIED','UNVERIFIED')),
  accent_color INTEGER,
  icon_ref TEXT NOT NULL DEFAULT '',
  icon_sha256 TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
)
-- @@
CREATE TABLE providers (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL REFERENCES provider_profiles(id),
  display_name TEXT NOT NULL,
  created_at INTEGER NOT NULL
)
-- @@
INSERT INTO provider_profiles(id, display_name, origin, engine, kind, created_at) VALUES
  ('chatgpt','ChatGPT','https://chatgpt.com','chatgpt','CORE',:now),
  ('claude','Claude','https://claude.ai','claude','CORE',:now)
-- @@
INSERT OR IGNORE INTO provider_profiles(id, display_name, origin, engine, kind, created_at)
  SELECT pid, CASE pid WHEN 'gemini' THEN 'Gemini' WHEN 'mock-delta' THEN 'Mock Delta' ELSE pid END, '', 'mock', 'MOCK', :now
  FROM (SELECT provider_id AS pid FROM participants UNION SELECT provider_id FROM provider_bindings
        UNION SELECT provider_id FROM deliveries UNION SELECT author_id FROM messages WHERE author_type='PROVIDER')
  WHERE pid NOT IN ('chatgpt','claude')
-- @@
INSERT INTO providers(id, profile_id, display_name, created_at) SELECT id, id, display_name, :now FROM provider_profiles
-- @@
CREATE TABLE provider_availability (
  provider_id TEXT PRIMARY KEY REFERENCES providers(id),
  state TEXT NOT NULL DEFAULT 'READY' CHECK (state IN ('READY','ATTENTION','UNHEALTHY')),
  reason TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  resets_at INTEGER,
  observed_at INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT ''
)
-- @@
-- 2. rooms: name, kind, natural-turn limit (ADD COLUMN without CHECK: old Android SQLite cannot test it; triggers guard instead).
--    The permanent default for kind is LIVE: a normal room can never silently become a developer room.
ALTER TABLE rooms ADD COLUMN name TEXT NOT NULL DEFAULT ''
-- @@
ALTER TABLE rooms ADD COLUMN kind TEXT NOT NULL DEFAULT 'LIVE'
-- @@
ALTER TABLE rooms ADD COLUMN natural_max_turns INTEGER NOT NULL DEFAULT 0
-- @@
-- v1 had no normal multi-room creation: 'default' is the live room, every other existing room is a developer/self-check room
UPDATE rooms SET kind = CASE WHEN id = 'default' THEN 'LIVE' ELSE 'MOCK' END,
                 name = CASE WHEN id = 'default' THEN 'Main room' WHEN id = 'mock-room' THEN 'Mock room' ELSE id END
-- @@
CREATE TRIGGER rooms_kind_insert BEFORE INSERT ON rooms WHEN NEW.kind NOT IN ('LIVE','MOCK')
BEGIN SELECT RAISE(ABORT, 'rooms.kind must be LIVE or MOCK'); END
-- @@
CREATE TRIGGER rooms_kind_update BEFORE UPDATE OF kind ON rooms WHEN NEW.kind NOT IN ('LIVE','MOCK')
BEGIN SELECT RAISE(ABORT, 'rooms.kind must be LIVE or MOCK'); END
-- @@
CREATE TRIGGER rooms_natural_turns_insert BEFORE INSERT ON rooms WHEN NEW.natural_max_turns NOT BETWEEN 0 AND 20
BEGIN SELECT RAISE(ABORT, 'natural_max_turns must be 0..20'); END
-- @@
CREATE TRIGGER rooms_natural_turns_update BEFORE UPDATE OF natural_max_turns ON rooms WHEN NEW.natural_max_turns NOT BETWEEN 0 AND 20
BEGIN SELECT RAISE(ABORT, 'natural_max_turns must be 0..20'); END
-- @@
-- 3. if legacy bindings exist but the live room was never created, create it now (silently seated, like the app's own seeding).
--    _mig_new_default is a marker that exists only inside this migration: it is the ONLY thing allowed to trigger automatic seating,
--    so the membership of a room that already existed is never changed.
CREATE TABLE _mig_new_default AS
  SELECT 1 AS x WHERE NOT EXISTS (SELECT 1 FROM rooms WHERE id = 'default') AND EXISTS (SELECT 1 FROM provider_bindings)
-- @@
INSERT INTO rooms(id, routing_mode, routing_arg, rounds, created_at, name, kind, natural_max_turns)
  SELECT 'default', 'AUTO_PICK', 'chatgpt', 1, :now, 'Main room', 'LIVE', 0
  WHERE EXISTS (SELECT 1 FROM _mig_new_default)
-- @@
-- 3b. keep the user's Natural-turn setting: part of the same transaction as the schema change (:natural_turns is read from the old preference by Java)
UPDATE rooms SET natural_max_turns = :natural_turns WHERE id = 'default'
-- @@
-- 4. participants: rebuild so provider_id references the registry (nothing references participants yet, so the rebuild is safe)
CREATE TABLE participants_v2 (
  room_id TEXT NOT NULL REFERENCES rooms(id),
  provider_id TEXT NOT NULL REFERENCES providers(id),
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0,1)),
  position INTEGER NOT NULL,
  context_seq INTEGER NOT NULL DEFAULT 0,
  mirror_state TEXT NOT NULL DEFAULT 'UNKNOWN',
  PRIMARY KEY (room_id, provider_id)
)
-- @@
INSERT INTO participants_v2(room_id, provider_id, enabled, position, context_seq, mirror_state)
  SELECT room_id, provider_id, enabled, position, context_seq, mirror_state FROM participants
-- @@
DROP TABLE participants
-- @@
ALTER TABLE participants_v2 RENAME TO participants
-- @@
-- seat the two core AIs ONLY in a default room that this migration itself just created for legacy bindings
INSERT INTO participants(room_id, provider_id, enabled, position, context_seq, mirror_state)
  SELECT 'default', 'chatgpt', 1, 0, 0, 'UNKNOWN' WHERE EXISTS (SELECT 1 FROM _mig_new_default)
-- @@
INSERT INTO participants(room_id, provider_id, enabled, position, context_seq, mirror_state)
  SELECT 'default', 'claude', 1, 1, 0, 'UNKNOWN' WHERE EXISTS (SELECT 1 FROM _mig_new_default)
-- @@
DROP TABLE _mig_new_default
-- @@
-- 4b. deliveries: rebuild so a delivery can never point at another room's data. v1 only said trigger_message_id REFERENCES messages(id)
--     (any room!), left reply_message_id with no foreign key at all, and did not tie the AI to a seat. The new keys:
--       trigger message and reply message must belong to the SAME room as the delivery, and the AI must have a participant row in that room
--       (a removed AI keeps its row with enabled = 0, so history stays valid).
--     "No reply yet" was the empty string; it becomes NULL (a foreign key cannot point at ''). The app maps NULL back to "".
--     Rows are copied exactly. An inconsistent old row is NOT repaired or dropped: the copy fails, the upgrade aborts, v1 stays untouched.
CREATE UNIQUE INDEX messages_id_room ON messages(id, room_id)
-- @@
CREATE TABLE deliveries_v2 (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  trigger_message_id TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  upto_seq INTEGER NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('PENDING','SENDING','SENT','CAPTURED','FAILED','UNCERTAIN','CANCELLED')),
  provider_user_msg_id TEXT NOT NULL DEFAULT '',
  provider_asst_msg_id TEXT NOT NULL DEFAULT '',
  reply_message_id TEXT,
  error TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE (trigger_message_id, provider_id),
  FOREIGN KEY (trigger_message_id, room_id) REFERENCES messages(id, room_id),
  FOREIGN KEY (reply_message_id, room_id) REFERENCES messages(id, room_id),
  FOREIGN KEY (room_id, provider_id) REFERENCES participants(room_id, provider_id)
)
-- @@
INSERT INTO deliveries_v2(id, room_id, trigger_message_id, provider_id, upto_seq, state, provider_user_msg_id, provider_asst_msg_id, reply_message_id, error, created_at, updated_at)
  SELECT id, room_id, trigger_message_id, provider_id, upto_seq, state, provider_user_msg_id, provider_asst_msg_id, NULLIF(reply_message_id, ''), error, created_at, updated_at FROM deliveries
-- @@
DROP TABLE deliveries
-- @@
ALTER TABLE deliveries_v2 RENAME TO deliveries
-- @@
CREATE INDEX deliveries_state ON deliveries(state)
-- @@
-- 5. room-scoped bindings with history. A RETIRED row may have an empty conversation id: a rollover that was cancelled before its new thread existed.
CREATE TABLE room_bindings (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('ACTIVE','RETIRED','PENDING_NEW')),
  conversation_id TEXT NOT NULL DEFAULT '',
  restore_locator TEXT NOT NULL DEFAULT '',
  display_title TEXT NOT NULL DEFAULT '',
  bound_at INTEGER NOT NULL,
  retired_at INTEGER,
  retired_reason TEXT NOT NULL DEFAULT '',
  UNIQUE (id, room_id, provider_id),
  FOREIGN KEY (room_id, provider_id) REFERENCES participants(room_id, provider_id),
  CHECK ((state = 'ACTIVE' AND conversation_id <> '')
      OR (state = 'PENDING_NEW' AND conversation_id = '')
      OR  state = 'RETIRED')
)
-- @@
CREATE UNIQUE INDEX room_bindings_one_current ON room_bindings(room_id, provider_id) WHERE state IN ('ACTIVE','PENDING_NEW')
-- @@
CREATE INDEX room_bindings_thread ON room_bindings(provider_id, conversation_id) WHERE state = 'ACTIVE'
-- @@
CREATE TRIGGER room_bindings_no_delete BEFORE DELETE ON room_bindings
BEGIN SELECT RAISE(ABORT, 'bindings are history; retire them instead'); END
-- @@
CREATE TRIGGER room_bindings_retired_is_final BEFORE UPDATE ON room_bindings WHEN OLD.state = 'RETIRED'
BEGIN SELECT RAISE(ABORT, 'a retired binding is history and cannot change'); END
-- @@
CREATE TRIGGER room_bindings_identity_fixed BEFORE UPDATE ON room_bindings
WHEN NEW.id <> OLD.id OR NEW.room_id <> OLD.room_id OR NEW.provider_id <> OLD.provider_id
BEGIN SELECT RAISE(ABORT, 'a binding cannot move to another room or provider'); END
-- @@
INSERT INTO room_bindings(id, room_id, provider_id, state, conversation_id, restore_locator, display_title, bound_at)
  SELECT 'migrated-' || b.provider_id, 'default', b.provider_id, 'ACTIVE', b.conversation_id, b.restore_locator, b.display_title, b.bound_at
  FROM provider_bindings b JOIN participants p ON p.room_id = 'default' AND p.provider_id = b.provider_id
-- @@
-- 6. artifacts (cross-room attachment is impossible: every link carries room_id and the foreign keys include it)
CREATE TABLE artifacts (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  origin TEXT NOT NULL CHECK (origin <> ''),             -- 'user' or the id of the AI that produced the file
  source_binding_id TEXT,                               -- the exact conversation (binding) an AI produced the file in; NULL ONLY for the user's files
  display_name TEXT NOT NULL,
  mime TEXT NOT NULL DEFAULT '',
  size INTEGER NOT NULL DEFAULT -1,
  sha256 TEXT NOT NULL DEFAULT '',
  storage_path TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL CHECK (state IN ('PENDING_CAPTURE','READY','FAILED')),
  created_at INTEGER NOT NULL,
  UNIQUE (id, room_id),
  CHECK ((origin = 'user' AND source_binding_id IS NULL) OR (origin <> 'user' AND source_binding_id IS NOT NULL)),   -- a user file has no source; an AI file ALWAYS names the conversation it came from
  FOREIGN KEY (source_binding_id, room_id, origin) REFERENCES room_bindings(id, room_id, provider_id)   -- same room, and the binding belongs to the AI named as origin
)
-- @@
CREATE INDEX artifacts_room ON artifacts(room_id)
-- @@
CREATE TRIGGER artifacts_identity_fixed BEFORE UPDATE ON artifacts
WHEN NEW.id <> OLD.id OR NEW.room_id <> OLD.room_id OR NEW.origin <> OLD.origin OR NEW.created_at <> OLD.created_at OR NEW.source_binding_id IS NOT OLD.source_binding_id
BEGIN SELECT RAISE(ABORT, 'artifact identity is fixed (including the conversation it was produced in)'); END
-- @@
CREATE TRIGGER artifacts_source_was_real BEFORE INSERT ON artifacts
WHEN NEW.source_binding_id IS NOT NULL AND (SELECT state FROM room_bindings WHERE id = NEW.source_binding_id) = 'PENDING_NEW'
BEGIN SELECT RAISE(ABORT, 'a file cannot come from a conversation that was never opened (PENDING_NEW); an ACTIVE or an already RETIRED one is fine'); END
-- @@
CREATE TRIGGER artifacts_state_path BEFORE UPDATE OF state ON artifacts
WHEN NEW.state <> OLD.state AND NOT ((OLD.state = 'PENDING_CAPTURE' AND NEW.state IN ('READY','FAILED')) OR (OLD.state = 'FAILED' AND NEW.state = 'PENDING_CAPTURE'))
BEGIN SELECT RAISE(ABORT, 'an artifact moves PENDING_CAPTURE -> READY or FAILED, and FAILED -> PENDING_CAPTURE (retry); nothing else'); END
-- @@
CREATE TRIGGER artifacts_ready_needs_file_insert BEFORE INSERT ON artifacts
WHEN NEW.state = 'READY' AND (NEW.size < 0 OR length(NEW.sha256) <> 64 OR NEW.sha256 GLOB '*[^0-9A-Fa-f]*' OR NEW.storage_path = '')
BEGIN SELECT RAISE(ABORT, 'a READY artifact needs size >= 0 (empty files are fine), a hexadecimal 64-character SHA-256 and a storage path'); END
-- @@
CREATE TRIGGER artifacts_ready_needs_file_update BEFORE UPDATE ON artifacts
WHEN NEW.state = 'READY' AND OLD.state <> 'READY' AND (NEW.size < 0 OR length(NEW.sha256) <> 64 OR NEW.sha256 GLOB '*[^0-9A-Fa-f]*' OR NEW.storage_path = '')
BEGIN SELECT RAISE(ABORT, 'a READY artifact needs size >= 0 (empty files are fine), a hexadecimal 64-character SHA-256 and a storage path'); END
-- @@
CREATE TRIGGER artifacts_ready_is_final BEFORE UPDATE ON artifacts
WHEN OLD.state = 'READY' AND (NEW.state <> 'READY' OR NEW.sha256 <> OLD.sha256 OR NEW.size <> OLD.size OR NEW.mime <> OLD.mime
                              OR NEW.storage_path <> OLD.storage_path OR NEW.display_name <> OLD.display_name)
BEGIN SELECT RAISE(ABORT, 'a READY artifact is final: state, hash, size, type, path and name cannot change'); END
-- @@
CREATE TABLE message_artifacts (
  message_id TEXT NOT NULL,
  room_id TEXT NOT NULL,
  artifact_id TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (message_id, artifact_id),
  FOREIGN KEY (message_id, room_id) REFERENCES messages(id, room_id),
  FOREIGN KEY (artifact_id, room_id) REFERENCES artifacts(id, room_id)
)
-- @@
CREATE TRIGGER message_artifacts_no_update BEFORE UPDATE ON message_artifacts
BEGIN SELECT RAISE(ABORT, 'message attachments are history and cannot change'); END
-- @@
CREATE TRIGGER message_artifacts_no_delete BEFORE DELETE ON message_artifacts
BEGIN SELECT RAISE(ABORT, 'message attachments are history and cannot be removed'); END
-- @@
CREATE TABLE artifact_transfers (
  artifact_id TEXT NOT NULL,
  room_id TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  binding_id TEXT NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('PENDING','SENDING','STAGED','VERIFIED','FAILED')),
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  error TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (artifact_id, binding_id),
  FOREIGN KEY (artifact_id, room_id) REFERENCES artifacts(id, room_id),
  FOREIGN KEY (binding_id, room_id, provider_id) REFERENCES room_bindings(id, room_id, provider_id)
)
-- @@
CREATE TRIGGER artifact_transfers_active_binding_only BEFORE INSERT ON artifact_transfers
WHEN (SELECT state FROM room_bindings WHERE id = NEW.binding_id) IS NOT 'ACTIVE'
BEGIN SELECT RAISE(ABORT, 'a new transfer must target an ACTIVE binding (not RETIRED, not PENDING_NEW)'); END
-- @@
CREATE TRIGGER artifact_transfers_identity_fixed BEFORE UPDATE ON artifact_transfers
WHEN NEW.artifact_id <> OLD.artifact_id OR NEW.room_id <> OLD.room_id OR NEW.provider_id <> OLD.provider_id OR NEW.binding_id <> OLD.binding_id
BEGIN SELECT RAISE(ABORT, 'a transfer is tied to its artifact, room, AI and binding for good; only its state, attempts, error and time can change'); END
-- @@
-- A transfer needs a READY artifact (the file exists and has its hash), and always starts PENDING with no attempts.
CREATE TRIGGER artifact_transfers_ready_artifact_only BEFORE INSERT ON artifact_transfers
WHEN (SELECT state FROM artifacts WHERE id = NEW.artifact_id) IS NOT 'READY'
BEGIN SELECT RAISE(ABORT, 'a transfer needs a READY artifact: the file must exist, with its hash, before it can be sent'); END
-- @@
CREATE TRIGGER artifact_transfers_start_clean BEFORE INSERT ON artifact_transfers
WHEN NEW.state <> 'PENDING' OR NEW.attempts <> 0
BEGIN SELECT RAISE(ABORT, 'a new transfer starts PENDING with 0 attempts'); END
-- @@
CREATE TRIGGER artifact_transfers_state_path BEFORE UPDATE ON artifact_transfers
WHEN NEW.state <> OLD.state AND NOT ((OLD.state = 'PENDING' AND NEW.state IN ('SENDING','FAILED'))
                                  OR (OLD.state = 'SENDING' AND NEW.state IN ('STAGED','FAILED'))
                                  OR (OLD.state = 'STAGED' AND NEW.state IN ('VERIFIED','FAILED'))
                                  OR (OLD.state = 'FAILED' AND NEW.state IN ('PENDING','SENDING')))
BEGIN SELECT RAISE(ABORT, 'invalid transfer state change (PENDING -> SENDING/FAILED, SENDING -> STAGED/FAILED, STAGED -> VERIFIED/FAILED, FAILED -> PENDING/SENDING)'); END
-- @@
CREATE TRIGGER artifact_transfers_verified_is_final BEFORE UPDATE ON artifact_transfers
WHEN OLD.state = 'VERIFIED'
BEGIN SELECT RAISE(ABORT, 'a VERIFIED transfer is final'); END
-- @@
CREATE TRIGGER artifact_transfers_attempts_count BEFORE UPDATE ON artifact_transfers
WHEN NEW.attempts <> OLD.attempts + (CASE WHEN OLD.state <> 'SENDING' AND NEW.state = 'SENDING' THEN 1 ELSE 0 END)
BEGIN SELECT RAISE(ABORT, 'attempts only grow, by exactly one each time a transfer starts sending'); END
-- @@
-- Global single-flight: at most ONE transfer in the whole database may be SENDING at any moment (all rooms, all AIs).
CREATE UNIQUE INDEX artifact_transfers_one_sending ON artifact_transfers(state) WHERE state = 'SENDING'
