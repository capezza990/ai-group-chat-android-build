package com.aigroupchat.bridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.method.LinkMovementMethod;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class MainActivity extends Activity {
    private static final int REQUEST_ATTACHMENTS = 1101;
    private static final int[] AUTO_LIMITS = {5, 10, 20};

    private static final int MODE_CHATGPT = 0;
    private static final int MODE_CLAUDE = 1;
    private static final int MODE_BOTH = 2;
    private static final int MODE_COLLAB = 3;
    private static final int MODE_AUTO = 4;

    private ConversationStore store;
    private final List<AttachmentRecord> draftAttachments = new ArrayList<>();

    private LinearLayout root;
    private TextView bridgeChip;
    private LinearLayout runStrip;
    private TextView runText;
    private Button stopButton;
    private ScrollView transcriptScroll;
    private TextView transcript;
    private FrameLayout transcriptFrame;
    private ImageButton jumpLatestButton;
    private EditText input;
    private LinearLayout controlsPanel;
    private Spinner modeSpinner;
    private Spinner firstActor;
    private Spinner detailSpinner;
    private HorizontalScrollView attachmentScroller;
    private LinearLayout attachmentRow;
    private boolean imeVisible;
    private boolean firstTranscriptRender = true;
    private String lastStatus = "";
    private boolean lastStatusError;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!BridgeAccessibilityService.ACTION_STATUS.equals(intent.getAction())) return;
            lastStatus = intent.getStringExtra(BridgeAccessibilityService.EXTRA_STATUS);
            if (lastStatus == null) lastStatus = "";
            lastStatusError = intent.getBooleanExtra(BridgeAccessibilityService.EXTRA_ERROR, false);
            refreshStatusUi();
            refreshTranscript();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new ConversationStore(this);
        draftAttachments.addAll(store.getDraftAttachments());

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);

        root = buildUi();
        setContentView(root);
        installSystemAndImeInsets(root);
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(BridgeAccessibilityService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(statusReceiver, filter);
    }

    @Override
    protected void onStop() {
        try { unregisterReceiver(statusReceiver); } catch (Exception ignored) {}
        super.onStop();
    }

    @Override
    protected void onPause() {
        if (input != null) store.setDraft(input.getText().toString());
        store.setDraftAttachments(draftAttachments);
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTranscript();
        refreshStatusUi();
        renderAttachments();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_ATTACHMENTS || resultCode != RESULT_OK || data == null) return;

        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount() && draftAttachments.size() < 5; i++) {
                addAttachment(data.getClipData().getItemAt(i).getUri(), flags);
            }
        } else if (data.getData() != null && draftAttachments.size() < 5) {
            addAttachment(data.getData(), flags);
        }
        store.setDraftAttachments(draftAttachments);
        renderAttachments();
    }

    private LinearLayout buildUi() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(12), dp(8), dp(12), dp(8));
        outer.setBackgroundColor(0xFF111315);

        LinearLayout topBar = horizontal();
        TextView title = text("AI Group Chat", 19, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        topBar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));

        bridgeChip = text("○ Bridge", 12, 0xFFFFD166);
        bridgeChip.setGravity(Gravity.CENTER);
        bridgeChip.setPadding(dp(10), 0, dp(10), 0);
        bridgeChip.setBackgroundColor(0xFF202428);
        bridgeChip.setOnClickListener(v -> {
            if (!BridgeAccessibilityService.isConnected()) {
                startActivity(BridgeAccessibilityService.accessibilitySettingsIntent());
            }
        });
        topBar.addView(bridgeChip, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34)));

        ImageButton menu = imageButton(com.aigroupchat.bridge.R.drawable.ic_more_vert, "More options", v -> showOverflow(v));
        topBar.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(40)));
        outer.addView(topBar, lpMatchWrap(0, 0, 0, dp(4)));

        runStrip = horizontal();
        runStrip.setPadding(dp(10), dp(6), dp(6), dp(6));
        runStrip.setBackgroundColor(0xFF1B2025);
        runText = text("", 12, 0xFFDCE3EA);
        runText.setMaxLines(2);
        runStrip.addView(runText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        stopButton = button("STOP", v -> {
            BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
            if (service != null) service.stopRelay();
        });
        stopButton.setTextSize(11f);
        stopButton.setBackgroundColor(0xFF8B1E2D);
        runStrip.addView(stopButton, new LinearLayout.LayoutParams(dp(72), dp(38)));
        runStrip.setVisibility(View.GONE);
        outer.addView(runStrip, lpMatchWrap(0, 0, 0, dp(4)));

        transcriptFrame = new FrameLayout(this);
        transcriptScroll = new ScrollView(this);
        transcriptScroll.setFillViewport(true);
        // M11.2: the transcript scroller must never take keyboard focus from the composer.
        transcriptScroll.setFocusable(false);
        transcriptScroll.setFocusableInTouchMode(false);
        transcript = text("", 15, 0xFFE8EAED);
        transcript.setTextIsSelectable(true);
        transcript.setMovementMethod(LinkMovementMethod.getInstance());
        transcript.setHighlightColor(0x334C8BF5);
        transcript.setPadding(dp(4), dp(4), dp(4), dp(18));
        transcriptScroll.addView(transcript, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        transcriptScroll.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> updateJumpLatestVisibility());
        transcriptFrame.addView(transcriptScroll, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        jumpLatestButton = imageButton(com.aigroupchat.bridge.R.drawable.ic_arrow_downward, "Jump to latest message", v -> scrollTranscriptToLatest(true));
        jumpLatestButton.setFocusable(false);
        jumpLatestButton.setFocusableInTouchMode(false);
        jumpLatestButton.setBackgroundResource(com.aigroupchat.bridge.R.drawable.bg_floating_button);
        jumpLatestButton.setElevation(dp(6));
        jumpLatestButton.setVisibility(View.GONE);
        FrameLayout.LayoutParams jumpLp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END | Gravity.BOTTOM);
        jumpLp.setMargins(dp(6), dp(6), dp(6), dp(8));
        transcriptFrame.addView(jumpLatestButton, jumpLp);

        outer.addView(transcriptFrame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        attachmentScroller = new HorizontalScrollView(this);
        attachmentScroller.setHorizontalScrollBarEnabled(false);
        attachmentRow = horizontal();
        attachmentScroller.addView(attachmentRow, new HorizontalScrollView.LayoutParams(
                HorizontalScrollView.LayoutParams.WRAP_CONTENT, HorizontalScrollView.LayoutParams.WRAP_CONTENT));
        attachmentScroller.setVisibility(View.GONE);
        outer.addView(attachmentScroller, lpMatchWrap(0, dp(2), 0, dp(4)));

        controlsPanel = horizontal();
        modeSpinner = spinner(new String[]{"ChatGPT", "Claude", "Both", "Collaborate", "Auto Collaborate"});
        modeSpinner.setSelection(MODE_AUTO);
        modeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { updateModeControls(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        controlsPanel.addView(modeSpinner, new LinearLayout.LayoutParams(0, dp(46), 1.25f));

        firstActor = spinner(new String[]{"ChatGPT first", "Claude first"});
        controlsPanel.addView(firstActor, new LinearLayout.LayoutParams(0, dp(46), 1f));

        detailSpinner = spinner(new String[]{"max 5 turns", "max 10 turns", "max 20 turns"});
        detailSpinner.setSelection(1);
        controlsPanel.addView(detailSpinner, new LinearLayout.LayoutParams(0, dp(46), 1f));
        outer.addView(controlsPanel, lpMatchWrap(0, dp(2), 0, dp(4)));

        LinearLayout composer = horizontal();
        Button attach = button("+", v -> chooseAttachments());
        attach.setTextSize(24f);
        composer.addView(attach, new LinearLayout.LayoutParams(dp(48), dp(48)));

        input = new EditText(this);
        input.setHint("Message ChatGPT and Claude…");
        input.setHintTextColor(0xFF8A949E);
        input.setTextColor(0xFFFFFFFF);
        input.setBackgroundColor(0xFF202428);
        input.setMinLines(1);
        input.setMaxLines(5);
        input.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        input.setHorizontallyScrolling(false);
        input.setVerticalScrollBarEnabled(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        input.setText(store.getDraft());
        input.setSelection(input.length());
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                store.setDraft(s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        inputLp.setMargins(dp(4), 0, dp(4), 0);
        composer.addView(input, inputLp);

        Button send = button("↑", v -> submitSelectedMode());
        send.setTextSize(22f);
        composer.addView(send, new LinearLayout.LayoutParams(dp(52), dp(48)));
        outer.addView(composer, lpMatchWrap(0, 0, 0, 0));

        refreshTranscript();
        renderAttachments();
        updateModeControls();
        return outer;
    }

    private void installSystemAndImeInsets(View rootView) {
        final int baseLeft = rootView.getPaddingLeft();
        final int baseTop = rootView.getPaddingTop();
        final int baseRight = rootView.getPaddingRight();
        final int baseBottom = rootView.getPaddingBottom();

        rootView.setOnApplyWindowInsetsListener((v, windowInsets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                boolean wasNearBottom = isTranscriptNearBottom();
                Insets bars = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets ime = windowInsets.getInsets(WindowInsets.Type.ime());
                boolean nowImeVisible = windowInsets.isVisible(WindowInsets.Type.ime()) && ime.bottom > bars.bottom;
                int bottom = Math.max(bars.bottom, ime.bottom);
                v.setPadding(baseLeft + bars.left, baseTop + bars.top, baseRight + bars.right, baseBottom + bottom);
                if (imeVisible != nowImeVisible) {
                    imeVisible = nowImeVisible;
                    controlsPanel.setVisibility(imeVisible ? View.GONE : View.VISIBLE);
                    if (wasNearBottom) {
                        // wasNearBottom was measured BEFORE this resize; the resize itself must not
                        // cancel the follow-scroll, so force it past the fire-time re-check.
                        forceNextAutoScroll = true;
                        scheduleAutoScroll(80L);
                    }
                    else transcriptScroll.postDelayed(this::updateJumpLatestVisibility, 80L);
                }
            } else {
                v.setPadding(baseLeft + windowInsets.getSystemWindowInsetLeft(),
                        baseTop + windowInsets.getSystemWindowInsetTop(),
                        baseRight + windowInsets.getSystemWindowInsetRight(),
                        baseBottom + windowInsets.getSystemWindowInsetBottom());
            }
            return windowInsets;
        });
        rootView.post(rootView::requestApplyInsets);
    }

    private void updateModeControls() {
        if (modeSpinner == null || firstActor == null || detailSpinner == null) return;
        int mode = modeSpinner.getSelectedItemPosition();
        boolean collab = mode == MODE_COLLAB || mode == MODE_AUTO;
        firstActor.setVisibility(collab ? View.VISIBLE : View.GONE);
        detailSpinner.setVisibility(collab ? View.VISIBLE : View.GONE);

        if (mode == MODE_COLLAB) {
            setSpinnerItems(detailSpinner, new String[]{"1 review round", "2 review rounds"}, 0);
        } else if (mode == MODE_AUTO) {
            setSpinnerItems(detailSpinner, new String[]{"max 5 turns", "max 10 turns", "max 20 turns"}, 1);
        }
    }

    private void submitSelectedMode() {
        String text = input.getText().toString().trim();
        if (text.isEmpty() && draftAttachments.isEmpty()) {
            toast("Type a message or attach a file first.");
            return;
        }
        if (text.isEmpty()) text = "Please inspect the attached file and respond to the shared task.";

        BridgeAccessibilityService service = readyService();
        if (service == null) return;
        RelayPlan.Actor first = selectedFirstActor();
        int mode = modeSpinner.getSelectedItemPosition();
        RelayPlan plan;
        List<AttachmentRecord> attachments = new ArrayList<>(draftAttachments);

        switch (mode) {
            case MODE_CHATGPT:
                plan = RelayPlan.build(text, RelayPlan.Mode.CHATGPT_ONLY, RelayPlan.Actor.CHATGPT, 1, attachments);
                break;
            case MODE_CLAUDE:
                plan = RelayPlan.build(text, RelayPlan.Mode.CLAUDE_ONLY, RelayPlan.Actor.CLAUDE, 1, attachments);
                break;
            case MODE_BOTH:
                plan = RelayPlan.build(text, RelayPlan.Mode.BOTH, first, 1, attachments);
                break;
            case MODE_COLLAB:
                plan = RelayPlan.build(text, RelayPlan.Mode.COLLABORATE, first,
                        detailSpinner.getSelectedItemPosition() + 1, attachments);
                break;
            case MODE_AUTO:
            default:
                int idx = Math.max(0, Math.min(AUTO_LIMITS.length - 1, detailSpinner.getSelectedItemPosition()));
                plan = RelayPlan.buildAuto(text, first, AUTO_LIMITS[idx], attachments);
                break;
        }
        startPlan(service, plan);
    }

    private void startPlan(BridgeAccessibilityService service, RelayPlan plan) {
        input.setText("");
        draftAttachments.clear();
        store.clearDraft();
        store.clearDraftAttachments();
        renderAttachments();
        service.startRelay(plan);
        refreshTranscript();
        refreshStatusUi();
    }

    private BridgeAccessibilityService readyService() {
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        if (service == null) {
            toast("Enable AI Group Chat Bridge in Accessibility settings first.");
            startActivity(BridgeAccessibilityService.accessibilitySettingsIntent());
            return null;
        }
        if (service.relayRunning()) {
            toast("A relay is already running. Use STOP first.");
            return null;
        }
        return service;
    }

    private RelayPlan.Actor selectedFirstActor() {
        return firstActor.getSelectedItemPosition() == 0 ? RelayPlan.Actor.CHATGPT : RelayPlan.Actor.CLAUDE;
    }

    private void chooseAttachments() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQUEST_ATTACHMENTS); }
        catch (Exception e) { toast("No file picker is available."); }
    }

    private void addAttachment(Uri uri, int flags) {
        if (uri == null) return;
        for (AttachmentRecord existing : draftAttachments) {
            if (existing.uriString.equals(uri.toString())) return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}

        String name = "Attachment";
        long size = 0L;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int nameCol = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeCol = c.getColumnIndex(OpenableColumns.SIZE);
                if (nameCol >= 0 && !c.isNull(nameCol)) name = c.getString(nameCol);
                if (sizeCol >= 0 && !c.isNull(sizeCol)) size = c.getLong(sizeCol);
            }
        } catch (Exception ignored) {}
        String mime = getContentResolver().getType(uri);
        draftAttachments.add(new AttachmentRecord(uri.toString(), name, mime, size));
    }

    private void renderAttachments() {
        if (attachmentRow == null || attachmentScroller == null) return;
        attachmentRow.removeAllViews();
        if (draftAttachments.isEmpty()) {
            attachmentScroller.setVisibility(View.GONE);
            return;
        }
        attachmentScroller.setVisibility(View.VISIBLE);
        for (int i = 0; i < draftAttachments.size(); i++) {
            final int index = i;
            AttachmentRecord a = draftAttachments.get(i);
            Button chip = button("📎 " + shorten(a.displayName, 26) + "  ×", v -> {
                if (index >= 0 && index < draftAttachments.size()) draftAttachments.remove(index);
                store.setDraftAttachments(draftAttachments);
                renderAttachments();
            });
            chip.setTextSize(11f);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38));
            p.setMargins(0, 0, dp(4), 0);
            attachmentRow.addView(chip, p);
        }
    }

    private String shorten(String s, int max) {
        if (s == null) return "Attachment";
        return s.length() <= max ? s : s.substring(0, Math.max(1, max - 1)) + "…";
    }

    private void showOverflow(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, 1, 0, "Enable / manage bridge");
        popup.getMenu().add(0, 2, 1, "Open ChatGPT");
        popup.getMenu().add(0, 3, 2, "Open Claude");

        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        boolean recoverable = service != null ? service.hasRecoverableRelay() : new RunStateStore(this).hasRecoverable();
        if (recoverable && (service == null || !service.relayRunning())) popup.getMenu().add(0, 4, 3, "Resume interrupted relay");
        if (recoverable && (service == null || !service.relayRunning())) popup.getMenu().add(0, 5, 4, "Discard saved relay");

        if (service != null && service.relayRunning()) popup.getMenu().add(0, 13, 6, "Re-check current provider reply");
        popup.getMenu().add(0, 11, 8, "Copy last message");
        popup.getMenu().add(0, 12, 9, "Copy whole transcript");
        popup.getMenu().add(0, 6, 10, "Refresh");
        popup.getMenu().add(0, 7, 11, "Clear transcript");
        popup.getMenu().add(0, 8, 20, "Copy ChatGPT UI map");
        popup.getMenu().add(0, 9, 21, "Copy Claude UI map");
        if (service == null || !service.relayRunning()) {
            popup.getMenu().add(0, 15, 22, "Set ChatGPT mapped thread title");
            popup.getMenu().add(0, 14, 23, "Reset provider thread guard");
        }
        popup.getMenu().add(0, 30, 45, "Engine Lab (P1-A, developer)");
        popup.getMenu().add(0, 40, 46, "Room database self-check (B1a)");
        popup.getMenu().add(0, 41, 44, "Room (B2.2A: live ChatGPT + Claude)");
        popup.getMenu().add(0, 10, 30, "About M11.7");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: startActivity(BridgeAccessibilityService.accessibilitySettingsIntent()); return true;
                case 2: openPackage("com.openai.chatgpt", "ChatGPT"); return true;
                case 3: openPackage("com.anthropic.claude", "Claude"); return true;
                case 4:
                    if (BridgeAccessibilityService.getInstance() == null) {
                        toast("Enable the bridge first, then choose Resume again.");
                        startActivity(BridgeAccessibilityService.accessibilitySettingsIntent());
                    } else BridgeAccessibilityService.getInstance().resumeRelay();
                    return true;
                case 5:
                    if (BridgeAccessibilityService.getInstance() != null) BridgeAccessibilityService.getInstance().discardRecoverableRelay();
                    else new RunStateStore(this).clear();
                    refreshStatusUi();
                    return true;
                case 6: refreshTranscript(); refreshStatusUi(); return true;
                case 7: clearTranscript(); return true;
                case 8: inspect(RelayPlan.Actor.CHATGPT); return true;
                case 9: inspect(RelayPlan.Actor.CLAUDE); return true;
                case 10: showAbout(); return true;
                case 11: copyLastMessage(); return true;
                case 12: copyWholeTranscript(); return true;
                case 13:
                    if (BridgeAccessibilityService.getInstance() != null) BridgeAccessibilityService.getInstance().checkCurrentReplyNow();
                    return true;
                case 14:
                    new ProviderThreadStore(this).clear();
                    toast("Provider thread guard reset. Open the intended existing ChatGPT/Claude conversations before the next relay.");
                    return true;
                case 15:
                    showChatGptThreadTitleDialog();
                    return true;
                case 30:
                    startActivity(new Intent(this, com.aigroupchat.bridge.engine.EngineLabActivity.class));
                    return true;
                case 41:
                    startActivity(new Intent(this, com.aigroupchat.bridge.room.ui.RoomActivity.class));
                    return true;
                case 40: {
                    final String report = com.aigroupchat.bridge.room.sqlite.RoomSelfCheck.run(this);
                    new android.app.AlertDialog.Builder(this)
                            .setTitle("Room database self-check")
                            .setMessage(report)
                            .setPositiveButton("Close", null)
                            .show();
                    return true;
                }
                default: return false;
            }
        });
        popup.show();
    }

    private void clearTranscript() {
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        if (service != null && service.relayRunning()) {
            toast("Stop the relay before clearing the transcript.");
            return;
        }
        store.clear();
        refreshTranscript();
    }

    private void inspect(RelayPlan.Actor actor) {
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        if (service == null) {
            toast("Enable the accessibility bridge first.");
            startActivity(BridgeAccessibilityService.accessibilitySettingsIntent());
            return;
        }
        toast("Diagnostic copy may include visible conversation text.");
        service.inspectApp(actor);
    }

    private void showChatGptThreadTitleDialog() {
        ProviderThreadStore threadStore = new ProviderThreadStore(this);
        EditText title = new EditText(this);
        title.setSingleLine(true);
        title.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        title.setHint("Exact ChatGPT history title");
        String current = threadStore.getTitle(RelayPlan.Actor.CHATGPT);
        if (current != null && !current.trim().isEmpty()) {
            title.setText(current);
            title.setSelection(title.length());
        }

        int pad = dp(22);
        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(pad, dp(8), pad, 0);
        holder.addView(title, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Set ChatGPT mapped thread")
                .setMessage("Enter the exact conversation title shown in ChatGPT's Menu/history. M11.7 will only open this one unique title automatically and will never probe other chats.")
                .setView(holder)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = title.getText() == null ? "" : title.getText().toString().trim();
            if (value.isEmpty()) {
                toast("Enter the exact ChatGPT conversation title.");
                return;
            }
            threadStore.setTitle(RelayPlan.Actor.CHATGPT, value);
            toast("Mapped ChatGPT thread title saved: " + value);
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("AI Group Chat M11.7")
                .setMessage("M11.7 removes M11.6's unsafe recent-chat probing. ChatGPT automatic restoration now uses only one explicitly mapped, unique history title; it never tries unrelated conversations and never clicks New chat. Current-turn anchors remain required for capture/re-copy recovery, while the mapped title is the deterministic locator for fresh sends. M11.4 long-Copy polling/re-copy and no-duplicate recovery remain intact. AI-generated file capture remains planned for M12 after this relay baseline is proven.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void refreshStatusUi() {
        if (bridgeChip == null || runStrip == null) return;
        BridgeAccessibilityService service = BridgeAccessibilityService.getInstance();
        boolean connected = service != null;
        boolean running = connected && service.relayRunning();
        bridgeChip.setText(connected ? "● Bridge" : "○ Bridge");
        bridgeChip.setTextColor(connected ? 0xFF7FD1AE : 0xFFFFD166);

        if (running) {
            runStrip.setVisibility(View.VISIBLE);
            runText.setText(lastStatus.isEmpty() ? "Relay running…" : lastStatus);
            runText.setTextColor(0xFFDCE3EA);
            stopButton.setVisibility(View.VISIBLE);
        } else if (lastStatusError && !lastStatus.isEmpty()) {
            runStrip.setVisibility(View.VISIBLE);
            runText.setText(lastStatus);
            runText.setTextColor(0xFFFFB4AB);
            stopButton.setVisibility(View.GONE);
        } else {
            runStrip.setVisibility(View.GONE);
        }
    }

    private void refreshTranscript() {
        if (transcript == null) return;
        final boolean wasFirstRender = firstTranscriptRender;
        boolean shouldFollow = firstTranscriptRender || isTranscriptNearBottom();
        List<Message> messages = store.all();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        DateFormat df = DateFormat.getTimeInstance(DateFormat.SHORT);
        for (Message m : messages) {
            if (m.participant == Message.Participant.SYSTEM) {
                int start = sb.length();
                sb.append("• ").append(m.text).append("  ").append(df.format(new Date(m.timestamp))).append("\n\n");
                int end = sb.length();
                sb.setSpan(new ForegroundColorSpan(0xFFAEB8C2), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.setSpan(new RelativeSizeSpan(0.84f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }
            int start = sb.length();
            sb.append(label(m.participant)).append("  ").append(df.format(new Date(m.timestamp))).append('\n');
            int end = sb.length();
            sb.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new ForegroundColorSpan(color(m.participant)), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new RelativeSizeSpan(0.86f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append(m.text).append('\n');

            final String copyText = m.text;
            int copyStart = sb.length();
            sb.append("Copy");
            int copyEnd = sb.length();
            sb.setSpan(new ClickableSpan() {
                @Override public void onClick(View widget) { copyTextToClipboard(copyText, "Message copied."); }
                @Override public void updateDrawState(TextPaint ds) {
                    ds.setColor(0xFF8AB4F8);
                    ds.setUnderlineText(false);
                    ds.setFakeBoldText(true);
                }
            }, copyStart, copyEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append("\n\n");
        }
        if (messages.isEmpty()) sb.append("Start a conversation below.");
        transcript.setText(sb);
        if (firstTranscriptRender) firstTranscriptRender = false;
        if (shouldFollow) {
            forceNextAutoScroll |= wasFirstRender; // first open always lands on the newest message
            scheduleAutoScroll(60L);
        } else transcriptScroll.postDelayed(this::updateJumpLatestVisibility, 60L);
    }

    private boolean isTranscriptNearBottom() {
        if (transcriptScroll == null || transcriptScroll.getChildCount() == 0) return true;
        View child = transcriptScroll.getChildAt(0);
        int remaining = child.getBottom() - (transcriptScroll.getHeight() + transcriptScroll.getScrollY());
        return remaining <= dp(120);
    }

    // M11.2: positional scrolling only. fullScroll(View.FOCUS_DOWN) performs a focus search and
    // requestFocus(), which stole focus from the composer whenever the IME opened.
    private boolean forceNextAutoScroll;
    private final Runnable autoScrollRunnable = () -> {
        // Re-check at fire time: if the user started reading upward during the delay, do nothing.
        if (forceNextAutoScroll || isTranscriptNearBottom()) scrollTranscriptToLatest(false);
        forceNextAutoScroll = false;
    };

    private void scheduleAutoScroll(long delayMs) {
        if (transcriptScroll == null) return;
        transcriptScroll.removeCallbacks(autoScrollRunnable); // one pending scroll at a time
        transcriptScroll.postDelayed(autoScrollRunnable, delayMs);
    }

    private void scrollTranscriptToLatest(boolean smooth) {
        if (transcriptScroll == null || transcriptScroll.getChildCount() == 0) return;
        transcriptScroll.post(() -> {
            View child = transcriptScroll.getChildAt(0);
            int range = child.getHeight() + transcriptScroll.getPaddingTop()
                    + transcriptScroll.getPaddingBottom() - transcriptScroll.getHeight();
            int targetY = Math.max(0, range);
            if (smooth) transcriptScroll.smoothScrollTo(0, targetY);
            else transcriptScroll.scrollTo(0, targetY);
            transcriptScroll.postDelayed(this::updateJumpLatestVisibility, smooth ? 350L : 40L);
        });
    }

    private void updateJumpLatestVisibility() {
        if (jumpLatestButton == null || transcriptScroll == null || transcriptScroll.getChildCount() == 0) return;
        View child = transcriptScroll.getChildAt(0);
        boolean canScroll = child.getHeight() > transcriptScroll.getHeight() + dp(8);
        jumpLatestButton.setVisibility(canScroll && !isTranscriptNearBottom() ? View.VISIBLE : View.GONE);
    }

    private void copyLastMessage() {
        List<Message> messages = store.all();
        for (int i = messages.size() - 1; i >= 0; i--) {
            Message m = messages.get(i);
            if (m.participant != Message.Participant.SYSTEM && m.text != null && !m.text.trim().isEmpty()) {
                copyTextToClipboard(m.text, "Last message copied.");
                return;
            }
        }
        toast("There is no message to copy yet.");
    }

    private void copyWholeTranscript() {
        List<Message> messages = store.all();
        if (messages.isEmpty()) {
            toast("The transcript is empty.");
            return;
        }
        StringBuilder out = new StringBuilder();
        for (Message m : messages) {
            if (out.length() > 0) out.append("\n\n");
            out.append(label(m.participant)).append(":\n").append(m.text);
        }
        copyTextToClipboard(out.toString(), "Transcript copied.");
    }

    private void copyTextToClipboard(String value, String toastText) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null) {
            toast("Clipboard is unavailable.");
            return;
        }
        cm.setPrimaryClip(ClipData.newPlainText("AI Group Chat", value == null ? "" : value));
        toast(toastText);
    }

    private String label(Message.Participant p) {
        switch (p) {
            case USER: return "You";
            case CHATGPT: return "ChatGPT";
            case CLAUDE: return "Claude";
            default: return "System";
        }
    }

    private int color(Message.Participant p) {
        switch (p) {
            case USER: return 0xFF7FD1AE;
            case CHATGPT: return 0xFF85B7FF;
            case CLAUDE: return 0xFFE8A87C;
            default: return 0xFFAEB8C2;
        }
    }

    private void openPackage(String packageName, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) { toast(name + " is not installed."); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    private void setSpinnerItems(Spinner spinner, String[] items, int selection) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        spinner.setAdapter(adapter);
        spinner.setSelection(Math.max(0, Math.min(items.length - 1, selection)));
    }

    private Spinner spinner(String[] items) {
        Spinner s = new Spinner(this);
        setSpinnerItems(s, items, 0);
        return s;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private ImageButton imageButton(int drawableRes, String description, View.OnClickListener listener) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawableRes);
        b.setContentDescription(description);
        b.setBackgroundColor(0x00000000);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        b.setOnClickListener(listener);
        return b;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setOnClickListener(listener);
        return b;
    }

    private TextView text(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
