package com.aigroupchat.bridge.engine;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Process-local, read-only content URIs used only by the embedded WebView file chooser. */
public final class ArtifactContentProvider extends ContentProvider {
    private static final Map<String, Entry> ENTRIES = new ConcurrentHashMap<>();

    private static final class Entry {
        final File file;
        final String name;
        final String mime;
        Entry(File file, String name, String mime) { this.file = file; this.name = name; this.mime = mime; }
    }

    public static final class Handle implements AutoCloseable {
        public final Uri uri;
        private final String token;
        private boolean closed;
        private Handle(Uri uri, String token) { this.uri = uri; this.token = token; }
        @Override public synchronized void close() {
            if (closed) return;
            closed = true;
            ENTRIES.remove(token);
        }
    }

    public static Handle expose(Context context, File file, String displayName, String mime) throws FileNotFoundException {
        if (file == null || !file.isFile()) throw new FileNotFoundException("artifact file is missing");
        String token = UUID.randomUUID().toString();
        String safeName = displayName == null || displayName.trim().isEmpty() ? "attachment" : displayName.replace('/', '_').replace('\\', '_');
        ENTRIES.put(token, new Entry(file, safeName, mime == null || mime.isEmpty() ? "application/octet-stream" : mime));
        Uri uri = new Uri.Builder().scheme("content").authority(context.getPackageName() + ".artifact-files")
                .appendPath("file").appendPath(token).appendPath(safeName).build();
        return new Handle(uri, token);
    }

    private Entry entry(Uri uri) {
        if (uri == null || uri.getPathSegments().size() < 2 || !"file".equals(uri.getPathSegments().get(0))) return null;
        return ENTRIES.get(uri.getPathSegments().get(1));
    }

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri uri) {
        Entry e = entry(uri);
        return e == null ? null : e.mime;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Entry e = entry(uri);
        if (e == null) return null;
        String[] cols = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor c = new MatrixCursor(cols, 1);
        MatrixCursor.RowBuilder row = c.newRow();
        for (String col : cols) {
            if (OpenableColumns.DISPLAY_NAME.equals(col)) row.add(e.name);
            else if (OpenableColumns.SIZE.equals(col)) row.add(e.file.length());
            else row.add(null);
        }
        return c;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("read only");
        Entry e = entry(uri);
        if (e == null || !e.file.isFile()) throw new FileNotFoundException("expired or missing artifact");
        return ParcelFileDescriptor.open(e.file, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("read only"); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("read only"); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("read only"); }
}
