package com.aigroupchat.bridge.engine;

import java.net.URI;
import java.util.Locale;

/**
 * Which addresses the app may ever fetch while capturing an AI's file. Everything is refused unless it is clearly safe: https only, no user info, no odd
 * ports, and only the provider's own host or an explicitly listed download host (exact match or a true subdomain, never a look-alike suffix).
 */
public final class CapturePolicy {
    /** A data: address is held in the page's memory; keep it bounded. */
    public static final int MAX_DATA_URL_CHARS = 36_000_000;

    private CapturePolicy() {}

    /** The lower-case host of a plain https URL, or null (wrong scheme, user info, non-443 port, bad syntax, absurd length). */
    public static String httpsHost(String url) {
        if (url == null || url.length() > 4000) return null;
        try {
            URI u = new URI(url);
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getRawUserInfo() != null || u.getHost() == null || u.getHost().isEmpty()) return null;
            if (u.getPort() != -1 && u.getPort() != 443) return null;
            return u.getHost().toLowerCase(Locale.ROOT);
        } catch (Exception e) {
            return null;
        }
    }

    /** Exact host, or a subdomain separated by a dot ("a.example.com" for "example.com"); "evilexample.com" never matches. */
    public static boolean hostAllowed(String host, String[] allowed) {
        if (host == null || allowed == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        for (String a : allowed) {
            if (a == null || a.isEmpty()) continue;
            String d = a.toLowerCase(Locale.ROOT);
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    /** May the PAGE itself fetch this (with the page's own login)? blob: only of this page's origin, data: only base64 and bounded, https only on the page's host or an allowed host. */
    public static boolean pageMayFetch(String url, String pageHost, String[] allowedHosts) {
        if (url == null) return false;
        if (url.startsWith("data:")) return url.length() <= MAX_DATA_URL_CHARS && url.contains(";base64,");
        String page = pageHost == null ? null : pageHost.toLowerCase(Locale.ROOT);
        if (url.startsWith("blob:")) {
            String h = httpsHost(url.substring(5));
            return h != null && h.equals(page);
        }
        String h = httpsHost(url);
        return h != null && (h.equals(page) || hostAllowed(h, allowedHosts));
    }

    /** May the APP download this itself (no page involved)? https on an allowed host only. */
    public static boolean nativeMayDownload(String url, String[] allowedHosts) {
        String h = httpsHost(url);
        return h != null && hostAllowed(h, allowedHosts);
    }
}
