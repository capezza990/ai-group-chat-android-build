package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.ArtifactStorage;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Base64;

/**
 * Assembles a file that the APP pulls from the page chunk by chunk (base64, in order) into a private temp file. Strict on purpose: chunks must arrive in
 * sequence, must be valid base64, must never exceed the size cap, and the total must equal the size the page announced. Nothing is kept on failure.
 */
public final class ChunkedReceiver implements Closeable {
    private final File file;
    private final OutputStream out;
    private final long maxBytes;
    private long size;
    private int nextSeq;
    private boolean finished, closed;

    public ChunkedReceiver(File dir, long maxBytes) throws IOException {
        this.maxBytes = maxBytes;
        this.file = File.createTempFile("cap-pull-", ".part", dir);
        this.out = new FileOutputStream(file);
    }

    public void append(int seq, String base64) throws IOException {
        if (finished || closed) throw new IOException("the transfer is already over");
        if (seq != nextSeq) throw new IOException("chunk out of order: expected " + nextSeq + " but got " + seq);
        if (base64 == null) throw new IOException("empty chunk");
        final byte[] bytes;
        try { bytes = Base64.getDecoder().decode(base64); }
        catch (IllegalArgumentException e) { throw new IOException("a chunk is not valid base64"); }
        if (size + bytes.length > maxBytes) throw new ArtifactStorage.TooLargeException(maxBytes);
        out.write(bytes);
        size += bytes.length;
        nextSeq++;
    }

    public long size() { return size; }

    /** Completes the transfer: the received size must equal what the page announced. The caller then owns (and must delete) the file. */
    public File finish(long announcedSize) throws IOException {
        if (finished || closed) throw new IOException("the transfer is already over");
        out.flush();
        out.close();
        if (size != announcedSize) throw new IOException("the file is incomplete: expected " + announcedSize + " bytes but received " + size);
        finished = true;
        return file;
    }

    /** Deletes the temp file unless finish() handed it over. */
    @Override public void close() {
        if (closed) return;
        closed = true;
        try { out.close(); } catch (IOException ignored) { }
        if (!finished) file.delete();
    }

    /** Opens a finished temp file; closing the stream deletes it. */
    public static InputStream openAndDelete(File f) throws IOException {
        return new FileInputStream(f) {
            @Override public void close() throws IOException {
                try { super.close(); } finally { f.delete(); }
            }
        };
    }
}
