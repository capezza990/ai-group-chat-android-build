package com.aigroupchat.bridge.engine;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Fetching ONE file an AI produced, from the provider page the AI answered in. A pure state machine driven through {@link Driver}, so the whole flow is
 * testable off-device. Everything runs on one (main) thread except the optional native download.
 *
 * <p>The app PULLS: it asks the page for the offers, then (link offers) has the page fetch the file with its own login and reads the bytes back chunk by
 * chunk, or (button offers) clicks the offer and waits for the page's download. Bytes are never pushed by the page. Anything unexpected ends the flow with a
 * plain-language reason; nothing is guessed. A cancelled flow stays silent (the caller already knows).
 */
public final class FileCaptureFlow {
    public interface Done<T> { void done(T value); }

    public interface DownloadSink { void onDownload(String url, String userAgent, String mime, long length); }

    public interface Driver {
        /** evaluateJavascript with the result decoded to a plain string (null when the page cannot answer). */
        void eval(String expression, Done<String> cb);
        void post(Runnable r, long delayMs);
        void background(Runnable r);
        long now();
        /** The conversation id the page is physically on right now (null when not on a conversation). */
        String conversationId();
        String pageHost();
        String cookieFor(String url);
        /** While a sink is armed the page's downloads are reported to it; with null every download is ignored. */
        void armDownloads(DownloadSink sink);
    }

    public interface Listener {
        void onFile(File file, String mime);
        void onFailed(String reason);
    }

    public static final class Request {
        public String conversationId = "", displayName = "", captureId = "cap";
        /** The provider's id of the exact reply that produced the file ("" when the page gave none: then only the newest message is considered). */
        public String replyRef = "";
        public long maxBytes = 25L * 1024 * 1024, timeoutMs = 90_000L;
        public File tmpDir;
        public String[] downloadHosts = new String[0];
        public String userAgent = "";
    }

    private static final long POLL_MS = 250L, CLICK_POLL_MS = 200L;
    private enum Route { PAGE, NATIVE, REFUSED }

    private final Driver d;
    private final Request r;
    private final Listener l;
    private boolean started, ended, pageMayHoldCapture;
    private long deadline;
    private FileOffer offer;
    private volatile String downloadUrl, downloadAgent, downloadMime;
    private ChunkedReceiver receiver;

    public FileCaptureFlow(Driver d, Request r, Listener l) { this.d = d; this.r = r; this.l = l; }

    public void start() {
        if (started || ended) return;
        started = true;
        deadline = d.now() + r.timeoutMs;
        d.post(() -> { if (!ended) fail("the provider page did not deliver the file in time"); }, r.timeoutMs + 500L);
        if (r.displayName == null || r.displayName.isEmpty()) { fail("there is no file name to look for"); return; }
        String conv = d.conversationId();
        if (conv == null || !conv.equals(r.conversationId)) { fail("the provider page is not on the conversation this file came from; open that conversation first"); return; }
        d.eval("window.__agc.fileOffers()", this::onOffers);
    }

    /** Silent: no listener call. Frees whatever the page holds and any partial file. */
    public void cancel() {
        if (ended) return;
        ended = true;
        cleanup();
    }

    // ------------------------------------------------------------------------------------------------------- offers

    private void onOffers(String json) {
        if (ended) return;
        if (json == null) { fail("the provider page did not answer"); return; }
        FileOfferMatcher.Result m = FileOfferMatcher.match(r.displayName, FileOffer.parseList(json), r.replyRef == null ? "" : r.replyRef);
        if (m.outcome != FileOfferMatcher.Outcome.FOUND) { fail(m.reason); return; }
        offer = m.offer;
        if (offer.mayClick()) { click(); return; }
        if (!offer.fetchable()) { fail("that file's link is not one the app will open"); return; }   // never "clicked just because it cannot be fetched"
        Route route = route(offer.href);
        if (route == Route.REFUSED) { fail("that file's address is not one the app may fetch"); return; }
        if (route == Route.NATIVE) { nativeDownload(offer.href, r.userAgent, offer.mime); return; }
        pageCapture("window.__agc.captureBegin(" + js(r.captureId) + "," + fingerprint(offer) + "," + r.maxBytes + ")");
    }

    private Route route(String url) {
        if (url == null) return Route.REFUSED;
        if (url.startsWith("blob:") || url.startsWith("data:")) return CapturePolicy.pageMayFetch(url, d.pageHost(), r.downloadHosts) ? Route.PAGE : Route.REFUSED;
        String h = CapturePolicy.httpsHost(url);
        if (h == null) return Route.REFUSED;
        String page = d.pageHost() == null ? null : d.pageHost().toLowerCase(Locale.ROOT);
        if (h.equals(page)) return Route.PAGE;
        return CapturePolicy.nativeMayDownload(url, r.downloadHosts) ? Route.NATIVE : Route.REFUSED;
    }

    // ------------------------------------------------------------------------------------------ click, then the download

    private void click() {
        d.armDownloads((url, agent, mime, length) -> { if (downloadUrl == null) { downloadAgent = agent; downloadMime = mime; downloadUrl = url == null ? "" : url; } });
        d.eval("window.__agc.clickOffer(" + fingerprint(offer) + ")", res -> {
            if (ended) return;
            Map<String, Object> o = res == null ? null : MiniJson.parseObject(res);
            if (o == null || !Boolean.TRUE.equals(o.get("ok"))) { fail("the file could not be opened on the provider page (" + (o == null ? "no answer" : String.valueOf(o.get("error"))) + ")"); return; }
            awaitDownload();
        });
    }

    private void awaitDownload() {
        if (ended) return;
        String url = downloadUrl;
        if (url != null) { onDownloadUrl(url); return; }
        if (d.now() > deadline) { fail("the provider did not start a download for that file"); return; }
        d.post(this::awaitDownload, CLICK_POLL_MS);
    }

    private void onDownloadUrl(String url) {
        d.armDownloads(null);
        Route route = route(url);
        if (route == Route.REFUSED) { fail("the provider offered that download from an address the app may not fetch"); return; }
        if (route == Route.NATIVE) { nativeDownload(url, downloadAgent == null || downloadAgent.isEmpty() ? r.userAgent : downloadAgent, downloadMime); return; }
        pageCapture("window.__agc.captureUrl(" + js(r.captureId) + "," + js(url) + "," + r.maxBytes + ")");
    }

    // -------------------------------------------------------------------------------------- the app downloads it itself

    private void nativeDownload(String url, String agent, String hintMime) {
        final NativeDownloader.Options o = new NativeDownloader.Options();
        o.allowedHosts = r.downloadHosts; o.userAgent = agent == null ? "" : agent; o.cookies = d::cookieFor; o.maxBytes = r.maxBytes; o.tmpDir = r.tmpDir;
        o.timeoutMs = (int) Math.max(5_000L, Math.min(30_000L, deadline - d.now()));
        d.background(() -> {
            NativeDownloader.Download dl = null;
            String why = null;
            try { dl = NativeDownloader.fetch(url, o); } catch (IOException e) { why = e.getMessage() == null ? "the download failed" : e.getMessage(); }
            final NativeDownloader.Download got = dl;
            final String error = why;
            d.post(() -> {
                if (ended) { if (got != null) got.file.delete(); return; }
                if (got == null) { fail(error); return; }
                succeed(got.file, got.mime.isEmpty() && hintMime != null ? hintMime : got.mime);
            }, 0L);
        });
    }

    // ------------------------------------------------------------------------ the page fetches it, the app pulls the bytes

    private void pageCapture(String beginExpression) {
        pageMayHoldCapture = true;
        d.eval(beginExpression, res -> {
            if (ended) return;
            Map<String, Object> o = res == null ? null : MiniJson.parseObject(res);
            if (o == null || !Boolean.TRUE.equals(o.get("ok"))) { fail("the provider page refused to hand over the file (" + (o == null ? "no answer" : String.valueOf(o.get("error"))) + ")"); return; }
            pollStatus();
        });
    }

    private void pollStatus() {
        if (ended) return;
        if (d.now() > deadline) { fail("the provider page did not deliver the file in time"); return; }
        d.eval("window.__agc.captureStatus(" + js(r.captureId) + ")", res -> {
            if (ended) return;
            Map<String, Object> o = res == null ? null : MiniJson.parseObject(res);
            if (o == null) { fail("the provider page did not answer"); return; }
            String state = String.valueOf(o.get("state"));
            if ("pending".equals(state)) { d.post(this::pollStatus, POLL_MS); return; }
            if ("failed".equals(state)) { fail("the provider page could not fetch the file (" + o.get("error") + ")"); return; }
            if (!"ready".equals(state) || !(o.get("size") instanceof Long) || !(o.get("chunks") instanceof Long)) { fail("the provider page lost the file"); return; }
            long size = (Long) o.get("size"), chunks = (Long) o.get("chunks");
            if (size < 0 || size > r.maxBytes) { fail("the file is larger than the allowed size"); return; }
            String mime = o.get("mime") instanceof String ? (String) o.get("mime") : "";
            try { receiver = new ChunkedReceiver(r.tmpDir, r.maxBytes); }
            catch (IOException e) { fail("the app could not prepare storage for the file"); return; }
            pull(0, chunks, size, mime.isEmpty() && offer != null ? offer.mime : mime);
        });
    }

    private void pull(long n, long total, long size, String mime) {
        if (ended) return;
        if (d.now() > deadline) { fail("the provider page did not deliver the file in time"); return; }
        if (n >= total) {
            try {
                File f = receiver.finish(size);
                receiver = null;
                succeed(f, mime);
            } catch (IOException e) { fail(e.getMessage() == null ? "the file was incomplete" : e.getMessage()); }
            return;
        }
        d.eval("window.__agc.captureChunk(" + js(r.captureId) + "," + n + ")", s -> {
            if (ended) return;
            if (s == null || s.startsWith("!") || s.isEmpty()) { fail("the provider page stopped handing over the file"); return; }
            try { receiver.append((int) n, s); }
            catch (IOException e) { fail(e instanceof com.aigroupchat.bridge.room.ArtifactStorage.TooLargeException ? "the file is larger than the allowed size" : "the file arrived damaged"); return; }
            pull(n + 1, total, size, mime);
        });
    }

    // --------------------------------------------------------------------------------------------------------- the end

    private void succeed(File f, String mime) {
        if (ended) { f.delete(); return; }
        ended = true;
        cleanup();
        l.onFile(f, mime == null ? "" : mime);
    }

    private void fail(String reason) {
        if (ended) return;
        ended = true;
        cleanup();
        l.onFailed(reason == null || reason.isEmpty() ? "the file could not be fetched" : reason);
    }

    private void cleanup() {
        d.armDownloads(null);
        if (receiver != null) { receiver.close(); receiver = null; }
        if (pageMayHoldCapture) { pageMayHoldCapture = false; d.eval("window.__agc.captureEnd(" + js(r.captureId) + ")", x -> { }); }
    }

    /**
     * The selected offer, described completely. The page re-scans before it acts and refuses unless the offer at that place is STILL exactly this one
     * (same index, name, kind, address, position among the messages and reply id): otherwise a list that changed between the two scans could make it fetch or
     * click a different file, or fetch an address the app never approved.
     */
    static String fingerprint(FileOffer o) {
        return "{\"index\":" + o.index + ",\"name\":" + js(o.name) + ",\"kind\":\"" + (o.kind == FileOffer.Kind.LINK ? "link" : "button") + "\",\"href\":" + js(o.href)
                + ",\"fromEnd\":" + o.fromEnd + ",\"msgId\":" + js(o.msgId) + "}";
    }

    /** A JavaScript string literal for arbitrary text (quotes, backslashes, line breaks, control characters and the two Unicode line separators are escaped). */
    static String js(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 0x20 || c == '\u2028' || c == '\u2029' || c == '<' || c == '>') b.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
            else b.append(c);
        }
        return b.append('"').toString();
    }

    /** Public for the off-device tests. */
    public static String jsLiteral(String s) { return js(s); }

    /** Convenience for callers that only have offers: lists the file names that could be captured. */
    public static List<FileOffer> offersFrom(String json) { return FileOffer.parseList(json); }
}
