package com.aigroupchat.bridge.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * One file an AI offers in a reply, as the page script saw it: a link or a button in an assistant message. Read-only description; nothing here
 * touches the page. {@code fromEnd} is 0 for the NEWEST assistant message, {@code index} identifies the element within one scan.
 */
public final class FileOffer {
    public enum Kind { LINK, BUTTON }

    public static final int MAX_OFFERS = 20, MAX_NAME = 300, MAX_HREF = 4000, MAX_MIME = 100, MAX_MSG_ID = 200;

    /** msgId: the page's stable id of the assistant message that offers the file (the same id the room records as the reply's provider id); empty when the page exposes none. */
    public final String name, href, mime, msgId;
    public final Kind kind;
    public final int index, fromEnd;

    public FileOffer(String name, Kind kind, String href, int index, int fromEnd, String mime) { this(name, kind, href, index, fromEnd, mime, ""); }

    public FileOffer(String name, Kind kind, String href, int index, int fromEnd, String mime, String msgId) {
        this.name = name; this.kind = kind; this.href = href == null ? "" : href; this.index = index; this.fromEnd = fromEnd; this.mime = mime == null ? "" : mime;
        this.msgId = msgId == null ? "" : msgId;
    }

    /**
     * Only a real BUTTON, or the provider's own sandbox: pseudo-link, may ever be clicked. "The address cannot be fetched" does NOT mean "safe to click":
     * a link with a javascript:, file:, plain http:, empty or unknown address is refused, never clicked.
     */
    public boolean mayClick() { return kind == Kind.BUTTON || (kind == Kind.LINK && href.regionMatches(true, 0, "sandbox:", 0, 8)); }

    /** A link address the capture may consider fetching (CapturePolicy still decides whether it is allowed). */
    public boolean fetchable() { return kind == Kind.LINK && (href.startsWith("https://") || href.startsWith("blob:") || href.startsWith("data:")); }

    /** Parses the page's answer. Invalid entries are skipped (never repaired); a text that is not the expected array yields an empty list. */
    public static List<FileOffer> parseList(String json) {
        List<Map<String, Object>> raw = MiniJson.parseObjectArray(json);
        List<FileOffer> out = new ArrayList<>();
        if (raw == null) return out;
        for (Map<String, Object> m : raw) {
            if (out.size() >= MAX_OFFERS) break;
            Object n = m.get("name"), k = m.get("kind"), ix = m.get("index"), fe = m.get("fromEnd"), h = m.get("href"), mt = m.get("mime"), mi = m.get("msgId");
            if (!(n instanceof String) || ((String) n).trim().isEmpty() || ((String) n).length() > MAX_NAME) continue;
            Kind kind = "link".equals(k) ? Kind.LINK : "button".equals(k) ? Kind.BUTTON : null;
            if (kind == null || !(ix instanceof Long) || (Long) ix < 0 || (Long) ix > 100000 || !(fe instanceof Long) || (Long) fe < 0 || (Long) fe > 100000) continue;
            if (h != null && (!(h instanceof String) || ((String) h).length() > MAX_HREF)) continue;
            if (mt != null && (!(mt instanceof String) || ((String) mt).length() > MAX_MIME)) continue;
            if (mi != null && (!(mi instanceof String) || ((String) mi).length() > MAX_MSG_ID)) continue;
            out.add(new FileOffer((String) n, kind, (String) h, ((Long) ix).intValue(), ((Long) fe).intValue(), (String) mt, (String) mi));
        }
        return out;
    }
}
