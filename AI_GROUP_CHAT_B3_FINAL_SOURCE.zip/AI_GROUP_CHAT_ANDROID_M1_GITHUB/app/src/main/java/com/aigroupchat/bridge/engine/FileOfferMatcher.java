package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.ArtifactNames;

import java.util.ArrayList;
import java.util.List;

/**
 * Decides which offer on the page IS the artifact we want to capture. The artifact only knows its CLEANED display name, so the page's raw names are
 * cleaned the same way. Wrong-file safety first: if the answer is not unique it is refused (never guessed), because capturing the wrong version of a
 * file would silently hand another AI the wrong bytes.
 *
 * <p>With a {@code replyRef} (the provider's id of the exact assistant reply that produced the artifact, recorded by the room) ONLY that reply's offers
 * count, and the file name is just the identifier inside it: a newer, different file of the same name can never be picked, not even on a later retry.
 * Without one (the page exposes no ids) the newest message that offers the name wins; that is only acceptable for the automatic first capture.
 */
public final class FileOfferMatcher {
    public enum Outcome { FOUND, NOT_FOUND, AMBIGUOUS }

    public static final class Result {
        public final Outcome outcome;
        public final FileOffer offer;
        public final String reason;
        private Result(Outcome o, FileOffer f, String r) { outcome = o; offer = f; reason = r; }
    }

    public static final int MAX_REPLY_FILES = 10;

    private FileOfferMatcher() {}

    public static Result match(String artifactDisplayName, List<FileOffer> offers) { return match(artifactDisplayName, offers, ""); }

    public static Result match(String artifactDisplayName, List<FileOffer> offers, String replyRef) {
        if (artifactDisplayName == null || offers == null) return new Result(Outcome.NOT_FOUND, null, "nothing to look for");
        final boolean exact = replyRef != null && !replyRef.isEmpty();
        boolean replyPresent = false;
        int newest = Integer.MAX_VALUE;
        List<FileOffer> same = new ArrayList<>();
        for (FileOffer o : offers) {
            if (exact) {
                if (!replyRef.equals(o.msgId)) continue;
                replyPresent = true;
            }
            if (!artifactDisplayName.equals(ArtifactNames.clean(o.name))) continue;
            same.add(o);
            if (o.fromEnd < newest) newest = o.fromEnd;
        }
        if (exact && !replyPresent) return new Result(Outcome.NOT_FOUND, null, "the reply that offered \"" + artifactDisplayName + "\" is no longer on the page");
        if (same.isEmpty()) return new Result(Outcome.NOT_FOUND, null, "no file called \"" + artifactDisplayName + "\" is offered " + (exact ? "in that reply" : "on the page"));
        List<FileOffer> inScope = new ArrayList<>();
        for (FileOffer o : same) {
            if (!exact && o.fromEnd != newest) continue;
            boolean duplicate = false;   // the same file shown twice (a link and a button with the same address) is one file
            for (FileOffer seen : inScope) if (!o.href.isEmpty() && o.href.equals(seen.href)) duplicate = true;
            if (!duplicate) inScope.add(o);
        }
        if (inScope.size() > 1) return new Result(Outcome.AMBIGUOUS, null, "more than one file called \"" + artifactDisplayName + "\" is offered in the same message");
        return new Result(Outcome.FOUND, inScope.get(0), "");
    }

    public static List<FileOffer> replyOffers(List<FileOffer> offers) { return replyOffers(offers, ""); }

    /**
     * The files a reply should turn into artifacts: only offers of THIS reply (the message with the provider's reply id when the page gave one, otherwise
     * the newest message), each file once, and only those the capture will later be able to find with the SAME rule (a name that would be ambiguous is not
     * promised at all). At most {@link #MAX_REPLY_FILES}.
     */
    public static List<FileOffer> replyOffers(List<FileOffer> offers, String providerAsstMsgId) {
        List<FileOffer> out = new ArrayList<>();
        if (offers == null) return out;
        final boolean exact = providerAsstMsgId != null && !providerAsstMsgId.isEmpty();
        for (FileOffer o : offers) {
            if (out.size() >= MAX_REPLY_FILES) break;
            if (exact ? !providerAsstMsgId.equals(o.msgId) : o.fromEnd != 0) continue;
            Result r = match(ArtifactNames.clean(o.name), offers, exact ? providerAsstMsgId : "");
            if (r.outcome == Outcome.FOUND && r.offer == o) out.add(o);
        }
        return out;
    }
}
