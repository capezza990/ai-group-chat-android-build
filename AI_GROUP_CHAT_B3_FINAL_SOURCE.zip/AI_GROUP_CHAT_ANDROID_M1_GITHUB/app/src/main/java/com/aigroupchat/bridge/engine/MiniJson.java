package com.aigroupchat.bridge.engine;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A tiny STRICT JSON reader for the flat shapes the page script returns (one object, or an array of objects, whose values are strings, integers,
 * booleans or null). Anything else - nesting, fractions, duplicate keys, control characters, trailing text, oversize input - makes the whole text
 * "not valid" (null). It exists because org.json is only a stub in the off-device tests, and because untrusted page output must be parsed fail-closed.
 */
public final class MiniJson {
    public static final int MAX_CHARS = 1_000_000, MAX_ITEMS = 200, MAX_KEYS = 40;
    private static final long MAX_INT = 9_007_199_254_740_991L; // 2^53 - 1: exactly representable in the page's numbers

    private static final class Bad extends RuntimeException { private static final long serialVersionUID = 1L; Bad() { super(null, null, false, false); } }

    private final String s;
    private int i;

    private MiniJson(String s) { this.s = s; }

    /** One flat object, or null when the text is not exactly that. */
    public static Map<String, Object> parseObject(String text) {
        if (text == null || text.length() > MAX_CHARS) return null;
        try {
            MiniJson p = new MiniJson(text);
            p.ws();
            Map<String, Object> o = p.object();
            p.ws();
            if (p.i != text.length()) return null;
            return o;
        } catch (Bad e) { return null; }
    }

    /** An array of flat objects, or null when the text is not exactly that. */
    public static List<Map<String, Object>> parseObjectArray(String text) {
        if (text == null || text.length() > MAX_CHARS) return null;
        try {
            MiniJson p = new MiniJson(text);
            p.ws();
            p.expect('[');
            List<Map<String, Object>> out = new ArrayList<>();
            p.ws();
            if (p.peek() == ']') { p.i++; }
            else {
                while (true) {
                    p.ws();
                    out.add(p.object());
                    if (out.size() > MAX_ITEMS) return null;
                    p.ws();
                    char c = p.next();
                    if (c == ']') break;
                    if (c != ',') return null;
                }
            }
            p.ws();
            if (p.i != text.length()) return null;
            return out;
        } catch (Bad e) { return null; }
    }

    private char peek() { if (i >= s.length()) throw new Bad(); return s.charAt(i); }
    private char next() { char c = peek(); i++; return c; }
    private void expect(char c) { if (next() != c) throw new Bad(); }
    private void ws() { while (i < s.length()) { char c = s.charAt(i); if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++; else break; } }

    private Map<String, Object> object() {
        expect('{');
        Map<String, Object> o = new LinkedHashMap<>();
        ws();
        if (peek() == '}') { i++; return o; }
        while (true) {
            ws();
            String k = string();
            ws();
            expect(':');
            ws();
            Object v = value();
            if (o.containsKey(k) || o.size() >= MAX_KEYS) throw new Bad();
            o.put(k, v);
            ws();
            char c = next();
            if (c == '}') return o;
            if (c != ',') throw new Bad();
        }
    }

    private Object value() {
        char c = peek();
        if (c == '"') return string();
        if (c == 't') { literal("true"); return Boolean.TRUE; }
        if (c == 'f') { literal("false"); return Boolean.FALSE; }
        if (c == 'n') { literal("null"); return null; }
        if (c == '-' || (c >= '0' && c <= '9')) return integer();
        throw new Bad(); // nested objects/arrays are not part of the shapes we accept
    }

    private void literal(String word) { for (int k = 0; k < word.length(); k++) if (next() != word.charAt(k)) throw new Bad(); }

    private Long integer() {
        int start = i;
        if (peek() == '-') i++;
        int digits = i;
        while (i < s.length() && s.charAt(i) >= '0' && s.charAt(i) <= '9') i++;
        int n = i - digits;
        if (n == 0 || n > 16 || (n > 1 && s.charAt(digits) == '0')) throw new Bad();
        if (i < s.length() && (s.charAt(i) == '.' || s.charAt(i) == 'e' || s.charAt(i) == 'E')) throw new Bad(); // no fractions
        long v = Long.parseLong(s.substring(start, i));
        if (v > MAX_INT || v < -MAX_INT) throw new Bad();
        return v;
    }

    private String string() {
        expect('"');
        StringBuilder b = new StringBuilder();
        while (true) {
            char c = next();
            if (c == '"') return b.toString();
            if (c < 0x20) throw new Bad();
            if (c != '\\') { b.append(c); continue; }
            char e = next();
            switch (e) {
                case '"': b.append('"'); break;
                case '\\': b.append('\\'); break;
                case '/': b.append('/'); break;
                case 'b': b.append('\b'); break;
                case 'f': b.append('\f'); break;
                case 'n': b.append('\n'); break;
                case 'r': b.append('\r'); break;
                case 't': b.append('\t'); break;
                case 'u': {
                    int v = 0;
                    for (int k = 0; k < 4; k++) {
                        int d = Character.digit(next(), 16);
                        if (d < 0) throw new Bad();
                        v = v * 16 + d;
                    }
                    b.append((char) v);
                    break;
                }
                default: throw new Bad();
            }
            if (b.length() > MAX_CHARS) throw new Bad();
        }
    }
}
