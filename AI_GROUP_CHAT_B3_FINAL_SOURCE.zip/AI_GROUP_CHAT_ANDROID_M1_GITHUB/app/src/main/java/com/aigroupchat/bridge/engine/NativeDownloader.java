package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.ArtifactStorage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Locale;

/**
 * Downloads a file the page pointed at when the page itself cannot fetch it (for example a signed address on another host). Every address, including
 * every redirect hop, must pass {@link CapturePolicy}; the size is capped while streaming; nothing is kept on failure.
 */
public final class NativeDownloader {
    public interface CookieSource { String cookieFor(String url); }

    public static final class Options {
        public String[] allowedHosts = new String[0];
        public String userAgent = "";
        public CookieSource cookies = u -> null;
        public long maxBytes = 25L * 1024 * 1024;
        public int timeoutMs = 30_000, maxRedirects = 3;
        public File tmpDir;
        /** Off-device tests only: also allow plain http on the local machine. Never set in the app. */
        public boolean allowLocalHttpForTests;
    }

    public static final class Download {
        public final File file;
        public final long size;
        public final String mime;
        Download(File f, long s, String m) { file = f; size = s; mime = m; }
    }

    private NativeDownloader() {}

    private static boolean allowed(String url, Options o) {
        if (CapturePolicy.nativeMayDownload(url, o.allowedHosts)) return true;
        if (!o.allowLocalHttpForTests) return false;
        try {
            URI u = new URI(url);
            return "http".equalsIgnoreCase(u.getScheme()) && u.getRawUserInfo() == null && u.getHost() != null
                    && ("127.0.0.1".equals(u.getHost()) || "localhost".equalsIgnoreCase(u.getHost()));
        } catch (Exception e) {
            return false;
        }
    }

    private static URL toUrl(String s) throws IOException {
        try { return URI.create(s).toURL(); } catch (IllegalArgumentException e) { throw new IOException("not a valid address"); }
    }

    private static String resolve(String base, String location) throws IOException {
        try { return URI.create(base).resolve(location).toString(); } catch (IllegalArgumentException e) { throw new IOException("not a valid redirect address"); }
    }

    /**
     * Copies {@code in} into {@code target} with a size cap and a no-progress guard, closing BOTH streams. It only reports success after both closed cleanly:
     * if anything fails, including a close() that throws, the target file is deleted. Returns the number of bytes written.
     */
    public static long saveStream(InputStream in, File target, long maxBytes) throws IOException {
        boolean ok = false;
        long size = 0;
        try {
            try (InputStream input = in; OutputStream out = new FileOutputStream(target)) {
                byte[] buf = new byte[16 * 1024];
                int n, empty = 0;
                while ((n = input.read(buf)) != -1) {
                    if (n == 0) { if (++empty > 1000) throw new IOException("the download is not making progress"); continue; }
                    empty = 0;
                    size += n;
                    if (size > maxBytes) throw new ArtifactStorage.TooLargeException(maxBytes);
                    out.write(buf, 0, n);
                }
            }
            ok = true;   // only here: both resources are closed without error
            return size;
        } finally {
            if (!ok) target.delete();
        }
    }

    public static Download fetch(String url, Options o) throws IOException {
        String current = url;
        for (int hop = 0; hop <= o.maxRedirects; hop++) {
            if (!allowed(current, o)) throw new IOException("download refused: that address is not allowed");
            HttpURLConnection c = (HttpURLConnection) toUrl(current).openConnection();
            try {
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(o.timeoutMs);
                c.setReadTimeout(o.timeoutMs);
                if (!o.userAgent.isEmpty()) c.setRequestProperty("User-Agent", o.userAgent);
                String cookie = o.cookies.cookieFor(current);
                if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null || loc.isEmpty()) throw new IOException("redirect without a location");
                    current = resolve(current, loc);
                    continue;
                }
                if (code != 200) throw new IOException("the server answered " + code);
                if (c.getContentLengthLong() > o.maxBytes) throw new ArtifactStorage.TooLargeException(o.maxBytes);
                File f = File.createTempFile("cap-dl-", ".part", o.tmpDir);
                long size = saveStream(c.getInputStream(), f, o.maxBytes);   // closes the stream; deletes f itself on any failure
                String type = c.getContentType();
                if (type != null && type.indexOf(';') >= 0) type = type.substring(0, type.indexOf(';'));
                return new Download(f, size, type == null ? "" : type.trim().toLowerCase(Locale.ROOT));
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("too many redirects");
    }
}
