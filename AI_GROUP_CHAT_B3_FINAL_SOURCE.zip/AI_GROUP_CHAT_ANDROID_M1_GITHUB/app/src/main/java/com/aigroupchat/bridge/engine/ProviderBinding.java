package com.aigroupchat.bridge.engine;

import android.content.Context;

import org.json.JSONObject;

/** The room never parses URLs: an adapter produces this and the room stores it. The id/locator, not the
 *  title, is the binding. (No cookies or tokens are ever stored here.) */
public final class ProviderBinding {
    public final String providerId;
    public final String providerConversationId;
    public final String restoreLocator;
    public final String displayTitle;
    public final long boundAt;

    public ProviderBinding(String providerId, String conversationId, String restoreLocator, String displayTitle, long boundAt) {
        this.providerId = providerId;
        this.providerConversationId = conversationId;
        this.restoreLocator = restoreLocator;
        this.displayTitle = displayTitle == null ? "" : displayTitle;
        this.boundAt = boundAt;
    }

    public JSONObject toJson() throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("providerId", providerId);
        o.put("conversationId", providerConversationId);
        o.put("restoreLocator", restoreLocator);
        o.put("title", displayTitle);
        o.put("boundAt", boundAt);
        return o;
    }

    public static ProviderBinding fromJson(JSONObject o) {
        if (o == null) return null;
        String id = o.optString("conversationId", "");
        if (id.isEmpty()) return null;
        return new ProviderBinding(o.optString("providerId", ""), id, o.optString("restoreLocator", ""),
                o.optString("title", ""), o.optLong("boundAt", 0L));
    }

    /** Persistence for bindings. A Store with a room id reads and writes ONLY that room's bindings (room_bindings, with history);
     *  a Store without one is the Engine Lab's legacy scope (provider_bindings, never read by rooms).
     *  save() and clear() return null on success and a plain-language reason on failure: nothing is swallowed, and the answer is
     *  confirmed by reading the binding back, so a caller can safely say "connected" only when this returned null. */
    public static final class Store {
        private final com.aigroupchat.bridge.room.sqlite.RoomDb db;
        private final String roomId; // null = legacy (Engine Lab) scope

        public Store(Context c) { this(c, null); }

        public Store(Context c, String roomId) { db = com.aigroupchat.bridge.room.sqlite.RoomDb.get(c); this.roomId = roomId; }

        public ProviderBinding get(String providerId) {
            try { return roomId == null ? db.getLegacyBinding(providerId) : db.getBinding(roomId, providerId); } catch (Exception e) { return null; }
        }

        public String save(ProviderBinding b) {
            if (roomId != null) return com.aigroupchat.bridge.room.BindingWriter.bind(db, roomId, b);
            try {
                db.putLegacyBinding(b);
                ProviderBinding saved = db.getLegacyBinding(b.providerId);
                return saved != null && b.providerConversationId.equals(saved.providerConversationId) ? null : "the connection was not kept";
            } catch (RuntimeException e) {
                return "the connection could not be saved (" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()) + ")";
            }
        }

        public String clear(String providerId) {
            if (roomId != null) return com.aigroupchat.bridge.room.BindingWriter.clear(db, roomId, providerId, System.currentTimeMillis());
            try { db.clearLegacyBinding(providerId); return db.getLegacyBinding(providerId) == null ? null : "the old connection is still there"; }
            catch (RuntimeException e) { return "the connection could not be cleared (" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()) + ")"; }
        }
    }
}
