package com.aigroupchat.bridge.engine;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Static description of one web provider: where it lives and which DOM selectors to use.
 *  Selectors are EXACT (no wildcard or generic fallbacks) and are CANDIDATES until verified: the lab's
 *  Health/Probe output is how they get corrected. If a selector is missing or ambiguous, the engine
 *  logs it and stops; it never guesses another element to click. */
public final class ProviderSpec {
    public final String id;
    public final String displayName;
    public final String startUrl;
    public final String[] scriptHosts;
    public final String[] navigationHosts;
    /** Hosts (besides the page's own) a captured file may be fetched from. Used by CapturePolicy; anything else is refused. */
    public final String[] downloadHosts;
    public final Pattern conversationPattern;
    public final String selectorsJson;

    private ProviderSpec(String id, String displayName, String startUrl, String[] scriptHosts,
                         String[] navigationHosts, String[] downloadHosts, String conversationRegex, JSONObject selectors) {
        this.id = id;
        this.displayName = displayName;
        this.startUrl = startUrl;
        this.scriptHosts = scriptHosts;
        this.navigationHosts = navigationHosts;
        this.downloadHosts = downloadHosts;
        this.conversationPattern = Pattern.compile(conversationRegex);
        this.selectorsJson = selectors.toString();
    }

    public static final ProviderSpec CHATGPT = new ProviderSpec(
            "chatgpt", "ChatGPT", "https://chatgpt.com/",
            new String[]{"chatgpt.com"},
            new String[]{"chatgpt.com", "openai.com", "auth.openai.com", "accounts.google.com",
                    "appleid.apple.com", "login.microsoftonline.com", "login.live.com"},
            new String[]{"oaiusercontent.com", "chatgpt.com"},
            "^https://chatgpt\\.com/(?:g/[^/]+/)?c/([0-9a-fA-F-]{36})",
            selectors(
                    new String[]{"#prompt-textarea"},
                    new String[]{"button[data-testid='send-button']"},
                    new String[]{"button[data-testid='stop-button']"},
                    new String[]{},
                    new String[]{"[data-message-author-role='assistant']"},
                    new String[]{"[data-message-author-role='user']"},
                    new String[]{"form[data-type='unified-composer']", "form"},
                    new String[]{"[data-testid='composer-attachment']", "[data-testid='file-thumbnail']"},
                    new String[]{"button[aria-label^='Remove file']", "button[aria-label^='Remove attachment']"},
                    new String[]{"[data-testid='composer-attachment'][data-state='uploading']", "[aria-label='Uploading file']"},
                    new String[]{"input[type='file']"},
                    // GUESSES (cannot be verified off-device; the Engine Lab "Probe files" shows what is really on the page). Nothing matching = the reply is plain text.
                    new String[]{"a[href^='sandbox:']", "a[href*='/backend-api/files/']", "a[download]"},
                    new String[]{"button[aria-label^='Download']", "[data-testid='file-download-button']"}));

    public static final ProviderSpec CLAUDE = new ProviderSpec(
            "claude", "Claude", "https://claude.ai/",
            new String[]{"claude.ai"},
            new String[]{"claude.ai", "anthropic.com", "accounts.google.com"},
            new String[]{"claude.ai", "claudeusercontent.com", "anthropic.com"},
            "^https://claude\\.ai/chat/([0-9a-fA-F-]{36})",
            selectors(
                    new String[]{"div.ProseMirror[contenteditable='true']"},
                    new String[]{"button[aria-label='Send message']"},
                    new String[]{"button[aria-label='Stop response']"},
                    new String[]{"[data-is-streaming='true']"},
                    new String[]{"[data-testid='assistant-message']"},
                    new String[]{"[data-testid='user-message']"},
                    new String[]{"form", "fieldset"},
                    new String[]{"[data-testid='attachment']", "[data-testid='composer-attachment']"},
                    new String[]{"button[aria-label^='Remove attachment']", "button[aria-label^='Remove file']"},
                    new String[]{"[data-testid='attachment'][data-state='uploading']", "[aria-label='Uploading']"},
                    new String[]{"input[type='file']"},
                    // GUESSES (cannot be verified off-device; the Engine Lab "Probe files" shows what is really on the page). Nothing matching = the reply is plain text.
                    new String[]{"a[download]", "a[href^='blob:']"},
                    new String[]{"button[aria-label='Download']", "button[aria-label^='Download file']", "[data-testid='file-download']"}));

    private static JSONObject selectors(String[] composer, String[] send, String[] stop, String[] streaming,
                                        String[] assistant, String[] user, String[] attachmentRoot,
                                        String[] attachment, String[] attachmentRemove, String[] attachmentBusy, String[] fileInput,
                                        String[] offerLink, String[] offerButton) {
        try {
            JSONObject o = new JSONObject();
            o.put("composer", new JSONArray(java.util.Arrays.asList(composer)));
            o.put("send", new JSONArray(java.util.Arrays.asList(send)));
            o.put("stop", new JSONArray(java.util.Arrays.asList(stop)));
            o.put("streaming", new JSONArray(java.util.Arrays.asList(streaming)));
            o.put("assistant", new JSONArray(java.util.Arrays.asList(assistant)));
            o.put("user", new JSONArray(java.util.Arrays.asList(user)));
            o.put("attachmentRoot", new JSONArray(java.util.Arrays.asList(attachmentRoot)));
            o.put("attachment", new JSONArray(java.util.Arrays.asList(attachment)));
            o.put("attachmentRemove", new JSONArray(java.util.Arrays.asList(attachmentRemove)));
            o.put("attachmentBusy", new JSONArray(java.util.Arrays.asList(attachmentBusy)));
            o.put("fileInput", new JSONArray(java.util.Arrays.asList(fileInput)));
            o.put("offerLink", new JSONArray(java.util.Arrays.asList(offerLink)));
            o.put("offerButton", new JSONArray(java.util.Arrays.asList(offerButton)));
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public boolean isNavigationAllowed(String host) { return hostIn(host, navigationHosts); }

    public boolean isScriptHost(String host) { return hostIn(host, scriptHosts); }

    private static boolean hostIn(String host, String[] list) {
        if (host == null) return false;
        String h = host.toLowerCase(java.util.Locale.ROOT);
        for (String allowed : list) if (h.equals(allowed) || h.endsWith("." + allowed)) return true;
        return false;
    }

    /** Returns the conversation id if the URL is a conversation page, else null. */
    public String conversationIdOf(String url) {
        if (url == null) return null;
        Matcher m = conversationPattern.matcher(url);
        return m.find() ? m.group(1) : null;
    }
}
