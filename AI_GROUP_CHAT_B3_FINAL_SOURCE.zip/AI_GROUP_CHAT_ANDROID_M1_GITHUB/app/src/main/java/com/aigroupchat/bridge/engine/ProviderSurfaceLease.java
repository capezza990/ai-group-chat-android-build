package com.aigroupchat.bridge.engine;

import java.util.Objects;

/**
 * Exclusive ownership for page-mutating work on one provider surface.
 *
 * <p>A holder may reacquire its own lease so attachment staging and the
 * following send share one operation. Retiring the lease invalidates every
 * previously issued token; a late release can therefore never unlock a newer
 * operation.</p>
 */
public final class ProviderSurfaceLease {
    public static final class Token {
        private final long generation;
        private final String holder;

        private Token(long generation, String holder) {
            this.generation = generation;
            this.holder = holder;
        }

        public String holder() { return holder; }
    }

    private long generation;
    private Token active;

    /** Returns a new/reused token, or null while another holder owns the page. */
    public synchronized Token acquire(String holder) {
        Objects.requireNonNull(holder, "holder");
        if (holder.isEmpty()) throw new IllegalArgumentException("holder must not be empty");
        if (active == null) active = new Token(++generation, holder);
        return active.holder.equals(holder) ? active : null;
    }

    public synchronized boolean isCurrent(Token token) {
        return token != null && active == token && token.generation == generation;
    }

    /** Releases only the exact current token. Stale tokens are harmless. */
    public synchronized boolean release(Token token) {
        if (!isCurrent(token)) return false;
        active = null;
        return true;
    }

    /**
     * Invalidates the current holder after renderer loss, destroy, timeout, or
     * abandonment. A later operation receives a different generation.
     */
    public synchronized boolean retire() {
        if (active == null) return false;
        active = null;
        generation++;
        return true;
    }

    public synchronized boolean isHeld() { return active != null; }

    public synchronized String holder() { return active == null ? null : active.holder; }
}
