package com.aigroupchat.bridge.engine;

import java.util.UUID;

/** State machine joining sequential attachment staging and the following turn under one surface lease. */
public final class ProviderSurfaceOperation {
    public static final class Stage {
        public final long id;
        public final int expectedVisibleCount;
        private Stage(long id, int expectedVisibleCount) {
            this.id = id;
            this.expectedVisibleCount = expectedVisibleCount;
        }
    }

    public static final class Turn {
        public final long id;
        private Turn(long id) { this.id = id; }
    }

    /** Fetching a file an AI produced. Never joins an upload or a turn: it needs the page to itself. */
    public static final class Capture {
        public final long id;
        private Capture(long id) { this.id = id; }
    }

    private final ProviderSurfaceLease lease;
    private ProviderSurfaceLease.Token token;
    private String bindingId;
    private long sequence;
    private Stage activeStage;
    private Turn activeTurn;
    private Capture activeCapture;
    private int stagedCount;

    public ProviderSurfaceOperation(ProviderSurfaceLease lease) { this.lease = lease; }

    /** Begins the next file in this binding, reusing the retained batch lease. */
    public synchronized Stage beginStage(String binding) {
        if (binding == null || binding.isEmpty() || activeStage != null || activeTurn != null || activeCapture != null) return null;
        if (token == null) {
            token = lease.acquire("provider-operation:" + UUID.randomUUID());
            if (token == null) return null;
            bindingId = binding;
        } else if (!binding.equals(bindingId) || !lease.isCurrent(token)) {
            return null;
        }
        activeStage = new Stage(++sequence, stagedCount + 1);
        return activeStage;
    }

    /** Records visual proof for exactly the current file. Repeated/late callbacks are ignored. */
    public synchronized boolean markStaged(Stage stage) {
        if (stage == null || activeStage != stage || !current()) return false;
        stagedCount = stage.expectedVisibleCount;
        activeStage = null;
        return true;
    }

    /** Starts a turn. A staged batch reuses its lease; a text-only turn acquires a fresh one. */
    public synchronized Turn beginTurn(String binding) {
        if (binding == null || binding.isEmpty() || activeStage != null || activeTurn != null || activeCapture != null) return null;
        if (token == null) {
            token = lease.acquire("provider-operation:" + UUID.randomUUID());
            if (token == null) return null;
            bindingId = binding;
        } else if (!binding.equals(bindingId) || !lease.isCurrent(token)) {
            return null;
        }
        activeTurn = new Turn(++sequence);
        return activeTurn;
    }

    /** A capture needs the page for itself: it is refused while ANY operation (a staged batch, a turn, another capture) holds the surface. */
    public synchronized Capture beginCapture(String binding) {
        if (binding == null || binding.isEmpty() || token != null || activeCapture != null) return null;
        token = lease.acquire("provider-operation:" + UUID.randomUUID());
        if (token == null) return null;
        bindingId = binding;
        activeCapture = new Capture(++sequence);
        return activeCapture;
    }

    public synchronized boolean finishCapture(Capture capture) {
        if (capture == null || activeCapture != capture || !current()) return false;
        retireLocked();
        return true;
    }

    public synchronized boolean isCurrent(Capture capture) { return capture != null && activeCapture == capture && current(); }
    public synchronized boolean hasActiveCapture() { return activeCapture != null && current(); }

    /** Accepted, rejected, failed, or uncertain: the operation is over and the page becomes available. */
    public synchronized boolean finishTurn(Turn turn) {
        if (turn == null || activeTurn != turn || !current()) return false;
        retireLocked();
        return true;
    }

    /** Activity/renderer loss, Stop, upload failure/timeout, or abandonment. */
    public synchronized boolean retire() {
        if (token == null) return false;
        retireLocked();
        return true;
    }

    public synchronized boolean isCurrent(Stage stage) {
        return stage != null && activeStage == stage && current();
    }

    public synchronized boolean isCurrent(Turn turn) {
        return turn != null && activeTurn == turn && current();
    }

    public synchronized boolean hasStagedFiles() { return token != null && stagedCount > 0 && current(); }
    public synchronized int stagedCount() { return hasStagedFiles() ? stagedCount : 0; }
    public synchronized String bindingId() { return current() ? bindingId : null; }
    public synchronized boolean isHeld() { return current(); }
    public synchronized boolean hasActiveTurn() { return activeTurn != null && current(); }
    public synchronized boolean hasActiveStage() { return activeStage != null && current(); }
    public synchronized long version() { return sequence; }

    /** True only for a retained, visibly staged batch that is between file staging and the following send. */
    public synchronized boolean isIdleStaged(String binding, long expectedVersion) {
        return current() && token != null && activeStage == null && activeTurn == null && stagedCount > 0
                && binding != null && binding.equals(bindingId) && sequence == expectedVersion;
    }

    public synchronized boolean isIdleStaged(String binding) {
        return current() && token != null && activeStage == null && activeTurn == null && stagedCount > 0
                && binding != null && binding.equals(bindingId);
    }

    private boolean current() { return token != null && lease.isCurrent(token); }

    private void retireLocked() {
        if (token != null) lease.release(token);
        token = null;
        bindingId = null;
        activeStage = null;
        activeTurn = null;
        activeCapture = null;
        stagedCount = 0;
    }
}
