package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.ArtifactTransfer;
import com.aigroupchat.bridge.room.BindingRecord;

import java.util.List;

/** Keeps the database binding-row id separate from the provider's real conversation/thread id. */
public final class ProviderTransferIdentity {
    public static final class Target {
        public final String bindingRowId;
        public final String conversationId;
        public final String roomId;
        public final String providerId;

        private Target(String bindingRowId, String conversationId, String roomId, String providerId) {
            this.bindingRowId = bindingRowId;
            this.conversationId = conversationId;
            this.roomId = roomId;
            this.providerId = providerId;
        }

        public boolean matchesPhysical(String physicalProviderId, String physicalConversationId) {
            return providerId.equals(physicalProviderId) && conversationId.equals(physicalConversationId);
        }
    }

    private ProviderTransferIdentity() {}

    /** A new upload may only target the ACTIVE binding row named by the transfer. */
    public static Target forUpload(ArtifactTransfer transfer, List<BindingRecord> history) {
        return resolve(transfer, history, true);
    }

    /** Cleanup may still need the conversation after that row was RETIRED by a rebind. */
    public static Target forCleanup(String roomId, String providerId, String bindingRowId, List<BindingRecord> history) {
        if (roomId == null || providerId == null || bindingRowId == null || history == null) return null;
        for (BindingRecord r : history) {
            if (!bindingRowId.equals(r.id) || !roomId.equals(r.roomId) || !providerId.equals(r.providerId)) continue;
            if (BindingRecord.PENDING_NEW.equals(r.state) || r.conversationId == null || r.conversationId.isEmpty()) return null;
            return new Target(r.id, r.conversationId, r.roomId, r.providerId);
        }
        return null;
    }

    private static Target resolve(ArtifactTransfer t, List<BindingRecord> history, boolean requireActive) {
        if (t == null || history == null) return null;
        for (BindingRecord r : history) {
            if (!t.bindingId.equals(r.id) || !t.roomId.equals(r.roomId) || !t.providerId.equals(r.providerId)) continue;
            if (requireActive && !BindingRecord.ACTIVE.equals(r.state)) return null;
            if (BindingRecord.PENDING_NEW.equals(r.state) || r.conversationId == null || r.conversationId.isEmpty()) return null;
            return new Target(r.id, r.conversationId, r.roomId, r.providerId);
        }
        return null;
    }
}
