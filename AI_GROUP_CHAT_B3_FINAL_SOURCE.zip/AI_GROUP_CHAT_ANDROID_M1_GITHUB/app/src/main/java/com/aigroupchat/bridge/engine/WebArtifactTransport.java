package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.Artifact;
import com.aigroupchat.bridge.room.ArtifactService;
import com.aigroupchat.bridge.room.ArtifactTransfer;
import com.aigroupchat.bridge.room.RoomStore;

import java.io.File;
import java.util.Map;

/** Upload transport for ChatGPT/Claude WebViews. Final app-scope service wiring is intentionally external. */
public final class WebArtifactTransport implements ArtifactService.Transport {
    private final Map<String, WebProviderSurface> surfaces;
    private final RoomStore store;
    private WebProviderSurface active;
    private WebProviderSurface lastSurface;
    private StagedExpiryListener expiryListener;

    public WebArtifactTransport(Map<String, WebProviderSurface> surfaces, RoomStore store) {
        this.surfaces = surfaces;
        this.store = store;
    }

    private ProviderTransferIdentity.Target uploadTarget(ArtifactTransfer transfer) {
        return ProviderTransferIdentity.forUpload(transfer, store.bindingHistory(transfer.roomId, transfer.providerId));
    }

    private ProviderTransferIdentity.Target cleanupTarget(String roomId, String providerId, String bindingId) {
        return ProviderTransferIdentity.forCleanup(roomId, providerId, bindingId, store.bindingHistory(roomId, providerId));
    }

    @Override public synchronized void transfer(Artifact artifact, File file, ArtifactTransfer transfer, Callback callback) {
        if (active != null) { callback.onFailed("another WebView upload is already active"); return; }
        WebProviderSurface surface = surfaces.get(transfer.providerId);
        if (surface == null) { callback.onFailed("provider surface is unavailable"); return; }
        ProviderTransferIdentity.Target target = uploadTarget(transfer);
        if (target == null) { callback.onFailed("the transfer no longer names this room's active provider conversation"); return; }
        active = surface;
        lastSurface = surface;
        surface.stageAttachment(artifact, file, transfer, target.conversationId, new WebProviderSurface.AttachmentListener() {
            private boolean finish() {
                synchronized (WebArtifactTransport.this) {
                    if (active != surface) return false;
                    active = null;
                    return true;
                }
            }
            @Override public void onStaged() {
                if (!finish()) return;
                surface.scheduleIdleStagedExpiry(target.conversationId, () -> {
                    StagedExpiryListener l;
                    synchronized (WebArtifactTransport.this) { l = expiryListener; }
                    if (l != null) l.onExpired(transfer.roomId, transfer.providerId, transfer.bindingId);
                });
                callback.onStaged();
            }
            @Override public void onFailed(String reason) { if (finish()) callback.onFailed(reason); }
        });
    }

    @Override public synchronized void cancel() {
        WebProviderSurface surface = active != null ? active : lastSurface;
        active = null; // any later callback is ignored by the wrapper above
        lastSurface = null;
        if (surface != null) surface.cancelAttachmentOperation();
    }

    @Override public void invalidateStaged(String roomId, String providerId, String bindingId) {
        WebProviderSurface surface = surfaces.get(providerId);
        if (surface == null) return;
        ProviderTransferIdentity.Target target = cleanupTarget(roomId, providerId, bindingId);
        if (target != null) surface.invalidateIdleStagedOperation(target.conversationId);
    }

    @Override public synchronized void setStagedExpiryListener(StagedExpiryListener listener) { expiryListener = listener; }
}
