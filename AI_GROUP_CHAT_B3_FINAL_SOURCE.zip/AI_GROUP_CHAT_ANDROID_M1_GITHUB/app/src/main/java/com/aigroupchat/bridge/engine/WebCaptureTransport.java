package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.Artifact;
import com.aigroupchat.bridge.room.ArtifactService;
import com.aigroupchat.bridge.room.RoomStore;

import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * The real {@link ArtifactService.CaptureTransport}: fetches a file an AI produced out of that AI's own provider page. The artifact remembers the exact
 * conversation it came from (its source binding), and the page must be physically on that conversation, otherwise the capture fails with a plain reason
 * (a different conversation could hold a different file of the same name).
 */
public final class WebCaptureTransport implements ArtifactService.CaptureTransport {
    public static final long DEFAULT_TIMEOUT_MS = 90_000L;

    private final Map<String, WebProviderSurface> surfaces;
    private final RoomStore store;
    private final File tmpDir;
    private final long maxBytes, timeoutMs;
    private volatile WebProviderSurface active;

    public WebCaptureTransport(Map<String, WebProviderSurface> surfaces, RoomStore store, File tmpDir, long maxBytes, long timeoutMs) {
        this.surfaces = surfaces; this.store = store; this.tmpDir = tmpDir; this.maxBytes = maxBytes; this.timeoutMs = timeoutMs;
    }

    @Override
    public void capture(Artifact artifact, Callback callback) {
        final WebProviderSurface surface = surfaces.get(artifact.origin);
        if (surface == null) { callback.onFailed("there is no provider page for " + artifact.origin); return; }
        final ProviderTransferIdentity.Target target = ProviderTransferIdentity.forCleanup(artifact.roomId, artifact.origin, artifact.sourceBindingId,
                store.bindingHistory(artifact.roomId, artifact.origin));
        if (target == null) { callback.onFailed("the conversation this file came from is no longer known"); return; }
        if (!tmpDir.isDirectory() && !tmpDir.mkdirs() && !tmpDir.isDirectory()) { callback.onFailed("the app could not prepare storage for the file"); return; }
        active = surface;
        // the exact reply that produced the file ("" when the page gave no id: then only the first, automatic capture can be attempted)
        surface.captureFile(target.conversationId, artifact.displayName, store.sourceReplyRef(artifact.id), maxBytes, timeoutMs, tmpDir, new WebProviderSurface.CaptureListener() {
            @Override public void onFile(File file, String mime) {
                try { callback.onBytes(ChunkedReceiver.openAndDelete(file), mime); }
                catch (IOException e) { file.delete(); callback.onFailed("the captured file could not be opened"); }
            }
            @Override public void onFailed(String reason) { callback.onFailed(reason); }
        });
    }

    /** Stop: silent. Frees the page and the surface; ArtifactService has already resolved the job. */
    @Override
    public void cancel() {
        WebProviderSurface s = active;
        if (s != null) s.cancelCapture();
    }
}
