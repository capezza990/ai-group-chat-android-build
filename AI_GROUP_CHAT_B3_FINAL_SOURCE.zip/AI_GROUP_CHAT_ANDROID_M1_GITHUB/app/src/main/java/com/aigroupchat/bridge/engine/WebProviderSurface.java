package com.aigroupchat.bridge.engine;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import com.aigroupchat.bridge.room.Artifact;
import com.aigroupchat.bridge.room.ArtifactTransfer;

/**
 * P1-A: one embedded consumer-web provider (ChatGPT or Claude) inside AI Group Chat.
 * This is an engine laboratory: it proves login persistence, conversation binding, composer control,
 * structural reply identity and hidden operation. It never stores cookies or tokens, never logs
 * conversation text, and fails closed whenever a selector, URL or identity check is not satisfied.
 */
public final class WebProviderSurface {
    public interface Callback<T> { void done(T result); }

    public interface AttachmentListener {
        void onStaged();
        void onFailed(String reason);
    }

    public static final class TurnResult {
        public boolean ok;
        public String summary = "";
        public String fullText = "";
        /** Files offered in the newest assistant messages (read-only scan); empty when the profile matches nothing. */
        public List<FileOffer> fileOffers = new ArrayList<>();
        public boolean identityProven;
        public int newAssistantNodes;
        public int newUserBubbles;
        public String identityMode = "";
        public String replyHash = "";
        public String providerUserMsgId = ""; // opaque, only when the page exposes stable ids
        public String providerAsstMsgId = "";
    }

    /** Phased turn callbacks used by the room. maybeSubmitted is false ONLY if the send provably never happened. */
    public interface TurnListener {
        void onSubmitted(String providerUserMsgId);
        void onReply(String text, String providerAsstMsgId);
        void onFailed(String reason, boolean maybeSubmitted);
        /** A reply together with the files it offers (only those the capture will later be able to find again). Default: files are ignored. */
        default void onReplyWithFiles(String text, String providerAsstMsgId, List<FileOffer> offers) { onReply(text, providerAsstMsgId); }
    }

    /** Hard ceiling for one turn even if the page keeps reporting hidden (so a stuck turn can never wait forever). */
    private static final long ABSOLUTE_TURN_CAP_MS = 20L * 60L * 1000L;
    private static final long UPLOAD_TIMEOUT_MS = 45_000L;
    private static final long ATTACHMENT_CLEANUP_TIMEOUT_MS = 6_000L;
    private static final long STAGED_IDLE_TIMEOUT_MS = 60_000L;

    public final ProviderSpec spec;
    private final Activity activity;
    private final WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile String bindFailure;
    private ProviderBinding.Store bindings; // legacy scope until setRoomScope() (the Engine Lab keeps the legacy scope)
    private final String script;
    private final Bridge bridge = new Bridge();
    private boolean bridgeAttached;
    private boolean pageFinished;
    private boolean rendererGone;
    private volatile String currentHost = "";
    private volatile FileCaptureFlow.DownloadSink armedDownloads;
    private FileCaptureFlow captureFlow;
    private boolean[] captureCancelled;
    private volatile int acceptedPushes;
    private volatile int rejectedPushes;
    private final ProviderSurfaceLease surfaceLease = new ProviderSurfaceLease();
    private final ProviderSurfaceOperation surfaceOperation = new ProviderSurfaceOperation(surfaceLease);
    private final List<ArtifactContentProvider.Handle> stagedHandles = new ArrayList<>();
    private UploadAttempt upload;

    private static final class UploadAttempt {
        final Artifact artifact;
        final File file;
        final ArtifactTransfer transfer;
        final ProviderSurfaceOperation.Stage stage;
        final AttachmentListener listener;
        final long deadline;
        ArtifactContentProvider.Handle handle;
        boolean chooserDelivered;
        boolean ended;

        UploadAttempt(Artifact artifact, File file, ArtifactTransfer transfer,
                      ProviderSurfaceOperation.Stage stage, AttachmentListener listener, long deadline) {
            this.artifact = artifact;
            this.file = file;
            this.transfer = transfer;
            this.stage = stage;
            this.listener = listener;
            this.deadline = deadline;
        }
    }

    public WebProviderSurface(Activity activity, ProviderSpec spec) {
        this.activity = activity;
        this.spec = spec;
        this.bindings = new ProviderBinding.Store(activity);
        this.script = readAsset("agc_engine.js");

        web = new WebView(activity);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        s.setAllowFileAccess(false);
        // Required only for our non-exported, random-token ArtifactContentProvider file-chooser URIs.
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setGeolocationEnabled(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        if ((activity.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        // Cross-site auth redirects may need these. P1-A measures whether we can disable this later.
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        // Downloads are ignored unless a file capture armed them: the app never saves anything it was not asked to capture.
        web.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            FileCaptureFlow.DownloadSink sink = armedDownloads;
            if (sink != null) sink.onDownload(url, userAgent, mimetype, contentLength);
        });
    }

    public View view() { return web; }

    public void load() {
        if (rendererGone) return;
        if (web.getUrl() == null) go(spec.startUrl);
    }

    /** Nudge the page awake: resume the renderer and JS timers (a covered/idle WebView can go stale). Safe to call any time. */
    public void wake() {
        try { web.onResume(); web.resumeTimers(); } catch (Exception ignored) { }
    }

    private static String newNonce() { return java.util.UUID.randomUUID().toString().substring(0, 6); }

    /** Back to the provider's start page (used by the room's "Reload" while connecting). */
    public void reloadHome() {
        if (surfaceOperation.isHeld()) { EngineLog.add(spec.id, "reload refused: provider surface operation active"); return; }
        go(spec.startUrl);
    }

    public boolean goBackIfPossible() {
        if (rendererGone || surfaceOperation.isHeld()) return false;
        if (web.canGoBack()) { web.goBack(); return true; }
        return false;
    }

    public void flushCookies() { CookieManager.getInstance().flush(); }

    public void destroy() {
        cancelCapture();
        cancelAttachmentOperation();
        retireSurfaceOperation();
        main.removeCallbacksAndMessages(null);
        flushCookies();
        try { web.removeJavascriptInterface("AGCBridge"); } catch (Exception ignored) {}
        web.destroy();
    }

    public boolean sessionCookiePresent() {
        String c = CookieManager.getInstance().getCookie(spec.startUrl);
        return c != null && !c.isEmpty(); // presence only; values are never logged
    }

    public boolean rendererGone() { return rendererGone; }

    private static JSONObject errObj(String why) {
        try { return new JSONObject().put("err", why); }
        catch (Exception e) { return new JSONObject(); }
    }

    // ---------------------------------------------------------------- navigation + JS bridge scoping

    private void go(String url) {
        if (rendererGone) return;
        Uri u = Uri.parse(url);
        prepareBridgeFor(u.getHost());
        pageFinished = false;
        web.loadUrl(url);
    }

    /**
     * addJavascriptInterface/removeJavascriptInterface changes take effect on page loads. This is best-effort
     * scoping only; SPA/redirect/subframe behavior means it is NOT caller-origin authentication. Bridge.event()
     * is intentionally tiny and powerless in P1-A. P1-C must replace it with origin-scoped messaging.
     */
    private void prepareBridgeFor(String host) {
        boolean want = spec.isScriptHost(host);
        if (want && !bridgeAttached) {
            web.addJavascriptInterface(bridge, "AGCBridge");
            bridgeAttached = true;
        } else if (!want && bridgeAttached) {
            web.removeJavascriptInterface("AGCBridge");
            bridgeAttached = false;
        }
    }

    // ---------------------------------------------------------------- binding / thread guard

    public ProviderBinding binding() { return bindings.get(spec.id); }

    /** Point this surface at one room's own bindings. Must not be called while a turn is in flight (the room UI blocks it). */
    public void setRoomScope(String roomId) { bindings = new ProviderBinding.Store(activity, roomId); }

    /** "Use this conversation": binds ONLY a provider URL matching the conversation pattern. */
    public ProviderBinding bindCurrentConversation() {
        bindFailure = null;
        if (surfaceOperation.isHeld()) {
            EngineLog.add(spec.id, "BIND refused: provider surface operation active");
            return null;
        }
        if (rendererGone) {
            EngineLog.add(spec.id, "BIND refused: renderer gone");
            return null;
        }
        String url = web.getUrl();
        String id = spec.conversationIdOf(url);
        if (id == null) {
            EngineLog.add(spec.id, "BIND refused: not on a conversation page (" + safeUrl(url) + ")");
            return null;
        }
        ProviderBinding b = new ProviderBinding(spec.id, id, stripQuery(url), web.getTitle(), System.currentTimeMillis());
        String err = bindings.save(b);
        if (err != null) { // the write failed or could not be confirmed: never report "bound"
            bindFailure = err;
            EngineLog.add(spec.id, "BIND FAILED: " + err);
            return null;
        }
        EngineLog.add(spec.id, "BOUND conversation=#" + EngineLog.fingerprint(id));
        return b;
    }

    /** Why the last bindCurrentConversation() returned null because of a SAVE problem (null if it was refused for another reason or succeeded). */
    public String bindFailure() { return bindFailure; }

    private boolean onBound(ProviderBinding b) {
        return b != null && b.providerConversationId.equals(spec.conversationIdOf(web.getUrl()));
    }

    /** Restore by stored locator, then wait until the page truly settles on the bound conversation. */
    public void restoreBound(Callback<Boolean> cb) {
        final ProviderBinding b = binding();
        if (rendererGone) {
            EngineLog.add(spec.id, "restore refused: renderer gone");
            cb.done(false);
            return;
        }
        if (b == null) {
            EngineLog.add(spec.id, "restore: no binding");
            cb.done(false);
            return;
        }

        Uri loc = Uri.parse(b.restoreLocator);
        if (!"https".equalsIgnoreCase(loc.getScheme()) || !spec.isScriptHost(loc.getHost())
                || !b.providerConversationId.equals(spec.conversationIdOf(b.restoreLocator))) {
            EngineLog.add(spec.id, "restore refused: stored locator does not match the stored conversation id");
            cb.done(false);
            return;
        }

        if (!onBound(b)) {
            EngineLog.add(spec.id, "thread guard: currently " + safeUrl(web.getUrl()) + " -> loading bound conversation");
            go(b.restoreLocator);
        }
        waitSettled(b, System.currentTimeMillis() + 25000L, cb);
    }

    private void waitSettled(ProviderBinding b, long deadline, Callback<Boolean> cb) {
        if (rendererGone) { cb.done(false); return; }
        if (System.currentTimeMillis() > deadline) {
            EngineLog.add(spec.id, "restore timed out; now at " + safeUrl(web.getUrl()) + " finished=" + pageFinished);
            cb.done(false);
            return;
        }
        if (pageFinished && onBound(b)) {
            evalJs("window.__agc?'1':'0'", r -> {
                if ("1".equals(r)) cb.done(true);
                else main.postDelayed(() -> waitSettled(b, deadline, cb), 400L);
            });
        } else {
            main.postDelayed(() -> waitSettled(b, deadline, cb), 400L);
        }
    }

    // ---------------------------------------------------------------- read-only JS access

    public void health(Callback<JSONObject> cb) {
        if (rendererGone) { cb.done(errObj("renderer-gone")); return; }
        evalObj("window.__agc?window.__agc.health():JSON.stringify({err:'script-not-installed'})", cb);
    }

    public void probe(Callback<JSONObject> cb) {
        if (rendererGone) { cb.done(errObj("renderer-gone")); return; }
        evalObj("window.__agc?window.__agc.probe():JSON.stringify({err:'script-not-installed'})", cb);
    }

    /** Explicit diagnostic mutation: one character on an EMPTY composer, then removes exactly that character. */
    public void typeCheck(Callback<JSONObject> cb) {
        if (rendererGone) { cb.done(errObj("renderer-gone")); return; }
        if (surfaceOperation.isHeld()) { cb.done(errObj("provider-surface-busy")); return; }
        evalJs("window.__agc?window.__agc.startTypeCheck():'no-script'",
                r -> main.postDelayed(() -> health(cb), 1300L));
    }

    // ---------------------------------------------------------------- provider composer attachment staging

    /** Stages one file while retaining the provider-surface lease for the files/send/acceptance operation. */
    public void stageAttachment(Artifact artifact, File file, ArtifactTransfer transfer, String expectedConversationId, AttachmentListener listener) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post(() -> stageAttachment(artifact, file, transfer, expectedConversationId, listener));
            return;
        }
        if (artifact == null || file == null || transfer == null || listener == null) return;
        ProviderBinding b = binding();
        if (rendererGone) { listener.onFailed("renderer gone; surface unhealthy"); return; }
        if (upload != null) { listener.onFailed("another attachment upload is already active"); return; }
        if (!spec.id.equals(transfer.providerId)) { listener.onFailed("upload provider does not match this surface"); return; }
        if (expectedConversationId == null || expectedConversationId.isEmpty() || b == null || !b.providerConversationId.equals(expectedConversationId)) {
            listener.onFailed("the bound provider conversation changed before upload");
            return;
        }
        // Surface-operation identity is the provider's actual conversation id. The transfer's bindingId is the DB row id and is intentionally NOT used here.
        ProviderSurfaceOperation.Stage stage = surfaceOperation.beginStage(expectedConversationId);
        if (stage == null) { listener.onFailed("provider surface is busy with another operation"); return; }
        UploadAttempt a = new UploadAttempt(artifact, file, transfer, stage, listener,
                System.currentTimeMillis() + UPLOAD_TIMEOUT_MS);
        upload = a;

        ensureReady(b, (failure, h) -> {
            if (!currentUpload(a)) return;
            if (failure != null) { failUpload(a, "upload preflight failed: " + failure); return; }
            prepareAttachmentCount(a.stage.expectedVisibleCount - 1, a.stage.expectedVisibleCount == 1, prepFailure -> {
                if (!currentUpload(a)) return;
                if (prepFailure != null) { failUpload(a, prepFailure); return; }
                openFileChooser(a);
            });
        });
    }

    /** Engine Lab: the read-only inventory of file offers (see agc_engine.js fileProbe). */
    public void fileProbe(Callback<JSONObject> cb) {
        if (rendererGone) { cb.done(errObj("renderer-gone")); return; }
        evalObj("window.__agc&&window.__agc.fileProbe?window.__agc.fileProbe():JSON.stringify({err:'script-not-installed'})", cb);
    }

    /** Engine Lab: the offers on the page right now (read-only). */
    public void fileOffers(Callback<List<FileOffer>> cb) {
        if (rendererGone) { cb.done(new ArrayList<>()); return; }
        evalJs("window.__agc&&window.__agc.fileOffers?window.__agc.fileOffers():'[]'", json -> cb.done(FileOffer.parseList(json)));
    }

    public interface CaptureListener {
        void onFile(File file, String mime);
        void onFailed(String reason);
    }

    /**
     * Fetches ONE file an AI produced out of the conversation this page is physically on. It needs the surface for itself (it never joins an upload or a
     * turn) and ends exactly once. A cancel (Stop) is silent: the caller already resolved the job.
     */
    public void captureFile(String conversationId, String displayName, String replyRef, long maxBytes, long timeoutMs, File tmpDir, CaptureListener l) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post(() -> captureFile(conversationId, displayName, replyRef, maxBytes, timeoutMs, tmpDir, l));
            return;
        }
        if (rendererGone) { l.onFailed("the provider page is not available (its renderer stopped)"); return; }
        final ProviderSurfaceOperation.Capture op = surfaceOperation.beginCapture(conversationId);
        if (op == null) { l.onFailed("the provider page is busy with another operation"); return; }
        FileCaptureFlow.Request req = new FileCaptureFlow.Request();
        req.conversationId = conversationId; req.displayName = displayName; req.replyRef = replyRef == null ? "" : replyRef; req.captureId = "cap-" + op.id;
        req.maxBytes = maxBytes; req.timeoutMs = timeoutMs; req.tmpDir = tmpDir; req.downloadHosts = spec.downloadHosts;
        try { req.userAgent = web.getSettings().getUserAgentString(); } catch (Exception ignored) { req.userAgent = ""; }
        final boolean[] cancelled = {false};
        final FileCaptureFlow[] self = new FileCaptureFlow[1];
        self[0] = new FileCaptureFlow(new CaptureDriver(), req, new FileCaptureFlow.Listener() {
            @Override public void onFile(File f, String mime) {
                surfaceOperation.finishCapture(op);
                if (captureFlow == self[0]) captureFlow = null;
                if (cancelled[0]) { f.delete(); return; }
                l.onFile(f, mime);
            }
            @Override public void onFailed(String reason) {
                surfaceOperation.finishCapture(op);
                if (captureFlow == self[0]) captureFlow = null;
                if (cancelled[0]) return;
                l.onFailed(reason);
            }
        });
        captureFlow = self[0];
        captureCancelled = cancelled;
        self[0].start();
    }

    /** Stop/abandon hook for a running capture: silent, frees the page's copy and the surface. Never touches an upload or a turn. */
    public void cancelCapture() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post(this::cancelCapture); return; }
        FileCaptureFlow f = captureFlow;
        boolean[] flag = captureCancelled;
        captureFlow = null;
        if (flag != null) flag[0] = true;
        if (f != null) f.cancel();
        if (surfaceOperation.hasActiveCapture()) surfaceOperation.retire();
        armedDownloads = null;
    }

    private final class CaptureDriver implements FileCaptureFlow.Driver {
        @Override public void eval(String expression, FileCaptureFlow.Done<String> cb) { evalJs(expression, cb::done); }
        @Override public void post(Runnable r, long delayMs) { main.postDelayed(r, delayMs); }
        @Override public void background(Runnable r) { new Thread(r, "agc-file-download").start(); }
        @Override public long now() { return System.currentTimeMillis(); }
        @Override public String conversationId() { return spec.conversationIdOf(web.getUrl()); }
        @Override public String pageHost() {
            try { return Uri.parse(web.getUrl()).getHost(); } catch (Exception e) { return null; }
        }
        @Override public String cookieFor(String url) { return CookieManager.getInstance().getCookie(url); }
        @Override public void armDownloads(FileCaptureFlow.DownloadSink sink) { armedDownloads = sink; }
    }

    /** Stop/abandon hook. No callback is emitted because ArtifactService has already claimed the job. */
    public void cancelAttachmentOperation() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post(this::cancelAttachmentOperation);
            return;
        }
        UploadAttempt a = upload;
        if (a != null) {
            a.ended = true;
            upload = null;
            closeUploadHandle(a);
        }
        if (surfaceOperation.isHeld()) cleanupAttachmentsAndRetire(null);
    }

    /** DB/controller invalidated staged rows. Clean only an IDLE staged batch; an active turn owns the page until its normal outcome. */
    public void invalidateIdleStagedOperation(String expectedConversationId) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post(() -> invalidateIdleStagedOperation(expectedConversationId));
            return;
        }
        if (surfaceOperation.hasActiveTurn() || surfaceOperation.hasActiveStage()) return;
        if (!surfaceOperation.isIdleStaged(expectedConversationId)) return;
        cleanupAttachmentsAndRetire(null);
    }

    /** A staged batch cannot hold a WebView forever if the controller never gets as far as sendTurn(). */
    public void scheduleIdleStagedExpiry(String expectedConversationId, Runnable onExpired) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post(() -> scheduleIdleStagedExpiry(expectedConversationId, onExpired));
            return;
        }
        final long version = surfaceOperation.version();
        if (!surfaceOperation.isIdleStaged(expectedConversationId, version)) return;
        main.postDelayed(() -> {
            if (!surfaceOperation.isIdleStaged(expectedConversationId, version)) return;
            cleanupAttachmentsAndRetire(failure -> { if (onExpired != null) onExpired.run(); });
        }, STAGED_IDLE_TIMEOUT_MS);
    }

    private boolean currentUpload(UploadAttempt a) {
        return a != null && upload == a && !a.ended && surfaceOperation.isCurrent(a.stage);
    }

    private interface FailureCb { void done(String failure); }

    /** Enforces either an exact owned count or an empty composer after safe stale-chip cleanup. */
    private void prepareAttachmentCount(int expected, boolean cleanupStale, FailureCb cb) {
        evalObj("window.__agc&&window.__agc.attachmentState?window.__agc.attachmentState():JSON.stringify({safe:false,error:'attachment-inspection-unavailable'})", o -> {
            if (o == null || !o.optBoolean("safe")) {
                cb.done("cannot safely inspect provider attachments: " + (o == null ? "no response" : o.optString("error")));
                return;
            }
            int count = o.optInt("count", -1);
            if (count == expected && (expected == 0 || o.optBoolean("ready"))) { cb.done(null); return; }
            if (count == expected && expected > 0) {
                cb.done("provider attachments are still uploading");
                return;
            }
            if (!cleanupStale || expected != 0 || count <= 0) {
                cb.done("provider attachment count changed (expected " + expected + ", found " + count + ")");
                return;
            }
            evalJs("window.__agc.cleanupStaleAttachments()", r -> {
                if (!"cleanup-started".equals(r) && !"clean".equals(r)) {
                    cb.done("stale provider attachment could not be removed: " + r);
                    return;
                }
                pollAttachmentCount(0, System.currentTimeMillis() + ATTACHMENT_CLEANUP_TIMEOUT_MS, cb);
            });
        });
    }

    private void pollAttachmentCount(int expected, long deadline, FailureCb cb) {
        evalObj("window.__agc&&window.__agc.attachmentState?window.__agc.attachmentState():JSON.stringify({safe:false,error:'attachment-inspection-unavailable'})", o -> {
            if (o != null && o.optBoolean("safe") && o.optInt("count", -1) == expected
                    && (expected == 0 || o.optBoolean("ready"))) { cb.done(null); return; }
            if (System.currentTimeMillis() >= deadline) {
                cb.done("timed out verifying provider attachment count " + expected);
                return;
            }
            main.postDelayed(() -> pollAttachmentCount(expected, deadline, cb), 250L);
        });
    }

    private void openFileChooser(UploadAttempt a) {
        try {
            a.handle = ArtifactContentProvider.expose(activity, a.file, a.artifact.displayName, a.artifact.mime);
        } catch (Exception e) {
            failUpload(a, "artifact could not be exposed to the provider: " + e.getMessage());
            return;
        }
        int before = a.stage.expectedVisibleCount - 1;
        evalJs("window.__agc&&window.__agc.startFileUpload?window.__agc.startFileUpload(" + before + "):'refused:upload-script-unavailable'", r -> {
            if (!currentUpload(a)) return;
            if (!"chooser-opened".equals(r)) { failUpload(a, "provider file chooser refused: " + r); return; }
            pollUploadVisible(a);
        });
    }

    private void pollUploadVisible(UploadAttempt a) {
        if (!currentUpload(a)) return;
        if (System.currentTimeMillis() >= a.deadline) {
            failUpload(a, a.chooserDelivered ? "timed out waiting for a visible provider attachment"
                    : "provider did not request the file chooser");
            return;
        }
        evalObj("window.__agc&&window.__agc.attachmentState?window.__agc.attachmentState():JSON.stringify({safe:false,error:'attachment-inspection-unavailable'})", o -> {
            if (!currentUpload(a)) return;
            if (o != null && o.optBoolean("safe")) {
                int count = o.optInt("count", -1);
                if (count == a.stage.expectedVisibleCount && o.optBoolean("ready")) {
                    if (!a.chooserDelivered) { failUpload(a, "an attachment appeared without this operation's file chooser"); return; }
                    a.ended = true;
                    upload = null;
                    retainUploadHandle(a);
                    if (!surfaceOperation.markStaged(a.stage)) return; // cancelled/retired won the race
                    a.listener.onStaged();
                    return;
                }
                if (count > a.stage.expectedVisibleCount) {
                    failUpload(a, "unexpected extra attachment appeared in the provider composer");
                    return;
                }
            }
            main.postDelayed(() -> pollUploadVisible(a), 300L);
        });
    }

    private void failUpload(UploadAttempt a, String reason) {
        if (!currentUpload(a)) return;
        a.ended = true;
        upload = null;
        closeUploadHandle(a);
        cleanupAttachmentsAndRetire(cleanupFailure -> a.listener.onFailed(cleanupFailure == null ? reason : reason + "; " + cleanupFailure));
    }

    private void closeUploadHandle(UploadAttempt a) {
        if (a != null && a.handle != null) { a.handle.close(); a.handle = null; }
    }

    private void retainUploadHandle(UploadAttempt a) {
        if (a != null && a.handle != null) { stagedHandles.add(a.handle); a.handle = null; }
    }

    private void retireSurfaceOperation() {
        surfaceOperation.retire();
        for (ArtifactContentProvider.Handle h : stagedHandles) h.close();
        stagedHandles.clear();
    }

    /** Cleanup keeps the lease until disappearance is proven or the bounded cleanup attempt ends. */
    private void cleanupAttachmentsAndRetire(FailureCb cb) {
        if (rendererGone) {
            retireSurfaceOperation();
            if (cb != null) cb.done("renderer was lost before attachment cleanup");
            return;
        }
        final String expectedConversation = surfaceOperation.bindingId();   // the conversation whose composer this operation staged into
        if (expectedConversation == null || !expectedConversation.equals(spec.conversationIdOf(web.getUrl()))) {
            // The page is not (or no longer) on that conversation, for example after a manual navigation. Never click remove controls in some OTHER draft: just let go of the operation.
            retireSurfaceOperation();
            if (cb != null) cb.done("the provider page is no longer on the staged conversation; no attachment was touched");
            return;
        }
        evalJs("window.__agc&&window.__agc.cleanupStaleAttachments?window.__agc.cleanupStaleAttachments():'refused:cleanup-script-unavailable'", r -> {
            if ("clean".equals(r)) {
                retireSurfaceOperation();
                if (cb != null) cb.done(null);
                return;
            }
            if (!"cleanup-started".equals(r)) {
                retireSurfaceOperation();
                if (cb != null) cb.done("provider attachment cleanup refused: " + r);
                return;
            }
            pollAttachmentCount(0, System.currentTimeMillis() + ATTACHMENT_CLEANUP_TIMEOUT_MS, failure -> {
                retireSurfaceOperation();
                if (cb != null) cb.done(failure);
            });
        });
    }

    /** One full turn: restore binding, check health, revalidate binding, send, then prove a new reply structurally. */
    public void runTurn(String text, String token, long timeoutMs, Callback<TurnResult> cb) {
        runTurnInternal(text, token, null, timeoutMs, cb, null, null);
    }

    private volatile boolean turnCancelled;

    // App-level foreground tracking. Only time the APP spent in the background pauses a turn's timeout; a provider page that
    // reports "hidden" underneath the foreground room does not.
    private final com.aigroupchat.bridge.room.BackgroundTracker bg = new com.aigroupchat.bridge.room.BackgroundTracker();

    public void setAppForeground(boolean foreground) { bg.setForeground(foreground, System.currentTimeMillis()); }

    /** Stops waiting for the current turn. It cannot un-send a message; the room records that as UNCERTAIN. */
    public void cancelTurn() { turnCancelled = true; }

    // C2 Stop state (main thread only). turnStop: Stop was pressed during this turn. sendInvoked: the page send() has been requested.
    private boolean turnStop;
    private boolean sendInvoked;
    private Waiter currentWaiter;

    /**
     * Stop for the room. Answers with how far the request got:
     *  - before the page send() was requested: NOT_SUBMITTED (the preflight sees turnStop and ends the turn);
     *  - otherwise the PAGE decides, atomically (abortSend): "aborted"/"not-sent" -> NOT_SUBMITTED (our inserted text is removed,
     *    nothing else); "clicked", unknown or no answer -> MAYBE_SUBMITTED / SUBMITTED, and the turn keeps being observed.
     * Observation continues with the normal active-time clock; a late real reply is delivered to the room.
     */
    public void stopTurn(java.util.function.Consumer<com.aigroupchat.bridge.room.RoomProvider.SubmitPhase> result) {
        turnStop = true;
        if (!sendInvoked) { result.accept(com.aigroupchat.bridge.room.RoomProvider.SubmitPhase.NOT_SUBMITTED); return; }
        evalJs("(window.__agc&&window.__agc.abortSend)?window.__agc.abortSend():'unavailable'", r -> {
            if ("aborted".equals(r) || "not-sent".equals(r)) {
                turnCancelled = true; // stop waiting; nothing was sent
                EngineLog.add(spec.id, "Stop: send aborted before the click (" + r + ")");
                result.accept(com.aigroupchat.bridge.room.RoomProvider.SubmitPhase.NOT_SUBMITTED);
            } else {
                boolean proven = currentWaiter != null && currentWaiter.userProvenSent;
                EngineLog.add(spec.id, "Stop: page says " + r + "; draining (" + (proven ? "submitted" : "maybe submitted") + ")");
                result.accept(proven ? com.aigroupchat.bridge.room.RoomProvider.SubmitPhase.SUBMITTED
                        : com.aigroupchat.bridge.room.RoomProvider.SubmitPhase.MAYBE_SUBMITTED);
            }
        });
    }

    /** Room API: one turn with submitted / reply / failed callbacks. The reply text is cleaned of hidden UI prefixes. */
    public void sendTurn(String text, long timeoutMs, TurnListener l) {
        turnCancelled = false;
        final Waiter[] holder = new Waiter[1];
        final String nonce = newNonce();
        final String tagged = com.aigroupchat.bridge.room.RefTag.tag(nonce, text); // provider-page only; never stored in the room
        runTurnInternal(tagged, null, nonce, timeoutMs, r -> {
            if (r.ok) {
                l.onReplyWithFiles(com.aigroupchat.bridge.room.ReplyCleaner.clean(r.fullText), r.providerAsstMsgId, FileOfferMatcher.replyOffers(r.fileOffers, r.providerAsstMsgId));
            } else {
                EngineLog.add(spec.id, "FAILED: " + r.summary); // the full diagnostic stays in the log, never in the room
                l.onFailed(com.aigroupchat.bridge.room.FailureText.shorten(r.summary), holder[0] != null && holder[0].loggedClick);
            }
        }, uid -> l.onSubmitted(uid.isEmpty() ? "ref:" + nonce : uid), holder);
    }

    private void runTurnInternal(String text, String token, String nonce, long timeoutMs, Callback<TurnResult> cb,
                                 Callback<String> userProvenCb, Waiter[] holder) {
        turnStop = false; sendInvoked = false; currentWaiter = null;
        final ProviderBinding b = binding();
        if (rendererGone) { cb.done(fail("renderer gone; surface unhealthy")); return; }
        if (b == null) { cb.done(fail("no bound conversation: open one and press Use this conversation")); return; }
        if (text == null || text.trim().isEmpty()) { cb.done(fail("empty test prompt refused")); return; }
        final ProviderSurfaceOperation.Turn operationTurn = surfaceOperation.beginTurn(b.providerConversationId);
        if (operationTurn == null) { cb.done(fail("provider surface is busy with another operation")); return; }
        final AtomicBoolean terminal = new AtomicBoolean();
        final Callback<TurnResult> finish = r -> {
            if (!terminal.compareAndSet(false, true)) return;
            currentWaiter = null;
            // A successful reply necessarily follows onSubmitted(), so staged rows were committed before release.
            if (r.ok) {
                surfaceOperation.finishTurn(operationTurn);
                for (ArtifactContentProvider.Handle h : stagedHandles) h.close();
                stagedHandles.clear();
                cb.done(r);
            } else {
                cb.done(r); // RoomController fails STAGED rows before the surface is released.
                if (surfaceOperation.hasStagedFiles()) cleanupAttachmentsAndRetire(null);
                else surfaceOperation.finishTurn(operationTurn);
            }
        };

        // B2.1 preflight: bound page -> wake -> recheck the DOM -> reload the bound chat if needed -> only then submit.
        // Everything here is PRE-submit, so a failure is retry-safe and nothing is ever resent.
        ensureReady(b, (failure, h) -> {
            if (turnStop) { finish.done(fail("cancelled")); return; }
            if (failure != null) { finish.done(fail(failure)); return; }
            if (!h.optBoolean("composerEmpty")) { finish.done(fail("composer already holds text; not touching the draft")); return; }
            if (h.optBoolean("generating")) { finish.done(fail("provider is busy generating")); return; }
            if (!onBound(b)) { finish.done(fail("conversation changed before send; refusing")); return; }

            final int expectedAttachments = surfaceOperation.stagedCount();
            prepareAttachmentCount(expectedAttachments, expectedAttachments == 0, attachmentFailure -> {
                if (attachmentFailure != null) { finish.done(fail(attachmentFailure)); return; }
                if (turnStop) { finish.done(fail("cancelled")); return; } // last chance: nothing has been inserted or sent yet
                sendInvoked = true;
                final long t0 = System.currentTimeMillis();
                evalJs("window.__agc.send(" + JSONObject.quote(text) + "," + JSONObject.quote(b.providerConversationId) + ","
                        + JSONObject.quote(nonce == null ? "" : nonce) + ")", r -> {
                    EngineLog.add(spec.id, "send -> " + r);
                    if ("aborted".equals(r)) { finish.done(fail("cancelled")); return; }
                    if (!"inserted".equals(r)) { finish.done(fail("send refused: " + r)); return; }
                    Waiter w = new Waiter(t0, timeoutMs, token, finish);
                    w.userProvenCb = userProvenCb;
                    currentWaiter = w;
                    if (holder != null) holder[0] = w;
                    w.tick();
                });
            });
        });
    }

    private interface ReadyCb { void done(String failure, JSONObject health); }

    private void ensureReady(ProviderBinding b, ReadyCb cb) { ensureReadyStep(b, cb, 0); }

    private void ensureReadyStep(ProviderBinding b, ReadyCb cb, int reloads) {
        if (turnStop) { cb.done("cancelled", null); return; }
        wake();
        restoreBound(settled -> {
            if (!settled) {
                if (reloads < 1) {
                    EngineLog.add(spec.id, "preflight: bound page did not settle; reloading it once");
                    go(b.restoreLocator);
                    ensureReadyStep(b, cb, reloads + 1);
                } else {
                    cb.done("could not settle on the bound conversation", null);
                }
                return;
            }
            recheckHealth(b, cb, 0, reloads);
        });
    }

    private void recheckHealth(ProviderBinding b, ReadyCb cb, int n, int reloads) {
        if (turnStop) { cb.done("cancelled", null); return; }
        health(h -> {
            boolean ok = h != null && !h.has("err") && h.optBoolean("healthy");
            if (ok) {
                if (!onBound(b)) { cb.done("conversation changed before send; refusing", h); return; }
                cb.done(null, h);
                return;
            }
            if (n < 3) { // the DOM may simply still be rendering: look again before giving up
                main.postDelayed(() -> recheckHealth(b, cb, n + 1, reloads), 1500L);
                return;
            }
            if (reloads < 2) {
                EngineLog.add(spec.id, "preflight: unhealthy after rechecks; reloading the bound conversation (" + (reloads + 1) + "/2)");
                go(b.restoreLocator);
                ensureReadyStep(b, cb, reloads + 1);
                return;
            }
            cb.done("unhealthy provider surface: " + (h == null ? "no response" : h.toString()), h);
        });
    }

    private final class Waiter {
        final long t0;
        final long timeoutMs;
        final String token;
        final Callback<TurnResult> cb;
        int lastLen = -1;
        long lastLenChange;
        boolean loggedClick;
        boolean loggedUser;
        boolean loggedIdentity;
        boolean loggedGen;
        boolean userProvenSent;
        Callback<String> userProvenCb;
        String lastPoll = "";
        final com.aigroupchat.bridge.room.TurnClock clock;
        boolean lastVisHidden;
        boolean loggedHidden;

        Waiter(long t0, long timeoutMs, String token, Callback<TurnResult> cb) {
            this.t0 = t0;
            this.timeoutMs = timeoutMs;
            this.token = token;
            this.cb = cb;
            this.lastLenChange = t0;
            this.clock = new com.aigroupchat.bridge.room.TurnClock(t0, timeoutMs, ABSOLUTE_TURN_CAP_MS, bg.totalBackgroundMs(t0));
        }

        void tick() {
            if (rendererGone) { cb.done(fail("renderer gone while waiting for reply")); return; }
            if (turnCancelled) { cb.done(fail("cancelled")); return; }
            long now = System.currentTimeMillis();
            long bgNow = bg.totalBackgroundMs(now);
            if (lastVisHidden && bg.isForeground()) wake(); // page says hidden although the app is on screen: nudge it
            if (clock.expired(now, bgNow)) {
                EngineLog.add(spec.id, "TIMEOUT: active " + clock.activeMs(now, bgNow) / 1000 + "s, total " + (now - t0) / 1000 + "s, appBackground "
                        + clock.backgroundDuringTurnMs(bgNow) / 1000 + "s; appForeground=" + bg.isForeground() + " viewShown=" + web.isShown()
                        + " windowVisibility=" + web.getWindowVisibility() + " size=" + web.getWidth() + "x" + web.getHeight() + "; last poll " + lastPoll);
                cb.done(fail("timeout after " + clock.activeMs(now, bgNow) / 1000 + "s"));
                return;
            }

            evalObj("window.__agc?window.__agc.poll():JSON.stringify({err:'no-script'})", o -> {
                if (o == null || o.has("err")) {
                    main.postDelayed(this::tick, 700L);
                    return;
                }
                lastPoll = o.toString();
                lastVisHidden = "hidden".equals(o.optString("vis"));
                if (lastVisHidden && !loggedHidden) {
                    loggedHidden = true;
                    EngineLog.add(spec.id, "page reports HIDDEN during the turn: appForeground=" + bg.isForeground() + " viewShown=" + web.isShown() + " windowVisibility="
                            + web.getWindowVisibility() + " size=" + web.getWidth() + "x" + web.getHeight());
                }
                long t = System.currentTimeMillis() - t0;
                String sr = o.optString("sendResult");
                int len = o.optInt("len");
                boolean gen = o.optBoolean("gen");
                boolean identity = o.optBoolean("identity");

                if ("clicked".equals(sr) && !loggedClick) {
                    loggedClick = true;
                    EngineLog.add(spec.id, "+" + t + "ms send clicked");
                }
                if (o.optInt("newU") > 0 && !loggedUser) {
                    loggedUser = true;
                    EngineLog.add(spec.id, "+" + t + "ms new user bubble; textMatches=" + o.optBoolean("userMatches"));
                }
                if (identity && !loggedIdentity) {
                    loggedIdentity = true;
                    EngineLog.add(spec.id, "+" + t + "ms assistant IDENTITY proven mode=" + o.optString("mode")
                            + " newA=" + o.optInt("newA") + " newU=" + o.optInt("newU")
                            + " nodeNovelty(diag)=" + o.optInt("nodeNovelty") + " vis=" + o.optString("vis"));
                }
                if (o.optBoolean("userProven") && !userProvenSent && userProvenCb != null) {
                    userProvenSent = true; // our message is visibly in the provider conversation
                    userProvenCb.done(o.optString("userId"));
                }
                if (gen && !loggedGen) {
                    loggedGen = true;
                    EngineLog.add(spec.id, "+" + t + "ms generating observed");
                }

                // Any state other than the normal in-flight/complete states is a terminal refusal.
                if (!"pending".equals(sr) && !"clicked".equals(sr) && !"none".equals(sr)) {
                    cb.done(fail("send failed: " + sr));
                    return;
                }

                if (len != lastLen) {
                    lastLen = len;
                    lastLenChange = System.currentTimeMillis();
                }

                // Structural identity is authoritative. Length stability only decides when that identified reply is finished.
                if (identity && !gen && len > 0 && System.currentTimeMillis() - lastLenChange >= 2500L) {
                    finish(o);
                    return;
                }
                main.postDelayed(this::tick, 500L);
            });
        }

        void finish(JSONObject o) {
            evalJs("window.__agc.full()", full -> evalJs("window.__agc.fileOffers ? window.__agc.fileOffers() : '[]'", offersJson -> {
                TurnResult r = new TurnResult();
                r.fileOffers = FileOffer.parseList(offersJson);
                r.fullText = full == null ? "" : full;
                boolean tokenOk = token == null || r.fullText.contains(token);
                r.identityProven = o.optBoolean("identity");
                r.newAssistantNodes = o.optInt("newA");
                r.newUserBubbles = o.optInt("newU");
                r.identityMode = o.optString("mode");
                r.replyHash = Integer.toHexString(r.fullText.hashCode());
                r.providerUserMsgId = o.optString("userId");
                r.providerAsstMsgId = o.optString("asstId");
                // count-independent for nonce identity; legacy modes still need positive count growth
                r.ok = com.aigroupchat.bridge.room.TurnAcceptance.accept(r.fullText, tokenOk, r.identityProven,
                        r.identityMode, r.newAssistantNodes, r.newUserBubbles);
                r.summary = "complete in " + (System.currentTimeMillis() - t0) / 1000 + "s; newAssistantNodes=" + r.newAssistantNodes
                        + "; newUserBubbles=" + r.newUserBubbles + "; identityMode=" + r.identityMode
                        + "; replyChars=" + r.fullText.length()
                        + (r.fullText.length() != o.optInt("len") ? " (pollLen=" + o.optInt("len") + ", capped?)" : "")
                        + "; replyHash=" + r.replyHash
                        + "; pushes=" + o.optInt("pushes") + "; vis=" + o.optString("vis")
                        + (token == null ? "" : "; containsToken=" + tokenOk);
                cb.done(r);
            }));
        }
    }

    private static TurnResult fail(String why) {
        TurnResult r = new TurnResult();
        r.ok = false;
        r.summary = why;
        return r;
    }

    private void evalJs(String expr, Callback<String> cb) {
        if (rendererGone) { cb.done(null); return; }
        web.evaluateJavascript(expr, raw -> cb.done(decode(raw)));
    }

    private void evalObj(String expr, Callback<JSONObject> cb) {
        evalJs(expr, s -> {
            try { cb.done(s == null ? null : new JSONObject(s)); }
            catch (Exception e) { cb.done(null); }
        });
    }

    private static String decode(String raw) {
        if (raw == null || raw.equals("null")) return null;
        try {
            Object o = new JSONTokener(raw).nextValue();
            return o == null || o == JSONObject.NULL ? null : String.valueOf(o);
        } catch (Exception e) {
            return raw;
        }
    }

    private void installScript() {
        if (rendererGone) return;
        String url = web.getUrl();
        if (url == null || script == null) return;
        String host = Uri.parse(url).getHost();
        if (!spec.isScriptHost(host)) return; // never inject on login/auth hosts
        web.evaluateJavascript("window.__AGC_SPEC=" + spec.selectorsJson + ";" + script, null);
    }

    private String readAsset(String name) {
        try (InputStream in = activity.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            EngineLog.add(spec.id, "could not read " + name + ": " + e.getClass().getSimpleName());
            return null;
        }
    }

    /** scheme://host/path only: query strings and fragments are never logged. Conversation UUIDs are fingerprinted. */
    public static String safeUrl(String url) {
        if (url == null) return "(none)";
        try {
            Uri u = Uri.parse(url);
            String scheme = u.getScheme() == null ? "?" : u.getScheme();
            String host = u.getHost() == null ? "?" : u.getHost();
            String s = scheme + "://" + host + (u.getPath() == null ? "" : u.getPath());
            s = EngineLog.redactIds(s);
            return s.length() > 140 ? s.substring(0, 140) + "…" : s;
        } catch (Exception e) {
            return "(unparsable)";
        }
    }

    private static String stripQuery(String url) {
        try {
            Uri u = Uri.parse(url);
            return u.getScheme() + "://" + u.getHost() + (u.getPath() == null ? "" : u.getPath());
        } catch (Exception e) {
            return url;
        }
    }

    private void noteHost(String url) {
        try {
            currentHost = url == null ? "" : String.valueOf(Uri.parse(url).getHost());
            if ("null".equals(currentHost)) currentHost = "";
        } catch (Exception e) {
            currentHost = "";
        }
    }

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (!r.isForMainFrame()) return false;
            Uri u = r.getUrl();
            if ("about".equalsIgnoreCase(u.getScheme())) return false;
            if ("https".equalsIgnoreCase(u.getScheme()) && spec.isNavigationAllowed(u.getHost())) {
                prepareBridgeFor(u.getHost());
                return false;
            }
            EngineLog.add(spec.id, "BLOCKED navigation to " + safeUrl(u.toString()));
            return true;
        }

        @Override
        public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
            pageFinished = false;
            noteHost(url);
            prepareBridgeFor(Uri.parse(url).getHost());
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            noteHost(url);
            pageFinished = true;
            EngineLog.add(spec.id, "page finished " + safeUrl(url));
            installScript();
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
            noteHost(url);
            EngineLog.add(spec.id, "history " + safeUrl(url));
            installScript();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) EngineLog.add(spec.id, "ERROR main-frame code=" + e.getErrorCode());
        }

        @Override
        public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse resp) {
            if (r.isForMainFrame()) {
                EngineLog.add(spec.id, "HTTP " + resp.getStatusCode() + " main-frame " + safeUrl(r.getUrl().toString()));
            }
        }

        @Override
        public void onReceivedSslError(WebView v, SslErrorHandler handler, SslError error) {
            handler.cancel();
            EngineLog.add(spec.id, "SSL error (cancelled) primaryError=" + error.getPrimaryError() + " " + safeUrl(error.getUrl()));
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
            rendererGone = true;
            pageFinished = false;
            UploadAttempt a = upload;
            if (a != null) {
                a.ended = true;
                upload = null;
                closeUploadHandle(a);
                a.listener.onFailed("renderer gone during attachment upload");
            }
            surfaceLease.retire();
            retireSurfaceOperation();
            EngineLog.add(spec.id, "RENDERER GONE crashed=" + detail.didCrash() + "; surface marked unhealthy");
            return true;
        }
    }

    private final class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
            UploadAttempt a = upload;
            if (!currentUpload(a) || a.handle == null || a.chooserDelivered || !spec.isScriptHost(currentHost)) return false;
            a.chooserDelivered = true;
            filePathCallback.onReceiveValue(new Uri[]{a.handle.uri});
            return true;
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            return true; // provider console output can contain conversation content; never log it
        }

        @Override
        public void onPermissionRequest(PermissionRequest req) {
            req.deny();
        }
    }

    /**
     * Page -> native. Only the tiny structural payload {a,u,gen,len} is accepted.
     * currentHost is the MAIN-FRAME host, not proof of the caller frame's origin. This is tolerable only
     * for P1-A because the handler is read-only/powerless. P1-C must use origin-scoped WebMessageListener.
     */
    private final class Bridge {
        private boolean integral(Object v, long min, long max) {
            if (!(v instanceof Number)) return false;
            double d = ((Number) v).doubleValue();
            return d == Math.rint(d) && d >= min && d <= max;
        }

        @JavascriptInterface
        public void event(String json) {
            if (json == null || json.length() > 120 || !spec.isScriptHost(currentHost)) {
                rejectedPushes++;
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                boolean shapeOk = o.length() == 4 && o.opt("gen") instanceof Boolean
                        && integral(o.opt("a"), 0, 100000)
                        && integral(o.opt("u"), 0, 100000)
                        && integral(o.opt("len"), 0, 50_000_000L);
                if (!shapeOk) { rejectedPushes++; return; }
                acceptedPushes++;
                if (acceptedPushes <= 40) {
                    EngineLog.add(spec.id, "push#" + acceptedPushes + " a=" + o.optInt("a") + " u=" + o.optInt("u")
                            + " gen=" + o.optBoolean("gen") + " len=" + o.optInt("len"));
                }
            } catch (Exception e) {
                rejectedPushes++;
            }
        }
    }
}
