package com.aigroupchat.bridge.engine;

import com.aigroupchat.bridge.room.RoomProvider;

import java.util.Collections;
import java.util.Set;

/**
 * A live ChatGPT/Claude participant: adapts an embedded WebProviderSurface to the room's RoomProvider contract.
 * The provider conversation is only an execution endpoint; the room owns the canonical history.
 */
public final class WebRoomProvider implements RoomProvider {
    public static final long TURN_TIMEOUT_MS = 240_000L;

    private final String id, name;
    private final WebProviderSurface surface;

    public WebRoomProvider(String id, String name, WebProviderSurface surface) {
        this.id = id; this.name = name; this.surface = surface;
    }

    public WebProviderSurface surface() { return surface; }

    @Override public String id() { return id; }
    @Override public String displayName() { return name; }
    @Override public Set<String> capabilities() { return Collections.singleton("GENERAL"); }

    /** Connected = a conversation is bound and the page renderer is alive. Anything else is "needs setup". */
    @Override public boolean isAvailable() { return !surface.rendererGone() && surface.binding() != null; }

    @Override
    public void send(String prompt, Listener l) {
        surface.sendTurn(prompt, TURN_TIMEOUT_MS, new WebProviderSurface.TurnListener() {
            @Override public void onSubmitted(String providerUserMsgId) { l.onAccepted(providerUserMsgId); }
            @Override public void onReply(String text, String providerAsstMsgId) { l.onReply(text, providerAsstMsgId); }
            @Override public void onReplyWithFiles(String text, String providerAsstMsgId, java.util.List<FileOffer> offers) {
                if (offers == null || offers.isEmpty()) { l.onReply(text, providerAsstMsgId); return; }
                java.util.List<FileIntent> files = new java.util.ArrayList<>();
                for (FileOffer o : offers) files.add(new FileIntent(o.name, o.mime));
                l.onReplyWithFiles(text, providerAsstMsgId, files);
            }
            @Override public void onFailed(String reason, boolean maybeSubmitted) { l.onError(reason, maybeSubmitted); }
        });
    }

    @Override public void cancel() { surface.cancelTurn(); }

    @Override public void requestStop(java.util.function.Consumer<SubmitPhase> result) { surface.stopTurn(result); }
}
