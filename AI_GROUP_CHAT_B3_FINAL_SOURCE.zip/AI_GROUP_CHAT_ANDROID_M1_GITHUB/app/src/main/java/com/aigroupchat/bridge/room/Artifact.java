package com.aigroupchat.bridge.room;

/** A file that belongs to one room. Immutable: a change produces a new object. Once READY, size/hash/path/name/type never change (the database enforces it). */
public final class Artifact {
    public static final String ORIGIN_USER = "user";   // otherwise the id of the AI that produced the file
    public final String id, roomId, origin, displayName, mime, sha256, storagePath;
    /** The exact conversation (binding id) an AI produced this file in; null ONLY for the user's files (an AI file always names it). Fixed for good. */
    public final String sourceBindingId;
    public final long size;                              // -1 until READY
    public final ArtifactState state;
    public final long createdAt;

    public Artifact(String id, String roomId, String origin, String displayName, String mime, long size, String sha256, String storagePath, ArtifactState state, long createdAt) {
        this(id, roomId, origin, null, displayName, mime, size, sha256, storagePath, state, createdAt);
    }

    public Artifact(String id, String roomId, String origin, String sourceBindingId, String displayName, String mime, long size, String sha256, String storagePath, ArtifactState state, long createdAt) {
        this.sourceBindingId = sourceBindingId;
        this.id = id; this.roomId = roomId; this.origin = origin; this.displayName = displayName; this.mime = mime == null ? "" : mime;
        this.size = size; this.sha256 = sha256 == null ? "" : sha256; this.storagePath = storagePath == null ? "" : storagePath;
        this.state = state; this.createdAt = createdAt;
    }

    public boolean fromUser() { return ORIGIN_USER.equals(origin); }

    @Override public String toString() { return "Artifact{" + id + " " + displayName + " " + state + "}"; }
}
