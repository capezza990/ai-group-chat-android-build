package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/** Decides whether a provider turn may be sent. Every required file must either already be in this provider conversation (VERIFIED), or be visibly attached in the
 *  composer for this send (STAGED). A plain-text conversation never reaches any file machinery: one query, no writes, OPEN. */
public final class ArtifactGate {
    /** After this many failed tries a file is not sent again automatically; the turn is blocked with a clear reason. */
    public static final int MAX_ATTEMPTS = 3;

    private final RoomStore store;
    private final Predicate<Artifact> intact; // checks the stored bytes still match size and hash (null = skip); only asked for files not yet in the AI's conversation

    public ArtifactGate(RoomStore store, Predicate<Artifact> intact) { this.store = store; this.intact = intact; }

    /** True only when this AI already holds the file in its CURRENT conversation BECAUSE it produced it there: the file records the exact conversation it was produced in, and that must be
     *  the AI's active conversation now. The AI's name alone proves nothing: after a rebind the AI is in a different conversation that has never seen the file. */
    public static boolean producedInCurrentConversation(Artifact a, String providerId, String activeBindingId) {
        return a.sourceBindingId != null && activeBindingId != null && providerId.equals(a.origin) && a.sourceBindingId.equals(activeBindingId);
    }

    /** afterSeq/uptoSeq: the messages this turn's prompt includes (afterSeq, uptoSeq]. May create PENDING transfer rows, but only when files are actually involved. */
    public GateDecision evaluate(String roomId, String providerId, long afterSeq, long uptoSeq, long now) {
        List<AttachedArtifact> attached = store.attachmentsBetween(roomId, afterSeq, uptoSeq);
        if (attached.isEmpty()) return GateDecision.open();
        final String activeBinding = store.activeBindingId(roomId, providerId);
        Map<String, Artifact> needed = new LinkedHashMap<>(); // one entry per file even if several messages carry it, in message order
        for (AttachedArtifact a : attached) {
            if (producedInCurrentConversation(a.artifact, providerId, activeBinding)) continue; // produced by this AI in the very conversation it is in now: it already has the file
            if (!needed.containsKey(a.artifact.id)) needed.put(a.artifact.id, a.artifact);
        }
        if (needed.isEmpty()) return GateDecision.open();
        String who = nameOf(providerId);
        List<ArtifactTransfer> startable = new ArrayList<>();
        List<Artifact> awaiting = new ArrayList<>();
        boolean sending = false;
        List<ArtifactTransfer> staged = new ArrayList<>();
        for (Artifact a : needed.values()) {
            switch (a.state) {
                case FAILED: return GateDecision.blocked("\"" + a.displayName + "\" could not be saved, so " + who + " cannot receive it");
                case PENDING_CAPTURE: awaiting.add(a); continue;
                default: break;
            }
            ArtifactTransfer t = store.currentTransfer(a.id, roomId, providerId);
            if (t != null && t.state == TransferState.VERIFIED) continue;
            if (t != null && t.state == TransferState.STAGED) { staged.add(t); continue; }
            if (intact != null && !intact.test(a)) return GateDecision.blocked("\"" + a.displayName + "\" is missing or damaged on this device");
            if (t == null) {
                t = store.ensureTransfer(a.id, roomId, providerId, now);
                if (t == null) return GateDecision.blocked(who + " is not connected to a conversation in this room, so \"" + a.displayName + "\" cannot be sent");
            }
            switch (t.state) {
                case PENDING: startable.add(t); break;
                case SENDING: sending = true; break;
                case FAILED:
                    if (t.attempts >= MAX_ATTEMPTS) return GateDecision.blocked("\"" + a.displayName + "\" could not be sent to " + who + " after " + t.attempts + " tries" + (t.error.isEmpty() ? "" : " (" + t.error + ")"));
                    startable.add(t);
                    break;
                default: break; // STAGED and VERIFIED handled above
            }
        }
        if (startable.isEmpty() && awaiting.isEmpty() && !sending) return !staged.isEmpty() ? GateDecision.readyToSend(staged) : GateDecision.open();
        String why = !awaiting.isEmpty() ? "waiting for \"" + awaiting.get(0).displayName + "\" to finish saving" : "sending files to " + who;
        return GateDecision.working(why, startable, awaiting);
    }

    private String nameOf(String providerId) {
        ProviderInfo p = store.getProvider(providerId);
        return p != null ? p.displayName : providerId;
    }
}
