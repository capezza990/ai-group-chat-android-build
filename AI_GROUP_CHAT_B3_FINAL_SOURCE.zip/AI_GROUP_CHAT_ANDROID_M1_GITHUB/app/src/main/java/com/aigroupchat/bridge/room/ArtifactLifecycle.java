package com.aigroupchat.bridge.room;

import java.io.File;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * The ONE app-wide {@link ArtifactService} and the choreography around the screens that come and go. A screen owns its provider pages (WebViews), but the
 * service (and its single-flight slot) must survive the screen, so the service talks to "switchable" transports that forward to whichever screen is attached.
 *
 * <p>Rules (all tested off-device): there is exactly one service for the whole life of the process; a screen attaches its transports and detaches when it is
 * destroyed; detaching FIRST cancels/resolves the running file job (while the transports still reach the live pages), then drops the service's listener, then
 * unlinks the transports; only the attached owner can detach (a late detach from an old screen never pulls the new screen's pages away); attaching a new owner
 * implicitly detaches the old one; with nothing attached a job fails at once instead of hanging the single-flight slot.
 */
public final class ArtifactLifecycle {
    private final ArtifactService service;
    private final SwitchableTransport upload;
    private final SwitchableCaptureTransport capture;
    private Object owner;

    private ArtifactLifecycle(ArtifactService service, SwitchableTransport upload, SwitchableCaptureTransport capture) {
        this.service = service; this.upload = upload; this.capture = capture;
    }

    public static ArtifactLifecycle create(RoomStore store, ArtifactStorage storage, LongSupplier clock, Supplier<String> ids, long maxFileBytes) {
        SwitchableTransport u = new SwitchableTransport();
        SwitchableCaptureTransport c = new SwitchableCaptureTransport();
        return new ArtifactLifecycle(new ArtifactService(store, storage, u, c, clock, ids, maxFileBytes), u, c);
    }

    /** The same instance for the whole life of the process. */
    public ArtifactService service() { return service; }

    public synchronized boolean isAttached() { return owner != null; }

    public synchronized void attach(Object newOwner, ArtifactService.Transport uploadTarget, ArtifactService.CaptureTransport captureTarget) {
        if (newOwner == null) throw new IllegalArgumentException("an owner is required");
        if (owner != null) detachLocked();   // a new screen replaces the old one: the old screen's running job is resolved first
        owner = newOwner;
        upload.setTarget(uploadTarget);
        capture.setTarget(captureTarget);
    }

    /** Only the attached owner can detach. Returns false (and changes nothing) for anyone else. */
    public synchronized boolean detach(Object whoever) {
        if (whoever == null || owner != whoever) return false;
        detachLocked();
        return true;
    }

    private void detachLocked() {
        service.cancelInFlight();   // FIRST: the running job is cancelled/resolved while the transports still reach the live pages
        service.setListener(null);  // nobody is listening any more
        upload.setTarget(null);
        capture.setTarget(null);
        owner = null;
    }

    // ------------------------------------------------------------------------------------------------ switchable transports

    private static final class SwitchableTransport implements ArtifactService.Transport {
        private volatile ArtifactService.Transport target;
        private volatile StagedExpiryListener expiry;

        void setTarget(ArtifactService.Transport t) {
            target = t;
            StagedExpiryListener l = expiry;
            if (t != null && l != null) t.setStagedExpiryListener(l);   // the service registered its listener once; every new screen's transport must get it
        }

        @Override public void transfer(Artifact artifact, File file, ArtifactTransfer transfer, Callback callback) {
            ArtifactService.Transport t = target;
            if (t == null) { callback.onFailed("the provider pages are not available right now"); return; }   // never leave the single-flight slot hanging
            t.transfer(artifact, file, transfer, callback);
        }

        @Override public void cancel() { ArtifactService.Transport t = target; if (t != null) t.cancel(); }

        @Override public void invalidateStaged(String roomId, String providerId, String bindingId) {
            ArtifactService.Transport t = target;
            if (t != null) t.invalidateStaged(roomId, providerId, bindingId);
        }

        @Override public void setStagedExpiryListener(StagedExpiryListener listener) {
            expiry = listener;
            ArtifactService.Transport t = target;
            if (t != null) t.setStagedExpiryListener(listener);
        }
    }

    private static final class SwitchableCaptureTransport implements ArtifactService.CaptureTransport {
        private volatile ArtifactService.CaptureTransport target;

        void setTarget(ArtifactService.CaptureTransport t) { target = t; }

        @Override public void capture(Artifact intent, Callback callback) {
            ArtifactService.CaptureTransport t = target;
            if (t == null) { callback.onFailed("the provider pages are not available right now"); return; }
            t.capture(intent, callback);
        }

        @Override public void cancel() { ArtifactService.CaptureTransport t = target; if (t != null) t.cancel(); }
    }
}
