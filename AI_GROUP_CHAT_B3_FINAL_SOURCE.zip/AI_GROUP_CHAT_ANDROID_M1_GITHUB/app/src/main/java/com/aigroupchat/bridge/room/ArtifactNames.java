package com.aigroupchat.bridge.room;

/** The ONE place a file name becomes safe canonical metadata. Both stores run every artifact name through here when the row is created, so what is saved (and what the
 *  screen and the prompts show) is already clean. It never decides where a file is stored: the storage path comes from the room id and artifact id only. */
public final class ArtifactNames {
    public static final int MAX_LENGTH = 120;      // characters (not bytes)
    private static final int MAX_EXTENSION = 12;   // an extension this short survives shortening
    private static final String FALLBACK = "file";

    private ArtifactNames() {}

    /** Keeps spaces and any language. Path separators become "_"; control characters and invisible direction marks (which can disguise a name) are removed; surrounding
     *  white space is trimmed; an empty name, "." or ".." becomes "file"; a very long name is shortened but keeps a short extension. Cleaning twice changes nothing. */
    public static String clean(String raw) {
        if (raw == null) return FALLBACK;
        StringBuilder sb = new StringBuilder(raw.length());
        for (int i = 0; i < raw.length(); ) {
            int cp = raw.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == '/' || cp == '\\') sb.append('_');
            else if (Character.isISOControl(cp) || isInvisibleMark(cp)) continue;
            else sb.appendCodePoint(cp);
        }
        String n = trim(sb.toString());
        if (n.isEmpty() || n.equals(".") || n.equals("..")) return FALLBACK;
        return cap(n);
    }

    private static boolean isInvisibleMark(int cp) {
        return (cp >= 0x200B && cp <= 0x200F) || (cp >= 0x202A && cp <= 0x202E) || (cp >= 0x2060 && cp <= 0x2064) || (cp >= 0x2066 && cp <= 0x2069) || cp == 0xFEFF;
    }

    private static String trim(String s) {
        int a = 0, b = s.length();
        while (a < b && Character.isWhitespace(s.codePointAt(a))) a += Character.charCount(s.codePointAt(a));
        while (b > a && Character.isWhitespace(s.codePointBefore(b))) b -= Character.charCount(s.codePointBefore(b));
        return s.substring(a, b);
    }

    private static String cap(String n) {
        if (n.codePointCount(0, n.length()) <= MAX_LENGTH) return n;
        int dot = n.lastIndexOf('.');
        String ext = dot > 0 ? n.substring(dot) : "";
        int extLen = ext.codePointCount(0, ext.length());
        if (extLen > MAX_EXTENSION) { ext = ""; extLen = 0; }
        String base = dot > 0 && !ext.isEmpty() ? n.substring(0, dot) : n;
        int keep = MAX_LENGTH - extLen;
        String cut = base.substring(0, base.offsetByCodePoints(0, Math.min(keep, base.codePointCount(0, base.length()))));
        cut = trim(cut);
        if (cut.isEmpty()) cut = FALLBACK;
        return cut + ext;
    }
}
