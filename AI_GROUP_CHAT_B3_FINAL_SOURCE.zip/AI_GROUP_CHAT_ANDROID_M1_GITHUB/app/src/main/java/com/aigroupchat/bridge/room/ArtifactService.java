package com.aigroupchat.bridge.room;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

/** Moves file bytes around, one job at a time for the WHOLE app (a transfer into an AI's conversation or the capture of a file an AI produced, never two at once).
 *  It only coordinates: the provider-specific mechanics (WebView upload, download capture) are plugged in as Transport / CaptureTransport. Every state change goes through the store,
 *  so the database rules (final VERIFIED, one SENDING, counted attempts) apply to everything this class does. Callbacks may arrive on any thread and may repeat.
 *  ONE instance per app process: the single-flight token lives in the instance, so the app must create it once (e.g. in the Application object) and share it across screens. */
public final class ArtifactService {
    public static final long DEFAULT_MAX_FILE_BYTES = 25L * 1024 * 1024;

    /** Puts the file into the provider composer and confirms it is visibly staged there. Must report exactly one result. */
    public interface Transport {
        interface Callback { void onStaged(); void onFailed(String reason); }
        interface StagedExpiryListener { void onExpired(String roomId, String providerId, String bindingId); }
        void transfer(Artifact artifact, File file, ArtifactTransfer transfer, Callback callback);
        void cancel();
        /** A controller/store decision invalidated staged rows. The WebView may clean an IDLE staged composer, but must not disturb an active turn. */
        default void invalidateStaged(String roomId, String providerId, String bindingId) { }
        /** WebView idle-expiry reports back so the database rows become retryable too. */
        default void setStagedExpiryListener(StagedExpiryListener listener) { }
    }

    /** Fetches the bytes of a file an AI produced. Must report exactly one result; the stream is read and closed by the service. */
    public interface CaptureTransport {
        interface Callback { void onBytes(InputStream in, String mime); void onFailed(String reason); }
        void capture(Artifact intent, Callback callback);
        void cancel();
    }

    private final RoomStore store;
    private final ArtifactStorage storage;
    private final Transport transport;
    private final CaptureTransport capture;
    private final LongSupplier clock;
    private final Supplier<String> ids;
    private final long maxFileBytes;
    private final ArtifactGate gate;
    private final Object lock = new Object();
    private boolean busy;            // the single-flight token: one transfer or one capture in the whole app
    private Job activeJob;           // who holds the token right now (null when it is free)

    /** One running transfer or capture. Whoever CLAIMS it ends it: either the job reporting its own result, or Stop. A result that arrives after the job was claimed is ignored, so a late
     *  or repeated callback can never change anything, and the single-flight slot is freed exactly once. */
    private static final class Job {
        final boolean transfer;
        final ArtifactTransfer t;   // transfer jobs
        final Artifact a;           // capture jobs
        private boolean claimed;
        volatile boolean stopped;   // true when STOP (not the job itself) claimed it
        Job(ArtifactTransfer t) { this.transfer = true; this.t = t; this.a = null; }
        Job(Artifact a) { this.transfer = false; this.t = null; this.a = a; }
        synchronized boolean claim() { if (claimed) return false; claimed = true; return true; }
    }
    private final java.util.ArrayDeque<Artifact> captureQueue = new java.util.ArrayDeque<>();   // files whose bytes still have to be fetched, oldest first
    private Runnable listener = () -> { };

    public ArtifactService(RoomStore store, ArtifactStorage storage, Transport transport, CaptureTransport capture, LongSupplier clock, Supplier<String> ids, long maxFileBytes) {
        this.store = store; this.storage = storage; this.transport = transport; this.capture = capture; this.clock = clock; this.ids = ids; this.maxFileBytes = maxFileBytes;
        this.gate = new ArtifactGate(store, storage::isIntact);
        if (transport != null) transport.setStagedExpiryListener((room, provider, binding) ->
                failStagedBinding(room, provider, binding, "staged attachment expired before the turn was sent", false));
    }

    /** Called (on any thread) every time a transfer or capture has finished, successfully or not. */
    public void setListener(Runnable r) { synchronized (lock) { listener = r == null ? () -> { } : r; } }

    public GateDecision evaluate(String roomId, String providerId, long afterSeq, long uptoSeq) {
        return gate.evaluate(roomId, providerId, afterSeq, uptoSeq, clock.getAsLong());
    }

    public boolean isBusy() { synchronized (lock) { return busy; } }

    /** Commits ONLY the exact transfer rows that this accepted send carried, and only ALL of them: every expected row must still be STAGED. If even one is not (it was reset by
     *  Stop, an expiry or a cleaned composer while the message was on its way) the accepted message cannot be trusted to carry the set we staged, so NOTHING is marked VERIFIED
     *  and whatever is still STAGED becomes retryable (a file may then be sent twice, which is harmless; a file wrongly believed delivered is not). */
    public int commitStaged(List<ArtifactTransfer> expected) {
        if (expected == null || expected.isEmpty()) return 0;
        return store.atomic(() -> {
            java.util.LinkedHashMap<String, ArtifactTransfer> unique = new java.util.LinkedHashMap<>();
            for (ArtifactTransfer e : expected) if (e != null) unique.putIfAbsent(e.artifactId + "\n" + e.bindingId, e);
            java.util.HashSet<String> stagedNow = new java.util.HashSet<>();
            for (ArtifactTransfer t : store.transfersInState(TransferState.STAGED)) stagedNow.add(t.artifactId + "\n" + t.bindingId);
            final long now = clock.getAsLong();
            if (!stagedNow.containsAll(unique.keySet())) {   // the whole expected set is checked BEFORE any row changes
                for (ArtifactTransfer e : unique.values())
                    store.transitionTransfer(e.artifactId, e.bindingId, new TransferState[]{TransferState.STAGED}, TransferState.FAILED, "the staged set changed before the provider accepted the message", now);
                return 0;
            }
            int changed = 0;
            for (ArtifactTransfer e : unique.values())   // inside one transaction nothing can change between the check above and these moves
                if (store.transitionTransfer(e.artifactId, e.bindingId, new TransferState[]{TransferState.STAGED}, TransferState.VERIFIED, null, now)) changed++;
            return changed;
        });
    }

    /** Makes uncommitted composer attachments retryable for this provider's ACTIVE binding. */
    public int failStaged(String roomId, String providerId, String reason) {
        final String bindingId = store.activeBindingId(roomId, providerId);
        if (bindingId == null) return 0;
        return failStagedBinding(roomId, providerId, bindingId, reason, true);
    }

    private int failStagedBinding(String roomId, String providerId, String bindingId, String reason, boolean notifyTransport) {
        final String why = reason == null || reason.isEmpty() ? "the staged attachment was not accepted" : reason;
        int changed = store.atomic(() -> {
            int n = 0;
            for (ArtifactTransfer t : store.transfersInState(TransferState.STAGED)) {
                if (!t.roomId.equals(roomId) || !t.providerId.equals(providerId) || !t.bindingId.equals(bindingId)) continue;
                if (store.transitionTransfer(t.artifactId, t.bindingId, new TransferState[]{TransferState.STAGED}, TransferState.FAILED, why, clock.getAsLong())) n++;
            }
            return n;
        });
        if (changed > 0 && notifyTransport && transport != null) transport.invalidateStaged(roomId, providerId, bindingId);
        return changed;
    }

    // ------------------------------------------------------------------ doing the work

    /** Starts at most ONE job for a WORKING decision: first a capture that is waiting, otherwise the next transfer. Returns whether something started. */
    public boolean advance(GateDecision d) {
        if (d == null || d.kind != GateDecision.Kind.WORKING) return false;
        for (Artifact a : d.awaitingCapture) if (startCapture(a)) return true;
        for (ArtifactTransfer t : d.startable) if (startTransfer(t)) return true;
        return false;
    }

    /** Queues the files whose bytes must be fetched and starts the first one. They are fetched one at a time: each one's end starts the next (nothing waits for a later turn). */
    public void startCaptures(List<Artifact> intents) {
        synchronized (lock) {
            for (Artifact a : intents) {
                if (a.state != ArtifactState.PENDING_CAPTURE) continue;
                boolean queued = false;
                for (Artifact q : captureQueue) if (q.id.equals(a.id)) queued = true;
                if (!queued) captureQueue.addLast(a);
            }
        }
        pumpCaptures();
    }

    /** Starts the next queued capture if the slot is free. A file that is no longer waiting for bytes (or cannot be captured at all) is dropped; a lost race puts it back. */
    private void pumpCaptures() {
        while (true) {
            Artifact next;
            synchronized (lock) {
                if (busy || captureQueue.isEmpty()) return;
                next = captureQueue.pollFirst();
            }
            if (startCapture(next)) return;                       // running: its end pumps again
            synchronized (lock) { if (busy) { captureQueue.addFirst(next); return; } }   // someone else took the slot a moment ago
        }
    }

    private boolean acquire(Job job) { synchronized (lock) { if (busy) return false; busy = true; activeJob = job; return true; } }

    private void release() { Runnable l; synchronized (lock) { busy = false; activeJob = null; l = listener; } l.run(); }

    private void releaseQuietly() { synchronized (lock) { busy = false; activeJob = null; } }

    private static void cancelQuietly(Runnable r) { try { r.run(); } catch (RuntimeException ignored) { } }

    private boolean startTransfer(ArtifactTransfer t) {
        if (transport == null) return false;
        final Job job = new Job(t);
        if (!acquire(job)) return false;
        final long now = clock.getAsLong();
        final boolean moved;
        try {
            moved = store.transitionTransfer(t.artifactId, t.bindingId, new TransferState[]{TransferState.PENDING, TransferState.FAILED}, TransferState.SENDING, null, now);
        } catch (RuntimeException e) { releaseQuietly(); throw e; }
        if (!moved) { releaseQuietly(); return false; }   // someone else moved it, or the database says another transfer is sending
        if (job.stopped) { // Stop arrived between taking the slot and starting: Stop already freed the slot, so only record that this transfer never ran
            store.transitionTransfer(t.artifactId, t.bindingId, new TransferState[]{TransferState.SENDING}, TransferState.FAILED, "cancelled", clock.getAsLong());
            return true;
        }
        final Artifact a = store.getArtifact(t.artifactId);
        ArtifactTransfer sending = null;
        for (ArtifactTransfer s : store.transfersInState(TransferState.SENDING)) if (s.artifactId.equals(t.artifactId) && s.bindingId.equals(t.bindingId)) sending = s;
        final File file = a == null ? null : storage.fileOf(a.storagePath);
        if (a == null || sending == null || file == null || !storage.isIntact(a)) { if (job.claim()) finishTransfer(t, false, "the file is missing or damaged on this device"); return true; }
        try {
            transport.transfer(a, file, sending, new Transport.Callback() {
                @Override public void onStaged() { if (job.claim()) finishTransfer(t, true, null); }
                @Override public void onFailed(String reason) { if (job.claim()) finishTransfer(t, false, reason == null || reason.isEmpty() ? "the transfer failed" : reason, true); }
            });
        } catch (RuntimeException e) {
            if (job.claim()) finishTransfer(t, false, e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
        if (job.stopped) cancelQuietly(transport::cancel);   // Stop won while the upload was being started: stop what was just started (best effort)
        return true;
    }

    private void finishTransfer(ArtifactTransfer t, boolean ok, String reason) { finishTransfer(t, ok, reason, false); }

    /** composerCleaned: the transport reports a failed upload, and a failed upload CLEANS the provider composer (every chip in it is removed). Files staged earlier for the same
     *  send are then no longer in the composer, so they go back to FAILED (retryable) BEFORE anyone looks at the gate again; otherwise the next acceptance could mark a file
     *  VERIFIED that was never sent. */
    private void finishTransfer(ArtifactTransfer t, boolean ok, String reason, boolean composerCleaned) {
        try {
            store.transitionTransfer(t.artifactId, t.bindingId, new TransferState[]{TransferState.SENDING}, ok ? TransferState.STAGED : TransferState.FAILED, ok ? null : reason, clock.getAsLong());
            if (!ok && composerCleaned) failStaged(t.roomId, t.providerId, "the provider composer was cleaned after another file failed to upload");
        } finally { release(); pumpCaptures(); }
    }

    private boolean startCapture(Artifact a) {
        if (capture == null || a == null) return false;
        Artifact current = store.getArtifact(a.id);                  // the object we were handed may be old: only a file still waiting for its bytes is captured
        if (current == null || current.state != ArtifactState.PENDING_CAPTURE) return false;
        final Job job = new Job(a);
        if (!acquire(job)) return false;
        synchronized (lock) { captureQueue.removeIf(q -> q.id.equals(a.id)); }
        try {
            capture.capture(a, new CaptureTransport.Callback() {
                @Override public void onBytes(InputStream in, String mime) { if (job.claim()) finishCapture(a, in, mime); else closeQuietly(in); }
                @Override public void onFailed(String reason) { if (job.claim()) finishCapture(a, null, null); }
            });
        } catch (RuntimeException e) {
            if (job.claim()) finishCapture(a, null, null);
        }
        if (job.stopped) cancelQuietly(capture::cancel);   // Stop won while the capture was being started: stop what was just started (best effort)
        return true;
    }

    private static void closeQuietly(InputStream in) { if (in != null) try { in.close(); } catch (IOException ignored) { } }

    private void finishCapture(Artifact a, InputStream in, String mime) {
        String stored = null;
        try {
            if (in != null) {
                Artifact now = store.getArtifact(a.id);
                if (now != null && now.state == ArtifactState.PENDING_CAPTURE) storage.deleteOrphan(a.roomId, a.id);   // a file here belongs to nobody (crash before READY): clear it so the capture can be stored
                ArtifactStorage.Stored s = storage.write(a.roomId, a.id, in, maxFileBytes);
                stored = s.relativePath;
                if (store.finalizeArtifact(a.id, mime, s.size, s.sha256, s.relativePath)) return;
            }
            store.failArtifact(a.id);
            if (stored != null) storage.delete(stored);
        } catch (IOException | RuntimeException e) {
            try { store.failArtifact(a.id); } catch (RuntimeException ignored) { }
            if (stored != null) storage.delete(stored);
        } finally {
            closeQuietly(in);
            release();
            pumpCaptures();
        }
    }

    /** Stop. Deterministic whatever the transport does: queued captures become FAILED; the RUNNING job (if it has not already reported) is taken over here: only ITS mechanism is asked to
     *  stop (best effort), its state is resolved at once (transfer -> FAILED "cancelled", capture -> FAILED), the single-flight slot is freed exactly once, and anything the job reports
     *  afterwards is ignored. A job that had already finished (e.g. a capture that already committed READY) is left exactly as it is. */
    public void cancelInFlight() {
        List<Artifact> dropped;
        final Job job;
        synchronized (lock) { dropped = new java.util.ArrayList<>(captureQueue); captureQueue.clear(); job = activeJob; }
        for (Artifact a : dropped) store.failArtifact(a.id);        // the files still waiting to be fetched: FAILED, retryable
        if (job == null || !job.claim()) return;                    // nothing running, or the job is already reporting its own end
        job.stopped = true;
        if (job.transfer) {
            if (transport != null) cancelQuietly(transport::cancel);
            try { store.transitionTransfer(job.t.artifactId, job.t.bindingId, new TransferState[]{TransferState.SENDING}, TransferState.FAILED, "cancelled", clock.getAsLong()); }
            finally { release(); pumpCaptures(); }
        } else {
            if (capture != null) cancelQuietly(capture::cancel);
            try { store.failArtifact(job.a.id); }
            finally { release(); pumpCaptures(); }
        }
    }

    /** Startup clean-up of file bytes, for crashes at the worst moment. Call once at start, after RoomController.recoverOnStart() (which marks interrupted work FAILED) and before any job runs.
     *  For every artifact that never became READY it removes a complete file left at its place (never adopted, never touching a READY artifact's file), forgets a user's half-saved file
     *  (nothing can retry it) and clears stale temporary parts. Returns how many files/rows were removed. */
    public int reconcileStorage() {
        int n = 0;
        for (Artifact a : store.artifactsNotReady()) {
            if (storage.deleteOrphan(a.roomId, a.id)) n++;
            if (a.fromUser() && store.deleteUnreferencedArtifact(a.id)) n++;
        }
        if (!isBusy()) n += storage.cleanTemp();
        return n;
    }

    /** Whether a FAILED AI file can be retried safely: it must have a stored reply identity. The screen shows an explanation instead of a Retry button otherwise. */
    public boolean canRetryCapture(String artifactId) {
        Artifact a = store.getArtifact(artifactId);
        return a != null && a.state == ArtifactState.FAILED && !a.fromUser() && !store.sourceReplyRef(artifactId).isEmpty();
    }

    /** The explicit retry of a file an AI produced whose capture FAILED: back to PENDING_CAPTURE, and any file left at its place by a crash is cleared first. */
    public boolean retryCapture(String artifactId) {
        Artifact a = store.getArtifact(artifactId);
        if (a == null) return false;
        // A later retry must capture exactly the file this reply produced. Without a stored reply identity that cannot be proven (a newer, different
        // file of the same name could be chosen), so it is refused: the user asks the AI to send the file again.
        if (!a.fromUser() && store.sourceReplyRef(artifactId).isEmpty()) return false;
        if (!store.retryArtifact(artifactId)) return false;
        storage.deleteOrphan(a.roomId, a.id);
        return true;
    }

    /** The user chose to try again after the automatic tries ran out: FAILED -> PENDING (error text cleared, the attempt count is kept for the record).
     *  The next turn then gets exactly one more automatic try. Returns whether anything changed. */
    public boolean retryTransfer(String artifactId, String roomId, String providerId) {
        ArtifactTransfer t = store.currentTransfer(artifactId, roomId, providerId);
        if (t == null || t.state != TransferState.FAILED) return false;
        return store.transitionTransfer(artifactId, t.bindingId, new TransferState[]{TransferState.FAILED}, TransferState.PENDING, "", clock.getAsLong());
    }

    // ------------------------------------------------------------------ files the user adds

    /** Copies the user's file into the app's private storage and records it as a READY artifact of this room. Nothing is left behind if anything goes wrong. */
    public Artifact addUserFile(String roomId, String displayName, String mime, InputStream in) throws IOException {
        final String id = ids.get();
        store.createArtifact(id, roomId, Artifact.ORIGIN_USER, displayName, mime, clock.getAsLong());
        String path = null;
        try {
            ArtifactStorage.Stored s = storage.write(roomId, id, in, maxFileBytes);
            path = s.relativePath;
            if (!store.finalizeArtifact(id, mime, s.size, s.sha256, s.relativePath)) throw new IOException("the file could not be recorded");
            return store.getArtifact(id);
        } catch (IOException | RuntimeException e) {
            if (path != null) storage.delete(path);
            store.deleteUnreferencedArtifact(id);
            throw e;
        }
    }

    /** The user dropped a file before sending it: forget it and its stored bytes (only if no message uses it). */
    public boolean discard(String artifactId) {
        Artifact a = store.getArtifact(artifactId);
        if (a == null || !store.deleteUnreferencedArtifact(artifactId)) return false;
        storage.delete(a.storagePath);
        storage.deleteOrphan(a.roomId, a.id);   // a file that never got a recorded path (a crash before READY) lives at the same deterministic place
        return true;
    }
}
