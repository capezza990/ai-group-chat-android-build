package com.aigroupchat.bridge.room;

/** Life of a file in a room. PENDING_CAPTURE: we know the file exists (the intent is saved) but its bytes are not stored yet.
 *  READY: bytes are stored, size and SHA-256 are fixed for good. FAILED: capturing the bytes did not work (can be retried). The database enforces the same moves. */
public enum ArtifactState {
    PENDING_CAPTURE, READY, FAILED;

    public boolean canMoveTo(ArtifactState to) {
        if (this == to) return true;
        return (this == PENDING_CAPTURE && (to == READY || to == FAILED)) || (this == FAILED && to == PENDING_CAPTURE);
    }
}
