package com.aigroupchat.bridge.room;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** The canonical, app-private home of artifact bytes: one file per artifact under one root folder, named <roomId>/<artifactId>.
 *  Bytes are streamed to a temporary file while the size and SHA-256 are computed, and only a COMPLETE file is moved into place, so a half-written file never has a real name.
 *  A stored file is never overwritten. Plain java.io only: the same code runs in the app and in the tests. */
public final class ArtifactStorage {
    /** What was stored. The path is relative to the root (it survives the app folder moving) and is what the artifact row records. */
    public static final class Stored {
        public final String relativePath, sha256;
        public final long size;
        Stored(String relativePath, long size, String sha256) { this.relativePath = relativePath; this.size = size; this.sha256 = sha256; }
    }

    /** The incoming bytes were larger than allowed. Nothing is kept. */
    public static final class TooLargeException extends IOException {
        private static final long serialVersionUID = 1L;
        public TooLargeException(long max) { super("the file is larger than the allowed " + max + " bytes"); }
    }

    private static final String TMP_DIR = ".tmp";
    /** A legal InputStream may return 0 bytes without being at the end. Only -1 is the end; a stream that returns 0 this many times in a row is not making progress and is refused. */
    static final int MAX_EMPTY_READS = 10_000;
    private final File root;

    public ArtifactStorage(File root) { this.root = root; }

    /** Ids become folder and file names, so only plain safe names are accepted (UUIDs and our room ids are). */
    static boolean safeName(String s) {
        if (s == null || s.isEmpty() || s.equals(".") || s.equals("..") || s.startsWith(".")) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.')) return false;
        }
        return true;
    }

    /** Streams the bytes into place. Throws TooLargeException (and keeps nothing) above maxBytes, IOException on any read/write problem (and keeps nothing). Never overwrites. */
    public Stored write(String roomId, String artifactId, InputStream in, long maxBytes) throws IOException {
        if (!safeName(roomId) || !safeName(artifactId)) throw new IllegalArgumentException("unsafe room or artifact id");
        File dir = new File(root, roomId);
        File target = new File(dir, artifactId);
        if (target.exists()) throw new IOException("a file is already stored for artifact " + artifactId);
        File tmpDir = new File(root, TMP_DIR);
        if (!tmpDir.isDirectory() && !tmpDir.mkdirs() && !tmpDir.isDirectory()) throw new IOException("cannot create " + tmpDir);
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) throw new IOException("cannot create " + dir);
        File tmp = File.createTempFile("cap-", ".part", tmpDir);
        boolean done = false;
        try {
            MessageDigest md;
            try { md = MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException e) { throw new IOException(e); }
            long size = 0;
            try (OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[16 * 1024];
                int n, empty = 0;
                while ((n = in.read(buf)) != -1) {
                    if (n == 0) { if (++empty > MAX_EMPTY_READS) throw new IOException("the incoming stream is not making progress"); continue; }
                    empty = 0;
                    size += n;
                    if (size > maxBytes) throw new TooLargeException(maxBytes);
                    md.update(buf, 0, n);
                    out.write(buf, 0, n);
                }
                out.flush();
            }
            if (!tmp.renameTo(target)) throw new IOException("could not move the finished file into place");
            done = true;
            return new Stored(roomId + "/" + artifactId, size, hex(md.digest()));
        } finally {
            if (!done) tmp.delete();
        }
    }

    /** The file an artifact's recorded path points at, or null if there is none or the path would leave the root folder. */
    public File fileOf(String relativePath) {
        if (relativePath == null || relativePath.isEmpty()) return null;
        String[] parts = relativePath.split("/", -1);
        if (parts.length != 2 || !safeName(parts[0]) || !safeName(parts[1])) return null;
        File f = new File(new File(root, parts[0]), parts[1]);
        return f.isFile() ? f : null;
    }

    /** True only if the artifact is READY and its stored file still has exactly the recorded size and SHA-256 (checked again before every upload). */
    public boolean isIntact(Artifact a) {
        if (a == null || a.state != ArtifactState.READY) return false;
        File f = fileOf(a.storagePath);
        if (f == null || f.length() != a.size) return false;
        try (InputStream in = new FileInputStream(f)) {
            return sha256Of(in).equalsIgnoreCase(a.sha256);
        } catch (IOException e) {
            return false;
        }
    }

    /** The SHA-256 (lower-case hex) of everything the stream holds, read to its true end (-1). */
    public static String sha256Of(InputStream in) throws IOException {
        MessageDigest md;
        try { md = MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException e) { throw new IOException(e); }
        byte[] buf = new byte[16 * 1024];
        int n, empty = 0;
        while ((n = in.read(buf)) != -1) {
            if (n == 0) { if (++empty > MAX_EMPTY_READS) throw new IOException("the stream is not making progress"); continue; }
            empty = 0;
            md.update(buf, 0, n);
        }
        return hex(md.digest());
    }

    /** Removes the file at an artifact's deterministic place, if there is one. ONLY for an artifact that is not READY: a complete file with no READY owner can only be left over from a
     *  crash between "file moved into place" and "artifact marked READY" (it is never adopted, because nothing proves it is complete and right). Returns whether a file was removed. */
    public boolean deleteOrphan(String roomId, String artifactId) {
        if (!safeName(roomId) || !safeName(artifactId)) return false;
        File f = new File(new File(root, roomId), artifactId);
        return f.isFile() && f.delete();
    }

    /** Removes leftover temporary parts of writes that never finished. Only call while nothing is being written (at startup). Returns how many were removed. */
    public int cleanTemp() {
        File[] parts = new File(root, TMP_DIR).listFiles();
        int n = 0;
        if (parts != null) for (File f : parts) if (f.isFile() && f.delete()) n++;
        return n;
    }

    /** Removes the stored file (cleanup of an abandoned artifact). True if nothing is left afterwards. */
    public boolean delete(String relativePath) {
        File f = fileOf(relativePath);
        return f == null || f.delete();
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(Character.forDigit((x >> 4) & 15, 16)).append(Character.forDigit(x & 15, 16));
        return sb.toString();
    }
}
