package com.aigroupchat.bridge.room;

/** One file in one AI's conversation thread: tied for good to the artifact, the room, the AI and the exact binding (= conversation) it was made for. Immutable. */
public final class ArtifactTransfer {
    public final String artifactId, roomId, providerId, bindingId, error;
    public final TransferState state;
    public final int attempts;
    public final long updatedAt;

    public ArtifactTransfer(String artifactId, String roomId, String providerId, String bindingId, TransferState state, int attempts, String error, long updatedAt) {
        this.artifactId = artifactId; this.roomId = roomId; this.providerId = providerId; this.bindingId = bindingId;
        this.state = state; this.attempts = attempts; this.error = error == null ? "" : error; this.updatedAt = updatedAt;
    }

    public ArtifactTransfer with(TransferState newState, int newAttempts, String newError, long now) {
        return new ArtifactTransfer(artifactId, roomId, providerId, bindingId, newState, newAttempts, newError, now);
    }

    @Override public String toString() { return "Transfer{" + artifactId + "->" + providerId + " " + state + " x" + attempts + "}"; }
}
