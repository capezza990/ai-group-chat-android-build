package com.aigroupchat.bridge.room;

import java.util.Locale;

/** Pure presentation rules for file chips/cards. Kept out of Android views so the important status/retry wording is unit-testable. */
public final class ArtifactUiRules {
    private ArtifactUiRules() {}

    /** Retry only when the exact reply that produced the file is known: otherwise a newer file of the same name could be captured by mistake. */
    public static boolean canRetryCapture(Artifact a, boolean replyKnown) { return a != null && a.state == ArtifactState.FAILED && !a.fromUser() && replyKnown; }

    public static boolean needsFreshFile(Artifact a, boolean replyKnown) { return a != null && a.state == ArtifactState.FAILED && !a.fromUser() && !replyKnown; }

    public static String freshFileText() { return "This provider didn't expose a stable reply ID, so this file can't be safely retried. Ask the AI to send it again."; }
    public static boolean canRetryTransfer(ArtifactTransfer t) { return t != null && t.state == TransferState.FAILED; }
    public static boolean isTransient(Artifact a) { return a != null && a.state == ArtifactState.PENDING_CAPTURE; }
    public static boolean isTransient(ArtifactTransfer t) { return t != null && (t.state == TransferState.SENDING || t.state == TransferState.STAGED); }

    public static String artifactMeta(Artifact a) {
        if (a == null) return "File unavailable";
        switch (a.state) {
            case PENDING_CAPTURE: return "Saving\u2026";
            case FAILED: return "Couldn't save";
            case READY: return humanBytes(a.size);
            default: return "";
        }
    }

    public static String transferStatus(ArtifactTransfer t, String providerName) {
        if (t == null) return "";
        String who = providerName == null || providerName.trim().isEmpty() ? t.providerId : providerName;
        switch (t.state) {
            case PENDING: return "Queued for " + who;
            case SENDING: return "Uploading to " + who + "\u2026";
            case STAGED: return "Attached for " + who + " \u2022 waiting to send";
            case VERIFIED: return "Delivered to " + who;
            case FAILED:
                String why = t.error == null || t.error.trim().isEmpty() ? "" : " \u2022 " + FailureText.shorten(t.error);
                return "Couldn't send to " + who + why;
            default: return "";
        }
    }

    public static String humanBytes(long bytes) {
        if (bytes < 0) return "";
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024.0) return oneDecimal(kb) + " KB";
        double mb = kb / 1024.0;
        if (mb < 1024.0) return oneDecimal(mb) + " MB";
        return oneDecimal(mb / 1024.0) + " GB";
    }

    private static String oneDecimal(double n) {
        if (Math.abs(n - Math.rint(n)) < 0.05) return String.format(Locale.US, "%.0f", n);
        return String.format(Locale.US, "%.1f", n);
    }
}
