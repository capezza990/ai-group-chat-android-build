package com.aigroupchat.bridge.room;

/** A file attached to a message, with enough about that message to decide whether a given AI needs it. */
public final class AttachedArtifact {
    public final String messageId, authorType, authorId;
    public final long messageSeq;
    public final int position;
    public final Artifact artifact;

    public AttachedArtifact(String messageId, long messageSeq, String authorType, String authorId, int position, Artifact artifact) {
        this.messageId = messageId; this.messageSeq = messageSeq; this.authorType = authorType; this.authorId = authorId; this.position = position; this.artifact = artifact;
    }
}
