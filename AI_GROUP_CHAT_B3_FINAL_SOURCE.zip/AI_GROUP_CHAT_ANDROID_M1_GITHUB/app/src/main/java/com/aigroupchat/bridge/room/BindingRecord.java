package com.aigroupchat.bridge.room;

import com.aigroupchat.bridge.engine.ProviderBinding;

/** One row of a room's binding history for an AI. ACTIVE is the thread in use; RETIRED rows are kept as history. */
public final class BindingRecord {
    public static final String ACTIVE = "ACTIVE", RETIRED = "RETIRED", PENDING_NEW = "PENDING_NEW";

    public final String id, roomId, providerId, conversationId, restoreLocator, displayTitle;
    public final long boundAt;
    public String state;
    public long retiredAt;          // 0 while not retired
    public String retiredReason = ""; // "rebound" | "cleared" | "max_length" | ...

    public BindingRecord(String id, String roomId, String providerId, String state, String conversationId,
                         String restoreLocator, String displayTitle, long boundAt) {
        this.id = id; this.roomId = roomId; this.providerId = providerId; this.state = state;
        this.conversationId = conversationId; this.restoreLocator = restoreLocator; this.displayTitle = displayTitle; this.boundAt = boundAt;
    }

    public BindingRecord copy() {
        BindingRecord r = new BindingRecord(id, roomId, providerId, state, conversationId, restoreLocator, displayTitle, boundAt);
        r.retiredAt = retiredAt; r.retiredReason = retiredReason;
        return r;
    }

    public ProviderBinding toBinding() { return new ProviderBinding(providerId, conversationId, restoreLocator, displayTitle, boundAt); }
}
