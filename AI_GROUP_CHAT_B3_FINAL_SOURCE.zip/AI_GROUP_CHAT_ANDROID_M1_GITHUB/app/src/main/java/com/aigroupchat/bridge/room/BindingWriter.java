package com.aigroupchat.bridge.room;

import com.aigroupchat.bridge.engine.ProviderBinding;

/** Saves or clears a room's binding and PROVES the result by reading it back. Returns null on success, otherwise a short plain-language reason.
 *  A database error is never swallowed and the caller must not tell the user "connected" unless this returned null. */
public final class BindingWriter {
    private BindingWriter() {}

    public static String bind(RoomStore store, String roomId, ProviderBinding b) {
        try {
            store.putBinding(roomId, b);
        } catch (RuntimeException e) {
            return "the room could not save it (" + reason(e) + ")";
        }
        ProviderBinding saved;
        try {
            saved = store.getBinding(roomId, b.providerId);
        } catch (RuntimeException e) {
            return "the room could not confirm it was saved (" + reason(e) + ")";
        }
        if (saved == null || !b.providerConversationId.equals(saved.providerConversationId)) return "the room did not keep it";
        return null;
    }

    public static String clear(RoomStore store, String roomId, String providerId, long now) {
        try {
            store.clearBinding(roomId, providerId, now);
        } catch (RuntimeException e) {
            return "the room could not clear it (" + reason(e) + ")";
        }
        try {
            if (store.getBinding(roomId, providerId) != null) return "the room still has the old connection";
        } catch (RuntimeException e) {
            return "the room could not confirm it was cleared (" + reason(e) + ")";
        }
        return null;
    }

    private static String reason(RuntimeException e) {
        String m = e.getMessage();
        return m == null || m.isEmpty() ? e.getClass().getSimpleName() : m;
    }
}
