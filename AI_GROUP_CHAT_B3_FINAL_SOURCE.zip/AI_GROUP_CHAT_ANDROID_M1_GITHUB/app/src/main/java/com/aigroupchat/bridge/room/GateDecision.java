package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** The answer to "may this AI's turn be sent now?". OPEN: yes, no staged attachment must accompany this send. READY_TO_SEND: yes, all required files are visibly staged in
 *  the provider composer. WORKING: not yet, something is still being saved or uploaded. BLOCKED: no, and it will not fix itself; reason is a short explanation. */
public final class GateDecision {
    public enum Kind { OPEN, READY_TO_SEND, WORKING, BLOCKED }

    public final Kind kind;
    public final String reason;                          // BLOCKED: why. WORKING: what we are waiting for. OPEN: ""
    public final List<ArtifactTransfer> startable;       // WORKING: transfers that could start right now (PENDING, or FAILED with tries left), in message order
    public final List<Artifact> awaitingCapture;         // WORKING: files whose bytes are not stored yet
    public final List<ArtifactTransfer> stagedTransfers; // READY_TO_SEND: exact transfer rows visibly staged for THIS send

    private GateDecision(Kind kind, String reason, List<ArtifactTransfer> startable, List<Artifact> awaitingCapture, List<ArtifactTransfer> stagedTransfers) {
        this.kind = kind; this.reason = reason;
        this.startable = Collections.unmodifiableList(new ArrayList<>(startable));
        this.awaitingCapture = Collections.unmodifiableList(new ArrayList<>(awaitingCapture));
        this.stagedTransfers = Collections.unmodifiableList(new ArrayList<>(stagedTransfers));
    }

    static GateDecision open() { return new GateDecision(Kind.OPEN, "", new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); }
    static GateDecision readyToSend(List<ArtifactTransfer> staged) { return new GateDecision(Kind.READY_TO_SEND, "", new ArrayList<>(), new ArrayList<>(), staged); }
    static GateDecision blocked(String reason) { return new GateDecision(Kind.BLOCKED, reason, new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); }
    static GateDecision working(String reason, List<ArtifactTransfer> startable, List<Artifact> awaiting) { return new GateDecision(Kind.WORKING, reason, startable, awaiting, new ArrayList<>()); }

    @Override public String toString() { return kind + (reason.isEmpty() ? "" : " (" + reason + ")"); }
}
