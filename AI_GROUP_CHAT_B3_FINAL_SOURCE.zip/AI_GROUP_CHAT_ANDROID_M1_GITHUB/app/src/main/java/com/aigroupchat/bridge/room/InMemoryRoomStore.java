package com.aigroupchat.bridge.room;

import com.aigroupchat.bridge.engine.ProviderBinding;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** Reference implementation of RoomStore for the deterministic test harness (mirrors the SQLite constraints). */
public final class InMemoryRoomStore implements RoomStore {
    private final Object lock = new Object();
    private Map<String, RoomSettings> rooms = new LinkedHashMap<>();
    private Map<String, RoomMessage> messages = new LinkedHashMap<>(); // by id, insertion = seq order
    private long nextSeq = 1;
    private Map<String, RoomParticipant> participants = new LinkedHashMap<>(); // key room|provider
    private Map<String, Delivery> deliveries = new LinkedHashMap<>();
    private Map<String, RoomInfo> roomInfos = new LinkedHashMap<>();
    private Map<String, ProviderInfo> providers = new LinkedHashMap<>();
    private List<BindingRecord> bindingRecords = new ArrayList<>();
    private Map<String, Artifact> artifacts = new LinkedHashMap<>();
    private List<String[]> attachments = new ArrayList<>();            // {messageId, artifactId, position}
    private Map<String, ArtifactTransfer> transfers = new LinkedHashMap<>(); // key artifactId|bindingId
    private int depth;

    public InMemoryRoomStore() { // the two core AIs are seeded exactly like the database migration does
        providers.put("chatgpt", new ProviderInfo("chatgpt", "chatgpt", "ChatGPT", "CORE", "https://chatgpt.com", "chatgpt"));
        providers.put("claude", new ProviderInfo("claude", "claude", "Claude", "CORE", "https://claude.ai", "claude"));
    }

    @Override
    public <T> T atomic(Supplier<T> body) {
        synchronized (lock) {
            if (depth > 0) return body.get();
            // snapshot for rollback
            Map<String, RoomSettings> r = new LinkedHashMap<>(rooms);
            Map<String, RoomMessage> m = new LinkedHashMap<>(messages);
            long seq = nextSeq;
            Map<String, RoomParticipant> p = new LinkedHashMap<>();
            for (Map.Entry<String, RoomParticipant> e : participants.entrySet()) p.put(e.getKey(), e.getValue().copy());
            Map<String, Delivery> d = new LinkedHashMap<>();
            for (Map.Entry<String, Delivery> e : deliveries.entrySet()) d.put(e.getKey(), e.getValue().copy());
            Map<String, RoomInfo> ri = new LinkedHashMap<>(roomInfos);
            Map<String, ProviderInfo> pr = new LinkedHashMap<>(providers);
            List<BindingRecord> br = new ArrayList<>();
            for (BindingRecord x : bindingRecords) br.add(x.copy());
            Map<String, Artifact> ar = new LinkedHashMap<>(artifacts);
            List<String[]> at = new ArrayList<>(attachments);
            Map<String, ArtifactTransfer> tr = new LinkedHashMap<>(transfers);
            depth++;
            try {
                return body.get();
            } catch (RuntimeException ex) {
                rooms = r; messages = m; nextSeq = seq; participants = p; deliveries = d;
                roomInfos = ri; providers = pr; bindingRecords = br;
                artifacts = ar; attachments = at; transfers = tr;
                throw ex;
            } finally {
                depth--;
            }
        }
    }

    private static String pk(String room, String provider) { return room + "|" + provider; }

    @Override public RoomSettings ensureRoom(String roomId, long now) {
        synchronized (lock) {
            RoomSettings s = rooms.get(roomId);
            if (s == null) { // implicit creation is for developer/test rooms only
                s = new RoomSettings(roomId, RoutingMode.AUTO_PICK, "", 1, now);
                rooms.put(roomId, s);
                roomInfos.put(roomId, new RoomInfo(roomId, roomId, RoomKind.MOCK, 0, now));
            }
            return s;
        }
    }

    @Override public RoomInfo createRoom(String roomId, String name, RoomKind kind, long now) {
        synchronized (lock) {
            if (rooms.containsKey(roomId)) throw new IllegalStateException("room already exists: " + roomId);
            rooms.put(roomId, new RoomSettings(roomId, RoutingMode.AUTO_PICK, "", 1, now));
            RoomInfo info = new RoomInfo(roomId, name, kind, 0, now);
            roomInfos.put(roomId, info);
            return info;
        }
    }

    @Override public RoomInfo getRoomInfo(String roomId) { synchronized (lock) { return roomInfos.get(roomId); } }

    @Override public List<RoomInfo> listRooms() {
        synchronized (lock) {
            List<RoomInfo> out = new ArrayList<>(roomInfos.values());
            out.sort((x, y) -> x.createdAt != y.createdAt ? Long.compare(x.createdAt, y.createdAt) : x.id.compareTo(y.id));
            return out;
        }
    }

    @Override public void setNaturalMaxTurns(String roomId, int turns) {
        synchronized (lock) {
            RoomInfo info = roomInfos.get(roomId);
            if (info == null) throw new IllegalStateException("FK: unknown room " + roomId);
            if (turns < 0 || turns > 20) throw new IllegalArgumentException("natural_max_turns must be 0..20");
            roomInfos.put(roomId, info.withNaturalMaxTurns(turns));
        }
    }

    @Override public List<ProviderInfo> listProviders(boolean liveOnly) {
        synchronized (lock) {
            List<ProviderInfo> out = new ArrayList<>();
            for (ProviderInfo p : providers.values()) if (!liveOnly || p.isLive()) out.add(p);
            out.sort((x, y) -> Integer.compare(rank(x.kind), rank(y.kind))); // stable: CORE, CUSTOM, then MOCK
            return out;
        }
    }

    private static int rank(String kind) { return "CORE".equals(kind) ? 0 : "CUSTOM".equals(kind) ? 1 : 2; }

    @Override public ProviderInfo getProvider(String providerId) { synchronized (lock) { return providers.get(providerId); } }

    @Override public void ensureMockProvider(String providerId, String displayName) {
        synchronized (lock) {
            if (!providers.containsKey(providerId)) providers.put(providerId, new ProviderInfo(providerId, providerId, displayName, "MOCK", "", "mock"));
        }
    }

    @Override public RoomSettings getRoom(String roomId) { synchronized (lock) { return rooms.get(roomId); } }

    @Override public void saveRoomSettings(RoomSettings s) {
        synchronized (lock) {
            if (!rooms.containsKey(s.roomId)) throw new IllegalStateException("FK: unknown room " + s.roomId);
            rooms.put(s.roomId, s);
        }
    }

    @Override public void upsertParticipant(String roomId, String providerId, int position) {
        synchronized (lock) {
            if (!rooms.containsKey(roomId)) throw new IllegalStateException("FK: unknown room " + roomId);
            if (!providers.containsKey(providerId)) throw new IllegalStateException("FK: unknown provider " + providerId);
            RoomParticipant p = participants.get(pk(roomId, providerId));
            if (p == null) participants.put(pk(roomId, providerId), new RoomParticipant(roomId, providerId, true, position, 0L, "UNKNOWN"));
            else p.enabled = true;
        }
    }

    @Override public void setParticipantEnabled(String roomId, String providerId, boolean enabled) {
        synchronized (lock) {
            RoomParticipant p = participants.get(pk(roomId, providerId));
            if (p != null) p.enabled = enabled;
        }
    }

    @Override public List<RoomParticipant> participants(String roomId) {
        synchronized (lock) {
            List<RoomParticipant> out = new ArrayList<>();
            for (RoomParticipant p : participants.values()) if (p.roomId.equals(roomId)) out.add(p.copy());
            out.sort((a, b) -> a.position != b.position ? Integer.compare(a.position, b.position) : a.providerId.compareTo(b.providerId));
            return out;
        }
    }

    @Override public void advanceContextSeq(String roomId, String providerId, long seq) {
        synchronized (lock) {
            RoomParticipant p = participants.get(pk(roomId, providerId));
            if (p != null && seq > p.contextSeq) p.contextSeq = seq;
        }
    }

    @Override public RoomMessage appendMessage(String roomId, String id, String authorType, String authorId, String text, String replyTo, long now) {
        synchronized (lock) {
            RoomMessage existing = messages.get(id);
            if (existing != null) return RoomIntegrity.messageInRoom(existing, roomId); // an id that belongs to another room is NOT an idempotent repeat
            if (!rooms.containsKey(roomId)) throw new IllegalStateException("FK: unknown room " + roomId);
            RoomMessage m = new RoomMessage(nextSeq++, id, roomId, authorType, authorId, text, now, replyTo);
            messages.put(id, m);
            return m;
        }
    }

    @Override public RoomMessage getMessage(String id) { synchronized (lock) { return messages.get(id); } }

    @Override public List<RoomMessage> messagesBetween(String roomId, long afterSeq, long uptoSeq) {
        synchronized (lock) {
            List<RoomMessage> out = new ArrayList<>();
            for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId) && m.seq > afterSeq && m.seq <= uptoSeq) out.add(m);
            return out;
        }
    }

    @Override public List<RoomMessage> latestMessages(String roomId, int limit) {
        synchronized (lock) {
            List<RoomMessage> all = new ArrayList<>();
            for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId)) all.add(m);
            return new ArrayList<>(all.subList(Math.max(0, all.size() - limit), all.size()));
        }
    }

    @Override public long latestSeq(String roomId) {
        synchronized (lock) {
            long max = 0;
            for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId) && m.seq > max) max = m.seq;
            return max;
        }
    }

    @Override public Delivery createDelivery(String deliveryId, String roomId, String triggerMessageId, String providerId, long uptoSeq, long now) {
        synchronized (lock) {
            for (Delivery d : deliveries.values()) {
                if (d.triggerMessageId.equals(triggerMessageId) && d.providerId.equals(providerId)) return RoomIntegrity.deliveryInRoom(d, roomId).copy();
            }
            RoomMessage trigger = messages.get(triggerMessageId);
            if (trigger == null) throw new IllegalStateException("FK: unknown trigger message");
            if (!trigger.roomId.equals(roomId)) throw new IllegalStateException("FK: trigger message belongs to another room");
            if (!participants.containsKey(pk(roomId, providerId))) throw new IllegalStateException("FK: " + providerId + " has no seat in room " + roomId); // a removed AI keeps its seat row
            Delivery d = new Delivery(deliveryId, roomId, triggerMessageId, providerId, uptoSeq, DeliveryState.PENDING, now, now);
            deliveries.put(deliveryId, d);
            return d.copy();
        }
    }

    @Override public Delivery getDelivery(String id) { synchronized (lock) { Delivery d = deliveries.get(id); return d == null ? null : d.copy(); } }

    @Override public boolean transition(String deliveryId, DeliveryState[] from, DeliveryState to, String error, long now) {
        synchronized (lock) {
            Delivery d = deliveries.get(deliveryId);
            if (d == null) return false;
            boolean ok = false;
            for (DeliveryState f : from) if (d.state == f) ok = true;
            if (!ok) return false;
            d.state = to;
            if (error != null) d.error = error;
            d.updatedAt = now;
            return true;
        }
    }

    @Override public void recordProviderIds(String deliveryId, String providerUserMsgId, String providerAsstMsgId) {
        synchronized (lock) {
            Delivery d = deliveries.get(deliveryId);
            if (d == null) return;
            if (providerUserMsgId != null && !providerUserMsgId.isEmpty()) d.providerUserMsgId = providerUserMsgId;
            if (providerAsstMsgId != null && !providerAsstMsgId.isEmpty()) d.providerAsstMsgId = providerAsstMsgId;
        }
    }

    @Override public void setDeliveryReply(String deliveryId, String replyMessageId) {
        synchronized (lock) {
            Delivery d = deliveries.get(deliveryId);
            if (d == null) return;
            RoomMessage reply = messages.get(replyMessageId);
            if (reply == null) throw new IllegalStateException("FK: unknown reply message");
            if (!reply.roomId.equals(d.roomId)) throw new IllegalStateException("FK: reply message belongs to another room");
            d.replyMessageId = replyMessageId;
        }
    }

    @Override public List<Delivery> deliveriesInState(DeliveryState state) {
        synchronized (lock) {
            List<Delivery> out = new ArrayList<>();
            for (Delivery d : deliveries.values()) if (d.state == state) out.add(d.copy());
            return out;
        }
    }

    @Override public int markInFlightUncertain(long now) {
        synchronized (lock) {
            int n = 0;
            for (Delivery d : deliveries.values()) {
                if (d.state == DeliveryState.SENDING || d.state == DeliveryState.SENT) {
                    d.state = DeliveryState.UNCERTAIN; d.error = "interrupted (app restart)"; d.updatedAt = now; n++;
                }
            }
            return n;
        }
    }

    // ---- room-scoped bindings (mirrors the SQLite rules: one current binding per room+AI, seat required, history kept)

    private BindingRecord current(String roomId, String providerId) {
        for (BindingRecord r : bindingRecords) {
            if (r.roomId.equals(roomId) && r.providerId.equals(providerId) && !BindingRecord.RETIRED.equals(r.state)) return r;
        }
        return null;
    }

    @Override public ProviderBinding getBinding(String roomId, String providerId) {
        synchronized (lock) {
            BindingRecord r = current(roomId, providerId);
            return r != null && BindingRecord.ACTIVE.equals(r.state) ? r.toBinding() : null;
        }
    }

    @Override public void putBinding(String roomId, ProviderBinding b) {
        synchronized (lock) {
            if (!participants.containsKey(pk(roomId, b.providerId))) throw new IllegalStateException("FK: " + b.providerId + " is not seated in room " + roomId);
            if (b.providerConversationId == null || b.providerConversationId.isEmpty()) throw new IllegalArgumentException("an ACTIVE binding needs a conversation id");
            BindingRecord cur = current(roomId, b.providerId);
            if (cur != null && BindingRecord.ACTIVE.equals(cur.state) && cur.conversationId.equals(b.providerConversationId)) return; // same thread: nothing to do
            if (cur != null) { cur.state = BindingRecord.RETIRED; cur.retiredAt = b.boundAt; cur.retiredReason = "rebound"; }
            bindingRecords.add(new BindingRecord(UUID.randomUUID().toString(), roomId, b.providerId, BindingRecord.ACTIVE,
                    b.providerConversationId, b.restoreLocator, b.displayTitle, b.boundAt));
        }
    }

    @Override public void clearBinding(String roomId, String providerId, long now) {
        synchronized (lock) {
            BindingRecord cur = current(roomId, providerId);
            if (cur != null) { cur.state = BindingRecord.RETIRED; cur.retiredAt = now; cur.retiredReason = "cleared"; }
        }
    }

    @Override public List<BindingRecord> bindingHistory(String roomId, String providerId) {
        synchronized (lock) {
            List<BindingRecord> out = new ArrayList<>();
            for (int i = bindingRecords.size() - 1; i >= 0; i--) {
                BindingRecord r = bindingRecords.get(i);
                if (r.roomId.equals(roomId) && r.providerId.equals(providerId)) out.add(r.copy());
            }
            return out;
        }
    }

    @Override public List<String> otherRoomsUsingThread(String providerId, String conversationId, String exceptRoomId) {
        synchronized (lock) {
            List<String> out = new ArrayList<>();
            for (BindingRecord r : bindingRecords) {
                if (r.providerId.equals(providerId) && BindingRecord.ACTIVE.equals(r.state) && r.conversationId.equals(conversationId)
                        && !r.roomId.equals(exceptRoomId) && !out.contains(r.roomId)) out.add(r.roomId);
            }
            return out;
        }
    }

    // ---- artifacts and transfers (mirrors the SQLite rules)
    private static boolean validSha(String h) {
        if (h == null || h.length() != 64) return false;
        for (int i = 0; i < 64; i++) if (Character.digit(h.charAt(i), 16) < 0) return false;
        return true;
    }

    @Override public Artifact createArtifact(String id, String roomId, String origin, String sourceBindingId, String displayName, String mime, long now) {
        synchronized (lock) {
            if (!rooms.containsKey(roomId)) throw new IllegalStateException("FK: unknown room " + roomId);
            if (artifacts.containsKey(id)) throw new IllegalStateException("artifact already exists: " + id);
            if (origin == null || origin.isEmpty()) throw new IllegalArgumentException("an artifact must say where it came from");
            if (!Artifact.ORIGIN_USER.equals(origin) && sourceBindingId == null) throw new IllegalArgumentException("an AI file must name the conversation it came from");
            if (sourceBindingId != null) {
                if (Artifact.ORIGIN_USER.equals(origin)) throw new IllegalArgumentException("a user file has no source conversation");
                boolean found = false;   // the binding must be in THIS room and belong to the AI named as origin
                for (BindingRecord r : bindingRecords) if (r.id.equals(sourceBindingId) && r.roomId.equals(roomId) && r.providerId.equals(origin) && !BindingRecord.PENDING_NEW.equals(r.state)) found = true;   // a conversation that never existed (PENDING_NEW) cannot be a source
                if (!found) throw new IllegalStateException("FK: the source conversation is not a conversation of " + origin + " in this room");
            }
            Artifact a = new Artifact(id, roomId, origin, sourceBindingId, ArtifactNames.clean(displayName), mime, -1L, "", "", ArtifactState.PENDING_CAPTURE, now);
            artifacts.put(id, a);
            return a;
        }
    }

    @Override public Artifact getArtifact(String id) { synchronized (lock) { return artifacts.get(id); } }

    @Override public boolean finalizeArtifact(String id, String mime, long size, String sha256, String storagePath) {
        synchronized (lock) {
            Artifact a = artifacts.get(id);
            if (a == null) return false;
            if (size < 0 || !validSha(sha256) || storagePath == null || storagePath.isEmpty()) throw new IllegalArgumentException("a READY artifact needs size >= 0, a 64-character hex SHA-256 and a storage path");
            if (a.state == ArtifactState.READY) { // idempotent repeat of the same capture; anything different is refused
                return a.size == size && a.sha256.equalsIgnoreCase(sha256) && a.storagePath.equals(storagePath) && (mime == null || a.mime.equals(mime));
            }
            if (a.state != ArtifactState.PENDING_CAPTURE) return false;
            artifacts.put(id, new Artifact(a.id, a.roomId, a.origin, a.sourceBindingId, a.displayName, mime == null ? a.mime : mime, size, sha256, storagePath, ArtifactState.READY, a.createdAt));
            return true;
        }
    }

    private boolean moveArtifact(String id, ArtifactState from, ArtifactState to) {
        Artifact a = artifacts.get(id);
        if (a == null || a.state != from) return false;
        artifacts.put(id, new Artifact(a.id, a.roomId, a.origin, a.sourceBindingId, a.displayName, a.mime, a.size, a.sha256, a.storagePath, to, a.createdAt));
        return true;
    }

    @Override public boolean failArtifact(String id) { synchronized (lock) { return moveArtifact(id, ArtifactState.PENDING_CAPTURE, ArtifactState.FAILED); } }

    @Override public boolean retryArtifact(String id) { synchronized (lock) { return moveArtifact(id, ArtifactState.FAILED, ArtifactState.PENDING_CAPTURE); } }

    @Override public void attachArtifact(String messageId, String artifactId, int position) {
        synchronized (lock) {
            RoomMessage m = messages.get(messageId);
            if (m == null) throw new IllegalStateException("FK: unknown message " + messageId);
            Artifact a = artifacts.get(artifactId);
            if (a == null) throw new IllegalStateException("FK: unknown artifact " + artifactId);
            if (!a.roomId.equals(m.roomId)) throw new IllegalStateException("FK: artifact and message belong to different rooms");
            for (String[] row : attachments) if (row[0].equals(messageId) && row[1].equals(artifactId)) throw new IllegalStateException("already attached");
            attachments.add(new String[]{messageId, artifactId, String.valueOf(position)});
        }
    }

    @Override public List<Artifact> artifactsOfMessage(String messageId) {
        synchronized (lock) {
            List<String[]> rows = new ArrayList<>();
            for (String[] row : attachments) if (row[0].equals(messageId)) rows.add(row);
            rows.sort((x, y) -> Integer.compare(Integer.parseInt(x[2]), Integer.parseInt(y[2])));
            List<Artifact> out = new ArrayList<>();
            for (String[] row : rows) out.add(artifacts.get(row[1]));
            return out;
        }
    }

    @Override public List<AttachedArtifact> attachmentsBetween(String roomId, long afterSeq, long uptoSeq) {
        synchronized (lock) {
            List<AttachedArtifact> out = new ArrayList<>();
            for (String[] row : attachments) {
                RoomMessage m = messages.get(row[0]);
                if (m == null || !m.roomId.equals(roomId) || m.seq <= afterSeq || m.seq > uptoSeq) continue;
                out.add(new AttachedArtifact(m.id, m.seq, m.authorType, m.authorId, Integer.parseInt(row[2]), artifacts.get(row[1])));
            }
            out.sort((x, y) -> x.messageSeq != y.messageSeq ? Long.compare(x.messageSeq, y.messageSeq) : Integer.compare(x.position, y.position));
            return out;
        }
    }

    @Override public List<Artifact> artifactsNotReady() {
        synchronized (lock) {
            List<Artifact> out = new ArrayList<>();
            for (Artifact a : artifacts.values()) if (a.state != ArtifactState.READY) out.add(a);
            return out;
        }
    }

    @Override public String sourceReplyRef(String artifactId) {
        synchronized (lock) {
            Artifact a = artifacts.get(artifactId);
            if (a == null || a.fromUser()) return "";
            String messageId = null;
            for (String[] row : attachments) {
                if (!row[1].equals(artifactId)) continue;
                if (messageId != null) return "";   // attached to more than one message: not provable
                messageId = row[0];
            }
            if (messageId == null) return "";
            String ref = null;
            for (Delivery d : deliveries.values()) {
                if (!messageId.equals(d.replyMessageId)) continue;
                if (ref != null || !a.origin.equals(d.providerId) || !a.roomId.equals(d.roomId)) return "";   // two deliveries, another AI or another room: not provable
                ref = d.providerAsstMsgId;
            }
            return ref == null ? "" : ref;
        }
    }

    @Override public boolean deleteUnreferencedArtifact(String id) {
        synchronized (lock) {
            if (!artifacts.containsKey(id)) return false;
            for (String[] row : attachments) if (row[1].equals(id)) return false;
            for (ArtifactTransfer t : transfers.values()) if (t.artifactId.equals(id)) return false;
            artifacts.remove(id);
            return true;
        }
    }

    private static String tk(String artifactId, String bindingId) { return artifactId + "|" + bindingId; }

    @Override public String activeBindingId(String roomId, String providerId) { synchronized (lock) { BindingRecord r = activeRecord(roomId, providerId); return r == null ? null : r.id; } }

    private BindingRecord activeRecord(String roomId, String providerId) {
        BindingRecord r = current(roomId, providerId);
        return r != null && BindingRecord.ACTIVE.equals(r.state) ? r : null;
    }

    @Override public ArtifactTransfer ensureTransfer(String artifactId, String roomId, String providerId, long now) {
        synchronized (lock) {
            Artifact a = artifacts.get(artifactId);
            if (a == null) throw new IllegalStateException("FK: unknown artifact " + artifactId);
            if (!a.roomId.equals(roomId)) throw new IllegalStateException("FK: artifact belongs to another room");
            if (a.state != ArtifactState.READY) throw new IllegalStateException("a transfer needs a READY artifact");
            BindingRecord b = activeRecord(roomId, providerId);
            if (b == null) return null;
            ArtifactTransfer t = transfers.get(tk(artifactId, b.id));
            if (t == null) { t = new ArtifactTransfer(artifactId, roomId, providerId, b.id, TransferState.PENDING, 0, "", now); transfers.put(tk(artifactId, b.id), t); }
            return t;
        }
    }

    @Override public ArtifactTransfer currentTransfer(String artifactId, String roomId, String providerId) {
        synchronized (lock) {
            BindingRecord b = activeRecord(roomId, providerId);
            if (b == null) return null;
            ArtifactTransfer t = transfers.get(tk(artifactId, b.id));
            return t != null && t.roomId.equals(roomId) ? t : null;
        }
    }

    @Override public boolean transitionTransfer(String artifactId, String bindingId, TransferState[] from, TransferState to, String error, long now) {
        synchronized (lock) {
            ArtifactTransfer t = transfers.get(tk(artifactId, bindingId));
            if (t == null) return false;
            boolean ok = false;
            for (TransferState f : from) if (t.state == f) ok = true;
            if (!ok || !t.state.canMoveTo(to)) return false;
            if (to == TransferState.SENDING && t.state != TransferState.SENDING) {
                for (ArtifactTransfer other : transfers.values()) if (other != t && other.state == TransferState.SENDING) return false; // global single-flight
            }
            int attempts = t.attempts + (to == TransferState.SENDING && t.state != TransferState.SENDING ? 1 : 0);
            transfers.put(tk(artifactId, bindingId), t.with(to, attempts, error != null ? error : t.error, now));
            return true;
        }
    }

    @Override public List<ArtifactTransfer> transfersInState(TransferState state) {
        synchronized (lock) {
            List<ArtifactTransfer> out = new ArrayList<>();
            for (ArtifactTransfer t : transfers.values()) if (t.state == state) out.add(t);
            return out;
        }
    }

    @Override public int markArtifactWorkInterrupted(long now) {
        synchronized (lock) {
            int n = 0;
            for (Map.Entry<String, ArtifactTransfer> e : new ArrayList<>(transfers.entrySet())) {
                ArtifactTransfer t = e.getValue();
                if (t.state == TransferState.SENDING || t.state == TransferState.STAGED) { transfers.put(e.getKey(), t.with(TransferState.FAILED, t.attempts, "interrupted (app restart)", now)); n++; }
            }
            for (Artifact a : new ArrayList<>(artifacts.values())) if (a.state == ArtifactState.PENDING_CAPTURE && moveArtifact(a.id, ArtifactState.PENDING_CAPTURE, ArtifactState.FAILED)) n++;
            return n;
        }
    }
}
