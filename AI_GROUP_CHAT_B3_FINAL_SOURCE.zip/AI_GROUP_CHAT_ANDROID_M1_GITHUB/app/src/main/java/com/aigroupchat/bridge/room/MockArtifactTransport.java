package com.aigroupchat.bridge.room;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Stand-in for the WebView upload: no network, fully controllable. Used by tests and by developer mode. */
public final class MockArtifactTransport implements ArtifactService.Transport {
    public enum Mode { SUCCEED, FAIL, MANUAL }
    public volatile Mode mode = Mode.SUCCEED;
    public volatile String failReason = "mock upload failed";
    public final List<String> calls = new ArrayList<>();   // "<artifactId>-><providerId>" in the order the uploads were started
    public volatile int cancels;
    public volatile boolean ignoreCancel;   // true: cancel() only counts the call (like a page that never answers); the held job can still report later
    public volatile int invalidations;
    public volatile String lastInvalidated = "";
    private ArtifactService.Transport.StagedExpiryListener expiryListener;
    private ArtifactService.Transport.Callback held;

    @Override public void transfer(Artifact artifact, File file, ArtifactTransfer transfer, Callback cb) {
        synchronized (calls) { calls.add(artifact.id + "->" + transfer.providerId); }
        switch (mode) {
            case SUCCEED: cb.onStaged(); break;
            case FAIL: cb.onFailed(failReason); break;
            default: synchronized (calls) { held = cb; }
        }
    }

    /** MANUAL mode: finish the upload that is being held. */
    public boolean complete(boolean ok) {
        Callback cb; synchronized (calls) { cb = held; held = null; }
        if (cb == null) return false;
        if (ok) cb.onStaged(); else cb.onFailed(failReason);
        return true;
    }

    public boolean isHolding() { synchronized (calls) { return held != null; } }

    @Override public void cancel() {
        cancels++;
        if (ignoreCancel) return;
        Callback cb; synchronized (calls) { cb = held; held = null; }
        if (cb != null) cb.onFailed("cancelled");
    }

    @Override public void invalidateStaged(String roomId, String providerId, String bindingId) {
        invalidations++;
        lastInvalidated = roomId + ":" + providerId + ":" + bindingId;
    }

    @Override public void setStagedExpiryListener(StagedExpiryListener listener) { expiryListener = listener; }

    public void expireStaged(String roomId, String providerId, String bindingId) {
        StagedExpiryListener l = expiryListener;
        if (l != null) l.onExpired(roomId, providerId, bindingId);
    }
}
