package com.aigroupchat.bridge.room;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Stand-in for capturing a file an AI produced: it serves bytes registered by artifact id. Used by tests and developer mode. */
public final class MockCaptureTransport implements ArtifactService.CaptureTransport {
    public enum Mode { SUCCEED, FAIL, MANUAL }
    public volatile Mode mode = Mode.SUCCEED;
    public final Map<String, byte[]> contents = new HashMap<>();   // artifact id -> bytes (a missing entry fails the capture)
    public volatile byte[] defaultContent;                          // served for any artifact id without its own entry (null = fail)
    public volatile String mime = "application/octet-stream";
    public final List<String> calls = new ArrayList<>();
    public volatile int cancels;
    public volatile boolean ignoreCancel;   // true: cancel() only counts the call (like a page that never answers); the held job can still report later
    private ArtifactService.CaptureTransport.Callback held;
    private Artifact heldFor;

    @Override public void capture(Artifact intent, Callback cb) {
        synchronized (calls) { calls.add(intent.id); }
        if (mode == Mode.MANUAL) { synchronized (calls) { held = cb; heldFor = intent; } return; }
        finish(intent, cb, mode == Mode.SUCCEED);
    }

    private void finish(Artifact intent, Callback cb, boolean ok) {
        byte[] b = contents.containsKey(intent.id) ? contents.get(intent.id) : defaultContent;
        if (ok && b != null) cb.onBytes(new ByteArrayInputStream(b), mime); else cb.onFailed("mock capture failed");
    }

    public boolean complete(boolean ok) {
        Callback cb; Artifact a; synchronized (calls) { cb = held; a = heldFor; held = null; heldFor = null; }
        if (cb == null) return false;
        finish(a, cb, ok);
        return true;
    }

    public boolean isHolding() { synchronized (calls) { return held != null; } }

    @Override public void cancel() {
        cancels++;
        if (ignoreCancel) return;
        Callback cb; synchronized (calls) { cb = held; held = null; heldFor = null; }
        if (cb != null) cb.onFailed("cancelled");
    }
}
