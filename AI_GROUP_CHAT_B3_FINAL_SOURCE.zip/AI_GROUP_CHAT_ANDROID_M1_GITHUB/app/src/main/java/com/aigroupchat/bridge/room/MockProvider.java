package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Deterministic fake AI for the test harness and the UI milestone. No network, no accounts. */
public final class MockProvider implements RoomProvider {
    public enum Behavior { REPLY, FAIL_BEFORE_SEND, FAIL_AFTER_ACCEPT, DUPLICATE_REPLY, LATE_DUPLICATE, NEVER_REPLY, SILENT, EMPTY_REPLY }

    public interface Scheduler {
        void post(Runnable r, long delayMs);
        Scheduler IMMEDIATE = (r, d) -> r.run();
    }

    private final String id, name;
    private final Scheduler scheduler;
    public volatile Behavior behavior = Behavior.REPLY;
    /** Test hook: the next normal REPLY also produces these files (then the list is cleared). */
    public volatile List<RoomProvider.FileIntent> nextReplyFiles;
    public volatile long delayMs;
    public volatile Consumer<String> onSend; // test hook: runs synchronously inside send(), before any callback
    public final List<String> prompts = Collections.synchronizedList(new ArrayList<>());
    private volatile boolean cancelled;
    private volatile boolean accepted;
    private volatile Listener lastListener;
    /** Test hook: force the answer to requestStop (e.g. the page said "clicked" before the room ever saw onAccepted). */
    public volatile SubmitPhase stopAnswer;
    /** Test hook: hold the answer to requestStop (like a page that has not replied yet); release it with answerStop(). */
    public volatile boolean holdStop;
    private volatile Consumer<SubmitPhase> heldStop;
    private int n;

    public MockProvider(String id, String name, Scheduler scheduler) { this.id = id; this.name = name; this.scheduler = scheduler; }

    /** Deterministic, readable reply: "<Name> reply #k [role] re: <start of the request>". */
    private String replyText(String prompt, int k) {
        String role = "answer";
        if (prompt.contains("review this message critically")) role = "review";
        else if (prompt.contains("revise your earlier answer")) role = "revise";
        else if (prompt.contains("reply naturally as one participant")) role = "converse";
        else if (prompt.contains("answer independently")) role = "independent";
        String request = "";
        int i = prompt.lastIndexOf("REQUEST (");
        if (i >= 0) {
            int nl = prompt.indexOf('\n', i);
            if (nl >= 0) request = prompt.substring(nl + 1).replaceAll("^\\[[^\\]]*\\]\\s*", "").replace('\n', ' ').trim();
        }
        if (request.length() > 300) request = request.substring(0, 300) + " (+" + (request.length() - 300) + " chars)"; // never a bare "..."
        return name + " reply #" + k + " [" + role + "]" + (request.isEmpty() ? "" : " re: " + request);
    }

    @Override public String id() { return id; }
    @Override public String displayName() { return name; }
    @Override public Set<String> capabilities() { return Collections.singleton("GENERAL"); }
    @Override public boolean isAvailable() { return true; }
    @Override public void cancel() { cancelled = true; }

    @Override
    public void requestStop(Consumer<SubmitPhase> result) {
        if (holdStop) { heldStop = result; return; }
        SubmitPhase forced = stopAnswer;
        result.accept(forced != null ? forced : accepted ? SubmitPhase.SUBMITTED : SubmitPhase.NOT_SUBMITTED);
    }

    /** Test triggers: deliver a reply / a failure to the CURRENT request later, like a real page would. */
    public void fireLateReply(String text) { Listener x = lastListener; if (x != null) x.onReply(text, id + "-late"); }
    public void fireTimeout(String reason) { Listener x = lastListener; if (x != null) x.onError(reason, true); }
    public void answerStop(SubmitPhase phase) { Consumer<SubmitPhase> h = heldStop; heldStop = null; if (h != null) h.accept(phase); }
    public void fireError(String reason, boolean maybeSubmitted) { Listener x = lastListener; if (x != null) x.onError(reason, maybeSubmitted); }

    @Override
    public void send(String prompt, Listener listener) {
        final int k;
        synchronized (this) { k = ++n; }
        cancelled = false;
        accepted = false;
        // remember whether the request was ever accepted: that is what Stop reports (NOT_SUBMITTED until onAccepted)
        final Listener l = new Listener() {
            @Override public void onAccepted(String providerUserMsgId) { accepted = true; listener.onAccepted(providerUserMsgId); }
            @Override public void onReply(String text, String providerAsstMsgId) { listener.onReply(text, providerAsstMsgId); }
            @Override public void onReplyWithFiles(String text, String providerAsstMsgId, List<FileIntent> files) { listener.onReplyWithFiles(text, providerAsstMsgId, files); }
            @Override public void onError(String reason, boolean maybeSubmitted) { listener.onError(reason, maybeSubmitted); }
        };
        lastListener = l;
        prompts.add(prompt);
        Consumer<String> hook = onSend;
        if (hook != null) hook.accept(prompt);
        scheduler.post(() -> {
            if (cancelled) return;
            switch (behavior) {
                case FAIL_BEFORE_SEND:
                    l.onError("mock refused before send", false);
                    break;
                case SILENT:       // no callback at all: the delivery stays SENDING
                    break;
                case NEVER_REPLY:  // accepted, but the reply never arrives: the delivery stays SENT
                    l.onAccepted(id + "-u" + k);
                    break;
                case EMPTY_REPLY:
                    l.onAccepted(id + "-u" + k);
                    l.onReply("   ", id + "-a" + k);
                    break;
                case FAIL_AFTER_ACCEPT:
                    l.onAccepted(id + "-u" + k);
                    l.onError("mock lost the reply", true);
                    break;
                case DUPLICATE_REPLY:
                    l.onAccepted(id + "-u" + k);
                    l.onReply(replyText(prompt, k), id + "-a" + k);
                    l.onReply(replyText(prompt, k), id + "-a" + k);
                    l.onAccepted(id + "-u" + k);
                    break;
                case LATE_DUPLICATE: { // a correct reply, then the SAME reply again later (after the run has moved on)
                    final String text = replyText(prompt, k);
                    l.onAccepted(id + "-u" + k);
                    l.onReply(text, id + "-a" + k);
                    scheduler.post(() -> { if (!cancelled) l.onReply(text, id + "-a" + k); }, delayMs + 2500L);
                    break;
                }
                case REPLY:
                default: {
                    l.onAccepted(id + "-u" + k);
                    List<RoomProvider.FileIntent> files = nextReplyFiles;
                    nextReplyFiles = null;
                    if (files != null && !files.isEmpty()) l.onReplyWithFiles(replyText(prompt, k), id + "-a" + k, files);
                    else l.onReply(replyText(prompt, k), id + "-a" + k);
                    break;
                }
            }
        }, delayMs);
    }
}
