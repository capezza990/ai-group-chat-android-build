package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** The AIs the room knows how to add. The room UI reads this list instead of hard-coding two providers:
 *  adding an entry here is all it takes for "+ Add AI" to offer it. In B1B every entry is backed by a MockProvider. */
public final class ProviderCatalog {
    public static final class Entry {
        public final String id, name, note;
        public final boolean live; // true = has a real embedded provider; false = mock only
        Entry(String id, String name, String note, boolean live) { this.id = id; this.name = name; this.note = note; this.live = live; }
    }

    private static final List<Entry> ENTRIES;
    static {
        List<Entry> l = new ArrayList<>();
        l.add(new Entry("chatgpt", "ChatGPT", "your ChatGPT account", true));
        l.add(new Entry("claude", "Claude", "your Claude account", true));
        l.add(new Entry("gemini", "Gemini", "coming soon", false));
        l.add(new Entry("mock-delta", "Mock Delta", "developer mock", false));
        ENTRIES = Collections.unmodifiableList(l);
    }

    private ProviderCatalog() {}

    public static List<Entry> all() { return ENTRIES; }

    /** Names the user may type to address each AI (lowercase). Used by RecipientParser. */
    public static java.util.Map<String, String[]> aliases() {
        java.util.Map<String, String[]> m = new java.util.LinkedHashMap<>();
        m.put("chatgpt", new String[]{"chatgpt", "chat gpt", "chat-gpt", "gpt"});
        m.put("claude", new String[]{"claude"});
        m.put("gemini", new String[]{"gemini"});
        m.put("mock-delta", new String[]{"mock delta", "delta"});
        return m;
    }

    public static boolean isLive(String id) {
        for (Entry e : ENTRIES) if (e.id.equals(id)) return e.live;
        return false;
    }

    public static String nameOf(String id) {
        for (Entry e : ENTRIES) if (e.id.equals(id)) return e.name;
        return id;
    }
}
