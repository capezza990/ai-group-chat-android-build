package com.aigroupchat.bridge.room;

/** One entry of the global provider registry: a seat-able AI instance together with its service profile. Immutable. */
public final class ProviderInfo {
    public final String id;          // the instance id used everywhere (participants, deliveries, messages)
    public final String profileId;   // the service it belongs to ("chatgpt", "claude", ...)
    public final String displayName;
    public final String kind;        // CORE | CUSTOM | MOCK
    public final String origin;      // e.g. https://chatgpt.com ("" for mocks)
    public final String engine;      // which hardened page engine drives it ("chatgpt", "claude", "generic", "mock")

    public ProviderInfo(String id, String profileId, String displayName, String kind, String origin, String engine) {
        this.id = id; this.profileId = profileId; this.displayName = displayName; this.kind = kind; this.origin = origin; this.engine = engine;
    }

    /** Offered in live rooms. MOCK entries only ever appear in developer (MOCK) rooms. */
    public boolean isLive() { return !"MOCK".equals(kind); }
}
