package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deterministic "who is the user talking to?" detection (pure Java, no model involved).
 * An AI counts as ADDRESSED only when its name is used as an address: as the opener ("Claude, ...", "hey Claude ..."),
 * as an @mention, after ask/tell/have, or as a trailing vocative (", Claude?"). A name merely mentioned inside a sentence
 * ("what does Claude think about this?") is NOT an address.
 */
public final class RecipientParser {
    public enum Kind { NONE, DIRECT, GROUP, INDEPENDENT }

    public static final class Result {
        public final Kind kind;
        public final List<String> ids; // DIRECT: the one addressed AI; GROUP/INDEPENDENT: the named AIs, or empty = everyone
        Result(Kind kind, List<String> ids) { this.kind = kind; this.ids = Collections.unmodifiableList(ids); }
    }

    private static final Result NONE = new Result(Kind.NONE, new ArrayList<>());

    private static final Pattern GREETING = Pattern.compile("^(?:hey there|hey|hi|hello|hiya|yo|ok|okay|so|and|um|uh|well|alright)(?:[,!.\\s]+|$)");
    private static final Pattern SEPARATOR = Pattern.compile("\\s*(?:,|&|\\+|\\band\\b)\\s*");
    /** Real greetings make "hey <name> ..." a strong vocative whatever follows. Fillers (so, and, ok, well) do not. */
    private static final Pattern STRONG_GREETING = Pattern.compile("^(?:hey there|hey|hi|hello|hiya|yo)\\b");
    /** Second-person forms that are clearly addressed to the name even though they begin with a verb that is also a subject word. */
    private static final Pattern SECOND_PERSON_START = Pattern.compile(
            "^\\s+(?:are you|were you|have you|did you|do you|does it|is it|is there|any ideas|any thoughts)\\b");
    /** What a bare opener ("Claude I need...", "Claude can you...") may continue with: first/second person, modals, wh-words, requests, commands. */
    private static final Pattern BARE_OPENER_CONTINUATION = Pattern.compile(
            "^\\s+(?:i|i'm|i\\u2019m|i've|i\\u2019ve|i'll|i\\u2019ll|i'd|i\\u2019d|my|me|we|we're|let's|you|you're|your|you've|you'll|you'd|"
                    + "can|could|would|will|should|shall|may|might|do|what|which|who|whom|whose|when|where|why|how|please|pls|thanks|thank|"
                    + "tell|explain|give|show|help|write|make|create|review|check|summari[sz]e|describe|list|compare|think|thoughts|look|see|try|read|fix|"
                    + "draft|generate|analy[sz]e|translate|find|rewrite|edit|add|remove|update|continue|go|start|pick|choose|remember|ignore|forget|"
                    + "answer|respond|reply|say|suggest|recommend|estimate|calculate|test|testing|quick|real quick|just|each|both)\\b");
    private static final Pattern CAPITALIZED_NEXT = Pattern.compile("^\\s+(\\p{Lu}[\\p{L}\\p{N}'\\u2019-]*)");
    private static final Pattern FOLLOW_WORD = Pattern.compile(
            "^\\s+(?:what|which|who|when|where|why|how|can|could|would|will|should|please|tell|explain|give|show|help|write|make|create|"
                    + "review|check|summari[sz]e|describe|list|compare|think|thoughts|do you|did you|are you|each|both)\\b");
    private static final Pattern IMPERATIVE = Pattern.compile("^(?:ask|tell|have|let|get|ping)\\s+");
    private static final Pattern GROUP_WORDS = Pattern.compile(
            "\\b(?:you guys|you all|y'all|all of you|both of you|you both|you two|you folks|you each|each of you)\\b");
    private static final Pattern VOCATIVE_GROUP = Pattern.compile("^(?:everyone|everybody|all)\\s*[,:]");
    private static final Pattern INDEPENDENT_WORDS = Pattern.compile(
            "\\b(?:you each|each of you|each of the ais|separately|independently|individually|on your own)\\b");

    private RecipientParser() {}

    public static Result parse(String text, Map<String, String[]> aliases) {
        if (text == null || text.trim().isEmpty() || aliases == null || aliases.isEmpty()) return NONE;

        Map<String, String> aliasToId = new LinkedHashMap<>();
        for (Map.Entry<String, String[]> e : aliases.entrySet()) for (String a : e.getValue()) aliasToId.put(a.toLowerCase(Locale.ROOT), e.getKey());
        List<String> sorted = new ArrayList<>(aliasToId.keySet());
        sorted.sort((a, b) -> Integer.compare(b.length(), a.length())); // longest alias first ("chat gpt" before "gpt")
        StringBuilder alt = new StringBuilder();
        for (String a : sorted) { if (alt.length() > 0) alt.append('|'); alt.append(Pattern.quote(a)); }
        Pattern name = Pattern.compile("@?(" + alt + ")(?![a-z0-9])");

        String s = text.trim().toLowerCase(Locale.ROOT);
        int nl = s.indexOf('\n');
        String line = nl >= 0 ? s.substring(0, nl) : s;
        String head = line.length() > 200 ? line.substring(0, 200) : line;

        String orig = text.trim();
        int onl = orig.indexOf('\n');
        String oline = onl >= 0 ? orig.substring(0, onl) : orig;
        String ohead = oline.length() > 200 ? oline.substring(0, 200) : oline;
        boolean sameLength = ohead.length() == head.length(); // lower-casing can change length for rare characters: then skip the case guard

        String core = head;
        boolean greeted = false;
        while (true) { // strip leading greetings: "hey", "hi", "ok so", ...
            Matcher g = GREETING.matcher(core);
            if (g.find() && g.end() > 0) {
                if (STRONG_GREETING.matcher(core.substring(0, g.end())).find()) greeted = true;
                core = core.substring(g.end());
            } else break;
        }

        List<String> names = new ArrayList<>();

        // 1. leading address: "claude, ..." / "claude and chatgpt: ..." / "@claude what ..."
        List<String> lead = readNames(core, 0, name, aliasToId);
        if (!lead.isEmpty()) {
            int end = namesEnd(core, 0, name);
            String rest = core.substring(end);
            String origRest = sameLength ? ohead.substring(head.length() - core.length()).substring(end) : rest;
            if (addressFollows(rest, origRest, greeted)) names = lead;
        }

        // 2. imperative: "ask claude ...", "tell chatgpt and claude ..."
        if (names.isEmpty()) {
            Matcher im = IMPERATIVE.matcher(core);
            if (im.find()) names = readNames(core, im.end(), name, aliasToId);
        }

        // 3. @mentions anywhere in the first line
        if (names.isEmpty()) {
            Matcher at = Pattern.compile("@(" + alt + ")(?![a-z0-9])").matcher(head);
            while (at.find()) { String id = aliasToId.get(at.group(1)); if (!names.contains(id)) names.add(id); }
        }

        // 4. trailing vocative on the last line: "..., claude?"
        if (names.isEmpty()) {
            String last = s.substring(s.lastIndexOf('\n') + 1).trim();
            Matcher tv = Pattern.compile(",\\s*((?:" + name.pattern() + ")(?:\\s*(?:,|&|\\+|\\band\\b)\\s*(?:" + name.pattern() + "))*)\\s*[?!.]*$").matcher(last);
            if (tv.find()) names = readNames(tv.group(1), 0, name, aliasToId);
        }

        boolean group = GROUP_WORDS.matcher(head).find() || VOCATIVE_GROUP.matcher(core).find();
        boolean independent = INDEPENDENT_WORDS.matcher(head).find();

        if (names.size() == 1 && !group) return new Result(Kind.DIRECT, names);
        if (names.size() >= 2 || (names.isEmpty() && group)) {
            return new Result(independent ? Kind.INDEPENDENT : Kind.GROUP, names);
        }
        if (names.size() == 1) return new Result(Kind.DIRECT, names); // "claude, you guys..." -> still the named one
        if (independent) return new Result(Kind.INDEPENDENT, new ArrayList<>());
        return NONE;
    }

    /**
     * Is the text right after an opening name (or name list) an ADDRESS? Hybrid grammar:
     *  - nothing, or punctuation right after the name: always a vocative;
     *  - after a real greeting ("hey Claude ..."): a vocative whatever follows, except a possessive ("Claude's ...");
     *  - a bare opener ("Claude I need ..."): only with a first/second-person, modal, wh-word, request or command continuation,
     *    so a subject-position word ("Claude is...", "Claude said...") or a name/product word ("Claude Shannon", "Claude Opus") is never an address.
     */
    static boolean addressFollows(String rest, String origRest, boolean greeted) {
        if (rest.trim().isEmpty()) return true;
        if (rest.matches("(?s)^\\s*[,:;\\-\\u2013\\u2014?!.].*")) return true;
        if (rest.startsWith("'s") || rest.startsWith("\u2019s")) return false; // possessive: "claude's answer"
        if (greeted) {
            // "Hey Claude Shannon was..." / "Hi ChatGPT Plus users...": a capitalized name-like word glued to the name is part of the
            // name, not a request. Exceptions: I-forms, known continuation words ("Hey Claude Tell me..."), and a comma/colon right
            // after it ("Hey Claude Opus, what do you think?" - the punctuation closes the addressed phrase).
            Matcher cap = CAPITALIZED_NEXT.matcher(origRest);
            if (cap.find()) {
                String tok = cap.group(1);
                boolean iForm = tok.matches("I(?:['\u2019][A-Za-z]+)?");
                boolean known = BARE_OPENER_CONTINUATION.matcher(" " + tok.toLowerCase(Locale.ROOT)).find();
                boolean punctuated = origRest.substring(cap.end(1)).matches("(?s)^[,:;].*");
                if (!iForm && !known && !punctuated) return false;
            }
            return true;
        }
        if (SECOND_PERSON_START.matcher(rest).find()) return true;
        return BARE_OPENER_CONTINUATION.matcher(rest).find();
    }

    /** Reads "name (, | and | & | +) name ..." starting at pos; returns distinct provider ids in order. */
    private static List<String> readNames(String s, int pos, Pattern name, Map<String, String> aliasToId) {
        List<String> out = new ArrayList<>();
        Matcher m = name.matcher(s);
        m.region(pos, s.length());
        while (m.lookingAt()) {
            String id = aliasToId.get(m.group(1));
            if (!out.contains(id)) out.add(id);
            int next = m.end();
            Matcher sep = SEPARATOR.matcher(s);
            sep.region(next, s.length());
            if (!sep.lookingAt()) break;
            Matcher nm = name.matcher(s);
            nm.region(sep.end(), s.length());
            if (!nm.lookingAt()) break;
            m = nm;
        }
        return out;
    }

    private static int namesEnd(String s, int pos, Pattern name) {
        Matcher m = name.matcher(s);
        m.region(pos, s.length());
        int end = pos;
        while (m.lookingAt()) {
            end = m.end();
            Matcher sep = SEPARATOR.matcher(s);
            sep.region(end, s.length());
            if (!sep.lookingAt()) break;
            Matcher nm = name.matcher(s);
            nm.region(sep.end(), s.length());
            if (!nm.lookingAt()) break;
            m = nm;
        }
        return end;
    }
}
