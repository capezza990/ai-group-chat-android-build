package com.aigroupchat.bridge.room;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * "Who is the user probably answering?" (pure Java, derived from the canonical transcript; nothing is stored).
 * The last non-system message owns the user's NEXT unaddressed message only if it is an AI message whose final paragraph
 * asks the user something (a direct question, a decision, or a request for information) and does not hand off to another AI.
 * One-shot by construction: once the owner answers, the owner is recomputed from the new last message.
 */
public final class ReplyOwnership {
    /** Safety cap only: a reply a day later should not silently route to whoever spoke last. */
    public static final long MAX_AGE_MS = 2L * 60L * 60L * 1000L;

    private static final Pattern SECOND_PERSON = Pattern.compile("\\b(?:you|your|yours|you're|you'd|you'll|you've)\\b");
    private static final Pattern DECISION = Pattern.compile(
            "\\b(?:should i|shall i|can i|may i|want me to|would you like|do you want|which (?:one|option|do|would)|what do you mean|prefer|"
                    + "make sense|sound good|sound right|is that (?:ok|okay|clear|right)|does that (?:help|work)|any (?:questions|preference)|anything else)\\b");
    private static final Pattern REQUEST = Pattern.compile(
            "(?:^|[.!?]\\s+)(?:please\\s+)?(?:tell me|explain|clarify|describe|elaborate|specify|share|confirm|walk me through|"
                    + "let me know (?:what|which|how|why|where|when|whether|who))\\b"
                    + "|\\b(?:could|can|would|will) you (?:please )?(?:clarify|explain|tell|share|confirm|describe|elaborate|specify|let me know|send|provide|paste|upload)\\b");

    private ReplyOwnership() {}

    /** @param recent messages in chronological order (oldest first); only the tail matters. @return the owning provider id, or null. */
    public static String owner(List<RoomMessage> recent, Set<String> enabledProviderIds, Map<String, String[]> aliases, long nowMs) {
        RoomMessage last = null;
        for (int i = recent.size() - 1; i >= 0; i--) {
            if (!RoomMessage.SYSTEM.equals(recent.get(i).authorType)) { last = recent.get(i); break; }
        }
        if (last == null || !RoomMessage.PROVIDER.equals(last.authorType)) return null;
        if (!enabledProviderIds.contains(last.authorId)) return null;
        if (nowMs - last.createdAt > MAX_AGE_MS) return null;
        String block = lastParagraph(last.text);
        if (block == null || block.startsWith("```")) return null;
        if (RecipientParser.parse(block, aliases).kind != RecipientParser.Kind.NONE) return null; // a handoff to someone else, not to the user
        return seeksReply(block) ? last.authorId : null;
    }

    static String lastParagraph(String text) {
        if (text == null) return null;
        String[] blocks = text.trim().split("\\n\\s*\\n");
        for (int i = blocks.length - 1; i >= 0; i--) if (!blocks[i].trim().isEmpty()) return blocks[i].trim();
        return null;
    }

    static boolean seeksReply(String block) {
        String b = block.toLowerCase(Locale.ROOT).replaceAll("[*_`>#]", " ").replaceAll("\\s+", " ").trim();
        boolean question = b.contains("?") && (SECOND_PERSON.matcher(b).find() || DECISION.matcher(b).find());
        return question || REQUEST.matcher(b).find();
    }
}
