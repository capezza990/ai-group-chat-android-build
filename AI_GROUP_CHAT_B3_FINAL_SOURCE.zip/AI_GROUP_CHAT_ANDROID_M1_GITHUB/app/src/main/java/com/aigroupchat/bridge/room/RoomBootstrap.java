package com.aigroupchat.bridge.room;

/** What the app does at startup to make sure the room it is about to open exists and matches the mode. Pure Java, so it is tested on the JVM. */
public final class RoomBootstrap {
    /** The one live room that existed before rooms had their own settings. ONLY this room may inherit the old global Natural-turn preference. */
    public static final String HISTORICAL_LIVE_ROOM = "default";

    private RoomBootstrap() {}

    /** Creates the room if it is missing (never touching an existing one), refuses to open a room in the wrong mode, and in developer mode
     *  registers the mock AIs so they can be seated. legacyNaturalTurns is the old SharedPreferences value (clamped to 0..20); it is used only
     *  when the historical live room is created here, never for any other room and never for a room that already exists. */
    public static void prepare(RoomStore store, String roomId, boolean live, String newRoomName, long now, int legacyNaturalTurns) {
        store.atomic(() -> {
            RoomInfo info = store.getRoomInfo(roomId);
            if (info == null) {
                info = store.createRoom(roomId, newRoomName, live ? RoomKind.LIVE : RoomKind.MOCK, now);
                seedNewRoom(store, roomId); // the ONLY place first seats are made: when the room is created, in this same transaction
                int legacy = Math.max(0, Math.min(20, legacyNaturalTurns));
                if (live && HISTORICAL_LIVE_ROOM.equals(roomId) && legacy != 0) store.setNaturalMaxTurns(roomId, legacy);
            }
            if (live != (info.kind == RoomKind.LIVE))
                throw new IllegalStateException("room " + roomId + " is a " + info.kind + " room and cannot be opened in this mode");
            if (!live) for (ProviderCatalog.Entry e : ProviderCatalog.all()) store.ensureMockProvider(e.id, e.name); // developer AIs must be registered before they can be seated
            return null;
        });
    }

    /** "New room": creates a LIVE room named "Room N" (the smallest N >= 2 not already used as a room name) with ChatGPT and Claude seated silently. */
    public static RoomInfo createLiveRoom(RoomStore store, java.util.function.Supplier<String> ids, long now) {
        return store.atomic(() -> {
            java.util.Set<String> used = new java.util.HashSet<>();
            for (RoomInfo r : store.listRooms()) used.add(r.name);
            int n = 2;
            while (used.contains("Room " + n)) n++;
            RoomInfo made = store.createRoom("room-" + ids.get(), "Room " + n, RoomKind.LIVE, now);
            seedNewRoom(store, made.id);
            return made;
        });
    }

    /** The first seats of a brand-new room: ChatGPT and Claude, silent (no notice), natural conversation led by ChatGPT. This runs ONLY at creation.
     *  Opening an existing room never seats anyone, so a room whose AIs were all removed (or that has no seat rows at all) stays exactly as it is. */
    private static void seedNewRoom(RoomStore store, String roomId) {
        store.upsertParticipant(roomId, "chatgpt", 0);
        store.upsertParticipant(roomId, "claude", 1);
        store.saveRoomSettings(store.getRoom(roomId).with(RoutingMode.AUTO_PICK, "chatgpt", 1));
    }
}
