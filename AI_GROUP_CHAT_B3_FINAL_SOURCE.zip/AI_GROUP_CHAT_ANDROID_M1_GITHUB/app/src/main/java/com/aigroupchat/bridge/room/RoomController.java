package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * Owns the canonical room flow. Rules:
 *  1. The user message is persisted BEFORE anything is dispatched.
 *  2. A delivery is persisted as SENDING BEFORE the provider is asked to send. A crash there leaves UNCERTAIN, never an auto-resend.
 *  3. A provider reply is persisted (idempotent id "reply:<deliveryId>") BEFORE the next provider sees it.
 *  4. Provider context progress (contextSeq) advances only to what was actually included in a request the provider accepted.
 *  5. Duplicate / late / stale provider callbacks change nothing.
 * Thread-safe: state changes happen under one lock; provider calls and UI events run after the lock is released.
 */
public final class RoomController {
    public interface Events {
        default void onMessage(RoomMessage m) {}
        default void onDelivery(Delivery d) {}
        default void onRunFinished(String summary) {}
    }

    private static final class Run {
        List<RoomRouter.Step> steps;
        int index;
        String userMessageId;
        String lastMessageId;   // trigger for the next step
        Delivery active;        // current delivery (null between steps)
        RoomProvider activeProvider;
        RoomRouter.Role activeRole;
        boolean activeDispatched; // true only once the persisted delivery has been handed to provider.send()
        boolean stopping;       // Stop pressed: no new routing; an already-submitted reply is still observed
        String stopWhy;         // "stopped by user" / "participant removed"
        // Monotonic floor: once Stop has to assume the request MAY have been sent, nothing later may turn it back into
        // "definitely not sent". Only the provider's own authoritative NOT_SUBMITTED answer cancels a delivery safely.
        boolean possiblySubmitted;
        // Files: the turn of the next AI is held back until every file it needs is in ITS conversation.
        boolean waiting;        // true while the gate says WORKING (nothing has been asked of the AI yet)
        String waitNote = "";   // what we are waiting for, for the status line
        int waitGen;            // bumped each time waiting starts, so a stale "nothing is happening" check can be recognised
        String activeBindingId; // the exact conversation of the AI that is answering NOW: files it produces are recorded as coming from it
        List<ArtifactTransfer> stagedForActiveSend = new ArrayList<>(); // exact rows visibly staged for the current provider send
    }

    private final RoomStore store;
    private final String roomId;
    private final Map<String, RoomProvider> providers = new LinkedHashMap<>();
    private final Map<String, String> names = new LinkedHashMap<>();
    private final LongSupplier clock;
    private final Supplier<String> ids;
    private final Events events;
    private final Object lock = new Object();
    private Run run;
    private ArtifactService artifacts;   // null = no file support: every turn is sent as before (the plain-text path)

    public RoomController(RoomStore store, String roomId, Events events) {
        this(store, roomId, events, System::currentTimeMillis, () -> UUID.randomUUID().toString());
    }

    public RoomController(RoomStore store, String roomId, Events events, LongSupplier clock, Supplier<String> ids) {
        this.store = store; this.roomId = roomId; this.events = events == null ? new Events() {} : events;
        this.clock = clock; this.ids = ids;
        store.ensureRoom(roomId, clock.getAsLong());
    }

    /** Turns on file support: from now on a turn is only sent once every file its prompt needs is in that AI's conversation. The service wakes this controller when a transfer or capture ends. */
    public void setArtifactService(ArtifactService service) {
        synchronized (lock) { artifacts = service; }
        if (service != null) service.setListener(this::onArtifactWorkChanged);
    }

    // ------------------------------------------------------------------ setup / membership

    public void registerProvider(RoomProvider p) {
        synchronized (lock) { providers.put(p.id(), p); names.put(p.id(), p.displayName()); }
    }

    // The ONE place the join/leave wording lives. These are SYSTEM messages: shown in the room, never part of any AI's prompt.
    public static final String TEXT_JOINED = "%s has taken a seat at the Roundtable.";
    public static final String TEXT_LEFT = "%s has left the Roundtable.";
    public static final String TEXT_REJOINED = "%s has rejoined the Roundtable.";

    /** Seats an AI (or re-seats a removed one: same seat row, same position, same context position). announce = false is for creating a room
     *  (the first seats are silent); afterwards pass true so the room shows "taken a seat" / "rejoined". Already seated: nothing changes, nothing is announced. */
    public void addParticipant(String providerId, boolean announce) {
        synchronized (lock) {
            store.atomic(() -> {
                RoomParticipant existing = seat(providerId);
                if (existing != null && existing.enabled) return null;
                store.upsertParticipant(roomId, providerId, existing != null ? existing.position : store.participants(roomId).size());
                if (announce) announceEvent(existing == null ? TEXT_JOINED : TEXT_REJOINED, providerId);
                return null;
            });
        }
    }

    /** The AIs that could still be added to this room: everything in the registry (live rooms: real AIs only) that is not currently seated. */
    public List<ProviderInfo> addableProviders(boolean liveOnly) {
        synchronized (lock) {
            Set<String> seated = new HashSet<>();
            for (RoomParticipant p : store.participants(roomId)) if (p.enabled) seated.add(p.providerId);
            List<ProviderInfo> out = new ArrayList<>();
            for (ProviderInfo p : store.listProviders(liveOnly)) if (!seated.contains(p.id)) out.add(p);
            return out;
        }
    }

    private RoomParticipant seat(String providerId) {
        for (RoomParticipant p : store.participants(roomId)) if (p.providerId.equals(providerId)) return p;
        return null;
    }

    private void announceEvent(String wording, String providerId) {
        ProviderInfo info = store.getProvider(providerId);
        String name = info != null ? info.displayName : names.containsKey(providerId) ? names.get(providerId) : providerId;
        store.appendMessage(roomId, "sys-" + ids.get(), RoomMessage.SYSTEM, "system", String.format(wording, name), null, clock.getAsLong());
    }

    public void removeParticipant(String providerId) {
        boolean drain;
        synchronized (lock) {
            store.atomic(() -> {
                RoomParticipant p = seat(providerId);
                if (p != null && p.enabled) { // removing someone who is not seated changes nothing and says nothing
                    store.setParticipantEnabled(roomId, providerId, false);
                    announceEvent(TEXT_LEFT, providerId);
                }
                return null;
            });
            drain = run != null && run.active != null && run.active.providerId.equals(providerId);
        }
        // Normally blocked by the UI while a run is active. If it happens anyway, an already-submitted reply is still captured.
        if (drain) beginStop("participant removed");
    }

    public List<RoomParticipant> participants() { return store.participants(roomId); }

    public void setRouting(RoutingMode mode, String arg, int rounds) {
        synchronized (lock) { store.saveRoomSettings(store.getRoom(roomId).with(mode, arg, rounds)); }
    }

    /** Call once at startup: anything that was SENDING/SENT when the process died becomes UNCERTAIN. Never resends. */
    public int recoverOnStart() {
        long now = clock.getAsLong();
        store.markArtifactWorkInterrupted(now); // an upload or capture that was running when the app died is FAILED (retryable), never silently "done"
        final ArtifactService svc;
        synchronized (lock) { svc = artifacts; }
        if (svc != null) svc.reconcileStorage(); // ...and a complete file left behind by a crash between "stored" and "READY" is removed, so the retry can never be refused
        return store.markInFlightUncertain(now);
    }

    /** True from submit until the run has completely finished, INCLUDING while a stopped run is draining a submitted reply. */
    public boolean isBusy() { synchronized (lock) { return run != null; } }

    /** True after Stop (or removal of the active AI) while the run waits for an already-submitted reply. No new routing happens. */
    public boolean isStopping() { synchronized (lock) { return run != null && run.stopping; } }

    /** Provider currently working on a request, or null. */
    public String activeProviderId() {
        synchronized (lock) { return run != null && run.active != null ? run.active.providerId : null; }
    }

    /** Human-readable progress of the active run ("step 2 of 3: Claude (REVIEW)"), or "" when idle. */
    public String runStatus() {
        synchronized (lock) {
            if (run == null) return "";
            int n = run.steps.size();
            int i = Math.min(run.index + 1, n);
            if (n == 0 || i < 1) return "starting";
            RoomRouter.Step st = run.steps.get(i - 1);
            String nm = names.containsKey(st.providerId) ? names.get(st.providerId) : st.providerId;
            String base = "step " + i + " of " + n + ": " + nm + " (" + st.role.name().toLowerCase() + ")";
            return run.waiting ? base + " - " + run.waitNote : base;
        }
    }

    // ------------------------------------------------------------------ user message

    /** Persists the user message first, then plans and dispatches. Returns null if empty or a run is already active. */
    public RoomMessage submitUserMessage(String text) { return submitUserMessage(text, null); }

    /** Same as above, but with a pre-built plan from RunPlanner (null = the room's default RoomRouter plan). */
    public RoomMessage submitUserMessage(String text, List<RoomRouter.Step> planOrNull) { return submitUserMessage(text, planOrNull, null); }

    /** Same, with files the user attached (artifact ids from ArtifactService.addUserFile). The message and its attachments are saved together or not at all.
     *  Throws IllegalArgumentException (and saves nothing) for an unknown file, a file of another room, a file that is not READY, or the same file twice. */
    public RoomMessage submitUserMessage(String text, List<RoomRouter.Step> planOrNull, List<String> artifactIds) {
        if (text == null || text.trim().isEmpty()) return null;
        RoomMessage msg;
        Runnable after;
        synchronized (lock) {
            if (run != null) return null;
            msg = store.atomic(() -> {
                RoomMessage m = store.appendMessage(roomId, ids.get(), RoomMessage.USER, "user", text, null, clock.getAsLong());
                if (artifactIds != null) {
                    java.util.Set<String> seen = new java.util.HashSet<>();
                    for (int i = 0; i < artifactIds.size(); i++) {
                        String aid = artifactIds.get(i);
                        Artifact a = aid == null ? null : store.getArtifact(aid);
                        if (a == null) throw new IllegalArgumentException("unknown file");
                        if (!a.roomId.equals(roomId)) throw new IllegalArgumentException("that file belongs to another room");
                        if (a.state != ArtifactState.READY) throw new IllegalArgumentException("\"" + a.displayName + "\" is not ready yet");
                        if (!seen.add(aid)) throw new IllegalArgumentException("the same file was attached twice");
                        store.attachArtifact(m.id, aid, i);
                    }
                }
                return m;
            });
            List<RoomRouter.Step> steps = planOrNull != null ? new ArrayList<>(planOrNull) : RoomRouter.plan(store.getRoom(roomId), store.participants(roomId));
            run = new Run();
            run.steps = steps;
            run.userMessageId = msg.id;
            run.lastMessageId = msg.id;
            after = steps.isEmpty() ? finishLocked("no enabled participant to answer") : startStepLocked();
        }
        events.onMessage(msg);
        if (after != null) after.run();
        return msg;
    }

    /**
     * Stop: immediately forbids any NEW routing, then asks the provider what happened to the request in flight.
     * Provably not sent -> cancelled. Possibly or certainly sent -> keep observing: a real reply is persisted to the room
     * (never routed onward); if it never becomes provable the delivery becomes UNCERTAIN (never resent).
     */
    public void stop() { beginStop("stopped by user"); }

    /** Immediate teardown (room closed, surfaces destroyed): observation is impossible, so the in-flight delivery becomes UNCERTAIN now. */
    public void abandon(String why) {
        Runnable after;
        synchronized (lock) { after = abandonLocked(why); }
        if (after != null) after.run();
    }

    private void beginStop(String why) {
        final RoomProvider p;
        final String deliveryId;
        Runnable fin = null;
        boolean wasWaiting = false;
        synchronized (lock) {
            if (run == null || run.stopping) return; // idle, or Stop already in progress
            run.stopping = true;                     // from this instant nothing new is routed
            run.stopWhy = why;
            wasWaiting = run.waiting;
            String stagedProvider = run.active != null ? run.active.providerId
                    : run.index < run.steps.size() ? run.steps.get(run.index).providerId : null;
            if (artifacts != null && stagedProvider != null) artifacts.failStaged(roomId, stagedProvider, why);
            if (run.active == null) { fin = finishLocked(why); p = null; deliveryId = null; }
            else if (!run.activeDispatched) {
                // The delivery is persisted SENDING, but provider.send() has not been handed the prompt yet. We know it was NOT submitted;
                // do not ask a WebView whose per-turn Stop state may still belong to the previous request.
                final String id = run.active.id;
                store.transition(id, new DeliveryState[]{DeliveryState.PENDING, DeliveryState.SENDING}, DeliveryState.CANCELLED, why + " (request not sent)", clock.getAsLong());
                run.active = null;
                fin = finishLocked(why); p = null; deliveryId = null;
            } else {
                p = run.activeProvider; deliveryId = run.active.id;
                run.possiblySubmitted = true; // assume the worst until the provider authoritatively says NOT_SUBMITTED
            }
        }
        if (fin != null) { fin.run(); if (wasWaiting && artifacts != null) artifacts.cancelInFlight(); return; } // a turn that was still waiting for its files: nothing was asked of any AI; stop moving files too
        p.requestStop(phase -> onStopPhase(deliveryId, p, phase));
    }

    private void onStopPhase(String deliveryId, RoomProvider p, RoomProvider.SubmitPhase phase) {
        Runnable after = null;
        synchronized (lock) {
            if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // a reply or error already resolved it
            if (phase != RoomProvider.SubmitPhase.NOT_SUBMITTED) return; // MAYBE/SUBMITTED: keep draining (beginStop already set the monotonic possible-submission floor)
            final String why = run.stopWhy;
            boolean cancelled = store.atomic(() -> store.transition(deliveryId,
                    new DeliveryState[]{DeliveryState.PENDING, DeliveryState.SENDING}, DeliveryState.CANCELLED, why + " (request not sent)", clock.getAsLong()));
            if (!cancelled) return; // it was accepted after all: stay conservative and drain
            run.active = null;
            after = finishLocked(why);
        }
        if (p != null) p.cancel(); // stop waiting; the provider already aborted the send
        if (after != null) after.run();
    }

    // ------------------------------------------------------------------ stepping (caller holds lock; returns an action to run AFTER unlocking)

    private Runnable startStepLocked() {
        final Run r = run;
        while (r.index < r.steps.size()) {
            RoomRouter.Step step = r.steps.get(r.index);
            RoomProvider provider = providers.get(step.providerId);
            RoomParticipant me = participant(step.providerId);
            if (me == null || !me.enabled) { r.index++; continue; } // removed mid-run: skip its turn
            if (provider == null || !provider.isAvailable()) return finishLocked(step.providerId + " is unavailable");

            final RoomMessage trigger = step.role == RoomRouter.Role.INDEPENDENT || step.role == RoomRouter.Role.ANSWER
                    ? store.getMessage(r.userMessageId) : store.getMessage(r.lastMessageId);
            if (artifacts != null) { // files: nothing is asked of this AI until every file its prompt needs sits in ITS conversation
                final GateDecision g;
                try {
                    final long gateUpto = step.role == RoomRouter.Role.INDEPENDENT ? trigger.seq : store.latestSeq(roomId);
                    g = artifacts.evaluate(roomId, step.providerId, Math.min(me.contextSeq, trigger.seq - 1), gateUpto);
                } catch (RuntimeException e) {
                    return finishLocked("storage error before send: " + e.getMessage());
                }
                if (g.kind == GateDecision.Kind.BLOCKED) return finishLocked(g.reason); // no request was created, so there is nothing to clean up
                r.stagedForActiveSend = g.kind == GateDecision.Kind.READY_TO_SEND ? new ArrayList<>(g.stagedTransfers) : new ArrayList<>();
                if (g.kind == GateDecision.Kind.WORKING) {
                    r.waiting = true; r.waitNote = g.reason; final int gen = ++r.waitGen;
                    return () -> {
                        boolean started = artifacts.advance(g);
                        if (started || artifacts.isBusy()) return;   // a job is running (or already finished and woke us): its end wakes this turn again
                        Runnable stuck = null;
                        synchronized (lock) { // nothing is running and nothing could start: do not wait forever
                            if (run != null && run.waiting && run.waitGen == gen && !run.stopping) stuck = finishLocked("the files for " + names.getOrDefault(step.providerId, step.providerId) + " could not be moved right now");
                        }
                        if (stuck != null) stuck.run();
                    };
                }
            }
            final String prompt;
            final Delivery d;
            try {
                final long upto = step.role == RoomRouter.Role.INDEPENDENT ? trigger.seq : store.latestSeq(roomId);
                final long now = clock.getAsLong();
                Object[] out = store.atomic(() -> {
                    Delivery created = store.createDelivery(ids.get(), roomId, trigger.id, step.providerId, upto, now);
                    if (created.state != DeliveryState.PENDING) return new Object[]{created, null};
                    if (!store.transition(created.id, new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, now)) {
                        return new Object[]{created, null};
                    }
                    Delivery sending = store.getDelivery(created.id);
                    String p = RoomPromptBuilder.build(store, roomId, me, sending, trigger, step.role, names, false);
                    return new Object[]{sending, p};
                });
                d = (Delivery) out[0];
                prompt = (String) out[1];
            } catch (RuntimeException e) {
                return finishLocked("storage error before send: " + e.getMessage());
            }
            if (prompt == null) return finishLocked("a request for " + step.providerId + " already exists in state " + d.state + "; not re-sending");

            r.active = d;
            r.activeBindingId = store.activeBindingId(roomId, step.providerId);   // provenance of any file this answer produces
            r.activeProvider = provider;
            r.activeRole = step.role;
            r.activeDispatched = false;
            final DeliveryListener listener = new DeliveryListener(d.id);
            final Delivery snapshot = d;
            return () -> {
                events.onDelivery(snapshot);
                synchronized (lock) { // Stop may have won the race between persisting SENDING and handing the prompt over
                    if (run == null || run.stopping || run.active == null || !run.active.id.equals(snapshot.id)) return;
                    run.activeDispatched = true;
                }
                provider.send(prompt, listener); // outside the lock; state already persisted as SENDING
            };
        }
        return finishLocked(null);
    }

    /** A file transfer or capture has ended (successfully or not): if the turn is waiting for files, look again. */
    private void onArtifactWorkChanged() {
        Runnable after;
        synchronized (lock) {
            if (run == null || run.stopping || !run.waiting) return;
            run.waiting = false;
            after = startStepLocked();
        }
        if (after != null) after.run();
    }

    private RoomParticipant participant(String providerId) {
        for (RoomParticipant p : store.participants(roomId)) if (p.providerId.equals(providerId)) return p;
        return null;
    }

    private Runnable finishLocked(String problem) {
        if (run != null && artifacts != null) {
            String providerId = run.active != null ? run.active.providerId
                    : run.index < run.steps.size() ? run.steps.get(run.index).providerId : null;
            if (providerId != null) artifacts.failStaged(roomId, providerId,
                    problem == null ? "the staged attachment was not accepted" : problem);
        }
        run = null;
        final String summary = problem == null ? "done" : problem;
        return () -> events.onRunFinished(summary);
    }

    private Runnable abandonLocked(String why) {
        if (run == null) return null;
        final RoomProvider p = run.activeProvider;
        final Delivery a = run.active;
        final boolean wasWaiting = run.waiting;
        if (a != null) {
            final ArtifactService svc = artifacts;
            // UI cleanup is an external side effect, so do not trigger it from inside a database transaction that could still roll back.
            if (svc != null) svc.failStaged(roomId, a.providerId, why);
            store.atomic(() -> {
                long now = clock.getAsLong();
                if (!store.transition(a.id, new DeliveryState[]{DeliveryState.SENDING, DeliveryState.SENT}, DeliveryState.UNCERTAIN, why, now)) {
                    store.transition(a.id, new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.CANCELLED, why, now);
                }
                return null;
            });
        }
        final Runnable fin = finishLocked(why);
        return () -> { if (p != null) p.cancel(); if (wasWaiting && artifacts != null) artifacts.cancelInFlight(); fin.run(); };
    }

    // ------------------------------------------------------------------ provider callbacks (idempotent, any thread)

    private final class DeliveryListener implements RoomProvider.Listener {
        private final String deliveryId;
        DeliveryListener(String deliveryId) { this.deliveryId = deliveryId; }

        @Override public void onAccepted(String providerUserMsgId) {
            synchronized (lock) {
                if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // stale
                final ArtifactService svc = artifacts;
                store.atomic(() -> {
                    long now = clock.getAsLong();
                    if (store.transition(deliveryId, new DeliveryState[]{DeliveryState.SENDING}, DeliveryState.SENT, null, now)) {
                        store.recordProviderIds(deliveryId, providerUserMsgId, null);
                        Delivery d = store.getDelivery(deliveryId);
                        if (svc != null) svc.commitStaged(run.stagedForActiveSend);
                        store.advanceContextSeq(roomId, d.providerId, d.uptoSeq); // provider accepted exactly what the prompt contained
                    }
                    return null;
                });
            }
        }

        @Override public void onReply(String text, String providerAsstMsgId) { handleReply(text, providerAsstMsgId, null); }

        @Override public void onReplyWithFiles(String text, String providerAsstMsgId, List<RoomProvider.FileIntent> files) { handleReply(text, providerAsstMsgId, files); }

        private void handleReply(String rawText, String providerAsstMsgId, List<RoomProvider.FileIntent> offered) {
            RoomMessage reply;
            Runnable after;
            final List<Artifact> created = new ArrayList<>();
            ArtifactService svc;
            synchronized (lock) {
                svc = artifacts;
                if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // stale
                final List<RoomProvider.FileIntent> files = svc == null || offered == null ? new ArrayList<>() : offered; // without file support the files are simply not kept
                final String sourceBinding = run.activeBindingId;
                // An AI file must name the exact conversation it came from. If the request left without one (it should never happen), the files are NOT recorded with unknown
                // provenance: the reply is kept, the run ends, and the user is told.
                final boolean unknownSource = !files.isEmpty() && sourceBinding == null;
                final List<RoomProvider.FileIntent> toSave = unknownSource ? new ArrayList<>() : files;
                final String who = names.getOrDefault(run.active.providerId, run.active.providerId);
                String text = rawText;
                if ((text == null || text.trim().isEmpty()) && !files.isEmpty()) { // an answer that is only a file still needs a line in the room
                    StringBuilder sb = new StringBuilder(unknownSource ? "(tried to share " : "(shared ");
                    for (int i = 0; i < files.size(); i++) sb.append(i > 0 ? ", " : "").append(ArtifactNames.clean(files.get(i).name));
                    text = sb.append(unknownSource ? "; not saved)" : ")").toString();
                }
                final String finalText = text;
                if (finalText == null || finalText.trim().isEmpty()) { after = failLocked("empty reply", true); reply = null; }
                else {
                    final boolean[] replyBeforeAccepted = {false};
                    final String[] replyProvider = {null};
                    reply = store.atomic(() -> {
                        long now = clock.getAsLong();
                        Delivery before = store.getDelivery(deliveryId);
                        boolean wasSending = before.state == DeliveryState.SENDING;
                        if (!store.transition(deliveryId, new DeliveryState[]{DeliveryState.SENDING, DeliveryState.SENT}, DeliveryState.CAPTURED, null, now)) {
                            return null; // already captured / failed: duplicate callback
                        }
                        replyBeforeAccepted[0] = wasSending; replyProvider[0] = before.providerId;
                        if (wasSending) store.advanceContextSeq(roomId, before.providerId, before.uptoSeq); // a reply proves acceptance
                        RoomMessage m = store.appendMessage(roomId, "reply:" + deliveryId, RoomMessage.PROVIDER, before.providerId, finalText, before.triggerMessageId, now);
                        // phase one of a file: the reply and the INTENT of each file are saved together; the bytes are fetched afterwards
                        for (int i = 0; i < toSave.size(); i++) {
                            Artifact a = store.createArtifact(ids.get(), roomId, before.providerId, sourceBinding, toSave.get(i).name, toSave.get(i).mime, now);
                            store.attachArtifact(m.id, a.id, i);
                            created.add(a);
                        }
                        store.recordProviderIds(deliveryId, null, providerAsstMsgId);
                        store.setDeliveryReply(deliveryId, m.id);
                        return m;
                    });
                    if (reply == null) return;
                    if (replyBeforeAccepted[0] && svc != null)
                        svc.failStaged(roomId, replyProvider[0], "the reply arrived before the staged attachment was confirmed");
                    run.lastMessageId = reply.id;
                    run.active = null;
                    run.index++;
                    // A reply that arrives after Stop is a real answer to a request that WAS sent: it is kept, but never routed onward.
                    after = run.stopping ? finishLocked(run.stopWhy)
                            : unknownSource ? finishLocked(who + " sent a file, but the room does not know which conversation it came from, so the file was not saved")
                            : startStepLocked();
                }
            }
            if (reply != null) events.onMessage(reply);
            if (!created.isEmpty() && svc != null) svc.startCaptures(created); // phase two: fetch the bytes (the next AI's turn waits for them at the gate)
            if (after != null) after.run();
        }

        @Override public void onError(String reason, boolean maybeSubmitted) {
            Runnable after;
            synchronized (lock) {
                if (run == null || run.active == null || !run.active.id.equals(deliveryId)) return; // stale
                after = failLocked(reason, maybeSubmitted);
            }
            if (after != null) after.run();
        }
    }

    private Runnable failLocked(String reason, boolean maybeSubmitted) {
        final Delivery a = run.active;
        final String pid = a.providerId;
        final boolean stopping = run.stopping;
        final String why = run.stopWhy;
        // A later "not submitted" callback can never undo a possible submission established by Stop.
        final boolean maybe = maybeSubmitted || run.possiblySubmitted;
        // After Stop the user caused this: keep the stop reason first so the status stays neutral (never a red failure).
        final String error = stopping ? why + "; " + reason : reason;
        final ArtifactService svc = artifacts;
        // Surface cleanup must not run from inside a DB transaction that can still roll back.
        if (svc != null) svc.failStaged(roomId, pid, error);
        store.atomic(() -> {
            long now = clock.getAsLong();
            DeliveryState end = maybe ? DeliveryState.UNCERTAIN : stopping ? DeliveryState.CANCELLED : DeliveryState.FAILED;
            if (!store.transition(a.id, new DeliveryState[]{DeliveryState.SENDING}, end, error, now)) {
                store.transition(a.id, new DeliveryState[]{DeliveryState.SENT}, DeliveryState.UNCERTAIN, error, now);
            }
            return null;
        });
        return finishLocked(stopping ? why : pid + ": " + reason);
    }
}
