package com.aigroupchat.bridge.room;

/** A room's identity and per-room settings that are not routing (routing lives in RoomSettings). Immutable. */
public final class RoomInfo {
    public final String id, name;
    public final RoomKind kind;
    public final int naturalMaxTurns; // 0 = automatic; 2..20 = the user's maximum for a natural conversation
    public final long createdAt;

    public RoomInfo(String id, String name, RoomKind kind, int naturalMaxTurns, long createdAt) {
        this.id = id; this.name = name; this.kind = kind; this.naturalMaxTurns = naturalMaxTurns; this.createdAt = createdAt;
    }

    public RoomInfo withNaturalMaxTurns(int turns) { return new RoomInfo(id, name, kind, turns, createdAt); }
}
