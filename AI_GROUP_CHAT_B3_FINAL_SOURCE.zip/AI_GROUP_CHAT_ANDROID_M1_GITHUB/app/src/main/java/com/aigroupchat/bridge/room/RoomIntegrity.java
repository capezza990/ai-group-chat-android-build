package com.aigroupchat.bridge.room;

/** Rules that stop one room's data from being mistaken for another room's. BOTH stores (SQLite and the in-memory twin) call these,
 *  so they cannot disagree. The SQLite schema enforces the same invariants with composite foreign keys; these cover the paths where a store
 *  would otherwise return an EXISTING row without ever reaching the database check (idempotent re-inserts). */
public final class RoomIntegrity {
    private RoomIntegrity() {}

    /** appendMessage(roomId, id, ...) found a message with that id already stored: it is only an idempotent repeat if it is in the SAME room. */
    public static RoomMessage messageInRoom(RoomMessage existing, String roomId) {
        if (!existing.roomId.equals(roomId)) throw new IllegalStateException("message id " + existing.id + " already belongs to another room");
        return existing;
    }

    /** createDelivery(roomId, trigger, ai) found a delivery for that trigger message and AI already stored: same rule. */
    public static Delivery deliveryInRoom(Delivery existing, String roomId) {
        if (!existing.roomId.equals(roomId)) throw new IllegalStateException("a request for that message and AI already exists in another room");
        return existing;
    }
}
