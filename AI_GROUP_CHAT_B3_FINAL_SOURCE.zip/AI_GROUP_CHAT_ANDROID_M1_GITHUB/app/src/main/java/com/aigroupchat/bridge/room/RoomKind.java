package com.aigroupchat.bridge.room;

/** LIVE rooms use the real embedded AI accounts; MOCK rooms are developer/self-check rooms with mock AIs. */
public enum RoomKind { LIVE, MOCK }
