package com.aigroupchat.bridge.room;

import java.util.Set;

/** An AI participant endpoint (embedded web surface, mock, later Gemini...). Callbacks may arrive on any thread and may repeat. */
public interface RoomProvider {
    interface Listener {
        /** The provider CONFIRMED the request was actually submitted (e.g. our user bubble proven on the page). */
        void onAccepted(String providerUserMsgId);
        /** The complete reply was captured. */
        void onReply(String text, String providerAsstMsgId);
        /** Same, for an answer that ALSO produced files. The files are saved with the reply as intents (their bytes are captured afterwards). Default: the files are ignored. */
        default void onReplyWithFiles(String text, String providerAsstMsgId, java.util.List<FileIntent> files) { onReply(text, providerAsstMsgId); }
        /** maybeSubmitted=false only when the request provably never left (safe to retry); otherwise true. */
        void onError(String reason, boolean maybeSubmitted);
    }

    /** A file an AI says it produced: what the room knows before the bytes are fetched. */
    final class FileIntent {
        public final String name, mime;
        public FileIntent(String name, String mime) { this.name = name == null || name.isEmpty() ? "file" : name; this.mime = mime == null ? "" : mime; }
    }

    /** How far a request got when Stop was pressed. Only NOT_SUBMITTED means it provably never left; anything else must be observed, never resent. */
    enum SubmitPhase { NOT_SUBMITTED, MAYBE_SUBMITTED, SUBMITTED }

    /**
     * Ask the provider what Stop means for the request in flight. The answer may arrive asynchronously (a page must be asked).
     * NOT_SUBMITTED: the provider has aborted the send and cleaned only what it inserted. Otherwise it keeps observing and its
     * callbacks continue (a late real reply is still delivered). Default: MAYBE_SUBMITTED, i.e. the conservative answer.
     */
    default void requestStop(java.util.function.Consumer<SubmitPhase> result) { result.accept(SubmitPhase.MAYBE_SUBMITTED); }

    String id();
    String displayName();
    Set<String> capabilities();
    boolean isAvailable();
    void send(String prompt, Listener listener);
    void cancel();
}
