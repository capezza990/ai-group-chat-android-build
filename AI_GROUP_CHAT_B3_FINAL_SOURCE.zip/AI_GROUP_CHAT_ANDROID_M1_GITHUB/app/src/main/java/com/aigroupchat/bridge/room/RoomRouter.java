package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the deterministic provider sequence. COLLABORATE generalizes the legacy relay exactly:
 * with two AIs, 1 round = propose, review, revise (3 steps) and 2 rounds = 5 steps. With more AIs every other
 * participant reviews in order before the first AI revises. No visible routing markers are involved.
 */
public final class RoomRouter {
    public enum Role { ANSWER, INDEPENDENT, REVIEW, REVISE, CONVERSE }

    public static final class Step {
        public final String providerId;
        public final Role role;
        public Step(String providerId, Role role) { this.providerId = providerId; this.role = role; }
        @Override public String toString() { return providerId + ":" + role; }
    }

    private RoomRouter() {}

    public static List<Step> plan(RoomSettings s, List<RoomParticipant> all) {
        List<String> enabled = new ArrayList<>();
        for (RoomParticipant p : all) if (p.enabled) enabled.add(p.providerId);
        List<Step> steps = new ArrayList<>();
        if (enabled.isEmpty()) return steps;

        switch (s.mode) {
            case SINGLE:
                if (enabled.contains(s.modeArg)) steps.add(new Step(s.modeArg, Role.ANSWER));
                break;
            case ASK_ALL:
                for (String id : enabled) steps.add(new Step(id, enabled.size() == 1 ? Role.ANSWER : Role.INDEPENDENT));
                break;
            case COLLABORATE: {
                String first = enabled.contains(s.modeArg) ? s.modeArg : enabled.get(0);
                List<String> others = new ArrayList<>(enabled);
                others.remove(first);
                steps.add(new Step(first, Role.ANSWER));
                if (others.isEmpty()) break;
                for (int r = 0; r < s.rounds; r++) {
                    for (String o : others) steps.add(new Step(o, Role.REVIEW));
                    steps.add(new Step(first, Role.REVISE));
                }
                break;
            }
            case AUTO_PICK:
            default:
                steps.add(new Step(enabled.get(0), Role.ANSWER)); // capability routing hooks in here later
                break;
        }
        return steps;
    }
}
