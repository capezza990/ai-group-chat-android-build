package com.aigroupchat.bridge.room;

import com.aigroupchat.bridge.engine.ProviderBinding;

import java.util.List;
import java.util.function.Supplier;

/** Persistence contract for the canonical room. Implementations: RoomDb (SQLite) and InMemoryRoomStore (tests). */
public interface RoomStore {
    /** Runs body atomically; any RuntimeException rolls everything back. Re-entrant (nested calls join the outer one). */
    <T> T atomic(Supplier<T> body);

    // ---- rooms
    /** Creates the room as a developer (MOCK) room if it does not exist yet. Real rooms are created with createRoom(). */
    RoomSettings ensureRoom(String roomId, long now);
    RoomSettings getRoom(String roomId);
    void saveRoomSettings(RoomSettings s);
    /** Creates a room with the default routing (natural conversation). Throws if the id already exists. */
    RoomInfo createRoom(String roomId, String name, RoomKind kind, long now);
    RoomInfo getRoomInfo(String roomId);                 // null if unknown
    List<RoomInfo> listRooms();                          // oldest first
    void setNaturalMaxTurns(String roomId, int turns);   // 0 = automatic, otherwise 2..20 (0..20 accepted by the database)

    // ---- provider registry (global; rooms only choose which entries to seat)
    List<ProviderInfo> listProviders(boolean liveOnly);  // live rooms see CORE/CUSTOM only; developer rooms see everything
    ProviderInfo getProvider(String providerId);
    /** Registers a developer mock AI (MOCK profile + instance). No-op if the id is already registered. */
    void ensureMockProvider(String providerId, String displayName);

    // ---- participants (membership is per room; the provider must be in the registry)
    void upsertParticipant(String roomId, String providerId, int position); // re-enable keeps contextSeq and position
    void setParticipantEnabled(String roomId, String providerId, boolean enabled);
    List<RoomParticipant> participants(String roomId);                       // ordered by position
    void advanceContextSeq(String roomId, String providerId, long seq);      // monotonic: never moves backwards

    // ---- messages (append-only)
    /** Idempotent on id: inserting an existing id returns the stored message and changes nothing. */
    RoomMessage appendMessage(String roomId, String id, String authorType, String authorId, String text, String replyTo, long now);
    RoomMessage getMessage(String id);
    List<RoomMessage> messagesBetween(String roomId, long afterSeq, long uptoSeq); // afterSeq < seq <= uptoSeq, ascending
    List<RoomMessage> latestMessages(String roomId, int limit);                    // latest N, ascending
    long latestSeq(String roomId);

    // ---- deliveries
    /** Idempotent on (triggerMessageId, providerId): returns the existing row unchanged if present. */
    Delivery createDelivery(String deliveryId, String roomId, String triggerMessageId, String providerId, long uptoSeq, long now);
    Delivery getDelivery(String id);
    /** Compare-and-set: moves to `to` only if the current state is one of `from`. Returns whether it moved. */
    boolean transition(String deliveryId, DeliveryState[] from, DeliveryState to, String error, long now);
    void recordProviderIds(String deliveryId, String providerUserMsgId, String providerAsstMsgId);
    void setDeliveryReply(String deliveryId, String replyMessageId);
    List<Delivery> deliveriesInState(DeliveryState state);
    /** After a restart: SENDING and SENT deliveries become UNCERTAIN ("interrupted"). Returns how many. */
    int markInFlightUncertain(long now);

    // ---- room-scoped provider bindings with history (the ONLY binding store rooms use; no dual writes)
    /** The ACTIVE binding of this AI in this room, or null. Never another room's binding. */
    ProviderBinding getBinding(String roomId, String providerId);
    /** Binds this AI in this room to a conversation. The AI must already be seated in the room. The same conversation again is a no-op;
     *  a different one retires the current binding (kept as history, reason "rebound") and makes the new one ACTIVE. */
    void putBinding(String roomId, ProviderBinding binding);
    /** Retires the current binding (reason "cleared"). History is kept. */
    void clearBinding(String roomId, String providerId, long now);
    List<BindingRecord> bindingHistory(String roomId, String providerId); // newest first, includes RETIRED
    /** Other rooms where this AI is ACTIVE on the same conversation (for the "thread already used elsewhere" warning). */
    List<String> otherRoomsUsingThread(String providerId, String conversationId, String exceptRoomId);

    // ---- artifacts (files that belong to one room) and their transfers into AI conversation threads
    /** Saves the INTENT: the file exists (user picked it / an AI produced it) but its bytes are not stored yet. State PENDING_CAPTURE. origin = "user" or an AI id. */
    /** Short form WITHOUT a source conversation: valid for the user's files only (an AI file made this way is refused). */
    default Artifact createArtifact(String id, String roomId, String origin, String displayName, String mime, long now) { return createArtifact(id, roomId, origin, null, displayName, mime, now); }
    /** Same, naming the exact conversation (binding id) an AI produced the file in (null ONLY for the user's files: an AI file must always name it). The binding must belong to this room and to the AI named as origin. */
    Artifact createArtifact(String id, String roomId, String origin, String sourceBindingId, String displayName, String mime, long now);
    /** The id of the ACTIVE conversation (binding) of this AI in this room, or null. */
    String activeBindingId(String roomId, String providerId);
    Artifact getArtifact(String id);                                        // null if unknown
    /** PENDING_CAPTURE -> READY with the stored file's type (null keeps the one from the intent), size, hex SHA-256 and storage path. The type is set HERE because it is often only
     *  known once the bytes arrive, and it is frozen from then on. Repeating the identical call on a READY artifact is true (idempotent); any other state returns false.
     *  Throws IllegalArgumentException for a negative size, a hash that is not 64 hex characters, or an empty path. */
    boolean finalizeArtifact(String id, String mime, long size, String sha256, String storagePath);
    boolean failArtifact(String id);                                        // PENDING_CAPTURE -> FAILED
    boolean retryArtifact(String id);                                       // FAILED -> PENDING_CAPTURE
    /** Attaches the artifact to the message (same room required). Attachments are history: they never change or go away. */
    void attachArtifact(String messageId, String artifactId, int position);
    List<Artifact> artifactsOfMessage(String messageId);                    // in attachment order
    /** Every attachment on messages of this room with afterSeq < seq <= uptoSeq, oldest message first. Empty for plain-text conversations. */
    /**
     * The provider's id of the exact assistant reply that produced this AI artifact, resolved through the canonical relationships
     * artifact -> message_artifacts -> reply message -> delivery.reply_message_id -> delivery.provider_asst_msg_id (one stored copy, nothing duplicated).
     * "" (fail closed) for a user file, an unknown artifact, a reply the page gave no id for, or any missing / ambiguous / mismatching relationship.
     */
    String sourceReplyRef(String artifactId);
    List<AttachedArtifact> attachmentsBetween(String roomId, long afterSeq, long uptoSeq);
    /** Every artifact that is not READY (waiting for bytes, or FAILED), oldest first. Used by startup clean-up: no committed file can belong to any of these. */
    List<Artifact> artifactsNotReady();
    /** Deletes an artifact that no message and no transfer refers to (cleanup of an abandoned attachment). False if it is referenced or unknown. */
    boolean deleteUnreferencedArtifact(String id);
    /** Makes sure this READY artifact has a transfer to the ACTIVE conversation of this AI in this room (created PENDING if missing) and returns it.
     *  Returns null when the AI has no ACTIVE conversation in the room. Throws if the artifact is unknown, belongs to another room, or is not READY. */
    ArtifactTransfer ensureTransfer(String artifactId, String roomId, String providerId, long now);
    ArtifactTransfer currentTransfer(String artifactId, String roomId, String providerId);   // the transfer for the ACTIVE conversation, or null
    /** Compare-and-set like deliveries. Entering SENDING counts one attempt and is refused (false) while ANY other transfer in the app is SENDING (global single-flight). */
    boolean transitionTransfer(String artifactId, String bindingId, TransferState[] from, TransferState to, String error, long now);
    List<ArtifactTransfer> transfersInState(TransferState state);
    /** After a restart: SENDING transfers become FAILED("interrupted") and PENDING_CAPTURE artifacts become FAILED, so nothing pretends to be in progress. Returns how many rows changed. */
    int markArtifactWorkInterrupted(long now);
}
