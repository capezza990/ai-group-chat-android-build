package com.aigroupchat.bridge.room;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Builds the run plan for one user message. Sits ABOVE RoomRouter: recipient detection happens first, then the room's
 * conversation style decides the rest. Structured collaboration still comes from RoomRouter.plan, untouched.
 *  - Direct address  -> exactly one step from the named AI, whatever the room style.
 *  - Group address   -> natural chained conversation (or structured, if that is the room style).
 *  - "each / separately" -> every named (or every) AI answers once, independently.
 *  - No address      -> the room's default style.
 */
public final class RunPlanner {
    public static final String AUTO = "auto", GROUP = "group", EACH = "each";

    public static final class Plan {
        public final List<RoomRouter.Step> steps;
        public final String label;       // e.g. "ChatGPT -> Claude -> ChatGPT" or "-> Claude"
        public final boolean overridden; // true if the user chose the routing by hand
        public final String note;        // optional hint, e.g. "Claude isn't in this chat"
        public final boolean replying;   // true when the route comes from reply ownership ("Replying -> Claude")
        Plan(List<RoomRouter.Step> steps, String label, boolean overridden, String note) { this(steps, label, overridden, note, false); }
        Plan(List<RoomRouter.Step> steps, String label, boolean overridden, String note, boolean replying) {
            this.steps = steps; this.label = label; this.overridden = overridden; this.note = note == null ? "" : note; this.replying = replying;
        }
    }

    private RunPlanner() {}

    public static Plan plan(String text, RoomSettings settings, List<RoomParticipant> participants,
                            Map<String, String[]> aliases, Map<String, String> names, String override, int naturalTurns) {
        return plan(text, settings, participants, aliases, names, override, naturalTurns, null);
    }

    /**
     * @param replyOwner provider whose just-asked question the user is probably answering (ReplyOwnership), or null.
     *                   Priority: chip override > explicit address in the text > reply owner > the room's default style.
     */
    public static Plan plan(String text, RoomSettings settings, List<RoomParticipant> participants,
                            Map<String, String[]> aliases, Map<String, String> names, String override, int naturalTurns, String replyOwner) {
        List<String> enabled = new ArrayList<>();
        for (RoomParticipant p : participants) if (p.enabled) enabled.add(p.providerId);
        if (enabled.isEmpty()) return new Plan(new ArrayList<>(), "No AI in this chat", false, "");

        boolean overridden = override != null && !AUTO.equals(override);
        RecipientParser.Kind kind;
        List<String> ids = new ArrayList<>();
        if (overridden) {
            if (GROUP.equals(override)) kind = RecipientParser.Kind.GROUP;
            else if (EACH.equals(override)) kind = RecipientParser.Kind.INDEPENDENT;
            else { kind = RecipientParser.Kind.DIRECT; ids.add(override); }
        } else {
            RecipientParser.Result r = RecipientParser.parse(text, aliases);
            kind = r.kind;
            ids.addAll(r.ids);
        }

        if (!overridden && kind == RecipientParser.Kind.NONE && replyOwner != null && enabled.contains(replyOwner)) {
            List<RoomRouter.Step> own = new ArrayList<>();
            own.add(new RoomRouter.Step(replyOwner, RoomRouter.Role.ANSWER));
            return new Plan(own, "Replying \u2192 " + nameOf(names, replyOwner), false, "", true);
        }

        String note = "";
        List<String> named = new ArrayList<>();
        for (String id : ids) if (enabled.contains(id)) named.add(id); else note = nameOf(names, id) + " isn't in this chat";
        if (kind == RecipientParser.Kind.DIRECT && named.isEmpty()) kind = RecipientParser.Kind.NONE; // addressed AI is not here: use the default

        List<RoomRouter.Step> steps = new ArrayList<>();
        switch (kind) {
            case DIRECT:
                steps.add(new RoomRouter.Step(named.get(0), RoomRouter.Role.ANSWER));
                return new Plan(steps, "\u2192 " + nameOf(names, named.get(0)), overridden, note);
            case INDEPENDENT: {
                List<String> who = named.isEmpty() ? enabled : named;
                for (String id : who) steps.add(new RoomRouter.Step(id, who.size() == 1 ? RoomRouter.Role.ANSWER : RoomRouter.Role.INDEPENDENT));
                return new Plan(steps, who.size() == 1 ? "\u2192 " + nameOf(names, who.get(0)) : "Each answers separately", overridden, note);
            }
            case GROUP:
                if (settings.mode == RoutingMode.COLLABORATE) return structured(settings, participants, names, overridden, note);
                return natural(named.isEmpty() ? enabled : named,
                        named.isEmpty() ? settings.modeArg : named.get(0), // typed order wins for this run; otherwise the stored preference
                        names, naturalTurns, overridden, note);
            case NONE:
            default:
                if (settings.mode == RoutingMode.AUTO_PICK) return natural(enabled, settings.modeArg, names, naturalTurns, overridden, note);
                return structured(settings, participants, names, overridden, note); // COLLABORATE / SINGLE / ASK_ALL as before
        }
    }

    /** Natural conversation: a bounded chain of CONVERSE turns, each AI reacting to the latest message. */
    static Plan natural(List<String> speakers, String firstSpeaker, Map<String, String> names, int requestedTurns, boolean overridden, String note) {
        int n = speakers.size();
        int start = Math.max(0, speakers.indexOf(firstSpeaker)); // preferred first speaker if it is in the conversation
        int turns = n == 1 ? 1 : requestedTurns > 0 ? Math.max(2, Math.min(4, requestedTurns)) : Math.min(4, n + 1);
        List<RoomRouter.Step> steps = new ArrayList<>();
        StringBuilder label = new StringBuilder();
        for (int i = 0; i < turns; i++) {
            String id = speakers.get((start + i) % n); // round robin: never the same AI twice in a row when n >= 2
            steps.add(new RoomRouter.Step(id, RoomRouter.Role.CONVERSE));
            if (label.length() > 0) label.append(" \u2192 ");
            label.append(nameOf(names, id));
        }
        return new Plan(steps, label.toString(), overridden, note);
    }

    private static Plan structured(RoomSettings settings, List<RoomParticipant> participants, Map<String, String> names, boolean overridden, String note) {
        List<RoomRouter.Step> steps = RoomRouter.plan(settings, participants);
        StringBuilder label = new StringBuilder();
        for (RoomRouter.Step st : steps) {
            if (label.length() > 0) label.append(" \u2192 ");
            label.append(nameOf(names, st.providerId));
        }
        String prefix = settings.mode == RoutingMode.COLLABORATE ? "Structured: " : settings.mode == RoutingMode.ASK_ALL ? "Each: " : "";
        return new Plan(steps, prefix + label, overridden, note);
    }

    static String nameOf(Map<String, String> names, String id) {
        String n = names == null ? null : names.get(id);
        return n == null || n.isEmpty() ? id : n;
    }
}
