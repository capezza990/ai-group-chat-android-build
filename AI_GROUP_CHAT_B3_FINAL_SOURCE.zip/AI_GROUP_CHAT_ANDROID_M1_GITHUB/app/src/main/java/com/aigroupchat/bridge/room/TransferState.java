package com.aigroupchat.bridge.room;

/** Life of ONE file in ONE AI's conversation thread. PENDING: not started. SENDING: the upload is in progress (only one in the whole app at a time).
 *  STAGED: visibly attached in the provider composer, but not yet accepted into the thread. VERIFIED: the provider accepted the user message containing it
 *  (final: the row never changes again). FAILED: it did not work, was abandoned or was interrupted; it can be retried. The database enforces the same moves. */
public enum TransferState {
    PENDING, SENDING, STAGED, VERIFIED, FAILED;

    public boolean canMoveTo(TransferState to) {
        if (this == VERIFIED) return false;   // final: not even a no-op update (the database refuses every update of a VERIFIED row)
        if (this == to) return true;
        return (this == PENDING && (to == SENDING || to == FAILED))
                || (this == SENDING && (to == STAGED || to == FAILED))
                || (this == STAGED && (to == VERIFIED || to == FAILED))
                || (this == FAILED && (to == PENDING || to == SENDING));
    }
}
