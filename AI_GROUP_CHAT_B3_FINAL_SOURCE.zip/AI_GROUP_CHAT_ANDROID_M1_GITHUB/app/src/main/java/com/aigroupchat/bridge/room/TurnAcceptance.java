package com.aigroupchat.bridge.room;

/**
 * The exact rule for accepting a captured provider reply (pure Java, unit-tested; the production code calls this).
 * "nonce" identity (our tagged bubble found + the first assistant node after it) is count-independent: virtualized pages
 * can show negative count deltas and the reply is still proven. Legacy identity modes keep their count evidence.
 */
public final class TurnAcceptance {
    public static final String NONCE_MODE = "nonce";

    private TurnAcceptance() {}

    public static boolean accept(String replyText, boolean tokenOk, boolean identityProven, String identityMode,
                                 int newAssistantNodes, int newUserBubbles) {
        if (replyText == null || replyText.trim().isEmpty() || !tokenOk || !identityProven) return false;
        if (NONCE_MODE.equals(identityMode)) return true;
        return newAssistantNodes > 0 && newUserBubbles > 0;
    }
}
