package com.aigroupchat.bridge.room;

/**
 * Timeout for one provider turn. Only time the APP spent in the background is excluded; a provider page that merely
 * reports "hidden" underneath the foreground room still counts in full. A hard cap bounds the turn no matter what.
 */
public final class TurnClock {
    private final long start, timeoutMs, capMs, backgroundAtStart;

    public TurnClock(long start, long timeoutMs, long capMs, long backgroundAtStart) {
        this.start = start; this.timeoutMs = timeoutMs; this.capMs = capMs; this.backgroundAtStart = backgroundAtStart;
    }

    public long activeMs(long now, long backgroundNow) { return now - start - (backgroundNow - backgroundAtStart); }

    /** Milliseconds of this turn that the app spent in the background (for diagnostics). */
    public long backgroundDuringTurnMs(long backgroundNow) { return backgroundNow - backgroundAtStart; }

    public boolean expired(long now, long backgroundNow) { return activeMs(now, backgroundNow) > timeoutMs || now - start > capMs; }
}
