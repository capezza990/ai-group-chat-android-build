package com.aigroupchat.bridge.room.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.Artifact;
import com.aigroupchat.bridge.room.ArtifactNames;
import com.aigroupchat.bridge.room.ArtifactState;
import com.aigroupchat.bridge.room.ArtifactTransfer;
import com.aigroupchat.bridge.room.AttachedArtifact;
import com.aigroupchat.bridge.room.TransferState;
import com.aigroupchat.bridge.room.BindingRecord;
import com.aigroupchat.bridge.room.Delivery;
import com.aigroupchat.bridge.room.DeliveryState;
import com.aigroupchat.bridge.room.ProviderInfo;
import com.aigroupchat.bridge.room.RoomIntegrity;
import com.aigroupchat.bridge.room.RoomInfo;
import com.aigroupchat.bridge.room.RoomKind;
import com.aigroupchat.bridge.room.RoomMessage;
import com.aigroupchat.bridge.room.RoomParticipant;
import com.aigroupchat.bridge.room.RoomSettings;
import com.aigroupchat.bridge.room.RoomStore;
import com.aigroupchat.bridge.room.RoutingMode;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * SQLite-backed canonical room (framework SQLite, no new dependency). Schema v1 lives in assets/room_schema_v1.sql and the
 * v1 -> v2 upgrade in assets/room_migration_v1_to_v2.sql (messages are append-only via triggers; UNIQUE ids; foreign keys on).
 * All access is serialized by one static lock and every public operation runs inside atomic(), which nests.
 */
public final class RoomDb extends SQLiteOpenHelper implements RoomStore {
    private static final String DB_NAME = "room.db";
    private static final int DB_VERSION = 2;
    private static final Object LOCK = new Object();
    private static RoomDb instance;

    // Old SharedPreferences that the v1 -> v2 upgrade reads (and never modifies, so a rollback loses nothing).
    private static final String META_PREFS = "room_meta";
    private static final String FLAG_BINDINGS_IMPORTED = "bindings_imported_v1"; // set after the first successful open; legacy prefs are left untouched
    private static final String LEGACY_BINDING_PREFS = "engine_bindings";
    /** Puts an old preference binding into the v1 table. IGNORE: a binding that is already in the database wins over an older preference. */
    static final String IMPORT_LEGACY_BINDING_SQL =
            "INSERT OR IGNORE INTO provider_bindings(provider_id, conversation_id, restore_locator, display_title, bound_at) VALUES (?,?,?,?,?)";
    private static final String LEGACY_PREFS = "room_b1b";          // holds the old Natural-turn setting; the upgrade copies it into the live room
    private static final String LEGACY_NATURAL_TURNS = "natural_turns";

    private final Context appContext;
    private int txDepth;

    /** Opens (and, if needed, upgrades) the database. Throws if the upgrade or a safety check fails: the caller must show a message. */
    public static synchronized RoomDb get(Context c) {
        if (instance == null) {
            RoomDb d = new RoomDb(c.getApplicationContext());
            try {
                d.getWritableDatabase(); // runs onCreate/onUpgrade/onOpen now, so a failure surfaces here and not later
            } catch (RuntimeException e) {
                try { d.close(); } catch (Exception ignored) {}
                throw e; // instance stays null and the old-preference marker stays unset: the next call gets a second chance
            }
            // Only now is the upgrade (including the import of old preference bindings) committed, so only now are those preferences consumed.
            d.appContext.getSharedPreferences(META_PREFS, Context.MODE_PRIVATE).edit().putBoolean(FLAG_BINDINGS_IMPORTED, true).apply();
            instance = d;
        }
        return instance;
    }

    private RoomDb(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
        this.appContext = c;
    }

    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }

    /** Foreign keys are what keeps rooms apart (a message, artifact or binding of one room can never attach to another), so a
     *  database that is open with them OFF is refused rather than used. */
    @Override public void onOpen(SQLiteDatabase db) {
        if (DatabaseUtils.longForQuery(db, "PRAGMA foreign_keys", null) != 1L) throw new IllegalStateException("foreign keys are not enforced");
    }

    @Override public void onCreate(SQLiteDatabase db) {
        runScript(db, readAsset("room_schema_v1.sql"), 0L, 0);
        runMigrationV1ToV2(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) runMigrationV1ToV2(db);
    }

    private void runMigrationV1ToV2(SQLiteDatabase db) {
        UpgradeV2.run(new UpgradeV2.Steps() {
            @Override public void importLegacyPreferenceBindings() { importPreferenceBindings(db); }
            @Override public void runMigrationScript() {
                runScript(db, readAsset("room_migration_v1_to_v2.sql"), System.currentTimeMillis(), legacyNaturalTurns());
            }
            @Override public void checkForeignKeys() {
                // Any dangling reference means the old data was inconsistent: abort, which rolls the whole upgrade back and leaves v1 untouched.
                try (Cursor c = db.rawQuery("PRAGMA foreign_key_check", null)) {
                    if (c.moveToFirst()) throw new IllegalStateException("database upgrade aborted: foreign_key_check found " + c.getCount() + " problem(s)");
                }
            }
        });
    }

    /** Bindings that exist only in the P1-A SharedPreferences are copied into provider_bindings BEFORE the migration script runs, inside the
     *  same transaction. A preference that cannot be parsed is skipped; a database error is not (it aborts and rolls back the upgrade). */
    private void importPreferenceBindings(SQLiteDatabase db) {
        if (appContext.getSharedPreferences(META_PREFS, Context.MODE_PRIVATE).getBoolean(FLAG_BINDINGS_IMPORTED, false)) return;
        SharedPreferences legacy = appContext.getSharedPreferences(LEGACY_BINDING_PREFS, Context.MODE_PRIVATE);
        for (String providerId : new String[]{"chatgpt", "claude"}) {
            String json = legacy.getString(providerId, null);
            if (json == null) continue;
            ProviderBinding b;
            try { b = ProviderBinding.fromJson(new JSONObject(json)); } catch (Exception unreadable) { continue; }
            if (b == null || !providerId.equals(b.providerId)) continue;
            db.execSQL(IMPORT_LEGACY_BINDING_SQL, new Object[]{b.providerId, b.providerConversationId, b.restoreLocator, b.displayTitle, b.boundAt});
        }
    }

    private int legacyNaturalTurns() {
        int v = appContext.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE).getInt(LEGACY_NATURAL_TURNS, 0);
        return Math.max(0, Math.min(20, v));
    }

    /** Runs every statement of an asset script (see SqlScript for the splitting rules, shared with the tests). */
    static void runScript(SQLiteDatabase db, String script, long now, int naturalTurns) {
        for (String sql : SqlScript.statements(script, now, naturalTurns)) db.execSQL(sql);
    }

    private String readAsset(String name) {
        try (InputStream in = appContext.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8").replace("\r\n", "\n");
        } catch (Exception e) {
            throw new IllegalStateException("database script missing: " + name, e);
        }
    }

    // ------------------------------------------------------------------ transactions

    @Override
    public <T> T atomic(Supplier<T> body) {
        synchronized (LOCK) {
            SQLiteDatabase db = getWritableDatabase();
            boolean outer = txDepth == 0;
            if (outer) db.beginTransactionNonExclusive();
            txDepth++;
            try {
                T r = body.get();
                if (outer) db.setTransactionSuccessful();
                return r;
            } finally {
                txDepth--;
                if (outer) db.endTransaction();
            }
        }
    }

    private SQLiteDatabase db() { return getWritableDatabase(); }

    // ------------------------------------------------------------------ rooms

    /** Implicit creation is for developer (MOCK) rooms only; real rooms are created explicitly with createRoom(). */
    @Override public RoomSettings ensureRoom(String roomId, long now) {
        return atomic(() -> {
            RoomSettings s = getRoom(roomId);
            if (s != null) return s;
            insertRoom(roomId, roomId, RoomKind.MOCK, now);
            return getRoom(roomId);
        });
    }

    private void insertRoom(String roomId, String name, RoomKind kind, long now) {
        ContentValues cv = new ContentValues();
        cv.put("id", roomId); cv.put("routing_mode", RoutingMode.AUTO_PICK.name());
        cv.put("routing_arg", ""); cv.put("rounds", 1); cv.put("created_at", now);
        cv.put("name", name); cv.put("kind", kind.name()); cv.put("natural_max_turns", 0);
        db().insertOrThrow("rooms", null, cv);
    }

    @Override public RoomInfo createRoom(String roomId, String name, RoomKind kind, long now) {
        return atomic(() -> {
            if (getRoom(roomId) != null) throw new IllegalStateException("room already exists: " + roomId);
            insertRoom(roomId, name, kind, now);
            return getRoomInfo(roomId);
        });
    }

    private static final String ROOM_INFO_COLS = "id, name, kind, natural_max_turns, created_at";

    private static RoomInfo readRoomInfo(Cursor c) {
        return new RoomInfo(c.getString(0), c.getString(1), RoomKind.valueOf(c.getString(2)), c.getInt(3), c.getLong(4));
    }

    @Override public RoomInfo getRoomInfo(String roomId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + ROOM_INFO_COLS + " FROM rooms WHERE id=?", new String[]{roomId})) {
                return c.moveToFirst() ? readRoomInfo(c) : null;
            }
        });
    }

    @Override public List<RoomInfo> listRooms() {
        return atomic(() -> {
            List<RoomInfo> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + ROOM_INFO_COLS + " FROM rooms ORDER BY created_at, id", null)) {
                while (c.moveToNext()) out.add(readRoomInfo(c));
            }
            return out;
        });
    }

    @Override public void setNaturalMaxTurns(String roomId, int turns) {
        atomic(() -> {
            if (turns < 0 || turns > 20) throw new IllegalArgumentException("natural_max_turns must be 0..20");
            ContentValues cv = new ContentValues();
            cv.put("natural_max_turns", turns);
            if (db().update("rooms", cv, "id=?", new String[]{roomId}) != 1) throw new IllegalStateException("FK: unknown room " + roomId);
            return null;
        });
    }

    // ------------------------------------------------------------------ provider registry (global; rooms only choose which entries to seat)

    @Override public List<ProviderInfo> listProviders(boolean liveOnly) {
        return atomic(() -> {
            List<ProviderInfo> out = new ArrayList<>();
            String sql = "SELECT p.id, p.profile_id, p.display_name, pp.kind, pp.origin, pp.engine FROM providers p "
                    + "JOIN provider_profiles pp ON pp.id = p.profile_id "
                    + (liveOnly ? "WHERE pp.kind IN ('CORE','CUSTOM') " : "")
                    + "ORDER BY CASE pp.kind WHEN 'CORE' THEN 0 WHEN 'CUSTOM' THEN 1 ELSE 2 END, p.rowid";
            try (Cursor c = db().rawQuery(sql, null)) {
                while (c.moveToNext()) out.add(new ProviderInfo(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)));
            }
            return out;
        });
    }

    @Override public ProviderInfo getProvider(String providerId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT p.id, p.profile_id, p.display_name, pp.kind, pp.origin, pp.engine FROM providers p "
                    + "JOIN provider_profiles pp ON pp.id = p.profile_id WHERE p.id=?", new String[]{providerId})) {
                return c.moveToFirst() ? new ProviderInfo(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)) : null;
            }
        });
    }

    @Override public void ensureMockProvider(String providerId, String displayName) {
        atomic(() -> {
            long now = System.currentTimeMillis();
            db().execSQL("INSERT OR IGNORE INTO provider_profiles(id, display_name, origin, engine, kind, created_at) VALUES (?,?,'','mock','MOCK',?)",
                    new Object[]{providerId, displayName, now});
            db().execSQL("INSERT OR IGNORE INTO providers(id, profile_id, display_name, created_at) VALUES (?,?,?,?)",
                    new Object[]{providerId, providerId, displayName, now});
            return null;
        });
    }

    @Override public RoomSettings getRoom(String roomId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT routing_mode, routing_arg, rounds, created_at FROM rooms WHERE id=?", new String[]{roomId})) {
                if (!c.moveToFirst()) return null;
                return new RoomSettings(roomId, RoutingMode.valueOf(c.getString(0)), c.getString(1), c.getInt(2), c.getLong(3));
            }
        });
    }

    @Override public void saveRoomSettings(RoomSettings s) {
        atomic(() -> {
            ContentValues cv = new ContentValues();
            cv.put("routing_mode", s.mode.name()); cv.put("routing_arg", s.modeArg); cv.put("rounds", s.rounds);
            if (db().update("rooms", cv, "id=?", new String[]{s.roomId}) != 1) throw new IllegalStateException("unknown room " + s.roomId);
            return null;
        });
    }

    // ------------------------------------------------------------------ participants

    @Override public void upsertParticipant(String roomId, String providerId, int position) {
        atomic(() -> {
            db().execSQL("INSERT OR IGNORE INTO participants(room_id, provider_id, enabled, position) VALUES (?,?,1,?)",
                    new Object[]{roomId, providerId, position});
            db().execSQL("UPDATE participants SET enabled=1 WHERE room_id=? AND provider_id=?", new Object[]{roomId, providerId});
            return null;
        });
    }

    @Override public void setParticipantEnabled(String roomId, String providerId, boolean enabled) {
        atomic(() -> {
            db().execSQL("UPDATE participants SET enabled=? WHERE room_id=? AND provider_id=?",
                    new Object[]{enabled ? 1 : 0, roomId, providerId});
            return null;
        });
    }

    @Override public List<RoomParticipant> participants(String roomId) {
        return atomic(() -> {
            List<RoomParticipant> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT provider_id, enabled, position, context_seq, mirror_state FROM participants "
                    + "WHERE room_id=? ORDER BY position, provider_id", new String[]{roomId})) {
                while (c.moveToNext()) out.add(new RoomParticipant(roomId, c.getString(0), c.getInt(1) == 1, c.getInt(2), c.getLong(3), c.getString(4)));
            }
            return out;
        });
    }

    @Override public void advanceContextSeq(String roomId, String providerId, long seq) {
        atomic(() -> {
            db().execSQL("UPDATE participants SET context_seq=? WHERE room_id=? AND provider_id=? AND context_seq < ?",
                    new Object[]{seq, roomId, providerId, seq});
            return null;
        });
    }

    // ------------------------------------------------------------------ messages

    private static RoomMessage readMessage(Cursor c) {
        return new RoomMessage(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4),
                c.getString(5), c.getLong(6), c.isNull(7) ? null : c.getString(7));
    }

    private static final String MSG_COLS = "seq, id, room_id, author_type, author_id, text, created_at, reply_to";

    @Override public RoomMessage appendMessage(String roomId, String id, String authorType, String authorId, String text, String replyTo, long now) {
        return atomic(() -> {
            RoomMessage existing = getMessage(id);
            if (existing != null) return RoomIntegrity.messageInRoom(existing, roomId); // idempotent repeat in the SAME room only; another room's id throws
            ContentValues cv = new ContentValues();
            cv.put("id", id); cv.put("room_id", roomId); cv.put("author_type", authorType); cv.put("author_id", authorId);
            cv.put("text", text); cv.put("created_at", now);
            if (replyTo != null) cv.put("reply_to", replyTo);
            db().insertOrThrow("messages", null, cv);
            return getMessage(id);
        });
    }

    @Override public RoomMessage getMessage(String id) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + MSG_COLS + " FROM messages WHERE id=?", new String[]{id})) {
                return c.moveToFirst() ? readMessage(c) : null;
            }
        });
    }

    @Override public List<RoomMessage> messagesBetween(String roomId, long afterSeq, long uptoSeq) {
        return atomic(() -> {
            List<RoomMessage> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + MSG_COLS + " FROM messages WHERE room_id=? AND seq>? AND seq<=? ORDER BY seq",
                    new String[]{roomId, String.valueOf(afterSeq), String.valueOf(uptoSeq)})) {
                while (c.moveToNext()) out.add(readMessage(c));
            }
            return out;
        });
    }

    @Override public List<RoomMessage> latestMessages(String roomId, int limit) {
        return atomic(() -> {
            List<RoomMessage> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + MSG_COLS + " FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT ?",
                    new String[]{roomId, String.valueOf(limit)})) {
                while (c.moveToNext()) out.add(readMessage(c));
            }
            Collections.reverse(out);
            return out;
        });
    }

    @Override public long latestSeq(String roomId) {
        return atomic(() -> DatabaseUtils.longForQuery(db(), "SELECT COALESCE(MAX(seq),0) FROM messages WHERE room_id=?", new String[]{roomId}));
    }

    // ------------------------------------------------------------------ deliveries

    private static final String DEL_COLS = "id, room_id, trigger_message_id, provider_id, upto_seq, state, "
            + "provider_user_msg_id, provider_asst_msg_id, reply_message_id, error, created_at, updated_at";

    private static Delivery readDelivery(Cursor c) {
        Delivery d = new Delivery(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4),
                DeliveryState.valueOf(c.getString(5)), c.getLong(10), c.getLong(11));
        d.providerUserMsgId = c.getString(6); d.providerAsstMsgId = c.getString(7);
        d.replyMessageId = c.isNull(8) ? "" : c.getString(8); d.error = c.getString(9); // the database stores "no reply" as NULL; the app has always used ""
        return d;
    }

    @Override public Delivery createDelivery(String deliveryId, String roomId, String triggerMessageId, String providerId, long uptoSeq, long now) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + DEL_COLS + " FROM deliveries WHERE trigger_message_id=? AND provider_id=?",
                    new String[]{triggerMessageId, providerId})) {
                if (c.moveToFirst()) return RoomIntegrity.deliveryInRoom(readDelivery(c), roomId); // idempotent on (trigger, provider), same room only
            }
            ContentValues cv = new ContentValues();
            cv.put("id", deliveryId); cv.put("room_id", roomId); cv.put("trigger_message_id", triggerMessageId);
            cv.put("provider_id", providerId); cv.put("upto_seq", uptoSeq); cv.put("state", DeliveryState.PENDING.name());
            cv.put("created_at", now); cv.put("updated_at", now);
            db().insertOrThrow("deliveries", null, cv);
            return getDelivery(deliveryId);
        });
    }

    @Override public Delivery getDelivery(String id) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + DEL_COLS + " FROM deliveries WHERE id=?", new String[]{id})) {
                return c.moveToFirst() ? readDelivery(c) : null;
            }
        });
    }

    @Override public boolean transition(String deliveryId, DeliveryState[] from, DeliveryState to, String error, long now) {
        return atomic(() -> {
            StringBuilder where = new StringBuilder("id=? AND state IN (");
            String[] args = new String[from.length + 1];
            args[0] = deliveryId;
            for (int i = 0; i < from.length; i++) { where.append(i == 0 ? "?" : ",?"); args[i + 1] = from[i].name(); }
            where.append(')');
            ContentValues cv = new ContentValues();
            cv.put("state", to.name()); cv.put("updated_at", now);
            if (error != null) cv.put("error", error);
            return db().update("deliveries", cv, where.toString(), args) == 1;
        });
    }

    @Override public void recordProviderIds(String deliveryId, String providerUserMsgId, String providerAsstMsgId) {
        atomic(() -> {
            if (providerUserMsgId != null && !providerUserMsgId.isEmpty())
                db().execSQL("UPDATE deliveries SET provider_user_msg_id=? WHERE id=?", new Object[]{providerUserMsgId, deliveryId});
            if (providerAsstMsgId != null && !providerAsstMsgId.isEmpty())
                db().execSQL("UPDATE deliveries SET provider_asst_msg_id=? WHERE id=?", new Object[]{providerAsstMsgId, deliveryId});
            return null;
        });
    }

    @Override public void setDeliveryReply(String deliveryId, String replyMessageId) {
        atomic(() -> { db().execSQL("UPDATE deliveries SET reply_message_id=? WHERE id=?", new Object[]{replyMessageId, deliveryId}); return null; });
    }

    @Override public List<Delivery> deliveriesInState(DeliveryState state) {
        return atomic(() -> {
            List<Delivery> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + DEL_COLS + " FROM deliveries WHERE state=? ORDER BY created_at", new String[]{state.name()})) {
                while (c.moveToNext()) out.add(readDelivery(c));
            }
            return out;
        });
    }

    @Override public int markInFlightUncertain(long now) {
        return atomic(() -> {
            ContentValues cv = new ContentValues();
            cv.put("state", DeliveryState.UNCERTAIN.name()); cv.put("error", "interrupted (app restart)"); cv.put("updated_at", now);
            return db().update("deliveries", cv, "state IN ('SENDING','SENT')", null);
        });
    }

    // ------------------------------------------------------------------ room-scoped provider bindings with history

    @Override public ProviderBinding getBinding(String roomId, String providerId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT conversation_id, restore_locator, display_title, bound_at FROM room_bindings "
                    + "WHERE room_id=? AND provider_id=? AND state='ACTIVE'", new String[]{roomId, providerId})) {
                return c.moveToFirst() ? new ProviderBinding(providerId, c.getString(0), c.getString(1), c.getString(2), c.getLong(3)) : null;
            }
        });
    }

    @Override public void putBinding(String roomId, ProviderBinding b) {
        atomic(() -> {
            if (b.providerConversationId == null || b.providerConversationId.isEmpty()) throw new IllegalArgumentException("an ACTIVE binding needs a conversation id");
            if (DatabaseUtils.longForQuery(db(), "SELECT COUNT(*) FROM participants WHERE room_id=? AND provider_id=?", new String[]{roomId, b.providerId}) == 0L)
                throw new IllegalStateException("FK: " + b.providerId + " is not seated in room " + roomId);
            String curId = null, curState = null, curConv = null;
            try (Cursor c = db().rawQuery("SELECT id, state, conversation_id FROM room_bindings WHERE room_id=? AND provider_id=? AND state IN ('ACTIVE','PENDING_NEW')",
                    new String[]{roomId, b.providerId})) {
                if (c.moveToFirst()) { curId = c.getString(0); curState = c.getString(1); curConv = c.getString(2); }
            }
            if (curId != null && BindingRecord.ACTIVE.equals(curState) && b.providerConversationId.equals(curConv)) return null; // same thread: nothing to do
            if (curId != null) { // retire first: only one current binding per room + AI is allowed
                db().execSQL("UPDATE room_bindings SET state='RETIRED', retired_at=?, retired_reason='rebound' WHERE id=?", new Object[]{b.boundAt, curId});
            }
            db().execSQL("INSERT INTO room_bindings(id, room_id, provider_id, state, conversation_id, restore_locator, display_title, bound_at) VALUES (?,?,?,'ACTIVE',?,?,?,?)",
                    new Object[]{UUID.randomUUID().toString(), roomId, b.providerId, b.providerConversationId, b.restoreLocator, b.displayTitle, b.boundAt});
            return null;
        });
    }

    @Override public void clearBinding(String roomId, String providerId, long now) {
        atomic(() -> {
            db().execSQL("UPDATE room_bindings SET state='RETIRED', retired_at=?, retired_reason='cleared' WHERE room_id=? AND provider_id=? AND state IN ('ACTIVE','PENDING_NEW')",
                    new Object[]{now, roomId, providerId});
            return null;
        });
    }

    @Override public List<BindingRecord> bindingHistory(String roomId, String providerId) {
        return atomic(() -> {
            List<BindingRecord> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT id, room_id, provider_id, state, conversation_id, restore_locator, display_title, bound_at, retired_at, retired_reason "
                    + "FROM room_bindings WHERE room_id=? AND provider_id=? ORDER BY rowid DESC", new String[]{roomId, providerId})) {
                while (c.moveToNext()) {
                    BindingRecord r = new BindingRecord(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getLong(7));
                    r.retiredAt = c.isNull(8) ? 0L : c.getLong(8);
                    r.retiredReason = c.getString(9);
                    out.add(r);
                }
            }
            return out;
        });
    }

    @Override public List<String> otherRoomsUsingThread(String providerId, String conversationId, String exceptRoomId) {
        return atomic(() -> {
            List<String> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT room_id FROM room_bindings WHERE provider_id=? AND conversation_id=? AND state='ACTIVE' AND room_id<>? "
                    + "GROUP BY room_id ORDER BY MIN(rowid)", new String[]{providerId, conversationId, exceptRoomId})) {
                while (c.moveToNext()) out.add(c.getString(0));
            }
            return out;
        });
    }

    // ------------------------------------------------------------------ legacy bindings (provider_bindings): the Engine Lab only, NEVER read by rooms

    public ProviderBinding getLegacyBinding(String providerId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT conversation_id, restore_locator, display_title, bound_at FROM provider_bindings WHERE provider_id=?",
                    new String[]{providerId})) {
                return c.moveToFirst() ? new ProviderBinding(providerId, c.getString(0), c.getString(1), c.getString(2), c.getLong(3)) : null;
            }
        });
    }

    public void putLegacyBinding(ProviderBinding b) {
        atomic(() -> {
            db().execSQL("INSERT OR REPLACE INTO provider_bindings(provider_id, conversation_id, restore_locator, display_title, bound_at) VALUES (?,?,?,?,?)",
                    new Object[]{b.providerId, b.providerConversationId, b.restoreLocator, b.displayTitle, b.boundAt});
            return null;
        });
    }

    public void clearLegacyBinding(String providerId) {
        atomic(() -> { db().execSQL("DELETE FROM provider_bindings WHERE provider_id=?", new Object[]{providerId}); return null; });
    }

    // ------------------------------------------------------------------ artifacts and transfers (the same rules as InMemoryRoomStore; the schema enforces them too)

    private static final String ART_COLS = "id, room_id, origin, display_name, mime, size, sha256, storage_path, state, created_at, source_binding_id";
    private static final String TR_COLS = "artifact_id, room_id, provider_id, binding_id, state, attempts, error, updated_at";
    static final String SQL_SOURCE_REPLY = "SELECT d.provider_asst_msg_id, d.provider_id, d.room_id FROM message_artifacts ma "
            + "JOIN deliveries d ON d.reply_message_id = ma.message_id AND d.room_id = ma.room_id WHERE ma.artifact_id = ?";
    static final String SQL_CREATE_ARTIFACT = "INSERT INTO artifacts(id, room_id, origin, source_binding_id, display_name, mime, state, created_at) VALUES (?,?,?,?,?,?,'PENDING_CAPTURE',?)";
    static final String SQL_FINALIZE_ARTIFACT = "UPDATE artifacts SET state='READY', mime=?, size=?, sha256=?, storage_path=? WHERE id=? AND state='PENDING_CAPTURE'";
    static final String SQL_FAIL_ARTIFACT = "UPDATE artifacts SET state='FAILED' WHERE id=? AND state='PENDING_CAPTURE'";
    static final String SQL_RETRY_ARTIFACT = "UPDATE artifacts SET state='PENDING_CAPTURE' WHERE id=? AND state='FAILED'";
    static final String SQL_ATTACH = "INSERT INTO message_artifacts(message_id, room_id, artifact_id, position) VALUES (?,?,?,?)";
    static final String SQL_DELETE_UNREFERENCED = "DELETE FROM artifacts WHERE id=? AND NOT EXISTS (SELECT 1 FROM message_artifacts m WHERE m.artifact_id = artifacts.id) "
            + "AND NOT EXISTS (SELECT 1 FROM artifact_transfers t WHERE t.artifact_id = artifacts.id)";
    static final String SQL_ACTIVE_BINDING_ID = "SELECT id FROM room_bindings WHERE room_id=? AND provider_id=? AND state='ACTIVE'";
    static final String SQL_ENSURE_TRANSFER = "INSERT OR IGNORE INTO artifact_transfers(artifact_id, room_id, provider_id, binding_id, state, attempts, error, updated_at) VALUES (?,?,?,?,'PENDING',0,'',?)";
    static final String SQL_OTHER_SENDING = "SELECT COUNT(*) FROM artifact_transfers WHERE state='SENDING' AND NOT (artifact_id=? AND binding_id=?)";
    static final String SQL_TRANSITION = "UPDATE artifact_transfers SET state=?, attempts = attempts + (CASE WHEN state <> 'SENDING' AND ? = 'SENDING' THEN 1 ELSE 0 END), "
            + "error = COALESCE(?, error), updated_at=? WHERE artifact_id=? AND binding_id=? AND state IN (?,?,?,?)";
    static final String SQL_INTERRUPT_TRANSFERS = "UPDATE artifact_transfers SET state='FAILED', error='interrupted (app restart)', updated_at=? WHERE state IN ('SENDING','STAGED')";
    static final String SQL_INTERRUPT_ARTIFACTS = "UPDATE artifacts SET state='FAILED' WHERE state='PENDING_CAPTURE'";

    private static Artifact readArtifact(Cursor c, int o) {
        return new Artifact(c.getString(o), c.getString(o + 1), c.getString(o + 2), c.isNull(o + 10) ? null : c.getString(o + 10), c.getString(o + 3), c.getString(o + 4), c.getLong(o + 5),
                c.getString(o + 6), c.getString(o + 7), ArtifactState.valueOf(c.getString(o + 8)), c.getLong(o + 9));
    }

    private static ArtifactTransfer readTransfer(Cursor c) {
        return new ArtifactTransfer(c.getString(0), c.getString(1), c.getString(2), c.getString(3), TransferState.valueOf(c.getString(4)), c.getInt(5), c.getString(6), c.getLong(7));
    }

    /** Runs one UPDATE/DELETE and returns how many rows it changed. */
    private int changed(String sql, Object... args) {
        SQLiteStatement st = db().compileStatement(sql);
        try {
            for (int i = 0; i < args.length; i++) {
                Object a = args[i];
                if (a == null) st.bindNull(i + 1);
                else if (a instanceof Long || a instanceof Integer) st.bindLong(i + 1, ((Number) a).longValue());
                else st.bindString(i + 1, a.toString());
            }
            return st.executeUpdateDelete();
        } finally { st.close(); }
    }

    private static boolean validSha(String h) {
        if (h == null || h.length() != 64) return false;
        for (int i = 0; i < 64; i++) if (Character.digit(h.charAt(i), 16) < 0) return false;
        return true;
    }

    @Override public Artifact createArtifact(String id, String roomId, String origin, String sourceBindingId, String displayName, String mime, long now) {
        return atomic(() -> {
            if (getRoom(roomId) == null) throw new IllegalStateException("FK: unknown room " + roomId);
            if (getArtifact(id) != null) throw new IllegalStateException("artifact already exists: " + id);
            if (origin == null || origin.isEmpty()) throw new IllegalArgumentException("an artifact must say where it came from");
            if (!Artifact.ORIGIN_USER.equals(origin) && sourceBindingId == null) throw new IllegalArgumentException("an AI file must name the conversation it came from");
            if (sourceBindingId != null) {
                if (Artifact.ORIGIN_USER.equals(origin)) throw new IllegalArgumentException("a user file has no source conversation");
                if (DatabaseUtils.longForQuery(db(), "SELECT COUNT(*) FROM room_bindings WHERE id=? AND room_id=? AND provider_id=? AND state IN ('ACTIVE','RETIRED')", new String[]{sourceBindingId, roomId, origin}) == 0L)
                    throw new IllegalStateException("FK: the source conversation is not a conversation of " + origin + " in this room");
            }
            db().execSQL(SQL_CREATE_ARTIFACT, new Object[]{id, roomId, origin, sourceBindingId, ArtifactNames.clean(displayName), mime == null ? "" : mime, now});
            return getArtifact(id);
        });
    }

    @Override public String activeBindingId(String roomId, String providerId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery(SQL_ACTIVE_BINDING_ID, new String[]{roomId, providerId})) { return c.moveToFirst() ? c.getString(0) : null; }
        });
    }

    @Override public Artifact getArtifact(String id) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT " + ART_COLS + " FROM artifacts WHERE id=?", new String[]{id})) {
                return c.moveToFirst() ? readArtifact(c, 0) : null;
            }
        });
    }

    @Override public boolean finalizeArtifact(String id, String mime, long size, String sha256, String storagePath) {
        return atomic(() -> {
            Artifact a = getArtifact(id);
            if (a == null) return false;
            if (size < 0 || !validSha(sha256) || storagePath == null || storagePath.isEmpty()) throw new IllegalArgumentException("a READY artifact needs size >= 0, a 64-character hex SHA-256 and a storage path");
            if (a.state == ArtifactState.READY) { // idempotent repeat of the same capture; anything different is refused
                return a.size == size && a.sha256.equalsIgnoreCase(sha256) && a.storagePath.equals(storagePath) && (mime == null || a.mime.equals(mime));
            }
            if (a.state != ArtifactState.PENDING_CAPTURE) return false;
            return changed(SQL_FINALIZE_ARTIFACT, mime == null ? a.mime : mime, size, sha256, storagePath, id) == 1;
        });
    }

    @Override public String sourceReplyRef(String artifactId) {
        return atomic(() -> {
            Artifact a = getArtifact(artifactId);
            if (a == null || a.fromUser()) return "";
            String ref = null;
            int rows = 0;
            try (Cursor c = db().rawQuery(SQL_SOURCE_REPLY, new String[]{artifactId})) {
                while (c.moveToNext()) {
                    rows++;
                    if (!a.origin.equals(c.getString(1)) || !a.roomId.equals(c.getString(2))) return "";   // another AI or another room: not provable
                    ref = c.getString(0);
                }
            }
            return rows == 1 && ref != null ? ref : "";   // exactly one delivery owns the reply this file is attached to
        });
    }

    @Override public boolean failArtifact(String id) { return atomic(() -> changed(SQL_FAIL_ARTIFACT, id) == 1); }

    @Override public boolean retryArtifact(String id) { return atomic(() -> changed(SQL_RETRY_ARTIFACT, id) == 1); }

    @Override public void attachArtifact(String messageId, String artifactId, int position) {
        atomic(() -> {
            RoomMessage m = getMessage(messageId);
            if (m == null) throw new IllegalStateException("FK: unknown message " + messageId);
            Artifact a = getArtifact(artifactId);
            if (a == null) throw new IllegalStateException("FK: unknown artifact " + artifactId);
            if (!a.roomId.equals(m.roomId)) throw new IllegalStateException("FK: artifact and message belong to different rooms");
            for (Artifact existing : artifactsOfMessage(messageId)) if (existing.id.equals(artifactId)) throw new IllegalStateException("already attached");
            db().execSQL(SQL_ATTACH, new Object[]{messageId, m.roomId, artifactId, position});
            return null;
        });
    }

    @Override public List<Artifact> artifactsOfMessage(String messageId) {
        return atomic(() -> {
            List<Artifact> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT a.id, a.room_id, a.origin, a.display_name, a.mime, a.size, a.sha256, a.storage_path, a.state, a.created_at, a.source_binding_id "
                    + "FROM message_artifacts ma JOIN artifacts a ON a.id = ma.artifact_id AND a.room_id = ma.room_id WHERE ma.message_id=? ORDER BY ma.position, ma.rowid", new String[]{messageId})) {
                while (c.moveToNext()) out.add(readArtifact(c, 0));
            }
            return out;
        });
    }

    @Override public List<AttachedArtifact> attachmentsBetween(String roomId, long afterSeq, long uptoSeq) {
        return atomic(() -> {
            List<AttachedArtifact> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT m.id, m.seq, m.author_type, m.author_id, ma.position, a.id, a.room_id, a.origin, a.display_name, a.mime, a.size, a.sha256, a.storage_path, a.state, a.created_at, a.source_binding_id "
                    + "FROM message_artifacts ma JOIN messages m ON m.id = ma.message_id AND m.room_id = ma.room_id JOIN artifacts a ON a.id = ma.artifact_id AND a.room_id = ma.room_id "
                    + "WHERE m.room_id=? AND m.seq > ? AND m.seq <= ? ORDER BY m.seq, ma.position, ma.rowid", new String[]{roomId, String.valueOf(afterSeq), String.valueOf(uptoSeq)})) {
                while (c.moveToNext()) out.add(new AttachedArtifact(c.getString(0), c.getLong(1), c.getString(2), c.getString(3), c.getInt(4), readArtifact(c, 5)));
            }
            return out;
        });
    }

    @Override public List<Artifact> artifactsNotReady() {
        return atomic(() -> {
            List<Artifact> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + ART_COLS + " FROM artifacts WHERE state <> 'READY' ORDER BY rowid", null)) {
                while (c.moveToNext()) out.add(readArtifact(c, 0));
            }
            return out;
        });
    }

    @Override public boolean deleteUnreferencedArtifact(String id) { return atomic(() -> changed(SQL_DELETE_UNREFERENCED, id) == 1); }

    @Override public ArtifactTransfer ensureTransfer(String artifactId, String roomId, String providerId, long now) {
        return atomic(() -> {
            Artifact a = getArtifact(artifactId);
            if (a == null) throw new IllegalStateException("FK: unknown artifact " + artifactId);
            if (!a.roomId.equals(roomId)) throw new IllegalStateException("FK: artifact belongs to another room");
            if (a.state != ArtifactState.READY) throw new IllegalStateException("a transfer needs a READY artifact");
            String bindingId = null;
            try (Cursor c = db().rawQuery(SQL_ACTIVE_BINDING_ID, new String[]{roomId, providerId})) { if (c.moveToFirst()) bindingId = c.getString(0); }
            if (bindingId == null) return null;
            db().execSQL(SQL_ENSURE_TRANSFER, new Object[]{artifactId, roomId, providerId, bindingId, now});
            try (Cursor c = db().rawQuery("SELECT " + TR_COLS + " FROM artifact_transfers WHERE artifact_id=? AND binding_id=?", new String[]{artifactId, bindingId})) {
                return c.moveToFirst() ? readTransfer(c) : null;
            }
        });
    }

    @Override public ArtifactTransfer currentTransfer(String artifactId, String roomId, String providerId) {
        return atomic(() -> {
            try (Cursor c = db().rawQuery("SELECT t.artifact_id, t.room_id, t.provider_id, t.binding_id, t.state, t.attempts, t.error, t.updated_at FROM artifact_transfers t "
                    + "JOIN room_bindings b ON b.id = t.binding_id WHERE t.artifact_id=? AND t.room_id=? AND t.provider_id=? AND b.state='ACTIVE'", new String[]{artifactId, roomId, providerId})) {
                return c.moveToFirst() ? readTransfer(c) : null;
            }
        });
    }

    @Override public boolean transitionTransfer(String artifactId, String bindingId, TransferState[] from, TransferState to, String error, long now) {
        return atomic(() -> {
            // only the source states that may legally move to `to` take part, so an illegal pair is a plain "no" (like InMemoryRoomStore) and never a trigger error
            String[] allowed = new String[4]; int n = 0;
            for (TransferState f : from) if (f.canMoveTo(to) && n < 4) allowed[n++] = f.name();
            if (n == 0) return false;
            for (int i = n; i < 4; i++) allowed[i] = allowed[0];
            if (to == TransferState.SENDING && DatabaseUtils.longForQuery(db(), SQL_OTHER_SENDING, new String[]{artifactId, bindingId}) > 0L) return false; // global single-flight
            return changed(SQL_TRANSITION, to.name(), to.name(), error, now, artifactId, bindingId, allowed[0], allowed[1], allowed[2], allowed[3]) == 1;
        });
    }

    @Override public List<ArtifactTransfer> transfersInState(TransferState state) {
        return atomic(() -> {
            List<ArtifactTransfer> out = new ArrayList<>();
            try (Cursor c = db().rawQuery("SELECT " + TR_COLS + " FROM artifact_transfers WHERE state=? ORDER BY rowid", new String[]{state.name()})) {
                while (c.moveToNext()) out.add(readTransfer(c));
            }
            return out;
        });
    }

    @Override public int markArtifactWorkInterrupted(long now) {
        return atomic(() -> changed(SQL_INTERRUPT_TRANSFERS, now) + changed(SQL_INTERRUPT_ARTIFACTS));
    }
}
