package com.aigroupchat.bridge.room.sqlite;

import java.util.ArrayList;
import java.util.List;

/** Splits the asset SQL scripts into single statements. Pure Java so the exact same code is testable without Android.
 *  Rules (identical to tools/roomtest/migration_test.py): statements are separated by a line "-- @@"; lines that start with "--"
 *  are comments and dropped; empty chunks are skipped; ":now" and ":natural_turns" are filled in. */
public final class SqlScript {
    public static final String SEPARATOR = "\n-- @@\n";

    private SqlScript() {}

    public static List<String> statements(String script, long now, int naturalTurns) {
        List<String> out = new ArrayList<>();
        for (String chunk : script.replace("\r\n", "\n").split(SEPARATOR)) {
            StringBuilder sb = new StringBuilder();
            for (String line : chunk.split("\n")) {
                if (line.trim().startsWith("--")) continue;
                sb.append(line).append('\n');
            }
            String sql = sb.toString().trim();
            if (sql.isEmpty()) continue;
            out.add(sql.replace(":now", String.valueOf(now)).replace(":natural_turns", String.valueOf(naturalTurns)));
        }
        return out;
    }
}
