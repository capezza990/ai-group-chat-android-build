package com.aigroupchat.bridge.room.sqlite;

/** The fixed order of the v1 -> v2 database upgrade, kept free of Android classes so a test can prove the order.
 *  The order matters: old preference bindings must already be in the v1 provider_bindings table when the migration script copies
 *  provider_bindings into room_bindings; otherwise they would arrive too late and no room would ever see them.
 *  Everything runs inside the one transaction SQLiteOpenHelper wraps around onCreate/onUpgrade: if any step throws, all of it rolls back. */
public final class UpgradeV2 {
    public interface Steps {
        /** Copy bindings that still live only in the old SharedPreferences into provider_bindings (the v1 table). */
        void importLegacyPreferenceBindings();
        /** Run assets/room_migration_v1_to_v2.sql. */
        void runMigrationScript();
        /** PRAGMA foreign_key_check: throw if any row is left dangling, which aborts the whole upgrade. */
        void checkForeignKeys();
    }

    private UpgradeV2() {}

    public static void run(Steps s) {
        s.importLegacyPreferenceBindings();
        s.runMigrationScript();
        s.checkForeignKeys();
    }
}
