package com.aigroupchat.bridge.room.ui;

import android.content.Context;

import com.aigroupchat.bridge.engine.WebArtifactTransport;
import com.aigroupchat.bridge.engine.WebCaptureTransport;
import com.aigroupchat.bridge.engine.WebProviderSurface;
import com.aigroupchat.bridge.room.ArtifactLifecycle;
import com.aigroupchat.bridge.room.ArtifactService;
import com.aigroupchat.bridge.room.ArtifactStorage;
import com.aigroupchat.bridge.room.MockArtifactTransport;
import com.aigroupchat.bridge.room.MockCaptureTransport;
import com.aigroupchat.bridge.room.sqlite.RoomDb;

import java.io.File;
import java.util.Map;
import java.util.UUID;

/**
 * The process-wide home of the ONE shared file service. It holds no screen: only the application context, the database and the {@link ArtifactLifecycle}.
 * A screen attaches its provider pages (live) or mock transports (mock mode) when it starts and detaches when it is destroyed; detaching cancels/resolves a
 * running file job first, while the pages still exist.
 */
public final class ArtifactRuntime {
    private static ArtifactRuntime instance;

    private final RoomDb db;
    private final File captureTmp;
    private final ArtifactLifecycle lifecycle;

    private ArtifactRuntime(Context applicationContext, RoomDb db) {
        this.db = db;
        this.captureTmp = new File(applicationContext.getCacheDir(), "capture");
        ArtifactStorage storage = new ArtifactStorage(new File(applicationContext.getFilesDir(), "artifacts"));
        this.lifecycle = ArtifactLifecycle.create(db, storage, System::currentTimeMillis, () -> UUID.randomUUID().toString(), ArtifactService.DEFAULT_MAX_FILE_BYTES);
    }

    /** The same instance for the whole life of the process (the database is a process-wide singleton too). */
    public static synchronized ArtifactRuntime get(Context context, RoomDb db) {
        if (instance == null) instance = new ArtifactRuntime(context.getApplicationContext(), db);
        return instance;
    }

    public ArtifactService service() { return lifecycle.service(); }

    /** Live mode: this screen's provider pages become the upload and capture mechanisms. */
    public void attachLive(Object owner, Map<String, WebProviderSurface> surfaces) {
        lifecycle.attach(owner, new WebArtifactTransport(surfaces, db),
                new WebCaptureTransport(surfaces, db, captureTmp, ArtifactService.DEFAULT_MAX_FILE_BYTES, WebCaptureTransport.DEFAULT_TIMEOUT_MS));
    }

    /** Mock mode has no provider pages: files move through the mock transports (instantly), so the whole file flow can be tried without the real sites. */
    public void attachMock(Object owner) {
        MockCaptureTransport capture = new MockCaptureTransport();
        capture.defaultContent = "mock file".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        lifecycle.attach(owner, new MockArtifactTransport(), capture);
    }

    /** Cancels/resolves a running file job and unlinks the transports. Only the attached owner can detach. */
    public void detach(Object owner) { lifecycle.detach(owner); }
}
