package com.aigroupchat.bridge.room.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Round participant avatar with an optional status dot. Uses the participant's real installed-app icon when available;
 *  otherwise a neutral monogram (never an approximated logo). */
final class AvatarView extends View {
    private final ProviderStyle style;
    private final Drawable icon; // nullable, private instance
    private final boolean showDot;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();

    AvatarView(Context c, ProviderStyle style, Drawable icon, boolean showDot, int dotColor) {
        super(c);
        this.style = style;
        this.icon = icon;
        this.showDot = showDot;
        fill.setColor(style.avatarBg);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(0x33FFFFFF);
        textPaint.setColor(style.monoColor);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        dotPaint.setColor(dotColor);
        dotRing.setStyle(Paint.Style.STROKE);
        dotRing.setColor(0xFF0A0F1C);
    }

    private boolean working;

    void setDotColor(int color) { dotPaint.setColor(color); invalidate(); }

    /** While the AI is responding the status dot becomes an animated "..." badge (green/red/gray stay plain dots). */
    void setWorking(boolean w) {
        if (w == working) return;
        working = w;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = Math.min(w, h) / 2f - 1f;
        float cx = w / 2f, cy = h / 2f;
        canvas.drawCircle(cx, cy, r, fill);
        if (icon != null) {
            canvas.save();
            clip.reset();
            clip.addCircle(cx, cy, r, Path.Direction.CW);
            canvas.clipPath(clip);
            icon.setBounds(Math.round(cx - r), Math.round(cy - r), Math.round(cx + r), Math.round(cy + r));
            icon.draw(canvas);
            canvas.restore();
        } else if (style.person) {
            canvas.save();
            clip.reset();
            clip.addCircle(cx, cy, r - 1f, Path.Direction.CW);
            canvas.clipPath(clip);
            textPaint.setColor(style.monoColor);
            canvas.drawCircle(cx, cy - r * 0.18f, r * 0.30f, textPaint);
            canvas.drawOval(new RectF(cx - r * 0.62f, cy + r * 0.22f, cx + r * 0.62f, cy + r * 1.15f), textPaint);
            canvas.restore();
        } else {
            textPaint.setTextSize(style.monogram.length() > 1 ? r * 0.62f : r * 1.0f);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            canvas.drawText(style.monogram, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint);
        }
        ring.setStrokeWidth(Math.max(1f, r * 0.05f));
        canvas.drawCircle(cx, cy, r, ring);
        if (showDot && working) {
            float bw = r * 1.05f, bh = r * 0.56f;
            float bx = cx + r * 0.95f - bw / 2f, by = cy + r * 0.95f - bh / 2f;
            RectF pill = new RectF(bx, by, bx + bw, by + bh);
            dotRing.setStyle(Paint.Style.FILL);
            dotRing.setColor(0xFF0A0F1C);
            canvas.drawRoundRect(new RectF(pill.left - 2f, pill.top - 2f, pill.right + 2f, pill.bottom + 2f), bh / 2f + 2f, bh / 2f + 2f, dotRing);
            dotPaint.setColor(0xFF2B3550);
            canvas.drawRoundRect(pill, bh / 2f, bh / 2f, dotPaint);
            int phase = (int) ((System.currentTimeMillis() / 280L) % 3L);
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
            for (int i = 0; i < 3; i++) {
                dp.setColor(i == phase ? 0xFFFFFFFF : 0x80FFFFFF);
                canvas.drawCircle(pill.left + bw * (0.24f + 0.26f * i), pill.centerY(), bh * 0.14f, dp);
            }
            dotRing.setStyle(Paint.Style.STROKE);
            postInvalidateOnAnimation();
        } else if (showDot) {
            float dr = Math.max(4f, r * 0.24f);
            float dx = cx + r * 0.72f, dy = cy + r * 0.72f;
            dotRing.setStrokeWidth(Math.max(2f, dr * 0.45f));
            canvas.drawCircle(dx, dy, dr, dotRing);
            canvas.drawCircle(dx, dy, dr, dotPaint);
        }
    }
}
