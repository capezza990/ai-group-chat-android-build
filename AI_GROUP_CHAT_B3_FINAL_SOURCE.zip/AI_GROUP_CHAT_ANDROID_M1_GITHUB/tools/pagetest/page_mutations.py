#!/usr/bin/env python3
"""Deliberate breakages of the page script's safety rules: each one is applied to a COPY of agc_engine.js and page_test.js must then FAIL.
Needs node and network access for `npm install jsdom` (done once into a temporary folder). Usage: python3 page_mutations.py"""
import os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
script_path = os.path.join(ROOT, 'app', 'src', 'main', 'assets', 'agc_engine.js')
base = open(script_path, encoding='utf-8').read()

MUTS = [
 ('the offer check ignores the reply id',            " && o.msgId === fp.msgId", ""),
 ('the offer check ignores the address',             " && o.href === fp.href", ""),
 ('the offer check ignores the message position',    " && o.fromEnd === fp.fromEnd", ""),
 ('the offer check ignores the kind',                " && o.kind === fp.kind", ""),
 ('the offer check ignores the name',                " && o.name === fp.name", ""),
 ('a link may be clicked whatever its address',      "    if (!(o.kind === 'button' || /^sandbox:/i.test(o.href))) return JSON.stringify({ ok: false, error: 'not-clickable' });\n", ""),
 ('any link with a colon may be clicked',            "/^sandbox:/i.test(o.href))) return JSON.stringify({ ok: false, error: 'not-clickable' })", "/:/.test(o.href))) return JSON.stringify({ ok: false, error: 'not-clickable' })"),
 ('the capture does not check the address scheme',   "if (!o.href || !urlOk(o.href)) return JSON.stringify({ ok: false, error: (o.kind", "if (!o.href) return JSON.stringify({ ok: false, error: (o.kind"),
 ('plain http addresses may be fetched',             "/^(https:|blob:|data:)/i.test(String(u))", "/^(https?:|blob:|data:)/i.test(String(u))"),
 ('the page-side size cap is dropped',               "if (buf.byteLength > maxBytes) throw new Error('too-large');", ""),
 ('the declared size is not checked',                "if (len > maxBytes) throw new Error('too-large');", ""),
 ('a capture never frees the previous one',          "    caps = {}; // one capture at a time: the previous one's memory is released\n", ""),
 ('the probe reports full addresses',                "return (m ? m[1] + (m[2] || '') : '?') + (ext ? ' .' + ext[1].toLowerCase() : '');", "return h;"),
 ('the message id is taken from a child element',    "var e = (n.getAttribute && n.getAttribute('data-message-id')) ? n : (n.closest ? n.closest('[data-message-id]') : null);", "var e = (n.getAttribute && n.getAttribute('data-message-id')) ? n : (n.querySelector ? n.querySelector('[data-message-id]') : null);"),
]

tmp = tempfile.mkdtemp(prefix='pagemut-')
try:
    os.makedirs(os.path.join(tmp, 'tools', 'pagetest')); os.makedirs(os.path.join(tmp, 'app', 'src', 'main', 'assets'))
    for f in ('page_test.js', 'package.json'): shutil.copy(os.path.join(HERE, f), os.path.join(tmp, 'tools', 'pagetest', f))
    tdir = os.path.join(tmp, 'tools', 'pagetest')
    r = subprocess.run(['npm', 'install', '--no-audit', '--no-fund'], cwd=tdir, capture_output=True, text=True)
    if r.returncode != 0: print('npm install failed: ' + r.stderr[-300:]); sys.exit(2)
    target = os.path.join(tmp, 'app', 'src', 'main', 'assets', 'agc_engine.js')
    def run(src):
        open(target, 'w', encoding='utf-8').write(src)
        p = subprocess.run(['node', 'page_test.js'], cwd=tdir, capture_output=True, text=True, timeout=120)
        return p.returncode
    if run(base) != 0: print('FAIL  the unmodified script does not pass its own tests'); sys.exit(1)
    survivors = 0
    for what, a, b in MUTS:
        if a not in base: print('ANCHOR MISSING  ' + what); survivors += 1; continue
        code = run(base.replace(a, b, 1))
        print(('caught    ' if code != 0 else 'SURVIVED  <-- not caught  ') + what)
        if code == 0: survivors += 1
    print('%d breakages, %d survivors' % (len(MUTS), survivors)); sys.exit(1 if survivors else 0)
finally:
    shutil.rmtree(tmp, ignore_errors=True)
