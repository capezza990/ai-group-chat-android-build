// Off-device tests for the page script (agc_engine.js) under jsdom: Stop/abortSend atomicity, nonce identity under a
// virtualized message list, "an older answer can never be captured", and hidden screen-reader text removal.
// jsdom has no layout and no innerText, so a tiny innerText polyfill (honouring inline display:none) is installed.
// This validates the script's LOGIC; real provider pages and the real WebView are still validated on the phone.
const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');
const script = fs.readFileSync(path.join(__dirname, '..', '..', 'app', 'src', 'main', 'assets', 'agc_engine.js'), 'utf8');

let checks = 0, failures = 0;
function check(ok, what) { checks++; if (!ok) { failures++; console.log('    FAIL: ' + what); } }
const sleep = ms => new Promise(r => setTimeout(r, ms));

function makePage(opts) {
  opts = opts || {};
  const html = '<body><div id="list">' + (opts.listHtml || '') + '</div><form id="composer-root"><textarea id="c">' + (opts.draft || '') + '</textarea>' +
    '<input id="file" type="file"><button id="s" type="button"' + (opts.sendDisabled === false ? '' : ' disabled') + '>send</button></form></body>';
  const dom = new JSDOM(html, { url: 'https://x.test/c/abc123', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  Object.defineProperty(w.HTMLElement.prototype, 'innerText', {
    get() {
      const walk = n => {
        if (n.nodeType === 3) return n.textContent;
        if (n.nodeType !== 1 || (n.style && n.style.display === 'none')) return '';
        let t = ''; n.childNodes.forEach(c => { t += walk(c); });
        return /^(P|DIV)$/.test(n.tagName) ? t + '\n' : t;
      };
      return walk(this).replace(/\n+$/, '');
    }, configurable: true
  });
  w.scrollTo = () => {}; // jsdom has no layout; the script only nudges the page to its end
  w.__AGC_SPEC = { composer: ['#c'], send: ['#s'], user: ['.u'], assistant: ['.a'], stop: ['#stop'], streaming: ['[data-streaming=true]'],
    attachmentRoot: ['#composer-root'], attachment: ['.attachment'], attachmentRemove: ['.remove-attachment'], fileInput: ['input[type=file]'] };
  w.eval(script);
  const clicks = { n: 0 };
  w.document.getElementById('s').addEventListener('click', () => { clicks.n++; });
  return { w, dom, clicks, ta: w.document.getElementById('c'), btn: w.document.getElementById('s'), list: w.document.getElementById('list') };
}
const poll = p => JSON.parse(p.w.__agc.poll());
const bubble = (p, cls, text) => { const d = p.w.document.createElement('div'); d.className = cls; d.textContent = text; p.list.appendChild(d); return d; };

function makeUploadProfile(provider) {
  const chatgpt = provider === 'chatgpt';
  const composer = chatgpt ? '<textarea id="prompt-textarea"></textarea>' : '<div class="ProseMirror" contenteditable="true"></div>';
  const chip = chatgpt ? '<div data-testid="composer-attachment"><button aria-label="Remove file report.pdf"></button></div>'
    : '<div data-testid="attachment"><button aria-label="Remove attachment report.pdf"></button></div>';
  const dom = new JSDOM('<body><form' + (chatgpt ? ' data-type="unified-composer"' : '') + '>' + composer + '<input type="file">' + chip + '</form></body>',
    { url: chatgpt ? 'https://chatgpt.com/c/00000000-0000-0000-0000-000000000000' : 'https://claude.ai/chat/00000000-0000-0000-0000-000000000000', runScripts: 'outside-only' });
  const w = dom.window;
  w.__AGC_SPEC = chatgpt ? {
    composer: ['#prompt-textarea'], send: ["button[data-testid='send-button']"], stop: [], streaming: [], assistant: [], user: [],
    attachmentRoot: ["form[data-type='unified-composer']", 'form'], attachment: ["[data-testid='composer-attachment']", "[data-testid='file-thumbnail']"],
    attachmentRemove: ["button[aria-label^='Remove file']", "button[aria-label^='Remove attachment']"], attachmentBusy: ["[data-testid='composer-attachment'][data-state='uploading']", "[aria-label='Uploading file']"], fileInput: ["input[type='file']"]
  } : {
    composer: ["div.ProseMirror[contenteditable='true']"], send: ["button[aria-label='Send message']"], stop: [], streaming: [], assistant: [], user: [],
    attachmentRoot: ['form', 'fieldset'], attachment: ["[data-testid='attachment']", "[data-testid='composer-attachment']"],
    attachmentRemove: ["button[aria-label^='Remove attachment']", "button[aria-label^='Remove file']"], attachmentBusy: ["[data-testid='attachment'][data-state='uploading']", "[aria-label='Uploading']"], fileInput: ["input[type='file']"]
  };
  const remove = w.document.querySelector('button[aria-label^="Remove"]');
  remove.addEventListener('click', e => { e.preventDefault(); remove.parentElement.remove(); });
  w.eval(script);
  return { w, dom };
}

(async () => {
  // ---- abortSend: atomic with respect to the click
  let p = makePage();
  check(p.w.__agc.send('[ref n0nce1] hello', 'abc123', 'n0nce1') === 'inserted' && p.ta.value === '[ref n0nce1] hello', 'send inserts the text (send button disabled, loop waiting)');
  check(p.w.__agc.abortSend() === 'aborted', 'abortSend before the click -> aborted');
  check(p.ta.value === '', 'only the text we inserted is removed');
  p.btn.disabled = false;
  await sleep(700);
  check(p.clicks.n === 0, 'the click NEVER happens after an abort, even when the send button becomes enabled later (' + p.clicks.n + ' clicks)');
  check(p.w.__agc.abortSend() === 'not-sent', 'a second abort reports not-sent');

  // only the abort guard can stop the click here: the composer is ambiguous at abort time, so the inserted text cannot be cleared
  p = makePage();
  p.w.__agc.send('[ref n0nce5] hello', 'abc123', 'n0nce5');
  const dup = p.w.document.createElement('textarea'); dup.id = 'c'; p.w.document.body.appendChild(dup); // a second #c: ambiguous
  check(p.w.__agc.abortSend() === 'aborted' && p.ta.value === '[ref n0nce5] hello', 'abort with an ambiguous composer: aborted, text left alone (we never guess)');
  p.btn.disabled = false;
  await sleep(700);
  check(p.clicks.n === 0, 'the abort flag alone prevents the click even though the text still matches (' + p.clicks.n + ' clicks)');

  p = makePage({ sendDisabled: false });
  check(p.w.__agc.send('[ref n0nce2] hi', 'abc123', 'n0nce2') === 'inserted', 'send inserted');
  check(p.clicks.n === 1, 'the send button was clicked once');
  check(p.w.__agc.abortSend() === 'clicked', 'abortSend after the click -> clicked (the room must drain, never retry)');
  check(p.ta.value === '[ref n0nce2] hi', 'nothing is cleared after the click');

  p = makePage();
  p.w.__agc.send('[ref n0nce3] hello', 'abc123', 'n0nce3');
  p.ta.value = 'something the USER typed instead';
  check(p.w.__agc.abortSend() === 'aborted', 'abort still reports aborted');
  check(p.ta.value === 'something the USER typed instead', 'text that is NOT ours is never cleared');

  p = makePage({ draft: 'my own draft' });
  check(p.w.__agc.send('[ref n0nce4] x', 'abc123', 'n0nce4') === 'composer-not-empty', 'a non-empty composer refuses the send');
  check(p.w.__agc.abortSend() === 'not-sent' && p.ta.value === 'my own draft', 'refused earlier -> not-sent, the user draft is untouched');

  p = makePage();
  check(p.w.__agc.abortSend() === 'none', 'no send ever performed -> "none" (the Java side treats unknown as possibly sent)');

  // ---- identity by our own [ref] bubble, independent of counts (the real Claude virtualization failure)
  p = makePage({ sendDisabled: false, listHtml: '<div class="u">old q1</div><div class="a">old a1</div><div class="u">old q2</div><div class="a">old a2</div>' +
    '<div class="u">old q3</div><div class="a">old a3</div><div class="u">old q4</div><div class="a">old a4</div>' });
  p.w.__agc.send('[ref v1rt01] review this', 'abc123', 'v1rt01');
  // the provider re-renders: virtualization unmounts old rows, mounts our bubble and the reply
  p.list.innerHTML = '<div class="a">old a4</div>';
  bubble(p, 'u', '[ref v1rt01] review this');
  bubble(p, 'a', 'The real reply');
  let r = poll(p);
  check(r.mode === 'nonce' && r.identity === true && r.userProven === true, 'identity proven by our [ref] bubble: ' + JSON.stringify({ m: r.mode, i: r.identity, u: r.userProven }));
  check(r.newA < 0 && r.newU < 0, 'while the legacy count deltas are negative (the exact field failure): newA=' + r.newA + ' newU=' + r.newU);
  check(p.w.__agc.full() === 'The real reply', 'the captured text is the reply after our bubble: ' + p.w.__agc.full());

  // ---- an older answer can never be captured; our bubble missing fails closed
  p = makePage({ sendDisabled: false, listHtml: '<div class="u">old q</div><div class="a">OLD ANSWER</div>' });
  p.w.__agc.send('[ref ol0001] new q', 'abc123', 'ol0001');
  bubble(p, 'u', '[ref ol0001] new q');
  r = poll(p);
  check(r.identity === false && r.userProven === true, 'our bubble is there but no reply yet: not identified');
  check(p.w.__agc.full() === '', 'the OLD answer (before our bubble) is never captured');
  bubble(p, 'a', 'fresh answer');
  r = poll(p);
  check(r.identity === true && p.w.__agc.full() === 'fresh answer', 'once a reply follows our bubble it is identified');
  p = makePage({ sendDisabled: false, listHtml: '<div class="u">old q</div><div class="a">OLD ANSWER</div>' });
  p.w.__agc.send('[ref gone01] q', 'abc123', 'gone01');
  r = poll(p);
  check(r.identity === false && r.userProven === false, 'our bubble not rendered at all: fails closed (no identity, not proven)');

  // ---- hidden screen-reader block ("Claude responded: ...") is not part of the captured reply
  p = makePage({ sendDisabled: false });
  p.w.__agc.send('[ref sr0001] hi', 'abc123', 'sr0001');
  bubble(p, 'u', '[ref sr0001] hi');
  const a = bubble(p, 'a', '');
  a.innerHTML = '<span class="sr-only">Claude responded: ok</span><div>ok</div>';
  poll(p);
  check(p.w.__agc.full() === 'ok', 'sr-only text removed: ' + JSON.stringify(p.w.__agc.full()));
  check(!a.querySelector('.sr-only').style.display, 'the hidden element is left exactly as it was found');

  // ---- stale attachment inspection and cleanup are composer-scoped and fail closed
  p = makePage();
  let state = JSON.parse(p.w.__agc.attachmentState());
  check(state.safe === true && state.count === 0, 'an empty composer has no stale attachments');
  const chip = p.w.document.createElement('div'); chip.className = 'attachment'; chip.textContent = 'old.pdf';
  const remove = p.w.document.createElement('button'); remove.type = 'button'; remove.className = 'remove-attachment';
  remove.addEventListener('click', () => chip.remove()); chip.appendChild(remove);
  p.w.document.getElementById('composer-root').appendChild(chip);
  state = JSON.parse(p.w.__agc.attachmentState());
  check(state.safe === true && state.count === 1 && state.removable === 1, 'one stale composer attachment is detected structurally');
  check(p.w.__agc.cleanupStaleAttachments() === 'cleanup-started', 'a fully removable stale attachment is cleaned');
  state = JSON.parse(p.w.__agc.attachmentState());
  check(state.safe === true && state.count === 0, 'cleanup is verified by the attachment disappearing');

  p = makePage();
  const unsafe = p.w.document.createElement('div'); unsafe.className = 'attachment';
  p.w.document.getElementById('composer-root').appendChild(unsafe);
  check(p.w.__agc.cleanupStaleAttachments() === 'refused:attachment-controls-do-not-match-visible-items', 'a visible attachment without an exact remove control is refused');
  check(p.w.document.body.contains(unsafe), 'refusal leaves the unknown attachment untouched');

  p = makePage();
  const outside = p.w.document.createElement('button'); outside.className = 'remove-attachment';
  p.w.document.body.insertBefore(outside, p.w.document.body.firstChild);
  state = JSON.parse(p.w.__agc.attachmentState());
  check(state.count === 0, 'attachment controls outside the composer root are ignored');

  p = makePage();
  let chooserClicks = 0;
  p.w.document.getElementById('file').addEventListener('click', e => { e.preventDefault(); chooserClicks++; });
  check(p.w.__agc.startFileUpload(0) === 'chooser-opened' && chooserClicks === 1, 'a clean composer opens exactly one native file chooser');
  const staged = p.w.document.createElement('div'); staged.className = 'attachment';
  const stagedRemove = p.w.document.createElement('button'); stagedRemove.type = 'button'; stagedRemove.className = 'remove-attachment'; staged.appendChild(stagedRemove);
  p.w.document.getElementById('composer-root').appendChild(staged);
  state = JSON.parse(p.w.__agc.attachmentState());
  check(state.safe === true && state.count === 1, 'the selected file is proven by a visible composer attachment');
  check(p.w.__agc.startFileUpload(0) === 'refused:attachment-count-changed' && chooserClicks === 1, 'a changed/stale attachment count cannot open another chooser');
  check(p.w.__agc.startFileUpload(1) === 'chooser-opened' && chooserClicks === 2, 'the same owned operation can stage its next file sequentially');

  p = makePage();
  p.w.__AGC_SPEC.attachmentBusy = ['.uploading'];
  const loading = p.w.document.createElement('div'); loading.className = 'attachment';
  const loadingRemove = p.w.document.createElement('button'); loadingRemove.type = 'button'; loadingRemove.className = 'remove-attachment'; loading.appendChild(loadingRemove);
  const spinner = p.w.document.createElement('span'); spinner.className = 'uploading'; loading.appendChild(spinner);
  p.w.document.getElementById('composer-root').appendChild(loading);
  state = JSON.parse(p.w.__agc.attachmentState());
  check(state.count === 1 && state.busy === 1 && state.ready === false, 'a visible uploading chip is not yet ready to send');
  spinner.remove();
  state = JSON.parse(p.w.__agc.attachmentState());
  check(state.ready === true, 'the chip becomes ready only after its upload indicator disappears');

  for (const provider of ['chatgpt', 'claude']) {
    const profile = makeUploadProfile(provider);
    state = JSON.parse(profile.w.__agc.attachmentState());
    check(state.safe === true && state.ready === true && state.count === 1, provider + ' adapter detects its visible ready attachment');
    check(profile.w.__agc.cleanupStaleAttachments() === 'cleanup-started', provider + ' adapter uses its exact removal control');
    state = JSON.parse(profile.w.__agc.attachmentState());
    check(state.count === 0, provider + ' adapter verifies actual DOM disappearance after cleanup');
  }

  // ------------------------------------------------------------ files an AI offers: read-only scan and PULL-based capture
  {
    const mk = () => {
      const q = makePage();
      q.w.__AGC_SPEC.offerLink = ['a.file']; q.w.__AGC_SPEC.offerButton = ['button.dl'];
      const msg = html => { const d = q.w.document.createElement('div'); d.className = 'a'; d.innerHTML = html; q.list.appendChild(d); return d; };
      return { q, msg };
    };
    const fetchCalls = [];
    const bytesOf = n => { const a = new Array(n); for (let i = 0; i < n; i++) a[i] = i % 251; return a; };
    const respond = (arr, headers, status) => ({ ok: (status || 200) < 400, status: status || 200, headers: { get: h => (headers || {})[String(h).toLowerCase()] || null }, arrayBuffer: () => Promise.resolve(new Uint8Array(arr).buffer) });

    let { q, msg } = mk();
    for (let i = 0; i < 7; i++) msg('<a class="file" href="https://x.test/old' + i + '" download="old' + i + '.txt">x</a>');
    msg('<p>Here you go</p><a class="file" href="https://x.test/f1" download="report.pdf" type="application/pdf">Download</a>' +
        '<button class="dl" aria-label="Download data.csv">Download</button>' +
        '<a class="file" href="sandbox:/mnt/data/s.txt">Download file: notes.md</a>' +
        '<a class="file" href="https://x.test/files/my%20doc.pdf"></a>');
    q.list.insertAdjacentHTML('afterend', '<a class="file" href="https://x.test/decoy" download="decoy.txt">decoy</a>');
    const before = q.w.document.body.innerHTML;
    const offers = JSON.parse(q.w.__agc.fileOffers());
    check(q.w.document.body.innerHTML === before, 'scanning for file offers never changes the page');
    const newest = offers.filter(o => o.fromEnd === 0).map(o => o.name + '|' + o.kind);
    check(newest.join(',') === 'report.pdf|link,notes.md|link,my doc.pdf|link,data.csv|button', 'the newest message lists its links then its buttons with names read from download, text, address and aria-label');
    check(offers.every(o => o.fromEnd <= 4) && !offers.some(o => o.name === 'decoy.txt') && !offers.some(o => o.name === 'old0.txt' || o.name === 'old1.txt'), 'only the 5 newest assistant messages are scanned and links outside assistant messages are ignored');
    check(offers.map(o => o.index).join(',') === offers.map((o, i) => i).join(','), 'offers are numbered in scan order');
    const rep = offers.find(o => o.name === 'report.pdf');
    check(rep.href === 'https://x.test/f1' && rep.mime === 'application/pdf' && offers.find(o => o.name === 'data.csv').href === '', 'a link reports its address and type, a button has no address');
    check(offers.find(o => o.name === 'notes.md').href === 'sandbox:/mnt/data/s.txt', 'a sandbox: address is reported as it is (the app will treat it as click-only)');

    // clicking is explicit and exact
    let clicked = [];
    q.w.document.querySelector('button.dl').addEventListener('click', () => clicked.push('data.csv'));
    const dl = offers.find(o => o.name === 'data.csv');
    check(JSON.parse(q.w.__agc.clickOffer(Object.assign({}, dl, { name: 'WRONG.csv' }))).error === 'offer-changed' && JSON.parse(q.w.__agc.clickOffer(Object.assign({}, dl, { index: 99 }))).error === 'offer-changed' && clicked.length === 0, 'a click needs the exact fingerprint; a wrong name or index clicks nothing');
    check(JSON.parse(q.w.__agc.clickOffer(dl)).ok === true && clicked.length === 1, 'the matching offer is clicked once');

    // pull-based capture
    q.w.fetch = (url, opts) => { fetchCalls.push({ url, credentials: opts && opts.credentials }); return Promise.resolve(respond(bytesOf(600000), { 'content-type': 'Application/PDF; charset=x' })); };
    check(JSON.parse(q.w.__agc.captureBegin('c1', rep, 1000000)).ok === true, 'a capture of a link offer starts');
    check(JSON.parse(q.w.__agc.captureStatus('c1')).state === 'pending' && q.w.__agc.captureChunk('c1', 0) === '!notready', 'while pending there is nothing to read');
    await sleep(30);
    const st = JSON.parse(q.w.__agc.captureStatus('c1'));
    check(st.state === 'ready' && st.size === 600000 && st.mime === 'application/pdf' && st.chunk === 262144 && st.chunks === 3, 'when ready the size, type and number of chunks are reported');
    check(fetchCalls.length === 1 && fetchCalls[0].url === 'https://x.test/f1' && fetchCalls[0].credentials === 'include', 'the page fetches with its own login');
    const got = []; let n = 0, piece;
    while ((piece = q.w.__agc.captureChunk('c1', n)) !== '') { got.push(Buffer.from(piece, 'base64')); n++; if (n > 10) break; }
    const all = Buffer.concat(got), want = Buffer.from(bytesOf(600000));
    check(n === 3 && all.length === 600000 && all.equals(want), 'pulling the chunks in order reproduces the file exactly');
    check(q.w.__agc.captureChunk('c1', 3) === '' && q.w.__agc.captureChunk('c1', -1) === '' && q.w.__agc.captureChunk('nope', 0) === '!notready', 'past the end is empty and an unknown capture is not ready');
    check(q.w.__agc.captureEnd('c1') === 'ok' && JSON.parse(q.w.__agc.captureStatus('c1')).state === 'none' && q.w.__agc.captureChunk('c1', 0) === '!notready', 'ending a capture frees it');

    // refusals
    const nf = fetchCalls.length;
    check(JSON.parse(q.w.__agc.captureBegin('c2', offers.find(o => o.name === 'notes.md'), 1000)).error === 'click-only', 'a sandbox: link cannot be fetched by the page');
    check(JSON.parse(q.w.__agc.captureBegin('c2', dl, 1000)).error === 'click-only', 'a button without an address cannot be fetched');
    check(JSON.parse(q.w.__agc.captureBegin('c2', Object.assign({}, rep, { name: 'other.pdf' }), 1000)).error === 'offer-changed', 'a changed name stops the capture');
    check(JSON.parse(q.w.__agc.captureUrl('c2', 'http://x.test/a', 1000)).error === 'url-not-allowed' && JSON.parse(q.w.__agc.captureUrl('c2', 'javascript:alert(1)', 1000)).error === 'url-not-allowed' && JSON.parse(q.w.__agc.captureUrl('c2', 'file:///etc/passwd', 1000)).error === 'url-not-allowed', 'only https, blob and data addresses are fetched');
    check(fetchCalls.length === nf, 'a refused capture never calls fetch');

    // failures
    const failWith = async (impl, expected, what, max) => { q.w.fetch = impl; q.w.__agc.captureUrl('f', 'https://x.test/f', max || 1000); await sleep(20); const s = JSON.parse(q.w.__agc.captureStatus('f')); check(s.state === 'failed' && s.error === expected && q.w.__agc.captureChunk('f', 0) === '!notready', what); };
    await failWith(() => Promise.resolve(respond(bytesOf(10), {}, 404)), 'http-404', 'an error answer fails the capture');
    await failWith(() => Promise.resolve(respond(bytesOf(10), { 'content-length': '5000' })), 'too-large', 'a declared size over the cap fails the capture', 1000);
    await failWith(() => Promise.resolve(respond(bytesOf(2000), {})), 'too-large', 'a body over the cap fails the capture even without a declared size', 1000);
    await failWith(() => Promise.reject(new Error('network down')), 'network down', 'a network error fails the capture');
    await failWith(() => { throw new Error('boom'); }, 'fetch-threw', 'a fetch that throws fails the capture');

    // one at a time, empty files
    q.w.fetch = () => Promise.resolve(respond(bytesOf(3), {}));
    q.w.__agc.captureUrl('first', 'https://x.test/1', 1000); await sleep(10);
    q.w.__agc.captureUrl('second', 'https://x.test/2', 1000); await sleep(10);
    check(JSON.parse(q.w.__agc.captureStatus('first')).state === 'none' && JSON.parse(q.w.__agc.captureStatus('second')).state === 'ready', 'starting a capture releases the previous one');
    q.w.fetch = () => Promise.resolve(respond([], {}));
    q.w.__agc.captureUrl('empty', 'https://x.test/e', 1000); await sleep(10);
    const es = JSON.parse(q.w.__agc.captureStatus('empty'));
    check(es.state === 'ready' && es.size === 0 && es.chunks === 0 && q.w.__agc.captureChunk('empty', 0) === '', 'an empty file is ready with zero chunks');
    check(q.w.__agc.version === 6, 'the page script version was bumped so an older script is replaced');

    // the exact reply: every offer carries the page's own stable id of its assistant message ('' when the page has none)
    {
      const m2 = mk();
      const withId = (id, html) => { const d = m2.q.w.document.createElement('div'); d.className = 'a'; if (id) d.setAttribute('data-message-id', id); d.innerHTML = html; m2.q.list.appendChild(d); };
      withId('msg-old', '<a class="file" href="https://x.test/r1" download="report.pdf">x</a>');
      withId('', '<a class="file" href="https://x.test/noid" download="plain.txt">x</a>');
      m2.q.list.insertAdjacentHTML('beforeend', '<div class="a"><div data-message-id="msg-inner"><a class="file" href="https://x.test/inner" download="inner.txt">x</a></div></div>');
      withId('msg-new', '<a class="file" href="https://x.test/r2" download="report.pdf">x</a><button class="dl" aria-label="Download extra.csv">x</button>');
      const o2 = JSON.parse(m2.q.w.__agc.fileOffers());
      const byHref = h => o2.find(o => o.href === h);
      check(byHref('https://x.test/r1').msgId === 'msg-old' && byHref('https://x.test/r2').msgId === 'msg-new', 'two files with the same name in different replies carry different message ids');
      check(o2.find(o => o.name === 'extra.csv').msgId === 'msg-new', 'a button offer carries the id of its message too');
      check(byHref('https://x.test/noid').msgId === '', 'a message without an id gives an empty id (never a made-up one)');
      check(byHref('https://x.test/inner').msgId === '', 'an id on a child of the message is not taken for the message itself');
    }
  }

  // ------------------------------------------------------------ time-of-check / time-of-use: the offer must STILL be exactly the one the app selected
  {
    const bytesOf = n => new Array(n).fill(7);
    const respond = arr => ({ ok: true, status: 200, headers: { get: () => null }, arrayBuffer: () => Promise.resolve(new Uint8Array(arr).buffer) });
    const fresh = () => {
      const q = makePage();
      q.w.__AGC_SPEC.offerLink = ['a.file']; q.w.__AGC_SPEC.offerButton = ['button.dl'];
      const fetches = [], clicks = [];
      q.w.fetch = url => { fetches.push(url); return Promise.resolve(respond(bytesOf(3))); };
      const add = (id, html) => { const d = q.w.document.createElement('div'); d.className = 'a'; if (id) d.setAttribute('data-message-id', id); d.innerHTML = html; q.list.appendChild(d); return d; };
      return { q, fetches, clicks, add, offers: () => JSON.parse(q.w.__agc.fileOffers()) };
    };
    const refused = (res, what, f) => check(JSON.parse(res).ok === false && JSON.parse(res).error === 'offer-changed' && f.fetches.length === 0 && f.clicks.length === 0, what);

    let f = fresh();
    f.add('m-1', '<a class="file" href="https://x.test/v1" download="report.pdf">x</a>');
    let fp = f.offers()[0];
    f.add('m-2', '<a class="file" href="https://x.test/v2" download="report.pdf">x</a>');   // a newer same-name offer appears: indexes and positions shift
    refused(f.q.w.__agc.captureBegin('t1', fp, 1000), 'capture: a newer same-name offer inserted after the app\'s scan is refused, nothing is fetched', f);

    f = fresh(); const m1 = f.add('m-1', '<a class="file" href="https://x.test/v1" download="report.pdf">x</a>'); fp = f.offers()[0];
    m1.querySelector('a').setAttribute('href', 'https://x.test/SWAPPED');
    refused(f.q.w.__agc.captureBegin('t2', fp, 1000), 'capture: the same offer with a swapped address is refused (the page never fetches an address the app did not approve)', f);

    f = fresh(); const m2 = f.add('m-1', '<a class="file" href="https://x.test/v1" download="report.pdf">x</a>'); fp = f.offers()[0];
    m2.setAttribute('data-message-id', 'm-OTHER');
    refused(f.q.w.__agc.captureBegin('t3', fp, 1000), 'capture: a different reply id on the same offer is refused', f);

    f = fresh(); const m3 = f.add('m-1', '<a class="file" href="https://x.test/v1" download="report.pdf">x</a>'); fp = f.offers()[0];
    m3.innerHTML = '<button class="dl" aria-label="Download report.pdf">x</button>';
    refused(f.q.w.__agc.captureBegin('t4', fp, 1000), 'capture: a button taking the place of the link is refused', f);

    f = fresh(); f.add('m-1', '<a class="file" href="https://x.test/v1" download="report.pdf">x</a>'); fp = f.offers()[0];
    check(JSON.parse(f.q.w.__agc.captureBegin('t5', fp, 1000)).ok === true && f.fetches.length === 1 && f.fetches[0] === 'https://x.test/v1', 'control: an unchanged offer is fetched, with exactly the approved address');
    f.add('m-9', '<p>unrelated newer message</p>');   // a message without offers does not shift anything for the newest offers... but the position among messages changes
    check(JSON.parse(f.q.w.__agc.captureBegin('t6', fp, 1000)).error === 'offer-changed', 'capture: even a harmless new message changes the offer\'s position, so the stale selection is refused (fail closed)');

    // clicking
    f = fresh(); const btn = f.add('m-1', '<button class="dl" aria-label="Download data.csv">x</button>'); f.q.w.document.querySelector('button.dl').addEventListener('click', () => f.clicks.push('btn'));
    fp = f.offers()[0];
    btn.querySelector('button').setAttribute('aria-label', 'Download other.csv');
    refused(f.q.w.__agc.clickOffer(fp), 'click: a button whose name changed is not clicked', f);
    f = fresh(); const btn2 = f.add('m-1', '<button class="dl" aria-label="Download data.csv">x</button>'); f.q.w.document.querySelector('button.dl').addEventListener('click', () => f.clicks.push('btn')); fp = f.offers()[0];
    btn2.setAttribute('data-message-id', 'm-OTHER');
    refused(f.q.w.__agc.clickOffer(fp), 'click: a button in a different reply is not clicked', f);
    f = fresh(); f.add('m-1', '<button class="dl" aria-label="Download data.csv">x</button>'); f.q.w.document.querySelector('button.dl').addEventListener('click', () => f.clicks.push('btn')); fp = f.offers()[0];
    check(JSON.parse(f.q.w.__agc.clickOffer(fp)).ok === true && f.clicks.length === 1, 'control: an unchanged button is clicked once');

    f = fresh(); const btn3 = f.add('m-1', '<button class="dl" aria-label="Download data.csv">x</button>'); fp = f.offers()[0];
    btn3.innerHTML = '<a class="file" download="data.csv">x</a>';   // a link without an address now has the same name and the same (empty) address
    refused(f.q.w.__agc.clickOffer(fp), 'click: a link with no address taking a button\'s place is "changed" (the kind must match), not merely "not clickable"', f);

    // only buttons and the provider's own sandbox: link are ever clicked
    f = fresh();
    f.add('m-1', '<a class="file" href="javascript:window.__pwn=1" download="x.js">x</a><a class="file" href="https://x.test/p.pdf" download="p.pdf">x</a><a class="file" href="file:///etc/passwd" download="e.txt">x</a><a class="file" href="sandbox:/mnt/data/s.txt">s.txt</a><a class="file" href="http://x.test/h.txt" download="h.txt">x</a>');
    f.q.w.document.querySelectorAll('a.file').forEach(a => a.addEventListener('click', e => { e.preventDefault(); f.clicks.push(a.getAttribute('href')); }));
    const all = f.offers();
    const click = name => JSON.parse(f.q.w.__agc.clickOffer(all.find(o => o.name === name)));
    check(click('x.js').error === 'not-clickable' && click('p.pdf').error === 'not-clickable' && click('e.txt').error === 'not-clickable' && click('h.txt').error === 'not-clickable' && f.clicks.length === 0 && f.q.w.__pwn === undefined, 'a link with a javascript:, https, file: or http: address is never clicked, even when the app asks');
    check(click('s.txt').ok === true && f.clicks.length === 1 && f.clicks[0].startsWith('sandbox:'), 'the provider\'s own sandbox: link is clicked');
    check(JSON.parse(f.q.w.__agc.captureBegin('t7', all.find(o => o.name === 'x.js'), 1000)).error === 'not-fetchable' && JSON.parse(f.q.w.__agc.captureBegin('t8', all.find(o => o.name === 'e.txt'), 1000)).error === 'not-fetchable' && JSON.parse(f.q.w.__agc.captureBegin('t9', all.find(o => o.name === 'h.txt'), 1000)).error === 'not-fetchable' && f.fetches.length === 0, 'links the page cannot fetch (javascript:, file:, http:) are reported "not-fetchable" and nothing is fetched');
  }

  // ------------------------------------------------------------ the Engine Lab's read-only file probe
  {
    const q = makePage();
    q.w.__AGC_SPEC.offerLink = ['a.file']; q.w.__AGC_SPEC.offerButton = ['button.dl'];
    const add = (id, html) => { const d = q.w.document.createElement('div'); d.className = 'a'; if (id) d.setAttribute('data-message-id', id); d.innerHTML = html; q.list.appendChild(d); };
    add('', '<p>older, no id</p>');
    add('m-1', '<a class="file" href="https://files.x.test/s/doc.pdf?sig=SECRETTOKEN&exp=99" download="doc.pdf">doc</a>' +
               '<button class="dl" aria-label="Download table.csv">x</button>' +
               '<a href="blob:https://claude.ai/0000-1111" data-testid="blob-link">Save as file</a>' +
               '<a href="sandbox:/mnt/data/notes.txt">notes.txt</a>' +
               '<button data-testid="menu">Copy</button><button data-testid="dl2" aria-label="Download everything">x</button>');
    const before = q.w.document.body.innerHTML;
    const pr = JSON.parse(q.w.__agc.fileProbe());
    check(q.w.document.body.innerHTML === before, 'the file probe never changes the page');
    check(pr.assistantNodes === 2 && pr.withStableId === 1, 'it reports how many assistant messages there are and how many expose a stable id');
    check(pr.offerSelectors.link === 1 && pr.offerSelectors.button === 1, 'it reports how many selectors the profile has');
    check(pr.offers.length === 2 && pr.offers[0].name === 'doc.pdf' && pr.offers[0].id === 'yes' && pr.offers[1].name === 'table.csv' && pr.offers[1].href === '', 'it lists the offers the selectors found, with id yes/no and no address for a button');
    check(pr.offers[0].href === 'https://files.x.test .pdf' && !JSON.stringify(pr).includes('SECRETTOKEN') && !JSON.stringify(pr).includes('sig='), 'an address is reduced to scheme, host and extension: a signed token is never reported');
    const looks = pr.lookAlikes.map(l => l.href + '|' + l.label);
    check(looks.some(l => l.startsWith('blob:https://claude.ai')) && looks.some(l => l.startsWith('sandbox: .txt')) && pr.lookAlikes.some(l => l.testid === 'dl2') && !pr.lookAlikes.some(l => l.testid === 'menu'), 'it also lists download-looking controls the selectors missed (blob:, sandbox:, "Download" buttons) but not unrelated buttons');
    check(!JSON.stringify(pr).includes('0000-1111'), 'a blob: address is reduced too');
  }

  console.log((failures === 0 ? 'PASS  ' : 'FAIL  ') + 'page script (' + checks + ' checks, ' + failures + ' failures)');
  process.exit(failures === 0 ? 0 : 1);
})();
