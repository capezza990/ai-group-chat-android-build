import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Files end to end through the real RoomController: a turn is never sent before its files are in that AI's conversation. */
public final class ArtifactFlowTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }
    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }
    static final TransferState P = TransferState.PENDING, S = TransferState.SENDING, T = TransferState.STAGED, V = TransferState.VERIFIED, F = TransferState.FAILED;

    /** Room A with ChatGPT (seat 0) and Claude (seat 1), each with its own conversation; file support switched on; everything immediate unless a test says MANUAL. */
    static final class W {
        final InMemoryRoomStore store = new InMemoryRoomStore();
        final MockProvider gpt = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE), cl = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
        final MockArtifactTransport tr = new MockArtifactTransport(); final MockCaptureTransport cap = new MockCaptureTransport();
        final List<String> summaries = new ArrayList<>(), sendLog = new ArrayList<>();
        final AtomicInteger clock = new AtomicInteger(1000), idn = new AtomicInteger();
        File root; ArtifactStorage storage; ArtifactService svc; RoomController c;
        String fileId;   // the user's file, once added

        W(boolean seatClaude) throws Exception { this(seatClaude, true); }
        W(boolean seatClaude, boolean withTransport) throws Exception {
            store.createRoom("A", "A", RoomKind.LIVE, 1);
            root = Files.createTempDirectory("agc-flow-").toFile(); storage = new ArtifactStorage(root);
            svc = new ArtifactService(store, storage, withTransport ? tr : null, cap, () -> clock.incrementAndGet(), () -> "x" + idn.incrementAndGet(), 1000);
            c = new RoomController(store, "A", new RoomController.Events() { @Override public void onRunFinished(String s) { summaries.add(s); } }, () -> clock.incrementAndGet(), () -> "m" + idn.incrementAndGet());
            c.registerProvider(gpt); c.registerProvider(cl);
            c.addParticipant("chatgpt", false); store.putBinding("A", new ProviderBinding("chatgpt", "convA-gpt", "l", "t", 1L));
            if (seatClaude) { c.addParticipant("claude", false); store.putBinding("A", new ProviderBinding("claude", "convA-cl", "l", "t", 1L)); }
            c.setArtifactService(svc);
            c.setRouting(RoutingMode.ASK_ALL, "", 1);
            gpt.onSend = p -> sendLog.add("chatgpt:" + stateOf("chatgpt"));
            cl.onSend = p -> sendLog.add("claude:" + stateOf("claude"));
        }
        String stateOf(String ai) { if (fileId == null) return "-"; ArtifactTransfer t = store.currentTransfer(fileId, "A", ai); return t == null ? "none" : t.state.name(); }
        Artifact addFile(String text) throws Exception { Artifact a = svc.addUserFile("A", "doc.txt", "text/plain", new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8))); fileId = a.id; return a; }
        ArtifactTransfer tr(String ai) { return store.currentTransfer(fileId, "A", ai); }
        int messages() { return store.latestMessages("A", 1000).size(); }
        boolean anyPromptHas(MockProvider p, String s) { synchronized (p.prompts) { for (String x : p.prompts) if (x.contains(s)) return true; } return false; }
    }

    public static void main(String[] args) {
        test("plain text: file support is on, but nothing file-related happens", () -> {
            W w = new W(true);
            RoomMessage m = w.c.submitUserMessage("hello everyone");
            check(m != null && w.gpt.prompts.size() == 1 && w.cl.prompts.size() == 1 && w.summaries.equals(Arrays.asList("done")) && !w.c.isBusy(), "both AIs answer as before");
            check(w.tr.calls.isEmpty() && w.cap.calls.isEmpty() && w.store.transfersInState(P).isEmpty() && w.store.transfersInState(S).isEmpty() && w.store.transfersInState(T).isEmpty() && w.store.transfersInState(V).isEmpty() && w.store.transfersInState(F).isEmpty(), "no transfer, no capture, no transfer row");
            check(!w.anyPromptHas(w.gpt, "[attached:") && !w.anyPromptHas(w.cl, "[attached:"), "no prompt mentions files");
        });

        test("a file reaches each AI's conversation BEFORE that AI is asked anything", () -> {
            W w = new W(true);
            Artifact a = w.addFile("hello file");
            RoomMessage m = w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(m != null && w.store.artifactsOfMessage(m.id).size() == 1 && w.store.artifactsOfMessage(m.id).get(0).id.equals(a.id), "the message was saved together with its attachment");
            check(w.sendLog.equals(Arrays.asList("chatgpt:STAGED", "claude:STAGED")), "each AI was asked only once the file was STAGED in its own composer: " + w.sendLog);
            check(w.tr.calls.equals(Arrays.asList(a.id + "->chatgpt", a.id + "->claude")), "one upload per AI, one after the other: " + w.tr.calls);
            check(w.anyPromptHas(w.gpt, "[Attached: doc.txt, 10 B]") && w.anyPromptHas(w.cl, "[Attached: doc.txt, 10 B]"), "the prompt tells each AI which file was attached, with its size");
            check(w.tr("chatgpt").attempts == 1 && w.tr("claude").attempts == 1 && w.summaries.equals(Arrays.asList("done")) && !w.c.isBusy() && !w.svc.isBusy(), "one attempt each, the run finished, nothing is busy");
            // the next plain message does not re-send anything
            w.c.submitUserMessage("thanks, now something else");
            check(w.tr.calls.size() == 2 && w.gpt.prompts.size() == 2 && w.cl.prompts.size() == 2 && w.summaries.size() == 2, "a later plain-text message re-sends nothing: the AIs already have the file");
        });

        test("the turn really waits: nothing is asked while an upload is in progress", () -> {
            W w = new W(true); w.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = w.addFile("hello file");
            w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(w.c.isBusy() && w.gpt.prompts.isEmpty() && w.cl.prompts.isEmpty() && w.tr.isHolding() && w.tr("chatgpt").state == S, "ChatGPT's file is uploading; no AI has been asked anything");
            check(w.c.runStatus().contains("sending files to ChatGPT") && w.c.runStatus().contains("step 1"), "the status line says what is going on: " + w.c.runStatus());
            check(w.store.deliveriesInState(DeliveryState.PENDING).isEmpty() && w.store.deliveriesInState(DeliveryState.SENDING).isEmpty(), "no request exists yet");
            check(w.tr.complete(true) && w.gpt.prompts.size() == 1 && w.cl.prompts.isEmpty() && w.tr.isHolding() && w.tr("claude").state == S, "ChatGPT's upload finished -> ChatGPT answered -> Claude's upload started (one at a time)");
            check(w.c.runStatus().contains("sending files to Claude"), "...and the status follows: " + w.c.runStatus());
            check(w.tr.complete(true) && w.cl.prompts.size() == 1 && w.summaries.equals(Arrays.asList("done")) && !w.c.isBusy(), "Claude's upload finished -> Claude answered -> done");
            check(w.sendLog.equals(Arrays.asList("chatgpt:STAGED", "claude:STAGED")), "order proof: " + w.sendLog);
        });

        test("uploads that keep failing stop the turn with a plain reason; nothing is asked", () -> {
            W w = new W(true); w.tr.mode = MockArtifactTransport.Mode.FAIL; w.tr.failReason = "attach button not found";
            Artifact a = w.addFile("hello file");
            w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(w.tr.calls.size() == 3 && w.tr("chatgpt").state == F && w.tr("chatgpt").attempts == 3, "three automatic tries, then it gives up: " + w.tr.calls.size());
            check(w.summaries.size() == 1 && w.summaries.get(0).contains("doc.txt") && w.summaries.get(0).contains("ChatGPT") && w.summaries.get(0).contains("3 tries") && w.summaries.get(0).contains("attach button not found"), "the run ends with a clear reason: " + w.summaries);
            check(w.gpt.prompts.isEmpty() && w.cl.prompts.isEmpty() && !w.c.isBusy() && w.store.deliveriesInState(DeliveryState.PENDING).isEmpty(), "no AI was asked, no request exists, nothing is busy");
            check(w.store.latestMessages("A", 10).size() == 1, "the user's message and its file are still in the room");
            w.c.submitUserMessage("try again please", null, Arrays.asList(a.id));
            check(w.tr.calls.size() == 3 && w.summaries.size() == 2 && w.summaries.get(1).contains("3 tries"), "another message does not retry on its own: the file stays blocked");
            check(w.svc.retryTransfer(a.id, "A", "chatgpt") && w.tr("chatgpt").state == P && !w.svc.retryTransfer(a.id, "A", "chatgpt") && !w.svc.retryTransfer("nope", "A", "chatgpt"), "the user can ask for one more try (only for a FAILED transfer)");
            w.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            w.c.submitUserMessage("and now?", null, Arrays.asList(a.id));
            check(w.tr("chatgpt").state == V && w.tr("chatgpt").attempts == 4 && w.gpt.prompts.size() == 1 && w.tr("claude").state == V && w.cl.prompts.size() == 1 && w.summaries.get(w.summaries.size() - 1).equals("done"), "after the retry the file goes through (its 4th attempt), ChatGPT is asked, then Claude gets its own upload and is asked, and the turn finishes");
        });

        test("Stop while the files are still moving", () -> {
            W w = new W(true); w.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = w.addFile("hello file");
            w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(w.c.isBusy() && w.tr.isHolding(), "waiting on the upload");
            w.c.stop();
            check(!w.c.isBusy() && w.summaries.equals(Arrays.asList("stopped by user")) && w.tr.cancels == 1 && w.tr("chatgpt").state == F && w.tr("chatgpt").error.equals("cancelled") && !w.svc.isBusy(), "Stop ends the turn at once, cancels the upload (FAILED 'cancelled') and frees the slot");
            check(w.gpt.prompts.isEmpty() && w.cl.prompts.isEmpty(), "no AI was asked anything");
            w.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            w.c.submitUserMessage("never mind, go on", null, Arrays.asList(a.id));
            check(w.summaries.get(1).equals("done") && w.tr("chatgpt").state == V && w.tr("chatgpt").attempts == 2 && w.gpt.prompts.size() == 1, "afterwards the same file is simply tried again (second attempt) and the turn goes through");
        });

        test("pre-send Stop after staging cleans the idle staged surface before provider.send is called", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("A", "A", RoomKind.LIVE, 1L);
            MockProvider gpt = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
            gpt.stopAnswer = RoomProvider.SubmitPhase.SUBMITTED; // if requestStop is wrongly consulted before provider.send(), this test will hang/drain instead of cancel safely
            MockArtifactTransport tr = new MockArtifactTransport();
            File root = Files.createTempDirectory("agc-presend-stop-").toFile();
            ArtifactService svc = new ArtifactService(store, new ArtifactStorage(root), tr, new MockCaptureTransport(), System::currentTimeMillis, () -> java.util.UUID.randomUUID().toString(), 1000);
            final RoomController[] holder = new RoomController[1];
            List<String> done = new ArrayList<>();
            RoomController c = new RoomController(store, "A", new RoomController.Events() {
                @Override public void onDelivery(Delivery d) { if (holder[0] != null && d.state == DeliveryState.SENDING) holder[0].stop(); }
                @Override public void onRunFinished(String summary) { done.add(summary); }
            });
            holder[0] = c; c.registerProvider(gpt); c.addParticipant("chatgpt", false);
            store.putBinding("A", new ProviderBinding("chatgpt", "conv-stop", "l", "t", 1L));
            c.setArtifactService(svc); c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            Artifact a = svc.addUserFile("A", "stop.txt", "text/plain", new ByteArrayInputStream("stop".getBytes(StandardCharsets.UTF_8)));
            c.submitUserMessage("stop before send", null, Arrays.asList(a.id));
            ArtifactTransfer t = store.currentTransfer(a.id, "A", "chatgpt");
            check(gpt.prompts.isEmpty(), "Stop won before provider.send, so no provider prompt was dispatched");
            check(t != null && t.state == F, "the staged transfer is FAILED/retryable");
            check(tr.invalidations == 1, "the transport was told to clean and retire the idle staged surface");
            check(!c.isBusy() && store.deliveriesInState(DeliveryState.CANCELLED).size() == 1 && done.equals(Arrays.asList("stopped by user")), "the never-submitted delivery is safely cancelled and the run ends once");
        });

        test("REVIEW: Stop before the prompt is handed over on the SECOND step of a run is also known NOT to have been sent (the hand-over flag belongs to each step)", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("A", "A", RoomKind.LIVE, 1L);
            MockProvider gpt = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
            MockProvider cl = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
            cl.stopAnswer = RoomProvider.SubmitPhase.SUBMITTED; // if a stale flag makes Stop ask the page, this answer would turn the safe cancel into a drain
            final RoomController[] holder = new RoomController[1];
            List<String> done = new ArrayList<>();
            RoomController c = new RoomController(store, "A", new RoomController.Events() {
                @Override public void onDelivery(Delivery d) { if (holder[0] != null && d.state == DeliveryState.SENDING && d.providerId.equals("claude")) holder[0].stop(); }
                @Override public void onRunFinished(String summary) { done.add(summary); }
            });
            holder[0] = c; c.registerProvider(gpt); c.registerProvider(cl); c.addParticipant("chatgpt", false); c.addParticipant("claude", false);
            c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            c.submitUserMessage("hello both");
            check(gpt.prompts.size() == 1 && cl.prompts.isEmpty(), "the first AI was asked, the second was never handed its prompt");
            check(!c.isBusy() && store.deliveriesInState(DeliveryState.CANCELLED).size() == 1 && store.deliveriesInState(DeliveryState.UNCERTAIN).isEmpty() && done.equals(Arrays.asList("stopped by user")), "the second step's never-sent delivery is cancelled (not uncertain) and the run ends once");
        });

        test("Stop when the upload never answers: the turn ends at once, the slot is free, the late answer is ignored", () -> {
            W w = new W(true); w.tr.mode = MockArtifactTransport.Mode.MANUAL; w.tr.ignoreCancel = true;
            Artifact a = w.addFile("hello file");
            w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(w.c.isBusy() && w.tr.isHolding(), "waiting on an upload that will never answer");
            w.c.stop();
            check(!w.c.isBusy() && w.summaries.equals(Arrays.asList("stopped by user")) && w.tr.cancels == 1 && w.tr("chatgpt").state == F && w.tr("chatgpt").error.equals("cancelled") && !w.svc.isBusy(), "Stop ends the turn at once and frees the file slot, even though the page never answered");
            w.tr.complete(true);   // the page finally answers, much later
            check(w.tr("chatgpt").state == F && w.gpt.prompts.isEmpty() && !w.c.isBusy() && w.summaries.size() == 1, "the late answer changes nothing: the transfer stays FAILED, nobody is asked, no new run starts");
            w.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            w.c.submitUserMessage("go on", null, Arrays.asList(a.id));
            check(w.tr("chatgpt").state == V && w.tr("chatgpt").attempts == 2 && w.summaries.get(1).equals("done"), "afterwards the next message simply tries the file again and goes through");
        });

        test("staged attachments are committed only by acceptance; rejection, uncertainty and Stop make them retryable", () -> {
            W rejected = new W(false); rejected.gpt.behavior = MockProvider.Behavior.FAIL_BEFORE_SEND;
            Artifact a = rejected.addFile("reject");
            rejected.c.submitUserMessage("read", null, Arrays.asList(a.id));
            check(rejected.tr("chatgpt").state == F && rejected.store.deliveriesInState(DeliveryState.FAILED).size() == 1, "definite rejection: STAGED -> FAILED and delivery FAILED");

            W uncertain = new W(false); uncertain.gpt.behavior = MockProvider.Behavior.SILENT;
            Artifact b = uncertain.addFile("uncertain");
            uncertain.c.submitUserMessage("read", null, Arrays.asList(b.id));
            check(uncertain.tr("chatgpt").state == T, "before any provider callback the file is STAGED, not VERIFIED");
            uncertain.gpt.fireError("page outcome unknown", true);
            check(uncertain.tr("chatgpt").state == F && uncertain.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "uncertain submission: attachment retryable, delivery conservatively UNCERTAIN");

            W stopped = new W(false); stopped.gpt.behavior = MockProvider.Behavior.SILENT; stopped.gpt.stopAnswer = RoomProvider.SubmitPhase.MAYBE_SUBMITTED;
            Artifact c = stopped.addFile("stop");
            stopped.c.submitUserMessage("read", null, Arrays.asList(c.id));
            stopped.c.stop();
            check(stopped.tr("chatgpt").state == F && stopped.store.deliveriesInState(DeliveryState.SENDING).size() == 1 && stopped.c.isBusy(), "Stop distrusts STAGED immediately while C2 keeps a maybe-submitted delivery draining");
            check(stopped.tr.invalidations == 1, "pre-send/uncertain Stop also tells the upload transport to clean an idle staged composer instead of leaving the surface lease held");

            W partial = new W(false); partial.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact first = partial.addFile("first"), second = partial.svc.addUserFile("A", "second.txt", "text/plain", new ByteArrayInputStream("second".getBytes(StandardCharsets.UTF_8)));
            partial.c.submitUserMessage("read both", null, Arrays.asList(first.id, second.id));
            check(partial.tr.complete(true), "the first of two files stages");
            partial.tr.mode = MockArtifactTransport.Mode.FAIL;
            partial.tr.failReason = "second rejected";
            check(partial.tr.complete(false), "the second file's first attempt fails; its remaining retries fail immediately");
            check(partial.store.currentTransfer(first.id, "A", "chatgpt").state == F && partial.store.currentTransfer(second.id, "A", "chatgpt").state == F
                    && partial.summaries.get(0).contains("3 tries"), "ending on a later file's exhausted retries also abandons the earlier STAGED attachment");
        });

        test("a file an AI produced: reply and file intent first, bytes second, THEN the next AI", () -> {
            W w = new W(true); w.cap.mode = MockCaptureTransport.Mode.MANUAL; w.cap.defaultContent = "PDFBYTES".getBytes(StandardCharsets.UTF_8); w.cap.mime = "application/pdf";
            w.c.setRouting(RoutingMode.COLLABORATE, "claude", 1);
            w.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("report.pdf", "application/pdf"));
            w.c.submitUserMessage("write a report");
            RoomMessage reply = null; for (RoomMessage m : w.store.latestMessages("A", 10)) if (RoomMessage.PROVIDER.equals(m.authorType)) reply = m;
            check(reply != null && reply.authorId.equals("claude") && w.store.artifactsOfMessage(reply.id).size() == 1, "Claude's reply is saved WITH its file intent, in one step");
            Artifact g = w.store.artifactsOfMessage(reply.id).get(0);
            check(g.state == ArtifactState.PENDING_CAPTURE && g.origin.equals("claude") && g.displayName.equals("report.pdf") && g.size == -1L, "phase one: the intent exists, there are no bytes yet");
            check(w.c.isBusy() && w.gpt.prompts.isEmpty() && w.cap.isHolding(), "ChatGPT is NOT asked while the bytes are being fetched");
            check(w.c.runStatus().contains("waiting for \"report.pdf\" to finish saving"), "the status says why: " + w.c.runStatus());
            check(w.cap.complete(true), "the capture finishes");
            Artifact done = w.store.getArtifact(g.id);
            check(done.state == ArtifactState.READY && done.size == 8 && done.mime.equals("application/pdf") && w.storage.isIntact(done), "phase two: the bytes are stored; the file is READY with its hash");
            check(w.gpt.prompts.size() == 1 && w.anyPromptHas(w.gpt, "[Attached: report.pdf, 8 B]") && w.sendLog.contains("chatgpt:-"), "only then is ChatGPT asked, and its prompt mentions the file");
            ArtifactTransfer t = w.store.currentTransfer(g.id, "A", "chatgpt");
            check(t != null && t.state == V && w.store.currentTransfer(g.id, "A", "claude") == null && w.summaries.equals(Arrays.asList("done")), "the file was uploaded to ChatGPT (VERIFIED); Claude, who made it, got no transfer; the run finished");
            check(w.tr.calls.equals(Arrays.asList(g.id + "->chatgpt")), "exactly one upload happened");
        });

        test("an AI's own file after the AI moves to a NEW conversation: it must be sent there (and the provenance is the conversation at SEND time)", () -> {
            W w = new W(true); w.cap.defaultContent = "CLAUDEFILE".getBytes(StandardCharsets.UTF_8);
            w.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            String sentFrom = w.store.activeBindingId("A", "claude");
            // Claude is rebound to another conversation WHILE it is answering (after the request left, before the reply came back)
            w.cl.onSend = p -> w.store.putBinding("A", new ProviderBinding("claude", "convA-cl-NEW", "l", "t", 99L));
            w.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("project.zip", "application/zip"));
            w.c.submitUserMessage("make me a project");
            Artifact made = w.store.attachmentsBetween("A", 0, 1000).get(0).artifact;
            check(made.origin.equals("claude") && made.sourceBindingId != null && made.sourceBindingId.equals(sentFrom) && !made.sourceBindingId.equals(w.store.activeBindingId("A", "claude")), "the file records the conversation the request was SENT to, not the one Claude is in when the answer arrives");
            check(made.state == ArtifactState.READY && w.tr.calls.isEmpty(), "it was captured and nothing was uploaded for it yet");
            w.cl.onSend = null;
            w.c.submitUserMessage("what is in the project?");
            check(w.tr.calls.equals(Arrays.asList(made.id + "->claude")) && w.store.currentTransfer(made.id, "A", "claude").state == V, "Claude is now in a conversation that never saw its own file: the file is uploaded there before Claude is asked");
            check(w.cl.prompts.size() == 2 && w.cl.prompts.get(1).contains("[Files shared earlier, now in this conversation] project.zip, 10 B"), "and Claude's prompt says so (its own reply is not repeated, so the file is named on its own line): " + w.cl.prompts.get(1));
            // a third question: the file is already in the new conversation
            w.c.submitUserMessage("thanks");
            check(w.tr.calls.size() == 1, "afterwards nothing is uploaded again");
        });

        test("an AI's own file stays where it was made: no upload, no note, while the conversation does not change", () -> {
            W w = new W(true); w.cap.defaultContent = "CLAUDEFILE".getBytes(StandardCharsets.UTF_8);
            w.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            w.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("project.zip", "application/zip"));
            w.c.submitUserMessage("make me a project");
            Artifact made = w.store.attachmentsBetween("A", 0, 1000).get(0).artifact;
            check(made.sourceBindingId != null && made.sourceBindingId.equals(w.store.activeBindingId("A", "claude")), "the file records Claude's conversation");
            w.c.submitUserMessage("what is in the project?");
            check(w.tr.calls.isEmpty() && w.store.currentTransfer(made.id, "A", "claude") == null && w.cl.prompts.size() == 2 && !w.cl.prompts.get(1).contains("[Attached") && !w.cl.prompts.get(1).contains("Files shared"), "Claude already has its own file in that conversation: no upload, and the prompt does not mention the file in any form");
            // ChatGPT joining the conversation later is a different matter
            w.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            w.c.submitUserMessage("chatgpt, did you see the project?");
            check(w.tr.calls.equals(Arrays.asList(made.id + "->chatgpt")) && w.gpt.prompts.size() == 1 && w.gpt.prompts.get(0).contains("[Attached: project.zip, 10 B]"), "ChatGPT gets the file uploaded and told about it");
        });

        test("a file an AI produced that cannot be saved stops the chain, but keeps the reply", () -> {
            W w = new W(true); w.cap.mode = MockCaptureTransport.Mode.MANUAL;
            w.c.setRouting(RoutingMode.COLLABORATE, "claude", 1);
            w.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("report.pdf", "application/pdf"));
            w.c.submitUserMessage("write a report");
            check(w.cap.complete(false), "the capture fails");
            check(w.summaries.size() == 1 && w.summaries.get(0).contains("report.pdf") && w.summaries.get(0).contains("could not be saved"), "the run ends with a clear reason: " + w.summaries);
            check(w.gpt.prompts.isEmpty() && !w.c.isBusy() && !w.svc.isBusy(), "ChatGPT was never asked");
            int replies = 0; for (RoomMessage m : w.store.latestMessages("A", 10)) if (RoomMessage.PROVIDER.equals(m.authorType)) replies++;
            check(replies == 1 && w.store.attachmentsBetween("A", 0, 1000).size() == 1 && w.store.attachmentsBetween("A", 0, 1000).get(0).artifact.state == ArtifactState.FAILED, "Claude's reply is still in the room and its file is marked FAILED");
        });

        test("files offered with a reply: saved in order and captured even on the last step; a file-only reply still gets a line; without file support they are ignored", () -> {
            W w = new W(true); w.cap.defaultContent = "x".getBytes(StandardCharsets.UTF_8);
            w.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            w.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("a.txt", "text/plain"), new RoomProvider.FileIntent("b.txt", "text/plain"));
            w.c.submitUserMessage("make two files");
            List<AttachedArtifact> got = w.store.attachmentsBetween("A", 0, 1000);
            check(got.size() == 2 && got.get(0).artifact.displayName.equals("a.txt") && got.get(1).artifact.displayName.equals("b.txt") && got.get(0).position == 0 && got.get(1).position == 1, "two files are saved with the reply, in order");
            check(w.summaries.equals(Arrays.asList("done")) && w.cap.calls.size() == 2 && got.get(0).artifact.state == ArtifactState.READY && w.store.getArtifact(got.get(1).artifact.id).state == ArtifactState.READY && w.storage.isIntact(w.store.getArtifact(got.get(1).artifact.id)),
                    "even though the reply was the LAST step, both files were captured afterwards (one at a time) and are READY with their bytes stored: " + w.cap.calls.size());
            // an answer that is only a file: the provider sends no text at all
            W v = new W(true); v.cap.defaultContent = new byte[]{9};
            v.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            RoomProvider fileOnly = new RoomProvider() {
                @Override public String id() { return "claude"; } @Override public String displayName() { return "Claude"; }
                @Override public java.util.Set<String> capabilities() { return java.util.Collections.singleton("GENERAL"); } @Override public boolean isAvailable() { return true; }
                @Override public void cancel() { }
                @Override public void send(String prompt, Listener l) { l.onAccepted("u1"); l.onReplyWithFiles("   ", "a1", Arrays.asList(new FileIntent("one.zip", ""), new FileIntent("x/y\u0000.zip", ""))); }
            };
            v.c.registerProvider(fileOnly);
            v.c.submitUserMessage("send me files");
            RoomMessage r = null; for (RoomMessage m : v.store.latestMessages("A", 10)) if (RoomMessage.PROVIDER.equals(m.authorType)) r = m;
            check(r != null && r.text.equals("(shared one.zip, x_y.zip)") && v.summaries.equals(Arrays.asList("done")), "an answer that is only files gets a line in the room naming them, with the CLEAN names: " + (r == null ? null : r.text));
            check(v.store.attachmentsBetween("A", 0, 1000).size() == 2 && v.store.attachmentsBetween("A", 0, 1000).get(1).artifact.displayName.equals("x_y.zip"), "and the saved name of the second file is clean too");
            // an answer with neither text nor files is still an empty reply
            W u = new W(true);
            u.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            RoomProvider nothing = new RoomProvider() {
                @Override public String id() { return "claude"; } @Override public String displayName() { return "Claude"; }
                @Override public java.util.Set<String> capabilities() { return java.util.Collections.singleton("GENERAL"); } @Override public boolean isAvailable() { return true; }
                @Override public void cancel() { }
                @Override public void send(String prompt, Listener l) { l.onAccepted("u1"); l.onReplyWithFiles("  ", "a1", new ArrayList<>()); }
            };
            u.c.registerProvider(nothing);
            u.c.submitUserMessage("say something");
            check(u.summaries.size() == 1 && u.summaries.get(0).contains("empty reply"), "no text and no files is still an empty reply: " + u.summaries);
            // no file support: the same offer is ignored and the room stays plain
            InMemoryRoomStore s = new InMemoryRoomStore(); s.createRoom("A", "A", RoomKind.LIVE, 1);
            MockProvider p = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
            RoomController plain = new RoomController(s, "A", null); plain.registerProvider(p); plain.addParticipant("claude", false); plain.setRouting(RoutingMode.SINGLE, "claude", 1);
            s.putBinding("A", new ProviderBinding("claude", "plainConv", "l", "t", 1L));   // it HAS a conversation: only the missing file support stops the files being kept
            p.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("ignored.txt", ""));
            plain.submitUserMessage("hi");
            check(s.attachmentsBetween("A", 0, 1000).isEmpty() && s.latestMessages("A", 10).size() == 2, "without file support a reply's files are not kept (no dangling intents)");
        });

        test("a reply with files but NO known conversation never creates a file with unknown provenance", () -> {
            W w = new W(true); w.cap.defaultContent = "x".getBytes(StandardCharsets.UTF_8);
            w.store.clearBinding("A", "claude", 500L);   // the request will leave Claude with no active conversation: nothing to snapshot at send time
            w.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            w.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("a.txt", "text/plain"));
            w.c.submitUserMessage("make a file");
            RoomMessage r = null; for (RoomMessage m : w.store.latestMessages("A", 10)) if (RoomMessage.PROVIDER.equals(m.authorType)) r = m;
            check(r != null && !r.text.isEmpty(), "Claude's answer is kept in the room");
            check(w.store.attachmentsBetween("A", 0, 1000).isEmpty() && w.store.artifactsNotReady().isEmpty() && w.cap.calls.isEmpty(), "but no file was recorded and no capture was started: there is no artifact without a source conversation");
            check(w.summaries.size() == 1 && w.summaries.get(0).contains("Claude sent a file") && w.summaries.get(0).contains("does not know which conversation"), "the run ends with a clear reason: " + w.summaries);
            check(!w.c.isBusy() && !w.svc.isBusy(), "nothing is left busy");
            // an answer that is only a file: the line in the room says it was not saved
            W v = new W(true);
            v.store.clearBinding("A", "claude", 500L);
            v.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            RoomProvider fileOnly = new RoomProvider() {
                @Override public String id() { return "claude"; } @Override public String displayName() { return "Claude"; }
                @Override public java.util.Set<String> capabilities() { return java.util.Collections.singleton("GENERAL"); } @Override public boolean isAvailable() { return true; }
                @Override public void cancel() { }
                @Override public void send(String prompt, Listener l) { l.onAccepted("u1"); l.onReplyWithFiles("", "a1", Arrays.asList(new FileIntent("one.zip", ""))); }
            };
            v.c.registerProvider(fileOnly);
            v.c.submitUserMessage("send me a file");
            RoomMessage r2 = null; for (RoomMessage m : v.store.latestMessages("A", 10)) if (RoomMessage.PROVIDER.equals(m.authorType)) r2 = m;
            check(r2 != null && r2.text.equals("(tried to share one.zip; not saved)") && v.store.attachmentsBetween("A", 0, 1000).isEmpty(), "a file-only answer is shown as 'tried to share ... not saved', never as shared: " + (r2 == null ? null : r2.text));
            // with a conversation, the same offer works (the file records that conversation)
            W ok = new W(true); ok.cap.defaultContent = "y".getBytes(StandardCharsets.UTF_8);
            ok.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            ok.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("b.txt", "text/plain"));
            ok.c.submitUserMessage("make a file");
            Artifact made = ok.store.attachmentsBetween("A", 0, 1000).get(0).artifact;
            check(made.sourceBindingId != null && made.sourceBindingId.equals(ok.store.activeBindingId("A", "claude")) && made.state == ArtifactState.READY, "with a conversation the file is recorded with it and captured");
        });

        test("a message cannot carry a file that does not belong in it (and then nothing is saved)", () -> {
            W w = new W(true);
            Artifact ok = w.addFile("fine");
            w.store.createRoom("B", "B", RoomKind.LIVE, 2);
            Artifact other = w.svc.addUserFile("B", "b.txt", "", new ByteArrayInputStream(new byte[]{1}));
            w.store.createArtifact("pend", "A", "claude", w.store.activeBindingId("A", "claude"), "p.bin", "", 5L);
            w.store.createArtifact("bad", "A", "claude", w.store.activeBindingId("A", "claude"), "b.bin", "", 5L); w.store.failArtifact("bad");
            int before = w.messages();
            String[][] cases = {{"unknown", "no-such-file"}, {"another room", other.id}, {"not ready", "pend"}, {"failed", "bad"}};
            for (String[] cs : cases) {
                boolean threw = false;
                try { w.c.submitUserMessage("with " + cs[0], null, Arrays.asList(ok.id, cs[1])); } catch (IllegalArgumentException e) { threw = true; }
                check(threw && w.messages() == before && !w.c.isBusy() && w.store.artifactsOfMessage("nothing").isEmpty() && w.store.attachmentsBetween("A", 0, 1000).isEmpty(), "refused (" + cs[0] + "): no message, no attachment, no run");
            }
            boolean dup = false, nul = false;
            try { w.c.submitUserMessage("dup", null, Arrays.asList(ok.id, ok.id)); } catch (IllegalArgumentException e) { dup = true; }
            try { w.c.submitUserMessage("null", null, Arrays.asList((String) null)); } catch (IllegalArgumentException e) { nul = true; }
            check(dup && nul && w.messages() == before && w.store.attachmentsBetween("A", 0, 1000).isEmpty(), "the same file twice, or a null id, is refused too (and rolled back)");
            check(w.c.submitUserMessage("   ", null, Arrays.asList(ok.id)) == null && w.messages() == before, "an empty message is still ignored");
        });

        test("an AI without a conversation cannot be sent a file: the turn ends clearly", () -> {
            W w = new W(true);
            Artifact a = w.addFile("hello");
            w.store.clearBinding("A", "claude", 500L);
            w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(w.gpt.prompts.size() == 1 && w.cl.prompts.isEmpty() && w.summaries.size() == 1 && w.summaries.get(0).contains("Claude is not connected") && w.summaries.get(0).contains("doc.txt"), "ChatGPT was served; Claude's turn ends with a clear reason: " + w.summaries);
        });

        test("nothing able to move files: the turn does not hang", () -> {
            W w = new W(true, false);
            Artifact a = w.addFile("hello");
            w.c.submitUserMessage("please read this", null, Arrays.asList(a.id));
            check(!w.c.isBusy() && w.summaries.size() == 1 && w.summaries.get(0).contains("could not be moved") && w.gpt.prompts.isEmpty(), "no transport: the run ends with a message instead of waiting forever: " + w.summaries);
        });

        test("an AI that joins later catches up on files it has not seen", () -> {
            W w = new W(false);
            Artifact a = w.addFile("hello");
            w.c.submitUserMessage("read this", null, Arrays.asList(a.id));
            check(w.tr.calls.equals(Arrays.asList(a.id + "->chatgpt")) && w.cl.prompts.isEmpty(), "only ChatGPT was in the room");
            w.c.addParticipant("claude", true); w.store.putBinding("A", new ProviderBinding("claude", "convA-cl", "l", "t", 2L));
            w.c.submitUserMessage("what do you both think?");
            check(w.tr.calls.equals(Arrays.asList(a.id + "->chatgpt", a.id + "->claude")) && w.tr("claude").state == V, "Claude's context starts at the beginning, so the old file is sent to it before it answers (ChatGPT already has it)");
            check(w.cl.prompts.size() == 1 && w.anyPromptHas(w.cl, "[Attached: doc.txt, 5 B]") && !w.gpt.prompts.get(w.gpt.prompts.size() - 1).contains("[Attached"), "Claude's prompt mentions the old file; ChatGPT's latest prompt does not repeat it");
        });

        test("restart: interrupted work is FAILED and the next turn simply retries", () -> {
            W w = new W(true); w.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = w.addFile("hello");
            w.c.submitUserMessage("read this", null, Arrays.asList(a.id));
            check(w.tr("chatgpt").state == S, "an upload is running when the app dies");
            RoomController fresh = new RoomController(w.store, "A", new RoomController.Events() { @Override public void onRunFinished(String s) { w.summaries.add("fresh:" + s); } }, () -> w.clock.incrementAndGet(), () -> "n" + w.idn.incrementAndGet());
            ArtifactService svc2 = new ArtifactService(w.store, w.storage, w.tr, w.cap, () -> w.clock.incrementAndGet(), () -> "y" + w.idn.incrementAndGet(), 1000);
            fresh.registerProvider(w.gpt); fresh.registerProvider(w.cl); fresh.setArtifactService(svc2); fresh.setRouting(RoutingMode.ASK_ALL, "", 1);
            fresh.recoverOnStart();
            check(w.tr("chatgpt").state == F && w.tr("chatgpt").error.contains("interrupted") && w.store.transfersInState(S).isEmpty(), "after the restart the transfer is FAILED (interrupted), not 'sending' and not 'done'");
            w.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            fresh.submitUserMessage("anyone there?", null, null);
            check(w.tr("chatgpt").state == V && w.tr("chatgpt").attempts == 2 && w.summaries.get(w.summaries.size() - 1).startsWith("fresh:"), "the next turn retries it (attempt 2) and goes on");
            // the worst moment: the app dies right after a captured file was moved into place and before its row became READY. One call at start-up must be enough.
            W x = new W(true); x.cap.mode = MockCaptureTransport.Mode.MANUAL; x.cap.defaultContent = "REAL".getBytes(StandardCharsets.UTF_8);
            x.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            x.cl.nextReplyFiles = Arrays.asList(new RoomProvider.FileIntent("report.pdf", "application/pdf"));
            x.c.submitUserMessage("write a report");
            Artifact gen = x.store.attachmentsBetween("A", 0, 1000).get(0).artifact;
            x.storage.write("A", gen.id, new ByteArrayInputStream("HALF-COMMITTED".getBytes(StandardCharsets.UTF_8)), 1000);   // moved into place, never marked READY
            File orphan = new File(x.root, "A/" + gen.id);
            check(orphan.isFile() && x.store.getArtifact(gen.id).state == ArtifactState.PENDING_CAPTURE, "the situation: a complete file at the artifact's place while its row is still waiting for bytes");
            RoomController back = new RoomController(x.store, "A", null, () -> x.clock.incrementAndGet(), () -> "r" + x.idn.incrementAndGet());
            ArtifactService svcBack = new ArtifactService(x.store, x.storage, x.tr, x.cap, () -> x.clock.incrementAndGet(), () -> "q" + x.idn.incrementAndGet(), 1000);
            back.registerProvider(x.gpt); back.registerProvider(x.cl); back.setArtifactService(svcBack);
            back.recoverOnStart();
            check(!orphan.exists() && x.store.getArtifact(gen.id).state == ArtifactState.FAILED, "ONE start-up call: the artifact is FAILED and the orphan file is gone (never adopted)");
            x.cap.mode = MockCaptureTransport.Mode.SUCCEED;
            check(svcBack.retryCapture(gen.id) && x.store.getArtifact(gen.id).state == ArtifactState.PENDING_CAPTURE, "the user retries it");
            svcBack.startCaptures(Arrays.asList(x.store.getArtifact(gen.id)));
            Artifact okAgain = x.store.getArtifact(gen.id);
            check(okAgain.state == ArtifactState.READY && okAgain.size == 4 && x.storage.isIntact(okAgain), "the retried capture is stored normally and the file becomes READY");
        });

        System.out.println((failures == 0 ? "PASS  " : "FAIL  ") + "files end to end (" + checks + " checks, " + failures + " failures)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
