import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/** The gate (may this AI's turn be sent?) and the service that moves the bytes (single-flight, retries, capture, intake, cancel, restart). */
public final class ArtifactGateTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }
    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }
    static final String HEX = "ab".repeat(32);
    static final TransferState P = TransferState.PENDING, S = TransferState.SENDING, T = TransferState.STAGED, V = TransferState.VERIFIED, F = TransferState.FAILED;
    static TransferState[] st(TransferState... a) { return a; }
    static boolean throwsAny(Runnable r) { try { r.run(); return false; } catch (RuntimeException e) { return true; } }

    /** Rooms A and B; ChatGPT and Claude are in A (each with a conversation), ChatGPT in B. Messages: mA (user, seq1), mB. */
    static InMemoryRoomStore store() {
        InMemoryRoomStore s = new InMemoryRoomStore();
        s.createRoom("A", "A", RoomKind.LIVE, 1); s.createRoom("B", "B", RoomKind.LIVE, 2);
        s.upsertParticipant("A", "chatgpt", 0); s.upsertParticipant("A", "claude", 1); s.upsertParticipant("B", "chatgpt", 0);
        s.putBinding("A", new ProviderBinding("chatgpt", "convA-gpt", "l", "t", 1L));
        s.putBinding("A", new ProviderBinding("claude", "convA-cl", "l", "t", 1L));
        s.putBinding("B", new ProviderBinding("chatgpt", "convB-gpt", "l", "t", 1L));
        s.appendMessage("A", "mA", "USER", "user", "in A", null, 10L);
        s.appendMessage("B", "mB", "USER", "user", "in B", null, 11L);
        return s;
    }
    static Artifact file(InMemoryRoomStore s, String id, String room, String msg) {
        s.createArtifact(id, room, "user", id + ".txt", "text/plain", 20L);
        s.finalizeArtifact(id, null, 3L, HEX, room + "/" + id);
        s.attachArtifact(msg, id, 0);
        return s.getArtifact(id);
    }
    /** A file the given AI produced in its CURRENT conversation of this room, attached to a message of that AI. */
    static Artifact aiFile(InMemoryRoomStore s, String id, String room, String msg, String ai) {
        s.createArtifact(id, room, ai, s.activeBindingId(room, ai), id + ".bin", "", 20L);
        s.finalizeArtifact(id, null, 3L, HEX, room + "/" + id);
        s.attachArtifact(msg, id, 0);
        return s.getArtifact(id);
    }
    static final class TrackingStream extends ByteArrayInputStream {
        volatile boolean closed;
        TrackingStream(byte[] b) { super(b); }
        @Override public void close() { closed = true; }
    }
    static long seq(InMemoryRoomStore s, String id) { return s.getMessage(id).seq; }
    static GateDecision eval(ArtifactGate g, String room, String ai) { return g.evaluate(room, ai, 0, 1000, 100L); }

    /** Gives an AI reply message a delivery that records the provider's reply id (what RoomController does for a real reply). */
    static void giveReplyRef(InMemoryRoomStore s, String room, String replyMsgId, String ref, long now) {
        RoomMessage m = s.getMessage(replyMsgId);
        String trigger = "t-" + replyMsgId, delivery = "dv-" + replyMsgId;
        s.appendMessage(room, trigger, "USER", "user", "trigger", null, now);
        s.createDelivery(delivery, room, trigger, m.authorId, 1L, now);
        if (ref != null && !ref.isEmpty()) s.recordProviderIds(delivery, "u-" + replyMsgId, ref);
        s.setDeliveryReply(delivery, replyMsgId);
    }

    public static void main(String[] args) {
        test("plain text never touches the file machinery", () -> {
            InMemoryRoomStore s = store();
            ArtifactGate g = new ArtifactGate(s, a -> { throw new IllegalStateException("integrity must not be asked"); });
            GateDecision d = eval(g, "A", "chatgpt");
            check(d.kind == GateDecision.Kind.OPEN && d.reason.isEmpty() && d.startable.isEmpty() && d.awaitingCapture.isEmpty(), "no files: OPEN");
            check(s.transfersInState(P).isEmpty() && s.transfersInState(S).isEmpty() && s.transfersInState(T).isEmpty() && s.transfersInState(V).isEmpty() && s.transfersInState(F).isEmpty(), "...and not a single transfer row was written");
            RoomMessage later = s.appendMessage("A", "mA2", "USER", "user", "later, plain", null, 12L);
            file(s, "old", "A", "mA");
            check(g.evaluate("A", "chatgpt", seq(s, "mA"), later.seq, 100L).kind == GateDecision.Kind.OPEN, "a file on an EARLIER message does not matter for a turn that does not include it");
            check(throwsAny(() -> d.startable.add(null)) && throwsAny(() -> d.awaitingCapture.add(null)), "a decision cannot be changed afterwards");
        });

        test("one file: PENDING, SENDING, READY_TO_SEND when STAGED, then OPEN once VERIFIED", () -> {
            InMemoryRoomStore s = store();
            Artifact a = file(s, "f1", "A", "mA");
            ArtifactGate g = new ArtifactGate(s, x -> true);
            GateDecision d = eval(g, "A", "chatgpt");
            check(d.kind == GateDecision.Kind.WORKING && d.startable.size() == 1 && d.awaitingCapture.isEmpty() && d.reason.equals("sending files to ChatGPT"), "the file is not in ChatGPT's conversation yet: WORKING, one transfer can start: " + d);
            ArtifactTransfer t = d.startable.get(0);
            check(t.state == P && t.attempts == 0 && t.artifactId.equals("f1") && t.providerId.equals("chatgpt") && t.roomId.equals("A") && t.bindingId.equals(s.currentTransfer("f1", "A", "chatgpt").bindingId), "the transfer is tied to this file, room, AI and its ACTIVE conversation");
            check(eval(g, "A", "chatgpt").startable.size() == 1 && s.transfersInState(P).size() == 1, "asking again does not create a second transfer");
            s.transitionTransfer("f1", t.bindingId, st(P), S, null, 101L);
            GateDecision sending = eval(g, "A", "chatgpt");
            check(sending.kind == GateDecision.Kind.WORKING && sending.startable.isEmpty() && !sending.reason.isEmpty(), "while it sends: WORKING and nothing more to start");
            s.transitionTransfer("f1", t.bindingId, st(S), T, null, 102L);
            check(eval(g, "A", "chatgpt").kind == GateDecision.Kind.READY_TO_SEND, "once STAGED in ChatGPT's composer: READY_TO_SEND");
            s.transitionTransfer("f1", t.bindingId, st(T), V, null, 103L);
            check(eval(g, "A", "chatgpt").kind == GateDecision.Kind.OPEN, "once VERIFIED in ChatGPT's conversation: OPEN");
            check(eval(g, "A", "claude").kind == GateDecision.Kind.WORKING, "...but Claude still needs it (each AI has its own conversation)");
        });

        test("failures: retry a limited number of times, then block with a reason", () -> {
            InMemoryRoomStore s = store();
            file(s, "f1", "A", "mA");
            ArtifactGate g = new ArtifactGate(s, x -> true);
            ArtifactTransfer t = eval(g, "A", "claude").startable.get(0);
            for (int i = 1; i <= 3; i++) {
                s.transitionTransfer("f1", t.bindingId, st(P, F), S, null, 100L + i);
                s.transitionTransfer("f1", t.bindingId, st(S), F, "page not ready", 110L + i);
                GateDecision d = eval(g, "A", "claude");
                if (i < 3) check(d.kind == GateDecision.Kind.WORKING && d.startable.size() == 1 && d.startable.get(0).attempts == i, "after failure " + i + " the file is tried again: " + d);
                else check(d.kind == GateDecision.Kind.BLOCKED && d.reason.contains("f1.txt") && d.reason.contains("Claude") && d.reason.contains("3 tries") && d.reason.contains("page not ready"), "after 3 failed tries the turn is BLOCKED with a clear reason: " + d.reason);
            }
            check(ArtifactGate.MAX_ATTEMPTS == 3, "the limit is three tries");
        });

        test("files that are not ready, damaged, or have nobody to receive them", () -> {
            InMemoryRoomStore s = store();
            s.createArtifact("cap", "A", "claude", s.activeBindingId("A", "claude"), "out.zip", "", 20L); s.attachArtifact("mA", "cap", 0);
            ArtifactGate g = new ArtifactGate(s, x -> true);
            GateDecision d = eval(g, "A", "chatgpt");
            check(d.kind == GateDecision.Kind.WORKING && d.awaitingCapture.size() == 1 && d.awaitingCapture.get(0).id.equals("cap") && d.startable.isEmpty() && d.reason.contains("out.zip"), "an AI's file whose bytes are not stored yet: WORKING, waiting for the capture: " + d);
            s.failArtifact("cap");
            d = eval(g, "A", "chatgpt");
            check(d.kind == GateDecision.Kind.BLOCKED && d.reason.contains("out.zip") && d.reason.contains("could not be saved"), "a file that could not be saved blocks the turn: " + d.reason);
            check(s.transfersInState(P).isEmpty(), "...and no transfer was made for it");
            InMemoryRoomStore s2 = store(); file(s2, "f1", "A", "mA");
            Set<String> damaged = new HashSet<>(); damaged.add("f1");
            ArtifactGate g2 = new ArtifactGate(s2, a -> !damaged.contains(a.id));
            d = eval(g2, "A", "chatgpt");
            check(d.kind == GateDecision.Kind.BLOCKED && d.reason.contains("missing or damaged") && s2.transfersInState(P).isEmpty(), "a stored file that no longer matches its hash blocks the turn (and nothing is queued): " + d.reason);
            InMemoryRoomStore s3 = store(); file(s3, "f1", "A", "mA");
            s3.clearBinding("A", "claude", 50L);
            d = eval(new ArtifactGate(s3, x -> true), "A", "claude");
            check(d.kind == GateDecision.Kind.BLOCKED && d.reason.contains("not connected") && d.reason.contains("f1.txt"), "an AI with no conversation in the room cannot receive files: " + d.reason);
            InMemoryRoomStore s4 = store(); Artifact a4 = file(s4, "f1", "A", "mA");
            String b = eval(new ArtifactGate(s4, x -> true), "A", "chatgpt").startable.get(0).bindingId;
            s4.transitionTransfer("f1", b, st(P), S, null, 1L); s4.transitionTransfer("f1", b, st(S), T, null, 2L); s4.transitionTransfer("f1", b, st(T), V, null, 3L);
            check(eval(new ArtifactGate(s4, a -> { throw new IllegalStateException("must not be asked"); }), "A", "chatgpt").kind == GateDecision.Kind.OPEN, "a file that is already VERIFIED is not re-checked on disk");
        });

        test("which files a turn needs: its own range, other authors only, one entry per file", () -> {
            InMemoryRoomStore s = store();
            RoomMessage m2 = s.appendMessage("A", "mA2", "PROVIDER", "chatgpt", "reply with file", "mA", 12L);
            RoomMessage m3 = s.appendMessage("A", "mA3", "USER", "user", "next", null, 13L);
            aiFile(s, "mine", "A", "mA2", "chatgpt");
            ArtifactGate g = new ArtifactGate(s, x -> true);
            check(g.evaluate("A", "chatgpt", 0, m3.seq, 1L).kind == GateDecision.Kind.OPEN && s.transfersInState(P).isEmpty(), "a file the AI produced in the conversation it is in NOW is already there: nothing to send to it");
            GateDecision d = g.evaluate("A", "claude", 0, m3.seq, 1L);
            check(d.kind == GateDecision.Kind.WORKING && d.startable.size() == 1 && d.startable.get(0).artifactId.equals("mine"), "...but the other AI needs it");
            check(g.evaluate("A", "claude", m2.seq, m3.seq, 1L).kind == GateDecision.Kind.OPEN && g.evaluate("A", "claude", 0, seq(s, "mA"), 1L).kind == GateDecision.Kind.OPEN, "the range is (after, upto]: a file on a message outside it is not needed");
            check(g.evaluate("A", "claude", m2.seq - 1, m2.seq, 1L).kind == GateDecision.Kind.WORKING, "...and the upper end is included");
            // the same file on two messages counts once; two files keep message order; a verified one is left out
            InMemoryRoomStore s2 = store();
            s2.appendMessage("A", "mA2", "USER", "user", "again", null, 12L);
            file(s2, "x1", "A", "mA"); s2.attachArtifact("mA2", "x1", 0);
            Artifact y = s2.createArtifact("y1", "A", "user", "y1.txt", "", 21L); s2.finalizeArtifact("y1", null, 1L, HEX, "A/y1"); s2.attachArtifact("mA2", "y1", 1);
            ArtifactGate g2 = new ArtifactGate(s2, x -> true);
            GateDecision d2 = g2.evaluate("A", "chatgpt", 0, 1000, 1L);
            check(d2.startable.size() == 2 && d2.startable.get(0).artifactId.equals("x1") && d2.startable.get(1).artifactId.equals("y1") && s2.transfersInState(P).size() == 2, "a file on two messages is one transfer; files come in message order");
            String bx = d2.startable.get(0).bindingId;
            s2.transitionTransfer("x1", bx, st(P), S, null, 2L); s2.transitionTransfer("x1", bx, st(S), T, null, 3L); s2.transitionTransfer("x1", bx, st(T), V, null, 4L);
            GateDecision d3 = g2.evaluate("A", "chatgpt", 0, 1000, 4L);
            check(d3.kind == GateDecision.Kind.WORKING && d3.startable.size() == 1 && d3.startable.get(0).artifactId.equals("y1"), "a VERIFIED file is left out; only the missing one is still to send");
            // one failed file blocks even if another is fine
            s2.createArtifact("z1", "A", "claude", s2.activeBindingId("A", "claude"), "z1.txt", "", 22L); s2.attachArtifact("mA2", "z1", 2); s2.failArtifact("z1");
            check(g2.evaluate("A", "chatgpt", 0, 1000, 5L).kind == GateDecision.Kind.BLOCKED, "one file that failed blocks the turn even though others are fine");
        });

        test("an AI's own file counts as already present ONLY in the very conversation it was made in", () -> {
            InMemoryRoomStore s = store();
            s.appendMessage("A", "gptMsg", "PROVIDER", "chatgpt", "here is a file", "mA", 12L);
            s.appendMessage("A", "clMsg", "PROVIDER", "claude", "and mine", "mA", 13L);
            aiFile(s, "fromClaude", "A", "clMsg", "claude");
            ArtifactGate g = new ArtifactGate(s, x -> true);
            check(g.evaluate("A", "claude", 0, 1000, 1L).kind == GateDecision.Kind.OPEN && s.transfersInState(P).isEmpty(), "Claude's file, Claude in the SAME conversation: nothing is uploaded");
            GateDecision toGpt = g.evaluate("A", "chatgpt", 0, 1000, 1L);
            check(toGpt.kind == GateDecision.Kind.WORKING && toGpt.startable.size() == 1 && toGpt.startable.get(0).providerId.equals("chatgpt"), "Claude's file, ChatGPT: an upload is required");
            String oldBinding = s.activeBindingId("A", "claude");
            s.putBinding("A", new ProviderBinding("claude", "convA-cl-2", "l", "t", 50L));   // Claude moves to a NEW conversation of the same room
            check(!s.activeBindingId("A", "claude").equals(oldBinding), "(Claude now has a different active conversation)");
            GateDecision after = g.evaluate("A", "claude", 0, 1000, 2L);
            check(after.kind == GateDecision.Kind.WORKING && after.startable.size() == 1 && after.startable.get(0).providerId.equals("claude") && after.startable.get(0).bindingId.equals(s.activeBindingId("A", "claude")), "after a rebind the same AI's own file must be sent to the NEW conversation, which has never seen it: " + after);
            check(s.getArtifact("fromClaude").sourceBindingId.equals(oldBinding), "the file still remembers the conversation it was made in");
            // an AI file whose conversation is not known cannot exist any more (both stores refuse it); the rule still never trusts one built by hand
            InMemoryRoomStore s2 = store();
            check(throwsAny(() -> s2.createArtifact("anon", "A", "claude", null, "anon.bin", "", 20L)) && s2.getArtifact("anon") == null, "an AI file with no recorded conversation cannot be created");
            Artifact anon = new Artifact("anon", "A", "claude", null, "anon.bin", "", 3L, HEX, "A/anon", ArtifactState.READY, 1L);
            // the rule itself: presence needs the same AI AND the same binding; another room's binding never counts
            Artifact made = s.getArtifact("fromClaude");
            String roomBClaude = null;
            s.upsertParticipant("B", "claude", 1); s.putBinding("B", new ProviderBinding("claude", "convB-cl", "l", "t", 60L)); roomBClaude = s.activeBindingId("B", "claude");
            check(ArtifactGate.producedInCurrentConversation(made, "claude", oldBinding) && !ArtifactGate.producedInCurrentConversation(made, "claude", s.activeBindingId("A", "claude")) && !ArtifactGate.producedInCurrentConversation(made, "claude", roomBClaude)
                    && !ArtifactGate.producedInCurrentConversation(made, "chatgpt", oldBinding) && !ArtifactGate.producedInCurrentConversation(made, "claude", null) && !ArtifactGate.producedInCurrentConversation(anon, "claude", oldBinding),
                    "the rule: same AI AND same conversation only; a room-B conversation, another AI, no conversation, or an unknown source never count");
            // a room-A conversation can never be the source of a room-B file
            boolean crossRoom = false, wrongAi = false, userWithSource = false;
            try { s.createArtifact("x1", "B", "claude", oldBinding, "x.bin", "", 1L); } catch (IllegalStateException e) { crossRoom = true; }
            try { s.createArtifact("x2", "A", "chatgpt", oldBinding, "x.bin", "", 1L); } catch (IllegalStateException e) { wrongAi = true; }
            try { s.createArtifact("x3", "A", "user", oldBinding, "x.bin", "", 1L); } catch (IllegalArgumentException e) { userWithSource = true; }
            check(crossRoom && wrongAi && userWithSource && s.getArtifact("x1") == null && s.getArtifact("x2") == null && s.getArtifact("x3") == null, "a source conversation of another room, of another AI, or on a user file is refused");
        });

        test("prompt notes: file sizes in plain units", () -> {
            check(RoomPromptBuilder.formatSize(0).equals("0 B") && RoomPromptBuilder.formatSize(5).equals("5 B") && RoomPromptBuilder.formatSize(1023).equals("1023 B"), "under 1 KB: bytes");
            check(RoomPromptBuilder.formatSize(1024).equals("1.0 KB") && RoomPromptBuilder.formatSize(1536).equals("1.5 KB") && RoomPromptBuilder.formatSize(2048).equals("2.0 KB") && RoomPromptBuilder.formatSize(3000).equals("2.9 KB") && RoomPromptBuilder.formatSize(10_000).equals("9.8 KB"), "kilobytes are 1024 bytes (3000 bytes is 2.9 KB, not 3.0)");
            check(RoomPromptBuilder.formatSize(1024L * 1024L).equals("1.0 MB") && RoomPromptBuilder.formatSize(5L * 1024L * 1024L).equals("5.0 MB") && RoomPromptBuilder.formatSize(25L * 1024L * 1024L + 512L * 1024L).equals("25.5 MB"), "megabytes are 1024 KB");
        });

        test("rooms and conversations stay apart", () -> {
            InMemoryRoomStore s = store();
            file(s, "fb", "B", "mB");
            ArtifactGate g = new ArtifactGate(s, x -> true);
            check(eval(g, "A", "chatgpt").kind == GateDecision.Kind.OPEN && eval(g, "B", "chatgpt").kind == GateDecision.Kind.WORKING, "a file of room B never gates a turn in room A");
            file(s, "fa", "A", "mA");
            ArtifactTransfer ta = eval(g, "A", "chatgpt").startable.get(0), tb = eval(g, "B", "chatgpt").startable.get(0);
            check(!ta.bindingId.equals(tb.bindingId) && ta.roomId.equals("A") && tb.roomId.equals("B"), "the same AI has a separate transfer (and conversation) in each room");
            s.transitionTransfer("fa", ta.bindingId, st(P), S, null, 1L); s.transitionTransfer("fa", ta.bindingId, st(S), T, null, 2L); s.transitionTransfer("fa", ta.bindingId, st(T), V, null, 3L);
            check(eval(g, "A", "chatgpt").kind == GateDecision.Kind.OPEN && eval(g, "B", "chatgpt").kind == GateDecision.Kind.WORKING, "verifying a file in room A does not satisfy room B");
            // a NEW conversation in room A needs the file again
            s.putBinding("A", new ProviderBinding("chatgpt", "convA-gpt-2", "l", "t", 50L));
            GateDecision d = eval(g, "A", "chatgpt");
            check(d.kind == GateDecision.Kind.WORKING && d.startable.size() == 1 && !d.startable.get(0).bindingId.equals(ta.bindingId) && s.transfersInState(V).size() == 1, "after the AI moves to a new conversation the file must go there too; the old VERIFIED row stays as history");
        });

        // ------------------------------------------------------------------ the service
        class Fx {
            final InMemoryRoomStore s = store(); final File root; final ArtifactStorage storage; final MockArtifactTransport tr = new MockArtifactTransport(); final MockCaptureTransport cap = new MockCaptureTransport();
            final AtomicInteger clock = new AtomicInteger(1000), idn = new AtomicInteger(), woke = new AtomicInteger(); final ArtifactService svc;
            Fx(long max) throws IOException {
                root = Files.createTempDirectory("agc-svc-").toFile(); storage = new ArtifactStorage(root);
                svc = new ArtifactService(s, storage, tr, cap, () -> clock.incrementAndGet(), () -> "id" + idn.incrementAndGet(), max);
                svc.setListener(woke::incrementAndGet);
            }
            Artifact userFile(String room, String msg, String text) throws IOException {
                Artifact a = svc.addUserFile(room, "doc.txt", "text/plain", new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
                s.attachArtifact(msg, a.id, 0); return a;
            }
            GateDecision eval(String room, String ai) { return svc.evaluate(room, ai, 0, 1000); }
        }

        test("the user's files: stored privately, hashed, cleaned up when anything fails", () -> {
            Fx f = new Fx(1000);
            Artifact a = f.svc.addUserFile("A", "notes.txt", "text/plain", new ByteArrayInputStream("hello".getBytes(StandardCharsets.UTF_8)));
            check(a.state == ArtifactState.READY && a.fromUser() && a.size == 5 && a.mime.equals("text/plain") && a.displayName.equals("notes.txt") && a.storagePath.equals("A/" + a.id) && a.sha256.equals("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"), "a user file becomes a READY artifact with its size, hash and private path");
            check(f.storage.isIntact(a) && new File(f.root, "A/" + a.id).isFile(), "the bytes are in the private folder");
            boolean tooBig = false; int rowsBefore = 1;
            try { f.svc.addUserFile("A", "big", "", new ByteArrayInputStream(new byte[1001])); } catch (IOException e) { tooBig = true; }
            check(tooBig && f.s.getArtifact("id2") == null && !new File(f.root, "A/id2").exists() && new File(f.root, ".tmp").listFiles().length == 0, "a file over the limit leaves nothing behind: no artifact row, no stored file, no temporary file");
            InputStream broken = new InputStream() { @Override public int read() throws IOException { throw new IOException("disk"); } @Override public int read(byte[] b, int o, int l) throws IOException { throw new IOException("disk"); } };
            boolean threw = false;
            try { f.svc.addUserFile("A", "x", "", broken); } catch (IOException e) { threw = true; }
            check(threw && f.s.getArtifact("id3") == null && new File(f.root, ".tmp").listFiles().length == 0, "a stream that breaks leaves nothing behind either");
            check(throwsAny(() -> { try { f.svc.addUserFile("nowhere", "x", "", new ByteArrayInputStream(new byte[1])); } catch (IOException e) { throw new RuntimeException(e); } }), "an unknown room is refused");
            Artifact loose = f.svc.addUserFile("A", "loose.txt", "", new ByteArrayInputStream("x".getBytes(StandardCharsets.UTF_8)));
            check(f.svc.discard(loose.id) && f.s.getArtifact(loose.id) == null && !new File(f.root, loose.storagePath).exists() && !f.svc.discard(loose.id), "dropping a file before sending forgets it and its bytes (once)");
            f.s.attachArtifact("mA", a.id, 0);
            check(!f.svc.discard(a.id) && f.storage.isIntact(f.s.getArtifact(a.id)), "a file that a message uses cannot be discarded");
            Artifact halfSaved = f.s.createArtifact("half-u", "A", Artifact.ORIGIN_USER, null, "half.txt", "", 70L);   // a user file whose row never reached READY, with its bytes already in place
            f.storage.write("A", "half-u", new ByteArrayInputStream("bytes".getBytes(StandardCharsets.UTF_8)), 1000);
            check(new File(f.root, "A/half-u").isFile() && halfSaved.storagePath.isEmpty() && f.svc.discard("half-u") && !new File(f.root, "A/half-u").exists() && f.s.getArtifact("half-u") == null, "discarding a half-saved file (no recorded path) still removes its bytes");
        });

        test("sending a file into an AI's conversation", () -> {
            Fx f = new Fx(1000);
            Artifact a = f.userFile("A", "mA", "hello");
            GateDecision d = f.eval("A", "claude");
            check(d.kind == GateDecision.Kind.WORKING && f.svc.advance(d) && f.tr.calls.equals(java.util.Arrays.asList(a.id + "->claude")), "advance starts the transfer");
            ArtifactTransfer t = f.s.currentTransfer(a.id, "A", "claude");
            check(t.state == T && t.attempts == 1 && f.woke.get() == 1 && !f.svc.isBusy() && f.eval("A", "claude").kind == GateDecision.Kind.READY_TO_SEND, "STAGED after one attempt, the listener was told once, nothing is busy, the gate is READY_TO_SEND");
            GateDecision ready = f.eval("A", "claude");
            check(ready.stagedTransfers.size() == 1 && ready.stagedTransfers.get(0).artifactId.equals(a.id), "READY_TO_SEND carries the exact staged transfer rows for this send");
            check(f.svc.commitStaged(ready.stagedTransfers) == 1 && f.s.currentTransfer(a.id, "A", "claude").state == V && f.eval("A", "claude").kind == GateDecision.Kind.OPEN, "provider acceptance explicitly commits ONLY this send's STAGED row -> VERIFIED and opens the gate");
            check(!f.svc.advance(f.eval("A", "claude")) && !f.svc.advance(null) && f.tr.calls.size() == 1, "nothing more to do: advance does nothing");
            check(f.svc.advance(f.eval("A", "chatgpt")) && f.s.currentTransfer(a.id, "A", "chatgpt").state == T, "ChatGPT gets its own staged transfer");
        });

        test("REVIEW: a later file that fails to stage resets the earlier staged files (the composer is cleaned), so they can never be committed without being sent", () -> {
            Fx f = new Fx(1000);
            Artifact a = f.userFile("A", "mA", "one");
            Artifact b = f.userFile("A", "mA", "two");
            check(f.svc.advance(f.eval("A", "claude")) && f.s.currentTransfer(a.id, "A", "claude").state == T, "the first file is STAGED in the composer");
            f.tr.mode = MockArtifactTransport.Mode.FAIL; f.tr.failReason = "upload rejected";
            check(f.svc.advance(f.eval("A", "claude")) && f.s.currentTransfer(b.id, "A", "claude").state == F, "the second file fails to stage");
            check(f.s.currentTransfer(a.id, "A", "claude").state == F, "the surface cleans the composer after a failed stage, so the FIRST file is no longer staged: it must be uploaded again, never trusted");
            check(f.tr.invalidations == 1, "invalidating staged DB rows notifies the transport so an idle retained surface cannot stay locked");
            f.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            int guard = 0;
            while (f.eval("A", "claude").kind == GateDecision.Kind.WORKING && guard++ < 6) f.svc.advance(f.eval("A", "claude"));
            check(f.eval("A", "claude").kind == GateDecision.Kind.READY_TO_SEND && f.s.currentTransfer(a.id, "A", "claude").state == T && f.s.currentTransfer(b.id, "A", "claude").state == T, "READY_TO_SEND only once BOTH files are staged again");
            check(f.tr.calls.stream().filter(c -> c.startsWith(a.id)).count() == 2, "the first file really was uploaded a second time");
            GateDecision ready = f.eval("A", "claude");
            check(ready.stagedTransfers.size() == 2 && f.svc.commitStaged(ready.stagedTransfers) == 2, "acceptance then commits exactly the two files that were really sent");
        });


        test("acceptance never sweeps an unrelated staged row", () -> {
            Fx f = new Fx(1000);
            Artifact inPrompt = f.userFile("A", "mA", "needed");
            check(f.svc.advance(f.eval("A", "claude")), "the prompt file stages");
            Artifact stray = f.svc.addUserFile("A", "stray.txt", "text/plain", new ByteArrayInputStream("stray".getBytes(StandardCharsets.UTF_8)));
            ArtifactTransfer st = f.s.ensureTransfer(stray.id, "A", "claude", 1L);
            check(f.s.transitionTransfer(stray.id, st.bindingId, new TransferState[]{P}, S, null, 2L), "unrelated row enters SENDING");
            check(f.s.transitionTransfer(stray.id, st.bindingId, new TransferState[]{S}, T, null, 3L), "unrelated row is STAGED but is not in this prompt");
            GateDecision ready = f.eval("A", "claude");
            check(ready.kind == GateDecision.Kind.READY_TO_SEND && ready.stagedTransfers.size() == 1 && ready.stagedTransfers.get(0).artifactId.equals(inPrompt.id), "gate snapshots only the staged row actually needed by this send");
            check(f.svc.commitStaged(ready.stagedTransfers) == 1 && f.s.currentTransfer(inPrompt.id, "A", "claude").state == V, "the intended row commits");
            check(f.s.currentTransfer(stray.id, "A", "claude").state == T, "the unrelated staged row stays STAGED and is never falsely VERIFIED");
        });


        test("idle staged expiry makes the exact binding retryable without pretending the file was sent", () -> {
            Fx f = new Fx(1000);
            Artifact a = f.userFile("A", "mA", "hello");
            check(f.svc.advance(f.eval("A", "claude")) && f.s.currentTransfer(a.id, "A", "claude").state == T, "file is staged");
            String binding = f.s.currentTransfer(a.id, "A", "claude").bindingId;
            f.tr.expireStaged("A", "claude", binding);
            check(f.s.currentTransfer(a.id, "A", "claude").state == F, "surface idle-expiry feeds back into the store and fails the exact staged row");
            check(f.tr.invalidations == 0, "expiry already cleaned the surface, so the store does not recursively invalidate it again");
        });

        test("REVIEW: acceptance is all-or-nothing: if one expected file is no longer staged, none of them is trusted", () -> {
            Fx f = new Fx(1000);
            Artifact a = f.userFile("A", "mA", "one");
            Artifact b = f.userFile("A", "mA", "two");
            int guard = 0;
            while (f.eval("A", "claude").kind == GateDecision.Kind.WORKING && guard++ < 6) f.svc.advance(f.eval("A", "claude"));
            GateDecision d = f.eval("A", "claude");
            check(d.kind == GateDecision.Kind.READY_TO_SEND && d.stagedTransfers.size() == 2, "two files are staged for this send");
            ArtifactTransfer tb = f.s.currentTransfer(b.id, "A", "claude");
            check(f.s.transitionTransfer(b.id, tb.bindingId, new TransferState[]{T}, F, "cleaned", 5L), "one of them is reset before the acceptance arrives");
            check(f.svc.commitStaged(d.stagedTransfers) == 0, "the mismatch commits nothing");
            check(f.s.currentTransfer(a.id, "A", "claude").state == F && f.s.currentTransfer(b.id, "A", "claude").state == F, "neither file is VERIFIED; both will be sent again, never trusted");
            check(f.svc.commitStaged(d.stagedTransfers) == 0 && f.svc.commitStaged(null) == 0 && f.svc.commitStaged(new java.util.ArrayList<>()) == 0, "repeating or empty commits are harmless");
        });

        test("a manual capture retry needs the exact reply identity: without it the file is never guessed", () -> {
            Fx f = new Fx(1000);
            f.s.appendMessage("A", "repA", "PROVIDER", "claude", "with an id", "mA", 30L);
            f.s.createArtifact("withId", "A", "claude", f.s.activeBindingId("A", "claude"), "a.pdf", "", 31L); f.s.attachArtifact("repA", "withId", 0); giveReplyRef(f.s, "A", "repA", "asst-A", 29L);
            f.s.appendMessage("A", "repB", "PROVIDER", "claude", "page gave no id", "mA", 32L);
            f.s.createArtifact("noId", "A", "claude", f.s.activeBindingId("A", "claude"), "b.pdf", "", 33L); f.s.attachArtifact("repB", "noId", 0); giveReplyRef(f.s, "A", "repB", "", 31L);
            f.s.failArtifact("withId"); f.s.failArtifact("noId");
            check(f.svc.canRetryCapture("withId") && !f.svc.canRetryCapture("noId") && !f.svc.canRetryCapture("nope"), "only the file with a stored reply identity can be retried");
            check(!f.svc.retryCapture("noId") && f.s.getArtifact("noId").state == ArtifactState.FAILED, "retrying the file without an identity is refused and changes nothing");
            check(f.svc.retryCapture("withId") && f.s.getArtifact("withId").state == ArtifactState.PENDING_CAPTURE && !f.svc.canRetryCapture("withId"), "the file with an identity is retried (and is no longer FAILED)");
        });

        test("failures are recorded, retried, and finally block", () -> {
            Fx f = new Fx(1000); f.tr.mode = MockArtifactTransport.Mode.FAIL; f.tr.failReason = "upload rejected";
            Artifact a = f.userFile("A", "mA", "hello");
            for (int i = 1; i <= 3; i++) {
                GateDecision d = f.eval("A", "claude");
                check(d.kind == GateDecision.Kind.WORKING && f.svc.advance(d), "attempt " + i + " starts");
                ArtifactTransfer t = f.s.currentTransfer(a.id, "A", "claude");
                check(t.state == F && t.attempts == i && t.error.equals("upload rejected") && !f.svc.isBusy(), "attempt " + i + " failed with its reason and the slot is free");
            }
            GateDecision end = f.eval("A", "claude");
            check(end.kind == GateDecision.Kind.BLOCKED && !f.svc.advance(end) && f.tr.calls.size() == 3 && f.woke.get() == 3, "after three failures the gate blocks and nothing is retried: " + end.reason);
        });

        test("global single-flight: one job at a time in the whole app", () -> {
            Fx f = new Fx(1000); f.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = f.userFile("A", "mA", "one");
            Artifact b = f.svc.addUserFile("B", "two.txt", "", new ByteArrayInputStream("two".getBytes(StandardCharsets.UTF_8))); f.s.attachArtifact("mB", b.id, 0);
            check(f.svc.advance(f.eval("A", "claude")) && f.svc.isBusy() && f.tr.isHolding() && f.s.currentTransfer(a.id, "A", "claude").state == S, "the first transfer is sending and the app is busy");
            check(!f.svc.advance(f.eval("A", "chatgpt")) && !f.svc.advance(f.eval("B", "chatgpt")) && f.tr.calls.size() == 1, "no second transfer starts, in the same room or another one");
            check(f.s.currentTransfer(a.id, "A", "chatgpt").state == P && f.s.currentTransfer(a.id, "A", "chatgpt").attempts == 0, "a transfer that could not start is untouched (still PENDING, no attempt counted)");
            check(f.woke.get() == 0, "nobody is woken while the job is still running");
            check(f.tr.complete(true) && !f.svc.isBusy() && f.woke.get() == 1 && f.s.currentTransfer(a.id, "A", "claude").state == T, "finishing it stages the file, frees the slot and wakes the listener");
            check(f.svc.advance(f.eval("B", "chatgpt")) && f.tr.complete(true) && f.s.currentTransfer(b.id, "B", "chatgpt").state == T, "then the other room's transfer can run and stage independently");
        });

        test("capturing a file an AI produced (the second phase)", () -> {
            Fx f = new Fx(1000);
            f.s.appendMessage("A", "rep", "PROVIDER", "claude", "here is a file", "mA", 30L);
            Artifact intent = f.s.createArtifact("gen1", "A", "claude", f.s.activeBindingId("A", "claude"), "report.pdf", "", 31L); f.s.attachArtifact("rep", "gen1", 0);
            check(f.eval("A", "chatgpt").kind == GateDecision.Kind.WORKING && f.eval("A", "chatgpt").awaitingCapture.size() == 1, "before the bytes are captured the next AI must wait");
            f.cap.contents.put("gen1", "PDFDATA".getBytes(StandardCharsets.UTF_8)); f.cap.mime = "application/pdf";
            check(f.svc.advance(f.eval("A", "chatgpt")) && !f.svc.isBusy(), "advance captures first");
            Artifact done = f.s.getArtifact("gen1");
            check(done.state == ArtifactState.READY && done.size == 7 && done.mime.equals("application/pdf") && done.storagePath.equals("A/gen1") && f.storage.isIntact(done) && f.woke.get() == 1, "the file is READY with its size, hash, type and stored bytes");
            check(f.eval("A", "chatgpt").kind == GateDecision.Kind.WORKING && f.eval("A", "chatgpt").awaitingCapture.isEmpty() && f.eval("A", "chatgpt").startable.size() == 1, "now the next AI's transfer can start");
            // failures
            f.s.appendMessage("A", "rep2", "PROVIDER", "claude", "another", "mA", 40L);
            f.s.createArtifact("gen2", "A", "claude", f.s.activeBindingId("A", "claude"), "gone.bin", "", 41L); f.s.attachArtifact("rep2", "gen2", 0);
            check(f.svc.advance(new ArtifactGate(f.s, null).evaluate("A", "chatgpt", f.s.getMessage("rep").seq, 1000, 1L)) && f.s.getArtifact("gen2").state == ArtifactState.FAILED && !new File(f.root, "A/gen2").exists() && !f.svc.isBusy(), "a capture that cannot get the bytes marks the file FAILED and keeps nothing");
            f.s.appendMessage("A", "rep3", "PROVIDER", "claude", "big one", "mA", 50L);
            f.s.createArtifact("gen3", "A", "claude", f.s.activeBindingId("A", "claude"), "huge.bin", "", 51L); f.s.attachArtifact("rep3", "gen3", 0); f.cap.contents.put("gen3", new byte[1001]);
            f.svc.startCaptures(java.util.Arrays.asList(f.s.getArtifact("gen3")));
            check(f.s.getArtifact("gen3").state == ArtifactState.FAILED && !new File(f.root, "A/gen3").exists() && new File(f.root, ".tmp").listFiles().length == 0 && !f.svc.isBusy(), "a captured file over the size limit is FAILED and nothing is kept");
            InMemoryRoomStore plain = store();
            GateDecision open = new ArtifactGate(plain, null).evaluate("A", "chatgpt", 0, 1000, 1L);
            plain.createArtifact("bad", "A", "claude", plain.activeBindingId("A", "claude"), "bad.bin", "", 1L); plain.attachArtifact("mA", "bad", 0); plain.failArtifact("bad");
            GateDecision blocked = new ArtifactGate(plain, null).evaluate("A", "chatgpt", 0, 1000, 1L);
            check(open.kind == GateDecision.Kind.OPEN && blocked.kind == GateDecision.Kind.BLOCKED && !f.svc.advance(open) && !f.svc.advance(blocked) && !f.svc.advance(null), "advance ignores anything but a WORKING decision");
        });

        test("captures and transfers share the one slot; cancel and callbacks are safe", () -> {
            Fx f = new Fx(1000); f.cap.mode = MockCaptureTransport.Mode.MANUAL;
            Artifact u = f.userFile("A", "mA", "x");
            f.s.appendMessage("A", "rep", "PROVIDER", "claude", "file", "mA", 30L);
            f.s.createArtifact("gen", "A", "claude", f.s.activeBindingId("A", "claude"), "g.bin", "", 31L); f.s.attachArtifact("rep", "gen", 0); f.cap.contents.put("gen", new byte[]{1, 2, 3});
            f.svc.startCaptures(java.util.Arrays.asList(f.s.getArtifact("gen")));
            check(f.svc.isBusy() && f.cap.isHolding(), "a capture is running");
            check(!f.svc.advance(f.eval("A", "chatgpt")), "neither the waiting capture nor a transfer can start while the capture holds the slot");
            check(f.tr.calls.isEmpty() && f.s.transfersInState(S).isEmpty(), "no transfer started during the capture");
            f.svc.cancelInFlight();
            check(f.cap.cancels == 1 && f.s.getArtifact("gen").state == ArtifactState.FAILED && !f.svc.isBusy() && f.woke.get() == 1, "cancel stops the capture; the file is FAILED (it can be retried) and the listener is woken");
            Fx g = new Fx(1000); g.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = g.userFile("A", "mA", "x");
            g.svc.advance(g.eval("A", "claude"));
            g.svc.cancelInFlight();
            check(g.tr.cancels == 1 && g.s.currentTransfer(a.id, "A", "claude").state == F && g.s.currentTransfer(a.id, "A", "claude").error.equals("cancelled") && !g.svc.isBusy(), "cancel stops a transfer; it is FAILED('cancelled') with its attempt counted");
            Fx h = new Fx(1000); h.svc.cancelInFlight();
            check(h.tr.cancels == 0 && h.cap.cancels == 0, "cancel with nothing running does nothing");
        });

        test("odd transports: repeated callbacks, exceptions, damaged files, a lost race", () -> {
            Fx f = new Fx(1000);
            f.userFile("A", "mA", "hello");
            ArtifactService twice = new ArtifactService(f.s, f.storage, new ArtifactService.Transport() {
                @Override public void transfer(Artifact a, File file, ArtifactTransfer t, Callback cb) { cb.onStaged(); cb.onStaged(); cb.onFailed("late"); }
                @Override public void cancel() { }
            }, null, () -> 5L, () -> "x", 1000);
            AtomicInteger woke = new AtomicInteger(); twice.setListener(woke::incrementAndGet);
            twice.advance(twice.evaluate("A", "claude", 0, 1000));
            check(woke.get() == 1 && f.s.transfersInState(T).size() == 1 && f.s.transfersInState(F).isEmpty(), "a transport that reports several times is counted once (the first staged result wins)");
            Fx g = new Fx(1000); Artifact a = g.userFile("A", "mA", "hello");
            ArtifactService boom = new ArtifactService(g.s, g.storage, new ArtifactService.Transport() {
                @Override public void transfer(Artifact x, File file, ArtifactTransfer t, Callback cb) { throw new IllegalStateException("webview crashed"); }
                @Override public void cancel() { }
            }, null, () -> 5L, () -> "x", 1000);
            boom.advance(boom.evaluate("A", "claude", 0, 1000));
            ArtifactTransfer t = g.s.currentTransfer(a.id, "A", "claude");
            check(t.state == F && t.error.equals("webview crashed") && !boom.isBusy(), "a transport that throws fails the transfer with its message and frees the slot");
            Fx h = new Fx(1000); Artifact ha = h.userFile("A", "mA", "hello");
            GateDecision d = h.svc.evaluate("A", "claude", 0, 1000);   // PENDING transfer created while the file is still intact
            Files.write(new File(h.root, ha.storagePath).toPath(), "tampered".getBytes(StandardCharsets.UTF_8));
            check(h.svc.advance(d) && h.tr.calls.isEmpty() && h.s.currentTransfer(ha.id, "A", "claude").state == F && h.s.currentTransfer(ha.id, "A", "claude").error.contains("damaged"), "a file that changed on disk is never uploaded: the transfer fails with a clear reason");
            check(h.svc.evaluate("A", "claude", 0, 1000).kind == GateDecision.Kind.BLOCKED, "...and the gate itself refuses it from then on");
            Fx i = new Fx(1000); Artifact ia = i.userFile("A", "mA", "hello");
            GateDecision di = i.eval("A", "claude");
            i.s.transitionTransfer(ia.id, di.startable.get(0).bindingId, st(P), S, null, 1L); // someone else got there first
            check(!i.svc.advance(di) && !i.svc.isBusy() && i.tr.calls.isEmpty(), "a lost race starts nothing and does not keep the slot");
        });

        test("Stop is deterministic: a transfer whose transport never answers is resolved by the service, and its late answer changes nothing", () -> {
            Fx f = new Fx(1000); f.tr.mode = MockArtifactTransport.Mode.MANUAL; f.tr.ignoreCancel = true;
            Artifact a = f.userFile("A", "mA", "hello");
            check(f.svc.advance(f.eval("A", "claude")) && f.svc.isBusy() && f.s.currentTransfer(a.id, "A", "claude").state == S, "an upload is running");
            f.svc.cancelInFlight();
            ArtifactTransfer t = f.s.currentTransfer(a.id, "A", "claude");
            check(t.state == F && t.error.equals("cancelled") && t.attempts == 1 && !f.svc.isBusy() && f.woke.get() == 1, "Stop resolves the transfer itself (FAILED 'cancelled', its attempt counted), frees the slot and wakes the listener once, although the transport never answered");
            check(f.tr.cancels == 1 && f.cap.cancels == 0, "only the transport that owns the running job was asked to stop");
            check(f.tr.complete(true) && f.s.currentTransfer(a.id, "A", "claude").state == F && f.woke.get() == 1 && !f.svc.isBusy(), "the late 'verified' from the cancelled upload changes nothing (it does not resurrect the transfer, wake anyone or touch the slot)");
            f.svc.cancelInFlight();
            check(f.tr.cancels == 1 && f.woke.get() == 1, "stopping again does nothing: the slot is freed exactly once");
            f.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            check(f.svc.advance(f.eval("A", "claude")) && f.s.currentTransfer(a.id, "A", "claude").state == T && f.s.currentTransfer(a.id, "A", "claude").attempts == 2, "the slot is usable again and the file can be retried and staged (second attempt)");
        });

        test("Stop is deterministic for a capture too: a late answer never brings the file back", () -> {
            Fx f = new Fx(1000);
            final ArtifactService.CaptureTransport.Callback[] held = new ArtifactService.CaptureTransport.Callback[1];
            final int[] cancels = {0};
            ArtifactService.CaptureTransport silent = new ArtifactService.CaptureTransport() {
                @Override public void capture(Artifact intent, Callback cb) { held[0] = cb; }
                @Override public void cancel() { cancels[0]++; }
            };
            AtomicInteger woke = new AtomicInteger();
            ArtifactService svc = new ArtifactService(f.s, f.storage, f.tr, silent, () -> f.clock.incrementAndGet(), () -> "z" + f.idn.incrementAndGet(), 1000);
            svc.setListener(woke::incrementAndGet);
            f.s.appendMessage("A", "rep", "PROVIDER", "claude", "a file", "mA", 30L);
            f.s.createArtifact("gen", "A", "claude", f.s.activeBindingId("A", "claude"), "g.bin", "", 31L); f.s.attachArtifact("rep", "gen", 0);
            svc.startCaptures(Arrays.asList(f.s.getArtifact("gen")));
            check(svc.isBusy() && held[0] != null, "a capture is running and the page has not answered");
            svc.cancelInFlight();
            check(cancels[0] == 1 && f.tr.cancels == 0 && f.s.getArtifact("gen").state == ArtifactState.FAILED && !svc.isBusy() && woke.get() == 1, "Stop marks the file FAILED itself, asks only the capture side to stop, frees the slot and wakes once");
            TrackingStream late = new TrackingStream("LATE BYTES".getBytes(StandardCharsets.UTF_8));
            held[0].onBytes(late, "text/plain");
            held[0].onFailed("too late");
            check(late.closed && f.s.getArtifact("gen").state == ArtifactState.FAILED && !new File(f.root, "A/gen").exists() && (!new File(f.root, ".tmp").exists() || new File(f.root, ".tmp").listFiles().length == 0) && woke.get() == 1 && !svc.isBusy(), "bytes that arrive after Stop are closed and thrown away: the file stays FAILED, nothing is stored, nobody is woken again");
            check(f.s.retryArtifact("gen") && f.s.getArtifact("gen").state == ArtifactState.PENDING_CAPTURE, "the file can still be retried later (FAILED -> PENDING_CAPTURE)");
        });

        test("Stop cannot undo a capture that already committed, and does nothing when nothing runs", () -> {
            Fx f = new Fx(1000); f.cap.defaultContent = "DONE".getBytes(StandardCharsets.UTF_8);
            f.s.appendMessage("A", "rep", "PROVIDER", "claude", "a file", "mA", 30L);
            f.s.createArtifact("gen", "A", "claude", f.s.activeBindingId("A", "claude"), "g.bin", "", 31L); f.s.attachArtifact("rep", "gen", 0);
            f.svc.startCaptures(Arrays.asList(f.s.getArtifact("gen")));
            check(f.s.getArtifact("gen").state == ArtifactState.READY && f.woke.get() == 1, "the capture finished and committed READY");
            f.svc.cancelInFlight();
            check(f.s.getArtifact("gen").state == ArtifactState.READY && f.cap.cancels == 0 && f.tr.cancels == 0 && f.woke.get() == 1 && !f.svc.isBusy(), "Stop afterwards leaves READY exactly as it is and wakes nobody");
            Fx g = new Fx(1000); g.svc.cancelInFlight();
            check(g.tr.cancels == 0 && g.cap.cancels == 0 && g.woke.get() == 0 && !g.svc.isBusy(), "Stop with nothing running does nothing");
        });

        test("Stop in the instant between taking the slot and starting the upload: the upload never starts", () -> {
            Fx f = new Fx(1000); f.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = f.userFile("A", "mA", "hello");
            final ArtifactService[] holder = new ArtifactService[1]; final boolean[] fired = {false};
            RoomStore proxy = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class}, (px, m, ar) -> {
                if (m.getName().equals("transitionTransfer") && !fired[0]) { fired[0] = true; holder[0].cancelInFlight(); }   // Stop arrives right before the first state change
                try { return m.invoke(f.s, ar); } catch (java.lang.reflect.InvocationTargetException e) { throw e.getCause(); }
            });
            AtomicInteger woke = new AtomicInteger();
            ArtifactService svc = new ArtifactService(proxy, f.storage, f.tr, f.cap, () -> f.clock.incrementAndGet(), () -> "q" + f.idn.incrementAndGet(), 1000);
            holder[0] = svc; svc.setListener(woke::incrementAndGet);
            GateDecision d = svc.evaluate("A", "claude", 0, 1000);
            check(svc.advance(d), "advance reports that it handled the transfer");
            ArtifactTransfer t = f.s.currentTransfer(a.id, "A", "claude");
            check(f.tr.calls.isEmpty() && t.state == F && t.error.equals("cancelled") && !svc.isBusy() && woke.get() == 1 && f.tr.cancels == 1, "the upload never started; the transfer is FAILED 'cancelled'; the slot was freed once: " + t + " cancels=" + f.tr.cancels);
        });

        test("restart: nothing pretends to be in progress, and work can resume", () -> {
            Fx f = new Fx(1000); f.tr.mode = MockArtifactTransport.Mode.MANUAL;
            Artifact a = f.userFile("A", "mA", "hello");
            f.svc.advance(f.eval("A", "claude"));
            f.s.createArtifact("gen", "A", "claude", f.s.activeBindingId("A", "claude"), "g.bin", "", 31L);
            check(f.s.currentTransfer(a.id, "A", "claude").state == S && f.s.getArtifact("gen").state == ArtifactState.PENDING_CAPTURE, "before the restart: a transfer is SENDING and a file waits for its bytes");
            ArtifactService fresh = new ArtifactService(f.s, f.storage, f.tr, f.cap, () -> 9999L, () -> "n", 1000);   // the app starts again: a new service, nothing is busy
            f.s.markArtifactWorkInterrupted(5000L);
            check(f.s.currentTransfer(a.id, "A", "claude").state == F && f.s.currentTransfer(a.id, "A", "claude").error.contains("interrupted") && f.s.getArtifact("gen").state == ArtifactState.FAILED, "after recovery: the transfer is FAILED (interrupted) and the unfinished capture is FAILED");
            f.tr.mode = MockArtifactTransport.Mode.SUCCEED;
            GateDecision d = fresh.evaluate("A", "claude", 0, 1000);
            check(d.kind == GateDecision.Kind.WORKING && d.startable.size() == 1 && fresh.advance(d) && f.s.currentTransfer(a.id, "A", "claude").state == T && f.s.currentTransfer(a.id, "A", "claude").attempts == 2, "the interrupted upload can be retried (its second attempt stages successfully)");
        });

        test("the capture queue: files are fetched one at a time, each end starts the next", () -> {
            Fx f = new Fx(1000); f.cap.mode = MockCaptureTransport.Mode.MANUAL; f.cap.defaultContent = "abc".getBytes(StandardCharsets.UTF_8);
            f.s.appendMessage("A", "rep", "PROVIDER", "claude", "three files", "mA", 30L);
            List<Artifact> intents = new ArrayList<>();
            for (int i = 1; i <= 3; i++) { intents.add(f.s.createArtifact("g" + i, "A", "claude", f.s.activeBindingId("A", "claude"), "g" + i + ".bin", "", 31L)); f.s.attachArtifact("rep", "g" + i, i); }
            f.svc.startCaptures(intents);
            check(f.cap.calls.equals(Arrays.asList("g1")) && f.svc.isBusy(), "only the first file is fetched; the others wait in line");
            f.svc.startCaptures(intents);
            check(f.cap.calls.size() == 1, "offering the same files again does not queue them twice");
            check(f.cap.complete(true) && f.s.getArtifact("g1").state == ArtifactState.READY && f.cap.calls.equals(Arrays.asList("g1", "g2")), "when the first ends the second starts by itself (no later turn needed)");
            check(f.cap.complete(false) && f.s.getArtifact("g2").state == ArtifactState.FAILED && f.cap.calls.equals(Arrays.asList("g1", "g2", "g3")), "a failed capture does not stop the ones behind it");
            check(f.cap.complete(true) && f.s.getArtifact("g3").state == ArtifactState.READY && !f.svc.isBusy() && f.woke.get() == 3, "all three are done, the slot is free, and the listener heard each end");
            // stale objects and files that are not waiting are never captured
            Fx g = new Fx(1000); g.cap.defaultContent = new byte[]{1};
            Artifact stale = g.s.createArtifact("s1", "A", "claude", g.s.activeBindingId("A", "claude"), "s1.bin", "", 1L);
            g.s.finalizeArtifact("s1", null, 1L, HEX, "A/s1");   // it became READY behind our back; the object we hold still says PENDING_CAPTURE
            Artifact ready = g.userFile("A", "mA", "x");
            Artifact failed = g.s.createArtifact("s2", "A", "claude", g.s.activeBindingId("A", "claude"), "s2.bin", "", 1L); g.s.failArtifact("s2");
            g.svc.startCaptures(Arrays.asList(stale, ready, g.s.getArtifact("s2")));
            check(g.cap.calls.isEmpty() && g.s.getArtifact("s1").sha256.equalsIgnoreCase(HEX), "a file that is already READY (even if our copy is old) or FAILED is not fetched again");
            // a transfer in progress holds the slot; queued captures start when it ends
            Fx h = new Fx(1000); h.tr.mode = MockArtifactTransport.Mode.MANUAL; h.cap.defaultContent = new byte[]{7};
            Artifact u = h.userFile("A", "mA", "x");
            h.svc.advance(h.eval("A", "claude"));
            h.s.appendMessage("A", "rep", "PROVIDER", "claude", "file", "mA", 30L);
            Artifact q = h.s.createArtifact("q1", "A", "claude", h.s.activeBindingId("A", "claude"), "q.bin", "", 31L); h.s.attachArtifact("rep", "q1", 0);
            h.svc.startCaptures(Arrays.asList(q));
            check(h.cap.calls.isEmpty() && h.svc.isBusy(), "while a transfer holds the slot the capture waits");
            h.tr.complete(true);
            check(h.cap.calls.equals(Arrays.asList("q1")) && h.s.getArtifact("q1").state == ArtifactState.READY && !h.svc.isBusy(), "when the transfer ends, the queued capture runs");
            // Stop: the running capture is cancelled and the ones waiting are dropped (FAILED, retryable)
            Fx k = new Fx(1000); k.cap.mode = MockCaptureTransport.Mode.MANUAL; k.cap.defaultContent = new byte[]{1};
            k.s.appendMessage("A", "rep", "PROVIDER", "claude", "files", "mA", 30L);
            List<Artifact> two = new ArrayList<>();
            for (int i = 1; i <= 3; i++) { two.add(k.s.createArtifact("c" + i, "A", "claude", k.s.activeBindingId("A", "claude"), "c" + i, "", 31L)); k.s.attachArtifact("rep", "c" + i, i); }
            k.svc.startCaptures(two);
            k.svc.cancelInFlight();
            check(k.cap.cancels == 1 && k.s.getArtifact("c1").state == ArtifactState.FAILED && k.s.getArtifact("c2").state == ArtifactState.FAILED && k.s.getArtifact("c3").state == ArtifactState.FAILED && !k.svc.isBusy() && k.cap.calls.equals(Arrays.asList("c1")),
                    "Stop cancels the running capture and drops the waiting ones: all FAILED, nothing starts afterwards");
            check(k.s.retryArtifact("c2") && k.s.getArtifact("c2").state == ArtifactState.PENDING_CAPTURE, "...and they can be retried later");
        });

        test("a crash between 'file stored' and 'marked READY' never wedges the file (the exact scenario)", () -> {
            Fx f = new Fx(1000);
            f.s.appendMessage("A", "rep", "PROVIDER", "claude", "here is a file", "mA", 30L);
            f.s.createArtifact("gen", "A", "claude", f.s.activeBindingId("A", "claude"), "report.pdf", "", 31L); f.s.attachArtifact("rep", "gen", 0); giveReplyRef(f.s, "A", "rep", "asst-gen", 29L);
            f.storage.write("A", "gen", new ByteArrayInputStream("OLD complete file from before the crash".getBytes(StandardCharsets.UTF_8)), 1000);   // the file was moved into place; the app died before the row was updated
            File target = new File(f.root, "A/gen");
            check(target.isFile() && f.s.getArtifact("gen").state == ArtifactState.PENDING_CAPTURE && f.s.getArtifact("gen").storagePath.isEmpty(), "the situation: a complete file sits at the artifact's place, the artifact never reached READY");
            f.s.markArtifactWorkInterrupted(5000L);   // restart recovery (RoomController.recoverOnStart does this)
            check(f.s.getArtifact("gen").state == ArtifactState.FAILED, "restart recovery marks it FAILED");
            check(f.svc.reconcileStorage() >= 1 && !target.exists() && f.s.getArtifact("gen").state == ArtifactState.FAILED, "storage reconciliation removes the orphan file (it is never adopted) and keeps the artifact so it can be retried");
            check(f.svc.retryCapture("gen") && f.s.getArtifact("gen").state == ArtifactState.PENDING_CAPTURE && !f.svc.retryCapture("gen") && !f.svc.retryCapture("nope"), "retry works once for a FAILED file, and refuses anything else");
            f.cap.defaultContent = "FRESH".getBytes(StandardCharsets.UTF_8); f.cap.mime = "application/pdf";
            f.svc.startCaptures(Arrays.asList(f.s.getArtifact("gen")));
            Artifact done = f.s.getArtifact("gen");
            check(done.state == ArtifactState.READY && done.size == 5 && done.mime.equals("application/pdf") && f.storage.isIntact(done) && new String(Files.readAllBytes(target.toPath()), StandardCharsets.UTF_8).equals("FRESH"), "the retried capture succeeds and reaches READY with the NEW bytes, not the orphan's");
            // the same crash, but nobody ran the startup clean-up: the capture itself clears a leftover (it is only ever done for a file that is not READY)
            f.s.appendMessage("A", "rep2", "PROVIDER", "claude", "another", "mA", 40L);
            f.s.createArtifact("gen2", "A", "claude", f.s.activeBindingId("A", "claude"), "two.bin", "", 41L); f.s.attachArtifact("rep2", "gen2", 0);
            f.storage.write("A", "gen2", new ByteArrayInputStream("leftover".getBytes(StandardCharsets.UTF_8)), 1000);
            f.cap.defaultContent = "NEW2".getBytes(StandardCharsets.UTF_8);
            f.svc.startCaptures(Arrays.asList(f.s.getArtifact("gen2")));
            check(f.s.getArtifact("gen2").state == ArtifactState.READY && new String(Files.readAllBytes(new File(f.root, "A/gen2").toPath()), StandardCharsets.UTF_8).equals("NEW2"), "even without the startup clean-up the capture replaces the leftover and succeeds");
            // retrying a FAILED file whose orphan is still in the way (nobody ran the startup clean-up): the retry itself clears it
            f.s.appendMessage("A", "rep3", "PROVIDER", "claude", "third", "mA", 50L);
            f.s.createArtifact("gen3", "A", "claude", f.s.activeBindingId("A", "claude"), "three.bin", "", 51L); f.s.attachArtifact("rep3", "gen3", 0); giveReplyRef(f.s, "A", "rep3", "asst-gen3", 49L);
            f.storage.write("A", "gen3", new ByteArrayInputStream("stuck".getBytes(StandardCharsets.UTF_8)), 1000);
            f.s.failArtifact("gen3");
            File orphan3 = new File(f.root, "A/gen3");
            check(orphan3.isFile() && f.s.getArtifact("gen3").state == ArtifactState.FAILED, "a FAILED file with its orphan still in place");
            check(f.svc.retryCapture("gen3") && !orphan3.exists() && f.s.getArtifact("gen3").state == ArtifactState.PENDING_CAPTURE, "retrying it removes the orphan at once (so the next capture can never be refused) and makes it waiting again");
        });

        test("startup clean-up never touches a finished file; it clears stale parts and a user's half-saved file", () -> {
            Fx f = new Fx(1000);
            Artifact keep = f.userFile("A", "mA", "keep me");
            check(f.svc.reconcileStorage() == 0 && f.storage.isIntact(f.s.getArtifact(keep.id)), "nothing to clean: a READY file stays exactly as it is");
            File tmpDir = new File(f.root, ".tmp"); tmpDir.mkdirs();
            Files.write(new File(tmpDir, "cap-1.part").toPath(), new byte[]{1}); Files.write(new File(tmpDir, "cap-2.part").toPath(), new byte[]{2});
            check(f.svc.reconcileStorage() == 2 && tmpDir.listFiles().length == 0 && f.storage.isIntact(f.s.getArtifact(keep.id)), "stale temporary parts are removed (so repeated crashes cannot pile up garbage)");
            // a user's file that crashed mid-save: the row never became READY and nothing can retry it (the bytes came from the user's picker)
            f.s.createArtifact("u-orph", "A", "user", null, "doc.txt", "", 50L);
            f.storage.write("A", "u-orph", new ByteArrayInputStream("complete orphan".getBytes(StandardCharsets.UTF_8)), 1000);
            // an AI's file that failed: its row stays (it can be retried), only a file at its place is removed
            f.s.createArtifact("ai-bad", "A", "claude", f.s.activeBindingId("A", "claude"), "x.bin", "", 51L);
            f.storage.write("A", "ai-bad", new ByteArrayInputStream("orphan".getBytes(StandardCharsets.UTF_8)), 1000);
            f.s.markArtifactWorkInterrupted(60L);
            int n = f.svc.reconcileStorage();
            check(n == 3 && f.s.getArtifact("u-orph") == null && !new File(f.root, "A/u-orph").exists(), "a user's half-saved file is forgotten together with its stray bytes");
            check(f.s.getArtifact("ai-bad") != null && f.s.getArtifact("ai-bad").state == ArtifactState.FAILED && !new File(f.root, "A/ai-bad").exists(), "an AI's failed file keeps its row (retryable); its stray bytes are removed");
            check(f.storage.isIntact(f.s.getArtifact(keep.id)) && f.svc.reconcileStorage() == 0, "the READY file is still intact and a second clean-up finds nothing");
            // while a job is running, temporary parts may belong to it: they are left alone
            Fx g = new Fx(1000); g.tr.mode = MockArtifactTransport.Mode.MANUAL; g.userFile("A", "mA", "x"); g.svc.advance(g.eval("A", "claude"));
            File gt = new File(g.root, ".tmp"); gt.mkdirs(); Files.write(new File(gt, "cap-9.part").toPath(), new byte[]{9});
            check(g.svc.isBusy() && g.svc.reconcileStorage() == 0 && new File(gt, "cap-9.part").exists(), "while a job runs, temporary parts are not touched");
        });

        test("a file name can never reach the storage path, and is already clean when saved", () -> {
            Fx f = new Fx(1000);
            Artifact a = f.svc.addUserFile("A", "../../x/y\u0000 name.txt", "text/plain", new ByteArrayInputStream("hello".getBytes(StandardCharsets.UTF_8)));
            check(a.displayName.equals(".._.._x_y name.txt") && f.s.getArtifact(a.id).displayName.equals(".._.._x_y name.txt") && a.storagePath.equals("A/" + a.id), "the saved name is clean and the path is only room/artifact id");
            java.util.Set<String> top = new java.util.TreeSet<>(Arrays.asList(f.root.list()));
            check(top.equals(new java.util.TreeSet<>(Arrays.asList("A", ".tmp"))) && new File(f.root, "A").list().length == 1, "nothing was written anywhere else: " + top);
        });

        System.out.println((failures == 0 ? "PASS  " : "FAIL  ") + "artifact gate and service (" + checks + " checks, " + failures + " failures)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
