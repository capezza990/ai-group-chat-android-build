import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.Artifact;
import com.aigroupchat.bridge.room.ArtifactLifecycle;
import com.aigroupchat.bridge.room.ArtifactService;
import com.aigroupchat.bridge.room.ArtifactState;
import com.aigroupchat.bridge.room.ArtifactStorage;
import com.aigroupchat.bridge.room.ArtifactTransfer;
import com.aigroupchat.bridge.room.GateDecision;
import com.aigroupchat.bridge.room.InMemoryRoomStore;
import com.aigroupchat.bridge.room.MockArtifactTransport;
import com.aigroupchat.bridge.room.MockCaptureTransport;
import com.aigroupchat.bridge.room.RoomKind;
import com.aigroupchat.bridge.room.TransferState;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

/** The ONE app-wide file service and the screens that come and go: attach, detach, replace, late callbacks, nothing hanging. */
public final class ArtifactLifecycleTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }

    static final class Fx {
        final InMemoryRoomStore s = new InMemoryRoomStore();
        final ArtifactLifecycle lc;
        final ArtifactService svc;
        final AtomicInteger clock = new AtomicInteger(1000), idn = new AtomicInteger(), woke = new AtomicInteger();
        Fx() throws Exception {
            s.createRoom("A", "A", RoomKind.LIVE, 1);
            s.upsertParticipant("A", "claude", 0);
            s.putBinding("A", new ProviderBinding("claude", "convA-cl", "l", "t", 1L));
            s.appendMessage("A", "mA", "USER", "user", "in A", null, 10L);
            s.appendMessage("A", "rep", "PROVIDER", "claude", "reply", "mA", 11L);
            lc = ArtifactLifecycle.create(s, new ArtifactStorage(Files.createTempDirectory("agc-lc-").toFile()), () -> clock.incrementAndGet(), () -> "id" + idn.incrementAndGet(), 1000);
            svc = lc.service();
            svc.setListener(woke::incrementAndGet);
        }
        Artifact userFile() throws Exception {
            Artifact a = svc.addUserFile("A", "doc.txt", "text/plain", new ByteArrayInputStream("hello".getBytes(StandardCharsets.UTF_8)));
            s.attachArtifact("mA", a.id, idn.get() % 5);
            return a;
        }
        Artifact aiFile(String id) {
            Artifact a = s.createArtifact(id, "A", "claude", s.activeBindingId("A", "claude"), id + ".bin", "", 30L);
            s.attachArtifact("rep", id, Integer.parseInt(id.substring(2)));
            return a;
        }
        boolean start() { return svc.advance(svc.evaluate("A", "claude", 0, 1000)); }
        ArtifactTransfer transfer(Artifact a) { return s.currentTransfer(a.id, "A", "claude"); }
    }

    public static void main(String[] args) throws Exception {
        // 1. nothing attached: a job fails at once; the single-flight slot never hangs
        Fx f = new Fx();
        Artifact a = f.userFile();
        check(!f.lc.isAttached() && f.start() && !f.svc.isBusy() && f.transfer(a).state == TransferState.FAILED && f.transfer(a).error.contains("not available"), "with no pages attached a transfer fails at once and the slot is free");
        Artifact g0 = f.aiFile("ai0");
        f.svc.startCaptures(Arrays.asList(g0));
        check(!f.svc.isBusy() && f.s.getArtifact("ai0").state == ArtifactState.FAILED, "with no pages attached a capture fails at once and the slot is free");

        // 2. detach resolves a RUNNING transfer, ignores late callbacks and stops listening
        f = new Fx(); a = f.userFile();
        MockArtifactTransport tr = new MockArtifactTransport(); tr.mode = MockArtifactTransport.Mode.MANUAL; tr.ignoreCancel = true;   // a page that never answers a cancel
        MockCaptureTransport cap = new MockCaptureTransport(); cap.mode = MockCaptureTransport.Mode.MANUAL;
        Object owner1 = new Object();
        f.lc.attach(owner1, tr, cap);
        check(f.lc.isAttached() && f.start() && f.svc.isBusy() && tr.isHolding(), "an attached screen's transport runs the job");
        check(f.lc.detach(owner1) && !f.lc.isAttached(), "the owner detaches");
        check(tr.cancels == 1 && cap.cancels == 0, "the running upload was cancelled ON THE LIVE PAGE (only the matching mechanism), before the pages went away");
        check(!f.svc.isBusy() && f.transfer(a).state == TransferState.FAILED && f.transfer(a).error.equals("cancelled"), "the job is resolved (FAILED, cancelled) and the single-flight slot is free");
        int wokeAfter = f.woke.get();
        check(tr.complete(true) && f.transfer(a).state == TransferState.FAILED && f.woke.get() == wokeAfter, "a late answer from the old page changes nothing and wakes nobody");
        f.svc.retryTransfer(a.id, "A", "claude");
        f.start();   // no pages are attached any more: the job fails at once
        check(f.woke.get() == wokeAfter && !f.svc.isBusy(), "after detaching nobody is listening: a job that fails at once wakes no old controller, and the slot is free");

        // 3. only the attached owner can detach
        f = new Fx(); a = f.userFile(); tr = new MockArtifactTransport(); tr.mode = MockArtifactTransport.Mode.MANUAL; cap = new MockCaptureTransport();
        owner1 = new Object(); f.lc.attach(owner1, tr, cap); f.start();
        check(!f.lc.detach(new Object()) && !f.lc.detach(null) && f.lc.isAttached() && tr.cancels == 0 && f.svc.isBusy(), "an old screen's late detach (or nobody's) changes nothing");
        boolean refused = false; try { f.lc.attach(null, tr, cap); } catch (IllegalArgumentException e) { refused = true; }
        check(refused, "attaching without an owner is refused");

        // 4. a new screen replaces the old one: the old screen's running job is resolved first
        MockArtifactTransport tr2 = new MockArtifactTransport(); tr2.mode = MockArtifactTransport.Mode.SUCCEED; MockCaptureTransport cap2 = new MockCaptureTransport();
        Object owner2 = new Object();
        f.lc.attach(owner2, tr2, cap2);
        check(tr.cancels == 1 && !f.svc.isBusy() && f.transfer(a).state == TransferState.FAILED && f.lc.isAttached(), "attaching a new owner resolves the old owner's running job");
        check(f.lc.detach(owner1) == false && f.lc.isAttached(), "the replaced owner can no longer detach the new one");
        check(f.svc.retryTransfer(a.id, "A", "claude") && f.start() && tr2.calls.size() == 1 && tr.calls.size() == 1 && f.transfer(a).state == TransferState.STAGED, "the next job goes to the NEW screen's transport, never the old one");

        // 5. detach resolves a RUNNING capture (and does not touch the upload mechanism)
        f = new Fx(); tr = new MockArtifactTransport(); cap = new MockCaptureTransport(); cap.mode = MockCaptureTransport.Mode.MANUAL; cap.defaultContent = "x".getBytes(StandardCharsets.UTF_8);
        owner1 = new Object(); f.lc.attach(owner1, tr, cap);
        Artifact g = f.aiFile("ai1");
        f.svc.startCaptures(Arrays.asList(g));
        check(f.svc.isBusy() && cap.isHolding(), "a capture is running");
        check(f.lc.detach(owner1) && cap.cancels == 1 && tr.cancels == 0 && !f.svc.isBusy() && f.s.getArtifact("ai1").state == ArtifactState.FAILED, "detach cancels the running capture on the live page and resolves it (FAILED)");

        // 6. idle detach
        f = new Fx(); tr = new MockArtifactTransport(); cap = new MockCaptureTransport(); owner1 = new Object();
        f.lc.attach(owner1, tr, cap);
        check(f.lc.detach(owner1) && tr.cancels == 0 && cap.cancels == 0 && !f.svc.isBusy(), "detaching an idle screen cancels nothing");

        // 7. the same service for the whole life of the process
        f = new Fx(); ArtifactService s0 = f.lc.service();
        for (int i = 0; i < 3; i++) { Object o = new Object(); f.lc.attach(o, new MockArtifactTransport(), new MockCaptureTransport()); f.lc.detach(o); }
        check(f.lc.service() == s0 && f.svc == s0 && f.svc.addUserFile("A", "again.txt", "text/plain", new ByteArrayInputStream(new byte[]{1})).state == ArtifactState.READY, "after any number of screens the service is the same instance and still works");

        // 8. the service's expiry listener reaches EVERY screen's transport
        f = new Fx(); a = f.userFile(); tr = new MockArtifactTransport(); tr.mode = MockArtifactTransport.Mode.SUCCEED; owner1 = new Object();
        f.lc.attach(owner1, tr, new MockCaptureTransport());
        f.start();
        String binding = f.transfer(a).bindingId;
        check(f.transfer(a).state == TransferState.STAGED, "a file is staged");
        tr.expireStaged("A", "claude", binding);
        check(f.transfer(a).state == TransferState.FAILED, "the first screen's idle expiry resets the staged row");
        f.lc.detach(owner1);
        f.svc.retryTransfer(a.id, "A", "claude");
        MockArtifactTransport trB = new MockArtifactTransport(); trB.mode = MockArtifactTransport.Mode.SUCCEED;
        Object ownerB = new Object(); f.lc.attach(ownerB, trB, new MockCaptureTransport());
        f.start();
        check(f.transfer(a).state == TransferState.STAGED, "staged again through the second screen's transport");
        trB.expireStaged("A", "claude", binding);
        check(f.transfer(a).state == TransferState.FAILED, "and the SECOND screen's idle expiry also resets it (the listener was handed on)");

        // 9. staged-row invalidation reaches only a live screen
        f = new Fx(); a = f.userFile(); tr = new MockArtifactTransport(); tr.mode = MockArtifactTransport.Mode.SUCCEED; owner1 = new Object();
        f.lc.attach(owner1, tr, new MockCaptureTransport());
        f.start();
        f.svc.failStaged("A", "claude", "stop");
        check(tr.invalidations == 1, "failing staged rows tells the live page");
        f.lc.detach(owner1);
        f.svc.retryTransfer(a.id, "A", "claude");
        f.start();   // fails at once (no pages) but must never reach the old transport
        f.svc.failStaged("A", "claude", "stop again");
        check(tr.invalidations == 1 && tr.calls.size() == 1, "after detaching, nothing reaches the old screen's transport");

        System.out.println("Artifact lifecycle: " + checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }
}
