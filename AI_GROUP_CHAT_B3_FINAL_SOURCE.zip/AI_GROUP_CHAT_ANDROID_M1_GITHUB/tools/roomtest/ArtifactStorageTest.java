import com.aigroupchat.bridge.room.Artifact;
import com.aigroupchat.bridge.room.ArtifactState;
import com.aigroupchat.bridge.room.ArtifactStorage;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Arrays;

/** The canonical file store: streaming with hash and size, size limit, never a half-written file, never an overwrite, no path tricks, integrity re-check. */
public final class ArtifactStorageTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }
    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }
    static final String SHA_HELLO = "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";
    static final String SHA_EMPTY = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

    static File root() throws IOException { return Files.createTempDirectory("agc-store-").toFile(); }
    /** A stream that answers 0 on every other read (and hands out at most 5 bytes at a time): legal for InputStream, and not the end. */
    static InputStream zeroy(byte[] data) {
        return new InputStream() {
            int pos; boolean zeroNext = true;
            @Override public int read() { throw new UnsupportedOperationException(); }
            @Override public int read(byte[] b, int off, int len) {
                if (zeroNext) { zeroNext = false; return 0; }
                zeroNext = true;
                if (pos >= data.length) return -1;
                int n = Math.min(len, Math.min(5, data.length - pos));
                System.arraycopy(data, pos, b, off, n); pos += n;
                return n;
            }
        };
    }
    static InputStream bytes(String s) { return new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8)); }
    static String read(File f) throws IOException { return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8); }
    static File[] tmpLeft(File root) { File t = new File(root, ".tmp"); File[] l = t.listFiles(); return l == null ? new File[0] : l; }
    static boolean threw(Class<? extends Throwable> k, T t) { try { t.run(); return false; } catch (Throwable e) { return k.isInstance(e); } }
    static Artifact ready(String room, String id, ArtifactStorage.Stored s) { return new Artifact(id, room, "user", id, "text/plain", s.size, s.sha256, s.relativePath, ArtifactState.READY, 1L); }

    public static void main(String[] args) {
        test("writing: size, SHA-256, a real file, no leftovers", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            ArtifactStorage.Stored s = st.write("room1", "a1", bytes("hello"), 1000);
            check(s.size == 5 && s.sha256.equals(SHA_HELLO) && s.relativePath.equals("room1/a1"), "size 5, the right SHA-256, and a path relative to the root: " + s.sha256 + " " + s.relativePath);
            check(new File(r, "room1/a1").isFile() && read(new File(r, "room1/a1")).equals("hello") && tmpLeft(r).length == 0, "the file holds the bytes and no temporary file is left");
            ArtifactStorage.Stored e = st.write("room1", "empty", bytes(""), 1000);
            check(e.size == 0 && e.sha256.equals(SHA_EMPTY) && new File(r, "room1/empty").isFile() && new File(r, "room1/empty").length() == 0, "an EMPTY file is stored (size 0, the SHA-256 of nothing)");
            byte[] big = new byte[100_000]; new java.util.Random(7).nextBytes(big);
            ArtifactStorage.Stored b = st.write("room1", "big", new ByteArrayInputStream(big), 1_000_000);
            String want; MessageDigest md = MessageDigest.getInstance("SHA-256"); StringBuilder sb = new StringBuilder(); for (byte x : md.digest(big)) sb.append(String.format("%02x", x)); want = sb.toString();
            check(b.size == 100_000 && b.sha256.equals(want) && Arrays.equals(Files.readAllBytes(new File(r, "room1/big").toPath()), big), "a file bigger than the read buffer is stored byte for byte with the right hash");
            check(st.write("room2", "a1", bytes("other room"), 1000).relativePath.equals("room2/a1") && read(new File(r, "room1/a1")).equals("hello") && read(new File(r, "room2/a1")).equals("other room"), "the same artifact id in another room is a different file");
        });

        test("size limit and failures keep nothing", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            check(st.write("room1", "exact", bytes("0123456789"), 10).size == 10, "exactly the limit is accepted");
            check(threw(ArtifactStorage.TooLargeException.class, () -> st.write("room1", "big", bytes("01234567890"), 10)), "one byte over the limit is refused");
            check(!new File(r, "room1/big").exists() && tmpLeft(r).length == 0, "...and nothing is kept (no file, no temporary file)");
            InputStream failing = new InputStream() {
                int n;
                @Override public int read() throws IOException { throw new IOException("unused"); }
                @Override public int read(byte[] b, int off, int len) throws IOException { if (n++ == 0) { Arrays.fill(b, off, off + 3, (byte) 'x'); return 3; } throw new IOException("connection lost"); }
            };
            check(threw(IOException.class, () -> st.write("room1", "broken", failing, 1000)) && !new File(r, "room1/broken").exists() && tmpLeft(r).length == 0, "a stream that breaks half-way keeps nothing: no half-written file ever has a real name");
        });

        test("a stream that returns 0 bytes between chunks is not mistaken for the end", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            byte[] data = "this is a file that arrives in small chunks".getBytes(StandardCharsets.UTF_8);
            ArtifactStorage.Stored s = st.write("room1", "a1", zeroy(data), 1000);
            check(s.size == data.length && java.util.Arrays.equals(Files.readAllBytes(new File(r, "room1/a1").toPath()), data), "all the bytes are stored, none lost at a zero read: " + s.size + " of " + data.length);
            check(s.sha256.equals(ArtifactStorage.sha256Of(new ByteArrayInputStream(data))) && ArtifactStorage.sha256Of(zeroy(data)).equals(s.sha256), "the hash covers the whole stream (also when computed through zero reads)");
            check(ArtifactStorage.sha256Of(new ByteArrayInputStream(new byte[0])).equals(SHA_EMPTY), "an empty stream still hashes to the SHA-256 of nothing");
            InputStream stuck = new InputStream() { @Override public int read() { return 0; } @Override public int read(byte[] b, int o, int l) { return 0; } };
            check(threw(IOException.class, () -> st.write("room1", "stuck", stuck, 1000)) && !new File(r, "room1/stuck").exists() && tmpLeft(r).length == 0, "a stream that never makes progress is refused (no endless loop) and nothing is kept");
            check(threw(IOException.class, () -> ArtifactStorage.sha256Of(stuck)), "the same for hashing");
        });

        test("a stored file is never overwritten", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            st.write("room1", "a1", bytes("original"), 1000);
            check(threw(IOException.class, () -> st.write("room1", "a1", bytes("replacement"), 1000)) && read(new File(r, "room1/a1")).equals("original") && tmpLeft(r).length == 0, "writing the same artifact again is refused and the original is untouched");
        });

        test("ids and paths cannot escape the storage folder", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            String[] bad = {"../x", "a/b", "", ".", "..", ".hidden", "a b", "x\\y", "a\0b", null, "é"};
            boolean all = true;
            for (String id : bad) { final String f = id; if (!threw(IllegalArgumentException.class, () -> st.write("room1", f, bytes("x"), 10))) all = false; if (!threw(IllegalArgumentException.class, () -> st.write(f, "a1", bytes("x"), 10))) all = false; }
            check(all, "an unsafe artifact id or room id is refused");
            check(!new File(r.getParentFile(), "x").exists() && r.list().length <= 1, "nothing was created outside the root (or inside it) by those attempts");
            st.write("room1", "ok-1_a.b", bytes("fine"), 10);
            check(st.fileOf("room1/ok-1_a.b") != null && st.fileOf("room1/missing") == null, "a normal path resolves to its file; a missing one to null");
            for (String p : new String[]{"../../etc/passwd", "a/b/c", "/abs/path", "room1/../room1/ok-1_a.b", "", null, "room1", "room1/", "/room1/ok-1_a.b", "room1//ok-1_a.b"}) check(st.fileOf(p) == null, "a recorded path that is not exactly <room>/<file> resolves to nothing: " + p);
        });

        test("integrity is re-checked: size AND hash", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            ArtifactStorage.Stored s = st.write("room1", "a1", bytes("hello"), 1000);
            Artifact a = ready("room1", "a1", s);
            check(st.isIntact(a), "an untouched READY artifact is intact");
            check(st.isIntact(new Artifact("a1", "room1", "user", "n", "", s.size, s.sha256.toUpperCase(), s.relativePath, ArtifactState.READY, 1L)), "an upper-case recorded hash still matches");
            check(!st.isIntact(null) && !st.isIntact(new Artifact("a1", "room1", "user", "n", "", s.size, s.sha256, s.relativePath, ArtifactState.PENDING_CAPTURE, 1L)) && !st.isIntact(new Artifact("a1", "room1", "user", "n", "", s.size, s.sha256, s.relativePath, ArtifactState.FAILED, 1L)), "null and not-READY artifacts are never intact");
            check(!st.isIntact(new Artifact("a1", "room1", "user", "n", "", 6, s.sha256, s.relativePath, ArtifactState.READY, 1L)), "a recorded size that does not match is not intact");
            check(!st.isIntact(new Artifact("a1", "room1", "user", "n", "", s.size, "0".repeat(64), s.relativePath, ArtifactState.READY, 1L)), "a recorded hash that does not match is not intact");
            check(!st.isIntact(new Artifact("a1", "room1", "user", "n", "", s.size, s.sha256, "room1/other", ArtifactState.READY, 1L)) && !st.isIntact(new Artifact("a1", "room1", "user", "n", "", s.size, s.sha256, "../a1", ArtifactState.READY, 1L)), "a missing file or an unsafe path is not intact");
            File f = new File(r, "room1/a1");
            try (RandomAccessFile raf = new RandomAccessFile(f, "rw")) { raf.seek(0); raf.write('j'); }
            check(!st.isIntact(a), "one changed byte (same size) is caught by the hash");
            Files.write(f.toPath(), "hello world".getBytes(StandardCharsets.UTF_8));
            check(!st.isIntact(a), "a longer file is caught");
            Files.write(f.toPath(), "hel".getBytes(StandardCharsets.UTF_8));
            check(!st.isIntact(a), "a shorter file is caught");
            f.delete();
            check(!st.isIntact(a), "a deleted file is caught");
        });

        test("clean-up of what a crash leaves behind", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            st.write("room1", "a1", bytes("complete but never marked READY"), 1000);
            check(st.deleteOrphan("room1", "a1") && !new File(r, "room1/a1").exists() && !st.deleteOrphan("room1", "a1"), "an orphan at its deterministic place is removed (once)");
            File outside = new File(r, "x"); Files.write(outside.toPath(), "keep".getBytes(StandardCharsets.UTF_8));
            check(!st.deleteOrphan("room1", "../x") && !st.deleteOrphan("../room1", "a1") && !st.deleteOrphan(null, "a1") && !st.deleteOrphan("room1", "") && outside.exists(), "unsafe ids never delete anything (not even a file outside the room folder)");
            File dir = new File(r, "room1/adir"); dir.mkdirs();
            check(!st.deleteOrphan("room1", "adir") && dir.isDirectory(), "a folder is never removed");
            check(st.cleanTemp() == 0, "no temporary folder: nothing to clean");
            File tmp = new File(r, ".tmp"); tmp.mkdirs();
            Files.write(new File(tmp, "cap-1.part").toPath(), "half".getBytes(StandardCharsets.UTF_8)); Files.write(new File(tmp, "cap-2.part").toPath(), "half".getBytes(StandardCharsets.UTF_8));
            check(st.cleanTemp() == 2 && tmpLeft(r).length == 0 && st.cleanTemp() == 0, "stale temporary parts of unfinished writes are removed");
            ArtifactStorage.Stored keep = st.write("room1", "keep", bytes("fine"), 100);
            st.cleanTemp(); st.deleteOrphan("room1", "other");
            check(st.isIntact(ready("room1", "keep", keep)), "a finished file is not touched by either");
        });

        test("cleanup", () -> {
            File r = root(); ArtifactStorage st = new ArtifactStorage(r);
            ArtifactStorage.Stored s = st.write("room1", "a1", bytes("x"), 10);
            check(st.delete(s.relativePath) && !new File(r, "room1/a1").exists() && st.delete(s.relativePath), "the stored file is removed; removing it again is fine");
            check(st.delete("../../etc/passwd") && st.delete(null) && st.delete(""), "an unsafe or empty path is never deleted (and nothing breaks)");
            File outside = new File(r.getParentFile(), "agc-outside.txt"); Files.write(outside.toPath(), "keep".getBytes(StandardCharsets.UTF_8));
            st.delete("../" + outside.getName());
            check(outside.exists(), "a file outside the storage folder survives a delete attempt with a crafted path");
            outside.delete();
        });

        System.out.println((failures == 0 ? "PASS  " : "FAIL  ") + "artifact storage (" + checks + " checks, " + failures + " failures)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
