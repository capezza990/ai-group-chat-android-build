import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** The artifact store and transfer rules, on the in-memory twin of the SQLite store. Usage: ArtifactStoreTest [rules-dump-file]. */
public final class ArtifactStoreTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }
    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }
    static final String HEX = "ab".repeat(32), HEX2 = "cd".repeat(32);
    static boolean throwsAny(Runnable r) { try { r.run(); return false; } catch (RuntimeException e) { return true; } }

    /** Two live rooms; A has ChatGPT+Claude (both with a conversation), B has ChatGPT (with a conversation). One message in each. */
    static InMemoryRoomStore store() {
        InMemoryRoomStore s = new InMemoryRoomStore();
        s.createRoom("A", "A", RoomKind.LIVE, 1); s.createRoom("B", "B", RoomKind.LIVE, 2);
        s.upsertParticipant("A", "chatgpt", 0); s.upsertParticipant("A", "claude", 1); s.upsertParticipant("B", "chatgpt", 0);
        s.putBinding("A", new ProviderBinding("chatgpt", "convA-gpt", "l", "t", 1L));
        s.putBinding("A", new ProviderBinding("claude", "convA-cl", "l", "t", 1L));
        s.putBinding("B", new ProviderBinding("chatgpt", "convB-gpt", "l", "t", 1L));
        s.appendMessage("A", "mA", "USER", "user", "in A", null, 10L);
        s.appendMessage("B", "mB", "USER", "user", "in B", null, 11L);
        return s;
    }
    static Artifact ready(InMemoryRoomStore s, String id, String room) {
        s.createArtifact(id, room, "user", id + ".txt", "text/plain", 20L);
        check(s.finalizeArtifact(id, null, 3L, HEX, room + "/" + id), "finalize " + id);
        return s.getArtifact(id);
    }
    static final TransferState P = TransferState.PENDING, S = TransferState.SENDING, T = TransferState.STAGED, V = TransferState.VERIFIED, F = TransferState.FAILED;
    static TransferState[] st(TransferState... a) { return a; }

    public static void main(String[] args) throws Exception {
        test("the two state machines (same moves as the database)", () -> {
            StringBuilder dump = new StringBuilder();
            for (ArtifactState a : ArtifactState.values()) for (ArtifactState b : ArtifactState.values()) if (a.canMoveTo(b)) dump.append("ARTIFACT ").append(a).append(' ').append(b).append('\n');
            for (TransferState a : TransferState.values()) for (TransferState b : TransferState.values()) if (a.canMoveTo(b)) dump.append("TRANSFER ").append(a).append(' ').append(b).append('\n');
            check(dump.toString().lines().filter(l -> l.startsWith("ARTIFACT")).count() == 6 && dump.toString().lines().filter(l -> l.startsWith("TRANSFER")).count() == 12, "6 artifact moves and 12 transfer moves are allowed");
            check(ArtifactState.READY.canMoveTo(ArtifactState.READY) && !ArtifactState.READY.canMoveTo(ArtifactState.FAILED) && !ArtifactState.READY.canMoveTo(ArtifactState.PENDING_CAPTURE) && !ArtifactState.FAILED.canMoveTo(ArtifactState.READY), "READY never leaves; FAILED can only retry (never jump to READY)");
            check(!V.canMoveTo(V) && !V.canMoveTo(P) && !V.canMoveTo(S) && !V.canMoveTo(T) && !V.canMoveTo(F) && !P.canMoveTo(V) && P.canMoveTo(S) && !S.canMoveTo(V) && S.canMoveTo(T) && T.canMoveTo(V) && T.canMoveTo(F) && F.canMoveTo(P) && F.canMoveTo(S) && !F.canMoveTo(V), "VERIFIED is final; a transfer is only VERIFIED after STAGED");
            if (args.length > 0) Files.write(Paths.get(args[0]), dump.toString().getBytes("UTF-8"));
        });

        test("the exact reply an AI file came from is resolved through the existing delivery (nothing duplicated), and fails closed", () -> {
            InMemoryRoomStore s = store();
            // delivery d1: claude answered trigger mA with canonical reply r1, the page's reply id was "asst-1"
            s.appendMessage("A", "r1", "PROVIDER", "claude", "here", "mA", 40L);
            s.createDelivery("d1", "A", "mA", "claude", 10L, 41L);
            s.recordProviderIds("d1", "u-1", "asst-1");
            s.setDeliveryReply("d1", "r1");
            Artifact f = s.createArtifact("f1", "A", "claude", s.activeBindingId("A", "claude"), "report.pdf", "", 42L);
            s.attachArtifact("r1", "f1", 0);
            check("asst-1".equals(s.sourceReplyRef("f1")), "the artifact's reply id is the delivery's provider reply id");
            check(s.sourceReplyRef("nope").isEmpty() && s.sourceReplyRef(null).isEmpty(), "an unknown artifact has no reply identity");
            Artifact u = ready(s, "u1", "A");
            s.attachArtifact("mA", "u1", 0);
            check(s.sourceReplyRef("u1").isEmpty(), "a user file never has one");
            // a second reply from the same AI with a file of the same name resolves to ITS OWN id
            s.appendMessage("A", "mA2", "USER", "user", "again", null, 50L);
            s.appendMessage("A", "r2", "PROVIDER", "claude", "new version", "mA2", 51L);
            s.createDelivery("d2", "A", "mA2", "claude", 12L, 52L);
            s.recordProviderIds("d2", "u-2", "asst-2");
            s.setDeliveryReply("d2", "r2");
            s.createArtifact("f2", "A", "claude", s.activeBindingId("A", "claude"), "report.pdf", "", 53L);
            s.attachArtifact("r2", "f2", 0);
            check("asst-1".equals(s.sourceReplyRef("f1")) && "asst-2".equals(s.sourceReplyRef("f2")), "two files with the same name resolve to their own, different replies");
            // no id from the page: nothing to prove with
            s.appendMessage("A", "mA3", "USER", "user", "third", null, 60L);
            s.appendMessage("A", "r3", "PROVIDER", "claude", "no ids", "mA3", 61L);
            s.createDelivery("d3", "A", "mA3", "claude", 14L, 62L);
            s.setDeliveryReply("d3", "r3");
            s.createArtifact("f3", "A", "claude", s.activeBindingId("A", "claude"), "x.txt", "", 63L);
            s.attachArtifact("r3", "f3", 0);
            check(s.sourceReplyRef("f3").isEmpty(), "a reply the page gave no id for has no identity (a retry must be refused, never guessed)");
            // no delivery owns the message
            s.appendMessage("A", "r4", "PROVIDER", "claude", "orphan reply", null, 70L);
            s.createArtifact("f4", "A", "claude", s.activeBindingId("A", "claude"), "y.txt", "", 71L);
            s.attachArtifact("r4", "f4", 0);
            check(s.sourceReplyRef("f4").isEmpty(), "a message that no delivery produced gives no identity");
            // not attached to any message
            s.createArtifact("f5", "A", "claude", s.activeBindingId("A", "claude"), "z.txt", "", 72L);
            check(s.sourceReplyRef("f5").isEmpty(), "a file that is not attached to a message has no identity");
            // attached to two messages: ambiguous
            s.attachArtifact("r1", "f2", 1);
            check(s.sourceReplyRef("f2").isEmpty(), "a file attached to two messages is ambiguous, so it has no identity");
            // another AI's delivery for the same reply message: mismatching provider
            s.appendMessage("A", "mA5", "USER", "user", "fifth", null, 80L);
            s.appendMessage("A", "r5", "PROVIDER", "chatgpt", "gpt reply", "mA5", 81L);
            s.createDelivery("d5", "A", "mA5", "chatgpt", 16L, 82L);
            s.recordProviderIds("d5", "u-5", "asst-5");
            s.setDeliveryReply("d5", "r5");
            s.createArtifact("f6", "A", "claude", s.activeBindingId("A", "claude"), "w.txt", "", 83L);
            s.attachArtifact("r5", "f6", 0);
            check(s.sourceReplyRef("f6").isEmpty(), "a claude file attached to chatgpt's reply is not provable");
            check("asst-1".equals(s.sourceReplyRef("f1")), "and the earlier answers did not change");
        });

        test("an artifact: intent first, bytes second, final once READY", () -> {
            InMemoryRoomStore s = store();
            Artifact a = s.createArtifact("f1", "A", "claude", s.activeBindingId("A", "claude"), "out.zip", "application/zip", 30L);
            check(a.state == ArtifactState.PENDING_CAPTURE && a.size == -1L && a.sha256.isEmpty() && a.storagePath.isEmpty() && a.mime.equals("application/zip") && !a.fromUser(), "created as PENDING_CAPTURE: the intent is saved, there are no bytes");
            check(throwsAny(() -> s.createArtifact("f1", "A", "user", "dup", "", 31L)), "a duplicate id is refused");
            check(throwsAny(() -> s.createArtifact("f2", "nowhere", "user", "x", "", 31L)) && s.getArtifact("f2") == null, "an unknown room is refused");
            check(throwsAny(() -> s.createArtifact("f3", "A", "", "x", "", 31L)) && throwsAny(() -> s.createArtifact("f3", "A", null, "x", "", 31L)), "an artifact must say where it came from");
            check(throwsAny(() -> s.finalizeArtifact("f1", null, -1L, HEX, "p")) && throwsAny(() -> s.finalizeArtifact("f1", null, 1L, "abc", "p")) && throwsAny(() -> s.finalizeArtifact("f1", null, 1L, "g".repeat(64), "p")) && throwsAny(() -> s.finalizeArtifact("f1", null, 1L, HEX, "")),
                    "a bad size, a bad hash (short or not hex) or an empty path is refused");
            check(s.getArtifact("f1").state == ArtifactState.PENDING_CAPTURE, "...and the artifact is untouched by those refusals");
            check(s.finalizeArtifact("f1", "application/x-zip", 0L, HEX.toUpperCase(), "A/f1") && s.getArtifact("f1").state == ArtifactState.READY && s.getArtifact("f1").size == 0L && s.getArtifact("f1").mime.equals("application/x-zip"), "finalize: READY with its size (an empty file is fine), upper-case hex accepted, and the type set when the bytes arrived");
            check(s.finalizeArtifact("f1", null, 0L, HEX, "A/f1") && s.finalizeArtifact("f1", "application/x-zip", 0L, HEX, "A/f1"), "repeating the same capture is a harmless success (idempotent)");
            check(!s.finalizeArtifact("f1", null, 0L, HEX2, "A/f1") && !s.finalizeArtifact("f1", null, 9L, HEX, "A/f1") && !s.finalizeArtifact("f1", null, 0L, HEX, "A/other") && !s.finalizeArtifact("f1", "text/plain", 0L, HEX, "A/f1"), "a READY artifact cannot be re-finalized with a different hash, size, path or type");
            check(s.getArtifact("f1").sha256.equalsIgnoreCase(HEX) && s.getArtifact("f1").storagePath.equals("A/f1"), "...and it still holds the original data");
            check(!s.failArtifact("f1") && !s.retryArtifact("f1") && s.getArtifact("f1").state == ArtifactState.READY, "READY can be neither failed nor retried");
            check(!s.finalizeArtifact("nope", null, 1L, HEX, "p") && !s.failArtifact("nope") && !s.retryArtifact("nope") && s.getArtifact("nope") == null, "unknown artifacts: false / null");
            s.createArtifact("f4", "A", "claude", s.activeBindingId("A", "claude"), "x", "", 40L);
            check(s.failArtifact("f4") && s.getArtifact("f4").state == ArtifactState.FAILED && !s.failArtifact("f4"), "a PENDING_CAPTURE artifact can fail (once)");
            check(!s.finalizeArtifact("f4", null, 1L, HEX, "p") && s.getArtifact("f4").state == ArtifactState.FAILED, "a FAILED artifact cannot jump to READY");
            check(s.retryArtifact("f4") && s.getArtifact("f4").state == ArtifactState.PENDING_CAPTURE && !s.retryArtifact("f4"), "...it must be retried first (back to PENDING_CAPTURE)");
            check(s.finalizeArtifact("f4", null, 2L, HEX2, "A/f4") && s.getArtifact("f4").state == ArtifactState.READY, "and then it can become READY");
        });

        test("the conversation a file was produced in: recorded, checked, and never lost", () -> {
            InMemoryRoomStore s = store();
            check(s.activeBindingId("A", "chatgpt") != null && s.activeBindingId("A", "claude") != null && !s.activeBindingId("A", "chatgpt").equals(s.activeBindingId("A", "claude")) && !s.activeBindingId("A", "chatgpt").equals(s.activeBindingId("B", "chatgpt")), "each AI has its own active conversation per room");
            check(s.activeBindingId("A", "nobody") == null && s.activeBindingId("nowhere", "chatgpt") == null, "none for an unknown AI or room");
            String claudeConv = s.activeBindingId("A", "claude");
            Artifact a = s.createArtifact("p1", "A", "claude", claudeConv, "made.zip", "", 30L);
            check(a.sourceBindingId.equals(claudeConv) && s.getArtifact("p1").sourceBindingId.equals(claudeConv), "an AI's file records the conversation it was made in");
            check(s.createArtifact("p2", "A", "user", null, "mine.txt", "", 31L).sourceBindingId == null, "a user file has no source conversation (null)");
            check(throwsAny(() -> s.createArtifact("p3", "A", "claude", null, "x.bin", "", 32L)) && throwsAny(() -> s.createArtifact("p3", "A", "chatgpt", "x.bin", "", 32L)) && s.getArtifact("p3") == null, "an AI file WITHOUT a source conversation is refused (its provenance is never unknown), including through the short form");
            check(throwsAny(() -> s.createArtifact("p4", "B", "claude", claudeConv, "x", "", 33L)) && throwsAny(() -> s.createArtifact("p5", "A", "chatgpt", claudeConv, "x", "", 33L)) && throwsAny(() -> s.createArtifact("p6", "A", "user", claudeConv, "x", "", 33L)) && throwsAny(() -> s.createArtifact("p7", "A", "claude", "no-such-binding", "x", "", 33L)), "another room's conversation, another AI's, a user file with a source, or an unknown one are all refused");
            check(s.getArtifact("p4") == null && s.getArtifact("p5") == null && s.getArtifact("p6") == null && s.getArtifact("p7") == null, "...and nothing was created");
            s.finalizeArtifact("p1", null, 3L, HEX, "A/p1");
            check(s.getArtifact("p1").sourceBindingId.equals(claudeConv), "becoming READY keeps it");
            s.createArtifact("p8", "A", "claude", claudeConv, "later.zip", "", 34L);
            s.failArtifact("p8");
            check(s.getArtifact("p8").sourceBindingId.equals(claudeConv), "failing keeps it");
            s.retryArtifact("p8");
            check(s.getArtifact("p8").sourceBindingId.equals(claudeConv), "retrying keeps it");
            s.putBinding("A", new ProviderBinding("claude", "convA-cl-2", "l", "t", 40L));
            check(!s.activeBindingId("A", "claude").equals(claudeConv) && s.getArtifact("p1").sourceBindingId.equals(claudeConv), "after a rebind the AI's active conversation changes, the file still names the old one");
            check(s.createArtifact("p9", "A", "claude", claudeConv, "late.zip", "", 41L).sourceBindingId.equals(claudeConv), "an AI file may still name a RETIRED conversation (the AI was rebound while its request was being answered)");
            s.clearBinding("A", "claude", 50L);
            check(s.activeBindingId("A", "claude") == null, "a cleared conversation is no longer active");
        });

        test("file names are made safe once, when the artifact is created (both for the user's files and an AI's)", () -> {
            check(ArtifactNames.clean("my report 2024.pdf").equals("my report 2024.pdf"), "spaces are kept");
            check(ArtifactNames.clean("r\u00e9sum\u00e9 \u4e2d\u6587 \ud83d\ude00.docx").equals("r\u00e9sum\u00e9 \u4e2d\u6587 \ud83d\ude00.docx"), "accents, Chinese and emoji are kept");
            check(ArtifactNames.clean("a/b\\c.txt").equals("a_b_c.txt") && ArtifactNames.clean("../etc/passwd").equals(".._etc_passwd") && ArtifactNames.clean("C:\\dir\\x.txt").equals("C:_dir_x.txt"), "slashes and backslashes become underscores, so no name can look like a path");
            check(ArtifactNames.clean("bad\u0000na\nme\t.txt").equals("badname.txt") && ArtifactNames.clean("x\u007f\u0085y").equals("xy"), "control characters are removed");
            check(ArtifactNames.clean("\u202egnp.exe").equals("gnp.exe") && ArtifactNames.clean("a\u200bb\ufeff.txt").equals("ab.txt"), "invisible direction marks and zero-width characters are removed");
            check(ArtifactNames.clean("  spaced.txt \u2003").equals("spaced.txt"), "surrounding white space is trimmed");
            check(ArtifactNames.clean("").equals("file") && ArtifactNames.clean(null).equals("file") && ArtifactNames.clean("   ").equals("file") && ArtifactNames.clean(".").equals("file") && ArtifactNames.clean("..").equals("file"), "an empty name, '.' and '..' become 'file'");
            check(ArtifactNames.clean("\u0000\u0007\u202e").equals("file") && ArtifactNames.clean("\n\t \u2003").equals("file"), "a name with nothing valid in it becomes 'file'");
            check(ArtifactNames.clean("...").equals("...") && ArtifactNames.clean(".hidden").equals(".hidden"), "ordinary dotted names are left alone");
            String longName = "a".repeat(200) + ".pdf", cut = ArtifactNames.clean(longName);
            check(cut.codePointCount(0, cut.length()) == ArtifactNames.MAX_LENGTH && cut.endsWith(".pdf") && cut.startsWith("aaaa"), "a long name is shortened to the cap but keeps its extension");
            String noExt = ArtifactNames.clean("b".repeat(200)), longExt = ArtifactNames.clean("c" + ".x".repeat(5) + "." + "e".repeat(40));
            check(noExt.length() == ArtifactNames.MAX_LENGTH && longExt.length() <= ArtifactNames.MAX_LENGTH, "no extension, or an absurdly long one: still capped");
            String emoji = ArtifactNames.clean("\ud83d\ude00".repeat(130)), emojiOk = emoji;
            check(emoji.codePointCount(0, emoji.length()) == ArtifactNames.MAX_LENGTH && !Character.isLowSurrogate(emoji.charAt(0)) && emoji.equals(new String(emoji.getBytes(java.nio.charset.StandardCharsets.UTF_8), java.nio.charset.StandardCharsets.UTF_8)), "shortening never splits an emoji in half");
            String[] samples = {"a b.txt", "x/y", "\u0000", "..", "d".repeat(300) + ".txt", "\u202eevil.exe", "  pad  "};
            boolean idem = true; for (String x : samples) if (!ArtifactNames.clean(ArtifactNames.clean(x)).equals(ArtifactNames.clean(x))) idem = false;
            check(idem, "cleaning twice changes nothing");
            InMemoryRoomStore s = store();
            Artifact u = s.createArtifact("n1", "A", "user", null, "../../evil\\name\u0000.txt", "", 1L);
            Artifact ai = s.createArtifact("n2", "A", "claude", s.activeBindingId("A", "claude"), "x/y z.zip", "", 2L);
            check(u.displayName.equals(".._.._evil_name.txt") && s.getArtifact("n1").displayName.equals(".._.._evil_name.txt") && ai.displayName.equals("x_y z.zip") && s.getArtifact("n2").displayName.equals("x_y z.zip"), "the SAVED name is already clean (not only what an AI is shown)");
            s.finalizeArtifact("n1", null, 1L, HEX, "A/n1");
            check(s.getArtifact("n1").displayName.equals(".._.._evil_name.txt") && s.getArtifact("n1").storagePath.equals("A/n1"), "the storage path never comes from the name");
        });

        test("artifactsNotReady: what a startup clean-up has to look at", () -> {
            InMemoryRoomStore s = store();
            ready(s, "ok", "A");
            s.createArtifact("wait", "A", "claude", s.activeBindingId("A", "claude"), "w.bin", "", 1L);
            s.createArtifact("bad", "A", "user", null, "b.bin", "", 2L); s.failArtifact("bad");
            List<Artifact> l = s.artifactsNotReady();
            check(l.size() == 2 && l.get(0).id.equals("wait") && l.get(1).id.equals("bad"), "waiting and FAILED files, oldest first; READY ones are not listed");
            s.finalizeArtifact("wait", null, 1L, HEX, "A/wait");
            check(s.artifactsNotReady().size() == 1 && s.artifactsNotReady().get(0).id.equals("bad") && store().artifactsNotReady().isEmpty(), "a file leaves the list when it becomes READY");
        });

        test("attachments belong to messages of the SAME room and are history", () -> {
            InMemoryRoomStore s = store();
            ready(s, "a1", "A"); ready(s, "a2", "A"); ready(s, "b1", "B");
            s.attachArtifact("mA", "a2", 1); s.attachArtifact("mA", "a1", 0);
            check(s.artifactsOfMessage("mA").size() == 2 && s.artifactsOfMessage("mA").get(0).id.equals("a1") && s.artifactsOfMessage("mA").get(1).id.equals("a2"), "attachments come back in their position order");
            check(s.artifactsOfMessage("mB").isEmpty() && s.artifactsOfMessage("nope").isEmpty(), "a message without attachments has none");
            check(throwsAny(() -> s.attachArtifact("mA", "b1", 0)) && throwsAny(() -> s.attachArtifact("mB", "a1", 0)), "a room-B file cannot be attached to a room-A message, nor the other way round");
            check(throwsAny(() -> s.attachArtifact("nope", "a1", 0)) && throwsAny(() -> s.attachArtifact("mA", "nope", 0)), "unknown message or artifact is refused");
            check(throwsAny(() -> s.attachArtifact("mA", "a1", 5)) && s.artifactsOfMessage("mA").size() == 2, "attaching the same file to the same message twice is refused");
            // a PENDING_CAPTURE intent can already be attached (two-phase: the reply and its file intent are saved together, the bytes come later)
            s.createArtifact("p1", "A", "claude", s.activeBindingId("A", "claude"), "later.bin", "", 50L); s.attachArtifact("mA", "p1", 2);
            check(s.artifactsOfMessage("mA").get(2).state == ArtifactState.PENDING_CAPTURE, "a file whose bytes are not stored yet can be attached (the intent is saved first)");
        });

        test("attachmentsBetween: only the right room and the right range", () -> {
            InMemoryRoomStore s = store();
            RoomMessage m2 = s.appendMessage("A", "mA2", "PROVIDER", "claude", "reply", "mA", 12L);
            RoomMessage m3 = s.appendMessage("A", "mA3", "USER", "user", "later", null, 13L);
            ready(s, "a1", "A"); ready(s, "a2", "A"); ready(s, "a3", "A"); ready(s, "b1", "B");
            s.attachArtifact("mA", "a1", 0); s.attachArtifact("mA2", "a3", 1); s.attachArtifact("mA2", "a2", 0); s.attachArtifact("mB", "b1", 0);
            long seqA = s.getMessage("mA").seq;
            List<AttachedArtifact> all = s.attachmentsBetween("A", 0, 1000);
            check(all.size() == 3 && all.get(0).artifact.id.equals("a1") && all.get(1).artifact.id.equals("a2") && all.get(2).artifact.id.equals("a3"), "oldest message first, then position: " + all.size());
            check(all.get(1).authorType.equals("PROVIDER") && all.get(1).authorId.equals("claude") && all.get(1).messageId.equals("mA2") && all.get(1).messageSeq == m2.seq, "each attachment says which message and author it belongs to");
            check(s.attachmentsBetween("A", seqA, 1000).size() == 2 && s.attachmentsBetween("A", 0, seqA).size() == 1 && s.attachmentsBetween("A", seqA, m2.seq).size() == 2 && s.attachmentsBetween("A", m2.seq, m3.seq).isEmpty(), "the range is (after, upto]: the lower end is excluded, the upper end included");
            check(s.attachmentsBetween("B", 0, 1000).size() == 1 && s.attachmentsBetween("B", 0, 1000).get(0).artifact.id.equals("b1") && s.attachmentsBetween("nowhere", 0, 1000).isEmpty(), "other rooms never leak in");
            InMemoryRoomStore plain = store();
            check(plain.attachmentsBetween("A", 0, 1000).isEmpty(), "a plain-text conversation has no attachments at all");
        });

        test("deleting an abandoned artifact", () -> {
            InMemoryRoomStore s = store();
            ready(s, "loose", "A"); ready(s, "attached", "A"); ready(s, "sent", "A");
            s.attachArtifact("mA", "attached", 0);
            s.ensureTransfer("sent", "A", "chatgpt", 60L);
            check(!s.deleteUnreferencedArtifact("attached") && !s.deleteUnreferencedArtifact("sent") && !s.deleteUnreferencedArtifact("nope"), "an artifact that a message or a transfer refers to (or an unknown one) is not deleted");
            check(s.deleteUnreferencedArtifact("loose") && s.getArtifact("loose") == null && !s.deleteUnreferencedArtifact("loose"), "an unreferenced artifact is deleted, once");
            s.createArtifact("half", "A", "user", "half.bin", "", 61L);
            check(s.deleteUnreferencedArtifact("half"), "a not-yet-READY artifact can be cleaned up too");
        });

        test("transfers: one per artifact and conversation, only for READY files, tied to the ACTIVE conversation", () -> {
            InMemoryRoomStore s = store();
            ready(s, "a1", "A"); s.createArtifact("pc", "A", "user", "pc", "", 1L); s.createArtifact("fl", "A", "user", "fl", "", 1L); s.failArtifact("fl");
            check(throwsAny(() -> s.ensureTransfer("pc", "A", "chatgpt", 1L)) && throwsAny(() -> s.ensureTransfer("fl", "A", "chatgpt", 1L)), "no transfer for a file that is not READY yet");
            check(throwsAny(() -> s.ensureTransfer("nope", "A", "chatgpt", 1L)) && throwsAny(() -> s.ensureTransfer("a1", "B", "chatgpt", 1L)), "no transfer for an unknown file, or one that belongs to another room");
            check(s.ensureTransfer("a1", "A", "chatgpt", 70L) != null && s.ensureTransfer("a1", "A", "chatgpt", 71L).updatedAt == 70L && s.transfersInState(P).size() == 1, "one PENDING transfer; asking again returns the same one (no duplicate)");
            ArtifactTransfer t = s.currentTransfer("a1", "A", "chatgpt");
            check(t.state == P && t.attempts == 0 && t.error.isEmpty() && t.providerId.equals("chatgpt") && t.roomId.equals("A"), "it starts PENDING with no attempts");
            check(s.currentTransfer("a1", "A", "claude") == null && s.ensureTransfer("a1", "A", "claude", 72L) != null && s.transfersInState(P).size() == 2, "each AI has its own transfer for the same file");
            s.upsertParticipant("B", "claude", 1);
            check(s.ensureTransfer("a1", "A", "ghost", 73L) == null, "an AI with no conversation in the room gets no transfer (null)");
            // rebind: the old transfer stays as history, the new conversation needs its own
            String oldBinding = t.bindingId;
            s.putBinding("A", new ProviderBinding("chatgpt", "convA-gpt-2", "l", "t", 80L));
            check(s.currentTransfer("a1", "A", "chatgpt") == null, "after the AI moves to a NEW conversation the file is not in it: there is no current transfer");
            ArtifactTransfer t2 = s.ensureTransfer("a1", "A", "chatgpt", 81L);
            check(t2 != null && !t2.bindingId.equals(oldBinding) && t2.state == P && s.transfersInState(P).size() == 3, "a fresh PENDING transfer is made for the new conversation; the old row is kept as history");
            s.clearBinding("A", "claude", 90L);
            check(s.currentTransfer("a1", "A", "claude") == null && s.ensureTransfer("a1", "A", "claude", 91L) == null, "when a conversation is cleared the AI has no current transfer and none can be made");
        });

        test("transfer moves, attempts and VERIFIED being final", () -> {
            InMemoryRoomStore s = store();
            ready(s, "a1", "A");
            ArtifactTransfer t = s.ensureTransfer("a1", "A", "chatgpt", 1L); String b = t.bindingId;
            check(!s.transitionTransfer("a1", b, st(P), V, null, 2L) && s.currentTransfer("a1", "A", "chatgpt").state == P, "PENDING cannot jump to VERIFIED (it was never sent)");
            check(!s.transitionTransfer("a1", b, st(S), S, null, 2L), "the move only happens from the states the caller names (compare-and-set)");
            check(s.transitionTransfer("a1", b, st(P, F), S, null, 3L) && s.currentTransfer("a1", "A", "chatgpt").state == S && s.currentTransfer("a1", "A", "chatgpt").attempts == 1, "PENDING -> SENDING counts one attempt");
            check(s.transitionTransfer("a1", b, st(S), S, "still sending", 4L) && s.currentTransfer("a1", "A", "chatgpt").attempts == 1 && s.currentTransfer("a1", "A", "chatgpt").error.equals("still sending"), "staying in SENDING does not count another attempt");
            check(s.transitionTransfer("a1", b, st(S), F, "page not ready", 5L) && s.currentTransfer("a1", "A", "chatgpt").error.equals("page not ready"), "SENDING -> FAILED records the reason");
            check(s.transitionTransfer("a1", b, st(F), P, null, 6L) && s.currentTransfer("a1", "A", "chatgpt").error.equals("page not ready"), "FAILED -> PENDING (retry); no new error text keeps the old one");
            check(s.transitionTransfer("a1", b, st(P), S, null, 7L) && s.currentTransfer("a1", "A", "chatgpt").attempts == 2, "the second attempt is counted");
            check(!s.transitionTransfer("a1", b, st(S), P, null, 8L), "SENDING cannot go back to PENDING");
            check(!s.transitionTransfer("a1", b, st(S), V, null, 9L), "SENDING cannot jump directly to VERIFIED");
            check(s.transitionTransfer("a1", b, st(S), T, null, 9L) && s.currentTransfer("a1", "A", "chatgpt").state == T && s.currentTransfer("a1", "A", "chatgpt").attempts == 2, "SENDING -> STAGED");
            check(s.transitionTransfer("a1", b, st(T), V, null, 10L) && s.currentTransfer("a1", "A", "chatgpt").state == V, "STAGED -> VERIFIED");
            check(!s.transitionTransfer("a1", b, st(P, S, T, V, F), V, "x", 11L) && !s.transitionTransfer("a1", b, st(V), F, "x", 11L) && !s.transitionTransfer("a1", b, st(V), S, null, 11L) && !s.transitionTransfer("a1", b, st(V), P, null, 11L), "VERIFIED is final: nothing moves it and nothing touches it");
            check(s.currentTransfer("a1", "A", "chatgpt").updatedAt == 10L && s.currentTransfer("a1", "A", "chatgpt").error.isEmpty() == false, "...not even its time or error text change");
            check(!s.transitionTransfer("nope", b, st(P), S, null, 1L) && !s.transitionTransfer("a1", "no-binding", st(P), S, null, 1L), "an unknown transfer is a plain false");
        });

        test("global single-flight: only one transfer in the whole app sends at a time", () -> {
            InMemoryRoomStore s = store();
            ready(s, "a1", "A"); ready(s, "a2", "A"); ready(s, "b1", "B");
            String t1 = s.ensureTransfer("a1", "A", "chatgpt", 1L).bindingId, t2 = s.ensureTransfer("a2", "A", "claude", 1L).bindingId, t3 = s.ensureTransfer("b1", "B", "chatgpt", 1L).bindingId;
            check(s.transitionTransfer("a1", t1, st(P), S, null, 2L), "the first transfer starts sending");
            check(!s.transitionTransfer("a2", t2, st(P), S, null, 3L) && !s.transitionTransfer("b1", t3, st(P), S, null, 3L), "no other transfer can start while it sends (same room or another room)");
            check(s.currentTransfer("a2", "A", "claude").state == P && s.currentTransfer("a2", "A", "claude").attempts == 0, "a refused start changes nothing, not even the attempt count");
            check(s.transitionTransfer("a1", t1, st(S), F, "x", 4L) && s.transitionTransfer("b1", t3, st(P), S, null, 5L), "once the first one is FAILED, another room may start");
            check(!s.transitionTransfer("a1", t1, st(F), S, null, 6L), "...and the failed one cannot retry while that one sends");
            check(s.transitionTransfer("b1", t3, st(S), T, null, 7L) && s.transitionTransfer("b1", t3, st(T), V, null, 8L) && s.transitionTransfer("a1", t1, st(F), S, null, 9L), "after it is STAGED then VERIFIED the retry may run");
            check(s.transitionTransfer("a1", t1, st(S), S, null, 9L), "the sending transfer may update itself (it is not 'another' one)");
        });

        test("restart recovery: nothing pretends to be in progress", () -> {
            InMemoryRoomStore s = store();
            ready(s, "done", "A"); ready(s, "sending", "A"); ready(s, "staged", "A"); ready(s, "queued", "A"); ready(s, "failedT", "A"); ready(s, "verified", "A");
            s.createArtifact("capturing", "A", "claude", s.activeBindingId("A", "claude"), "x.bin", "", 5L); s.createArtifact("failedA", "A", "claude", s.activeBindingId("A", "claude"), "y.bin", "", 5L); s.failArtifact("failedA");
            String bS = s.ensureTransfer("sending", "A", "chatgpt", 1L).bindingId, bT = s.ensureTransfer("staged", "A", "chatgpt", 1L).bindingId, bQ = s.ensureTransfer("queued", "A", "chatgpt", 1L).bindingId, bF = s.ensureTransfer("failedT", "A", "chatgpt", 1L).bindingId, bV = s.ensureTransfer("verified", "A", "chatgpt", 1L).bindingId;
            s.transitionTransfer("verified", bV, st(P), S, null, 2L); s.transitionTransfer("verified", bV, st(S), T, null, 3L); s.transitionTransfer("verified", bV, st(T), V, null, 4L);
            s.transitionTransfer("staged", bT, st(P), S, null, 2L); s.transitionTransfer("staged", bT, st(S), T, null, 3L);
            s.transitionTransfer("failedT", bF, st(P), S, null, 2L); s.transitionTransfer("failedT", bF, st(S), F, "boom", 3L);
            s.transitionTransfer("sending", bS, st(P), S, null, 4L);
            int changed = s.markArtifactWorkInterrupted(100L);
            check(changed == 3, "exactly the SENDING and STAGED transfers and the one artifact waiting for bytes changed: " + changed);
            ArtifactTransfer sent = s.currentTransfer("sending", "A", "chatgpt");
            check(sent.state == F && sent.error.equals("interrupted (app restart)") && sent.attempts == 1 && sent.updatedAt == 100L, "the interrupted upload is FAILED (retryable), with its attempt kept and the reason saved");
            check(s.getArtifact("capturing").state == ArtifactState.FAILED && s.getArtifact("failedA").state == ArtifactState.FAILED && s.getArtifact("done").state == ArtifactState.READY, "an artifact still waiting for its bytes is FAILED; READY ones are untouched");
            check(s.currentTransfer("staged", "A", "chatgpt").state == F && s.currentTransfer("queued", "A", "chatgpt").state == P && s.currentTransfer("failedT", "A", "chatgpt").error.equals("boom") && s.currentTransfer("verified", "A", "chatgpt").state == V, "STAGED becomes retryable; PENDING, already-FAILED and VERIFIED transfers are untouched");
            check(s.markArtifactWorkInterrupted(101L) == 0 && s.transfersInState(S).isEmpty(), "running recovery again changes nothing");
            check(s.transitionTransfer("sending", bS, st(F), S, null, 102L), "after recovery the single-flight slot is free again, and the failed upload can be retried");
        });

        test("a failed transaction restores artifacts, attachments and transfers", () -> {
            InMemoryRoomStore s = store();
            ready(s, "keep", "A");
            try {
                s.atomic(() -> {
                    s.createArtifact("temp", "A", "user", "t", "", 1L);
                    s.finalizeArtifact("temp", null, 1L, HEX, "p");
                    s.attachArtifact("mA", "temp", 0);
                    s.ensureTransfer("keep", "A", "chatgpt", 1L);
                    s.failArtifact("keep");
                    throw new IllegalStateException("probe");
                });
            } catch (IllegalStateException expected) { }
            check(s.getArtifact("temp") == null && s.artifactsOfMessage("mA").isEmpty() && s.transfersInState(P).isEmpty() && s.getArtifact("keep").state == ArtifactState.READY, "everything done inside the failed transaction is gone");
        });

        System.out.println((failures == 0 ? "PASS  " : "FAIL  ") + "artifact store (" + checks + " checks, " + failures + " failures)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
