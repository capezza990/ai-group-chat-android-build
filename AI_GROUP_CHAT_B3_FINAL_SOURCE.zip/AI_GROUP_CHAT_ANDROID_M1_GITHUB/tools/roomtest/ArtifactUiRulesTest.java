import com.aigroupchat.bridge.room.*;

public final class ArtifactUiRulesTest {
    private static int checks;
    private static void check(boolean v, String m) { checks++; if (!v) throw new AssertionError(m); }

    public static void main(String[] args) {
        Artifact pending = new Artifact("a", "r", "claude", "bind", "x.bin", "", -1, "", "", ArtifactState.PENDING_CAPTURE, 1L);
        Artifact failed = new Artifact("b", "r", "claude", "bind", "x.bin", "", -1, "", "", ArtifactState.FAILED, 1L);
        Artifact ready = new Artifact("c", "r", Artifact.ORIGIN_USER, "x.bin", "", 1536, "", "r/c", ArtifactState.READY, 1L);
        check(ArtifactUiRules.artifactMeta(pending).equals("Saving\u2026") && ArtifactUiRules.isTransient(pending), "capture in progress has a visible working status");
        check(ArtifactUiRules.artifactMeta(failed).equals("Couldn't save") && ArtifactUiRules.canRetryCapture(failed, true), "failed AI capture with a known reply offers retry");
        check(!ArtifactUiRules.canRetryCapture(failed, false) && ArtifactUiRules.needsFreshFile(failed, false) && !ArtifactUiRules.needsFreshFile(failed, true) && ArtifactUiRules.freshFileText().contains("Ask the AI to send it again"), "without a known reply there is no retry, only the explanation");
        check(ArtifactUiRules.artifactMeta(ready).equals("1.5 KB") && !ArtifactUiRules.canRetryCapture(ready, true) && !ArtifactUiRules.needsFreshFile(ready, false), "ready file shows compact size and no capture retry");

        ArtifactTransfer p = new ArtifactTransfer("c", "r", "chatgpt", "b", TransferState.PENDING, 0, "", 1L);
        ArtifactTransfer s = p.with(TransferState.SENDING, 1, "", 2L);
        ArtifactTransfer t = s.with(TransferState.STAGED, 1, "", 3L);
        ArtifactTransfer v = t.with(TransferState.VERIFIED, 1, "", 4L);
        ArtifactTransfer f = new ArtifactTransfer("c", "r", "chatgpt", "b", TransferState.FAILED, 3, "chooser refused because attachment controls changed", 5L);
        check(ArtifactUiRules.transferStatus(p, "ChatGPT").equals("Queued for ChatGPT"), "pending transfer is understandable");
        check(ArtifactUiRules.transferStatus(s, "ChatGPT").equals("Uploading to ChatGPT\u2026") && ArtifactUiRules.isTransient(s), "sending is shown as active");
        check(ArtifactUiRules.transferStatus(t, "ChatGPT").contains("waiting to send") && ArtifactUiRules.isTransient(t), "staged is distinct from delivered");
        check(ArtifactUiRules.transferStatus(v, "ChatGPT").equals("Delivered to ChatGPT"), "verified is delivered");
        check(ArtifactUiRules.transferStatus(f, "ChatGPT").startsWith("Couldn't send to ChatGPT") && ArtifactUiRules.canRetryTransfer(f), "failed transfer exposes retry state and reason");
        check(ArtifactUiRules.humanBytes(25L * 1024 * 1024).equals("25 MB"), "size formatter is stable at the current cap");
        System.out.println("Artifact UI rules: " + checks + " checks, 0 failures");
    }
}
