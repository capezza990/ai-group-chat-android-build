import com.aigroupchat.bridge.engine.CapturePolicy;
import com.aigroupchat.bridge.engine.ChunkedReceiver;
import com.aigroupchat.bridge.engine.FileOffer;
import com.aigroupchat.bridge.engine.FileOfferMatcher;
import com.aigroupchat.bridge.engine.MiniJson;
import com.aigroupchat.bridge.engine.NativeDownloader;
import com.aigroupchat.bridge.room.ArtifactStorage;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/** The pure core of file capture: strict page-output parsing, which offer is the file, which addresses are safe, chunk assembly and the guarded downloader. */
public final class FileCaptureCoreTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }

    static boolean bad(String json) { return MiniJson.parseObjectArray(json) == null; }
    static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    static FileOffer offer(String name, String href, int index, int fromEnd) { return new FileOffer(name, href.isEmpty() ? FileOffer.Kind.BUTTON : FileOffer.Kind.LINK, href, index, fromEnd, ""); }

    public static void main(String[] args) throws Exception {
        json();
        offers();
        matcher();
        replyOffers();
        exactReply();
        saveStream();
        policy();
        receiver();
        downloader();
        System.out.println("File capture core: " + checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }

    static void json() {
        List<Map<String, Object>> ok = MiniJson.parseObjectArray(" [ {\"name\":\"a b.pdf\",\"i\":2,\"on\":true,\"x\":null,\"e\":\"\\u00e9\\n\\\"q\\\"\"} , {} ] ");
        check(ok != null && ok.size() == 2 && "a b.pdf".equals(ok.get(0).get("name")) && Long.valueOf(2).equals(ok.get(0).get("i")) && Boolean.TRUE.equals(ok.get(0).get("on")) && ok.get(0).containsKey("x") && ok.get(0).get("x") == null, "a valid array of flat objects is read");
        check("\u00e9\n\"q\"".equals(ok.get(0).get("e")), "string escapes are decoded");
        check(MiniJson.parseObjectArray("[]").isEmpty() && MiniJson.parseObject("{\"a\":1}").get("a").equals(1L), "an empty array and a single object are read");
        check(bad("[{\"a\":{\"b\":1}}]") && bad("[{\"a\":[1]}]"), "nested values are refused");
        check(bad("[{\"a\":1.5}]") && bad("[{\"a\":1e3}]") && bad("[{\"a\":01}]") && bad("[{\"a\":-}]"), "fractions, exponents, leading zeros and a bare minus are refused");
        check(bad("[{\"a\":9007199254740993}]") && !bad("[{\"a\":9007199254740991}]"), "integers beyond what the page can represent exactly are refused");
        check(bad("[{\"a\":1,\"a\":2}]"), "a duplicate key is refused");
        check(bad("[{\"a\":1}] x") && bad("[{\"a\":1}]]") && bad("[{\"a\":1},]") && bad("[{\"a\":1}") && bad("{\"a\":1}") && bad(""), "trailing text, a trailing comma, a missing bracket and the wrong shape are refused");
        check(bad("[{\"a\":\"line\nbreak\"}]") && bad("[{\"a\":\"\\x\"}]") && bad("[{\"a\":\"\\u12G4\"}]") && bad("[{\"a\":\"open}]"), "raw control characters, bad escapes and an open string are refused");
        check(MiniJson.parseObjectArray(null) == null && MiniJson.parseObject("[]") == null && MiniJson.parseObject("{\"a\":1} x") == null, "null, an array where an object is needed and trailing text are refused");
        StringBuilder many = new StringBuilder("[");
        for (int i = 0; i < 201; i++) many.append(i > 0 ? "," : "").append("{}");
        check(bad(many + "]") && !bad(many.substring(0, many.length() - 3) + "]"), "more than 200 items is refused, exactly 200 is fine");
        StringBuilder big = new StringBuilder("[{\"a\":\"");
        for (int i = 0; i < MiniJson.MAX_CHARS; i++) big.append('x');
        check(bad(big + "\"}]"), "oversize input is refused");
        StringBuilder keys = new StringBuilder("[{");
        for (int i = 0; i <= MiniJson.MAX_KEYS; i++) keys.append(i > 0 ? "," : "").append("\"k").append(i).append("\":1");
        check(bad(keys + "}]"), "too many keys in one object is refused");
    }

    static void offers() {
        String json = "[{\"name\":\"report.pdf\",\"kind\":\"link\",\"index\":0,\"fromEnd\":0,\"href\":\"https://chatgpt.com/files/1\",\"mime\":\"application/pdf\"},"
                + "{\"name\":\"\",\"kind\":\"link\",\"index\":1,\"fromEnd\":0},"
                + "{\"name\":\"no kind\",\"kind\":\"menu\",\"index\":2,\"fromEnd\":0},"
                + "{\"name\":\"negative\",\"kind\":\"button\",\"index\":-1,\"fromEnd\":0},"
                + "{\"name\":\"data.csv\",\"kind\":\"button\",\"index\":3,\"fromEnd\":1},"
                + "{\"name\":\"href not a string\",\"kind\":\"link\",\"index\":4,\"fromEnd\":0,\"href\":5}]";
        List<FileOffer> l = FileOffer.parseList(json);
        check(l.size() == 2 && l.get(0).name.equals("report.pdf") && l.get(0).kind == FileOffer.Kind.LINK && l.get(0).mime.equals("application/pdf") && l.get(1).name.equals("data.csv") && l.get(1).fromEnd == 1, "valid offers are read, invalid ones are skipped and never repaired");
        check(FileOffer.parseList("not json").isEmpty() && FileOffer.parseList(null).isEmpty() && FileOffer.parseList("{}").isEmpty(), "output that is not the expected array gives no offers");
        FileOffer https = offer("a", "https://x.test/a", 0, 0), blob = offer("a", "blob:https://x.test/u", 0, 0), data = offer("a", "data:text/plain;base64,QQ==", 0, 0);
        check(https.fetchable() && blob.fetchable() && data.fetchable() && !https.mayClick() && !blob.mayClick() && !data.mayClick(), "https, blob and data links are candidates for fetching and are never clicked");
        FileOffer sandbox = offer("a", "sandbox:/mnt/data/a.txt", 0, 0), button = offer("a", "", 0, 0);
        check(sandbox.mayClick() && !sandbox.fetchable() && button.kind == FileOffer.Kind.BUTTON && button.mayClick() && !button.fetchable(), "the provider's sandbox: link and a real button may be clicked, never fetched");
        check(new FileOffer("a", FileOffer.Kind.LINK, "SANDBOX:/x", 0, 0, "").mayClick(), "the sandbox: scheme is recognised in any letter case");
        for (String bad : new String[]{"javascript:alert(1)", "file:///etc/passwd", "http://x.test/a", "ftp://x.test/a", "", "intent://x#Intent;end", "content://x/y", "data", "https:/x", "//x.test/a"})
            check(!new FileOffer("a", FileOffer.Kind.LINK, bad, 0, 0, "").mayClick() && !new FileOffer("a", FileOffer.Kind.LINK, bad, 0, 0, "").fetchable(), "a LINK whose address is '" + bad + "' is neither clicked nor fetched: it is refused");
        StringBuilder big = new StringBuilder("[");
        for (int i = 0; i < 30; i++) big.append(i > 0 ? "," : "").append("{\"name\":\"f").append(i).append("\",\"kind\":\"button\",\"index\":").append(i).append(",\"fromEnd\":0}");
        check(FileOffer.parseList(big + "]").size() == FileOffer.MAX_OFFERS, "at most 20 offers are taken");
    }

    static void matcher() {
        List<FileOffer> one = Arrays.asList(offer("report.pdf", "https://x.test/1", 0, 0), offer("other.txt", "https://x.test/2", 1, 0));
        FileOfferMatcher.Result r = FileOfferMatcher.match("report.pdf", one);
        check(r.outcome == FileOfferMatcher.Outcome.FOUND && r.offer.index == 0, "the offer with the artifact's name is found");
        check(FileOfferMatcher.match("a_b.txt", Arrays.asList(offer("a/b.txt", "https://x.test/1", 0, 0))).outcome == FileOfferMatcher.Outcome.FOUND, "the page's raw name is cleaned the same way the artifact's name was");
        check(FileOfferMatcher.match("missing.txt", one).outcome == FileOfferMatcher.Outcome.NOT_FOUND && FileOfferMatcher.match(null, one).outcome == FileOfferMatcher.Outcome.NOT_FOUND && FileOfferMatcher.match("x", null).outcome == FileOfferMatcher.Outcome.NOT_FOUND && FileOfferMatcher.match("x", Collections.<FileOffer>emptyList()).outcome == FileOfferMatcher.Outcome.NOT_FOUND, "a missing file, null input and an empty page are NOT_FOUND");
        check(FileOfferMatcher.match("REPORT.pdf", one).outcome == FileOfferMatcher.Outcome.NOT_FOUND, "names are matched exactly (case counts)");
        List<FileOffer> twoMsgs = Arrays.asList(offer("v.txt", "https://x.test/old", 0, 2), offer("v.txt", "https://x.test/new", 1, 0));
        r = FileOfferMatcher.match("v.txt", twoMsgs);
        check(r.outcome == FileOfferMatcher.Outcome.FOUND && r.offer.href.endsWith("/new"), "the same name in two messages: the NEWEST message wins");
        List<FileOffer> sameMsg = Arrays.asList(offer("v.txt", "https://x.test/a", 0, 0), offer("v.txt", "https://x.test/b", 1, 0));
        check(FileOfferMatcher.match("v.txt", sameMsg).outcome == FileOfferMatcher.Outcome.AMBIGUOUS, "two different files with the same name in the same message is AMBIGUOUS, never guessed");
        List<FileOffer> twice = Arrays.asList(offer("v.txt", "https://x.test/a", 0, 0), new FileOffer("v.txt", FileOffer.Kind.BUTTON, "https://x.test/a", 1, 0, ""));
        check(FileOfferMatcher.match("v.txt", twice).outcome == FileOfferMatcher.Outcome.FOUND, "the same file shown twice (same address) is one file");
        List<FileOffer> noHref = Arrays.asList(offer("v.txt", "", 0, 0), offer("v.txt", "", 1, 0));
        check(FileOfferMatcher.match("v.txt", noHref).outcome == FileOfferMatcher.Outcome.AMBIGUOUS, "two click-only offers with one name cannot be told apart, so they are AMBIGUOUS");
    }

    static void replyOffers() {
        List<FileOffer> mixed = Arrays.asList(
                offer("a.txt", "https://x.test/a", 0, 0), new FileOffer("a.txt", FileOffer.Kind.BUTTON, "https://x.test/a", 1, 0, ""),   // the same file twice
                offer("old.txt", "https://x.test/o", 2, 1),                                                                          // an older message
                offer("same.txt", "https://x.test/s1", 3, 0), offer("same.txt", "https://x.test/s2", 4, 0),                          // ambiguous
                offer("click.bin", "", 5, 0));
        List<FileOffer> r = FileOfferMatcher.replyOffers(mixed);
        check(r.size() == 2 && r.get(0).name.equals("a.txt") && r.get(0).index == 0 && r.get(1).name.equals("click.bin"), "a reply promises each file once, only from the newest message, and never an ambiguous name");
        check(FileOfferMatcher.replyOffers(null).isEmpty() && FileOfferMatcher.replyOffers(Collections.<FileOffer>emptyList()).isEmpty(), "no offers, no files");
        List<FileOffer> many = new ArrayList<>();
        for (int i = 0; i < 15; i++) many.add(offer("f" + i + ".txt", "https://x.test/" + i, i, 0));
        check(FileOfferMatcher.replyOffers(many).size() == FileOfferMatcher.MAX_REPLY_FILES, "at most 10 files per reply");
        check(FileOfferMatcher.replyOffers(Arrays.asList(offer("a/b.txt", "https://x.test/1", 0, 0), offer("a_b.txt", "https://x.test/2", 1, 0))).isEmpty(), "two names that clean to the same name are ambiguous after cleaning, so neither is promised");
    }

    static FileOffer in(String name, String href, int index, int fromEnd, String msgId) { return new FileOffer(name, FileOffer.Kind.LINK, href, index, fromEnd, "", msgId); }

    /** The retry bug: a newer, DIFFERENT file with the same name must never be chosen for an older artifact. */
    static void exactReply() {
        List<FileOffer> two = Arrays.asList(in("report.pdf", "https://x.test/v1", 0, 3, "msg-1"), in("report.pdf", "https://x.test/v2", 1, 0, "msg-2"));
        FileOfferMatcher.Result newest = FileOfferMatcher.match("report.pdf", two);
        check(newest.outcome == FileOfferMatcher.Outcome.FOUND && newest.offer.href.endsWith("/v2"), "WITHOUT a reply id the newest message wins (only acceptable for the first, automatic capture)");
        FileOfferMatcher.Result old = FileOfferMatcher.match("report.pdf", two, "msg-1");
        check(old.outcome == FileOfferMatcher.Outcome.FOUND && old.offer.href.endsWith("/v1"), "WITH the old reply's id the OLD file is chosen, never the newer one of the same name");
        check(FileOfferMatcher.match("report.pdf", two, "msg-2").offer.href.endsWith("/v2"), "and the newer reply's id still gives the newer file");
        check(FileOfferMatcher.match("report.pdf", Arrays.asList(in("report.pdf", "https://x.test/v2", 0, 0, "msg-2")), "msg-1").outcome == FileOfferMatcher.Outcome.NOT_FOUND, "when the old reply is no longer on the page the capture finds nothing (it never falls back to another reply)");
        check(FileOfferMatcher.match("report.pdf", Arrays.asList(in("report.pdf", "https://x.test/v2", 0, 0, "")), "msg-1").outcome == FileOfferMatcher.Outcome.NOT_FOUND, "offers without any id cannot prove they belong to the reply, so they are refused");
        check(FileOfferMatcher.match("other.pdf", two, "msg-1").outcome == FileOfferMatcher.Outcome.NOT_FOUND, "inside the exact reply the name must still match");
        List<FileOffer> dupInReply = Arrays.asList(in("a.txt", "https://x.test/1", 0, 0, "m"), in("a.txt", "https://x.test/2", 1, 0, "m"));
        check(FileOfferMatcher.match("a.txt", dupInReply, "m").outcome == FileOfferMatcher.Outcome.AMBIGUOUS, "two different files with one name inside the same reply are ambiguous");
        check(FileOfferMatcher.match("a.txt", Arrays.asList(in("a.txt", "https://x.test/1", 0, 0, "m"), in("a.txt", "https://x.test/1", 1, 0, "m")), "m").outcome == FileOfferMatcher.Outcome.FOUND, "the same file shown twice inside the reply is one file");
        // what a reply promises is decided by the SAME exact rule
        List<FileOffer> mixed = Arrays.asList(in("report.pdf", "https://x.test/v1", 0, 3, "msg-1"), in("report.pdf", "https://x.test/v2", 1, 0, "msg-2"), in("only-new.txt", "https://x.test/n", 2, 0, "msg-2"));
        List<FileOffer> forNew = FileOfferMatcher.replyOffers(mixed, "msg-2");
        check(forNew.size() == 2 && forNew.get(0).href.endsWith("/v2") && forNew.get(1).name.equals("only-new.txt"), "a reply with its id promises only that reply's files, even though an older reply has the same name");
        List<FileOffer> forOld = FileOfferMatcher.replyOffers(mixed, "msg-1");
        check(forOld.size() == 1 && forOld.get(0).href.endsWith("/v1"), "the exact reply is used even when it is not the newest message");
        check(FileOfferMatcher.replyOffers(mixed, "msg-GONE").isEmpty(), "a reply id that is not on the page promises nothing");
        check(FileOfferMatcher.replyOffers(Arrays.asList(in("a.txt", "https://x.test/a", 0, 0, "")), "msg-2").isEmpty(), "a reply id with offers that carry no id promises nothing (they could never be proven later)");
        check(FileOfferMatcher.replyOffers(Arrays.asList(in("a.txt", "https://x.test/a", 0, 0, "")), "").size() == 1, "with no reply id at all the newest message is used");
        check(FileOffer.parseList("[{\"name\":\"a\",\"kind\":\"link\",\"index\":0,\"fromEnd\":0,\"msgId\":\"abc-1\"}]").get(0).msgId.equals("abc-1") && FileOffer.parseList("[{\"name\":\"a\",\"kind\":\"link\",\"index\":0,\"fromEnd\":0}]").get(0).msgId.isEmpty(), "msgId is read when present and empty otherwise");
        check(FileOffer.parseList("[{\"name\":\"a\",\"kind\":\"link\",\"index\":0,\"fromEnd\":0,\"msgId\":7}]").isEmpty() && FileOffer.parseList("[{\"name\":\"a\",\"kind\":\"link\",\"index\":0,\"fromEnd\":0,\"msgId\":\"" + new String(new char[201]).replace('\0', 'x') + "\"}]").isEmpty(), "a msgId that is not a short string makes the entry invalid");
    }

    static final class FailingClose extends InputStream {
        final byte[] data; int pos; final boolean failClose;
        FailingClose(byte[] d, boolean f) { data = d; failClose = f; }
        @Override public int read() { return pos < data.length ? data[pos++] & 0xFF : -1; }
        @Override public void close() throws IOException { if (failClose) throw new IOException("close failed"); }
    }

    static void saveStream() throws Exception {
        File dir = tmp();
        File ok = new File(dir, "ok.part");
        check(NativeDownloader.saveStream(new FailingClose("hello".getBytes(StandardCharsets.UTF_8), false), ok, 100) == 5 && ok.length() == 5, "a stream is saved completely");
        File bad = new File(dir, "bad.part");
        boolean thrown = false;
        try { NativeDownloader.saveStream(new FailingClose("hello".getBytes(StandardCharsets.UTF_8), true), bad, 100); } catch (IOException e) { thrown = true; }
        check(thrown && !bad.exists(), "when closing the stream throws, the download fails AND the partial file is deleted");
        File big = new File(dir, "big.part");
        boolean tooLarge = false;
        try { NativeDownloader.saveStream(new FailingClose(new byte[50], false), big, 10); } catch (ArtifactStorage.TooLargeException e) { tooLarge = true; }
        check(tooLarge && !big.exists(), "a stream over the cap fails and leaves no file");
        InputStream zero = new InputStream() { @Override public int read() { return 0; } @Override public int read(byte[] b, int o, int l) { return 0; } };
        File stuck = new File(dir, "stuck.part");
        boolean refused = false;
        try { NativeDownloader.saveStream(zero, stuck, 100); } catch (IOException e) { refused = true; }
        check(refused && !stuck.exists(), "a stream that never makes progress fails and leaves no file");
    }

    static void policy() {
        String[] hosts = {"oaiusercontent.com"};
        check("chatgpt.com".equals(CapturePolicy.httpsHost("https://ChatGPT.com/a/b?c=d#e")) && "x.test".equals(CapturePolicy.httpsHost("https://x.test:443/p")), "an https host is read in lower case");
        check(CapturePolicy.httpsHost("http://x.test/a") == null && CapturePolicy.httpsHost("ftp://x.test/a") == null && CapturePolicy.httpsHost("https://user@x.test/a") == null && CapturePolicy.httpsHost("https://x.test:8443/a") == null && CapturePolicy.httpsHost("https:///a") == null && CapturePolicy.httpsHost("not a url") == null && CapturePolicy.httpsHost(null) == null && CapturePolicy.httpsHost("https://x.test/" + new String(new char[4100]).replace('\0', 'a')) == null, "plain http, other schemes, user info, odd ports, no host, nonsense, null and absurd length are refused");
        check(CapturePolicy.hostAllowed("oaiusercontent.com", hosts) && CapturePolicy.hostAllowed("files.OAIUSERCONTENT.com", hosts) && !CapturePolicy.hostAllowed("eviloaiusercontent.com", hosts) && !CapturePolicy.hostAllowed("oaiusercontent.com.evil.test", hosts) && !CapturePolicy.hostAllowed("x.test", hosts) && !CapturePolicy.hostAllowed(null, hosts) && !CapturePolicy.hostAllowed("a.test", null) && !CapturePolicy.hostAllowed("a.test", new String[]{"", null}), "an allowed host matches exactly or as a true subdomain, never as a look-alike");
        check(CapturePolicy.pageMayFetch("https://chatgpt.com/files/1", "chatgpt.com", hosts) && CapturePolicy.pageMayFetch("https://files.oaiusercontent.com/x", "chatgpt.com", hosts) && !CapturePolicy.pageMayFetch("https://evil.test/x", "chatgpt.com", hosts) && !CapturePolicy.pageMayFetch("http://chatgpt.com/x", "chatgpt.com", hosts), "the page may fetch from its own host and an allowed host over https only");
        check(CapturePolicy.pageMayFetch("blob:https://claude.ai/123", "claude.ai", hosts) && !CapturePolicy.pageMayFetch("blob:https://evil.test/123", "claude.ai", hosts) && !CapturePolicy.pageMayFetch("blob:null/123", "claude.ai", hosts) && !CapturePolicy.pageMayFetch("blob:https://claude.ai/123", null, hosts), "a blob: address only counts when it belongs to this page's own origin");
        check(CapturePolicy.pageMayFetch("data:text/plain;base64,QQ==", "x.test", hosts) && !CapturePolicy.pageMayFetch("data:text/plain,hello", "x.test", hosts) && !CapturePolicy.pageMayFetch("data:text/plain;base64," + new String(new char[CapturePolicy.MAX_DATA_URL_CHARS]).replace('\0', 'A'), "x.test", hosts), "a data: address must be base64 and bounded");
        check(!CapturePolicy.pageMayFetch("javascript:alert(1)", "x.test", hosts) && !CapturePolicy.pageMayFetch("file:///etc/passwd", "x.test", hosts) && !CapturePolicy.pageMayFetch("content://x/y", "x.test", hosts) && !CapturePolicy.pageMayFetch(null, "x.test", hosts), "script, file, content and null addresses are refused");
        check(CapturePolicy.nativeMayDownload("https://files.oaiusercontent.com/x", hosts) && !CapturePolicy.nativeMayDownload("https://chatgpt.com/x", hosts) && !CapturePolicy.nativeMayDownload("http://files.oaiusercontent.com/x", hosts), "the app itself downloads only from an allowed host over https");
    }

    static File tmp() throws IOException { File d = Files.createTempDirectory("capture-core").toFile(); d.deleteOnExit(); return d; }

    static void receiver() throws Exception {
        File dir = tmp();
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 100)) {
            r.append(0, b64("Hello, ")); r.append(1, b64("wor")); r.append(2, b64("ld"));
            check(r.size() == 12, "chunks are counted");
            File f = r.finish(12);
            check(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).equals("Hello, world"), "the chunks are assembled in order");
            r.close();
            check(f.exists(), "a finished file is handed over, not deleted by close()");
            try (InputStream in = ChunkedReceiver.openAndDelete(f)) { check(in.read() == 'H', "the handed-over file can be read"); }
            check(!f.exists(), "closing the stream deletes the temp file");
        }
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 100)) {
            r.append(0, b64("a"));
            boolean refused = false; try { r.append(2, b64("c")); } catch (IOException e) { refused = true; }
            check(refused, "a chunk out of order is refused");
        }
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 100)) {
            boolean refused = false; try { r.append(0, "***not base64***"); } catch (IOException e) { refused = true; }
            boolean nullRefused = false; try { r.append(0, null); } catch (IOException e) { nullRefused = true; }
            check(refused && nullRefused, "invalid base64 and an empty chunk are refused");
        }
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 5)) {
            r.append(0, b64("12345"));
            boolean tooLarge = false; try { r.append(1, b64("6")); } catch (ArtifactStorage.TooLargeException e) { tooLarge = true; }
            check(tooLarge, "one byte over the cap is TooLarge");
        }
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 100)) {
            r.append(0, b64("abc"));
            boolean refused = false; try { r.finish(4); } catch (IOException e) { refused = true; }
            check(refused, "a received size that differs from the announced size is refused");
        }
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 100)) {
            r.append(0, b64("abc")); r.finish(3);
            boolean again = false; try { r.append(1, b64("d")); } catch (IOException e) { again = true; }
            boolean twice = false; try { r.finish(3); } catch (IOException e) { twice = true; }
            check(again && twice, "nothing can be added to or finished again after finish()");
            // the handed-over file is deleted below
        }
        File[] left = dir.listFiles();
        if (left != null) for (File f : left) f.delete();
        try (ChunkedReceiver r = new ChunkedReceiver(dir, 100)) { r.append(0, b64("x")); }
        check(dir.listFiles().length == 0, "an unfinished transfer leaves nothing behind");
    }

    static void downloader() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        final AtomicReference<String> seenCookie = new AtomicReference<>("");
        final byte[] body = "FILE-BYTES-0123456789".getBytes(StandardCharsets.UTF_8);
        server.createContext("/ok", ex -> { seenCookie.set(String.valueOf(ex.getRequestHeaders().getFirst("Cookie"))); ex.getResponseHeaders().add("Content-Type", "Text/Plain; charset=utf-8"); ex.sendResponseHeaders(200, body.length); try (OutputStream o = ex.getResponseBody()) { o.write(body); } });
        server.createContext("/missing", ex -> { ex.sendResponseHeaders(404, -1); ex.close(); });
        server.createContext("/big", ex -> { ex.sendResponseHeaders(200, 1000); try (OutputStream o = ex.getResponseBody()) { o.write(new byte[1000]); } });
        server.createContext("/stream", ex -> { ex.sendResponseHeaders(200, 0); try (OutputStream o = ex.getResponseBody()) { for (int i = 0; i < 100; i++) o.write(new byte[100]); } });
        server.createContext("/hop", ex -> { ex.getResponseHeaders().add("Location", "/ok"); ex.sendResponseHeaders(302, -1); ex.close(); });
        server.createContext("/evil", ex -> { ex.getResponseHeaders().add("Location", "https://evil.example/x"); ex.sendResponseHeaders(302, -1); ex.close(); });
        server.createContext("/loop", ex -> { ex.getResponseHeaders().add("Location", "/loop"); ex.sendResponseHeaders(302, -1); ex.close(); });
        server.start();
        String base = "http://127.0.0.1:" + server.getAddress().getPort();
        try {
            File dir = tmp();
            NativeDownloader.Options o = new NativeDownloader.Options();
            o.tmpDir = dir; o.allowLocalHttpForTests = true; o.maxBytes = 500; o.timeoutMs = 5000; o.cookies = u -> "session=abc";
            NativeDownloader.Download d = NativeDownloader.fetch(base + "/ok", o);
            check(d.size == body.length && "text/plain".equals(d.mime) && Arrays.equals(Files.readAllBytes(d.file.toPath()), body), "a normal download is stored with its size and its type");
            check("session=abc".equals(seenCookie.get()), "the supplied cookie is sent");
            d.file.delete();
            check(fails(base + "/missing", o), "a 404 is a failure");
            check(fails(base + "/big", o), "a declared size over the cap is refused");
            check(fails(base + "/stream", o), "a streamed body over the cap is refused");
            NativeDownloader.Download via = NativeDownloader.fetch(base + "/hop", o);
            check(via.size == body.length, "a redirect to an allowed address is followed");
            via.file.delete();
            check(fails(base + "/evil", o), "a redirect to a host that is not allowed is refused");
            check(fails(base + "/loop", o), "too many redirects are refused");
            NativeDownloader.Options strict = new NativeDownloader.Options();
            strict.tmpDir = dir; strict.timeoutMs = 5000;
            check(fails(base + "/ok", strict), "without the test switch, plain http on the local machine is refused");
            check(fails("https://evil.example/x", strict) && fails("file:///etc/passwd", strict) && fails("not a url", strict), "other hosts, file: and nonsense are refused before any connection");
            File[] left = dir.listFiles();
            check(left == null || left.length == 0, "every failed download left no temp file behind");
        } finally { server.stop(0); }
    }

    static boolean fails(String url, NativeDownloader.Options o) {
        try { NativeDownloader.fetch(url, o); return false; } catch (IOException e) { return true; }
    }
}
