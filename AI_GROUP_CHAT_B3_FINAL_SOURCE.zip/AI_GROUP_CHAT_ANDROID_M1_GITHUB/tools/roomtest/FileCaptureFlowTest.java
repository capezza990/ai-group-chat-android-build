import com.aigroupchat.bridge.engine.FileCaptureFlow;
import com.aigroupchat.bridge.engine.FileOffer;
import com.aigroupchat.bridge.engine.MiniJson;
import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.ArtifactNames;
import com.aigroupchat.bridge.room.InMemoryRoomStore;
import com.aigroupchat.bridge.room.RoomKind;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.PriorityQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** The whole capture flow against a fake provider page that behaves like agc_engine.js (offers, fetch with polling, chunks, click + download), in virtual time. */
public final class FileCaptureFlowTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }

    static final String PAGE_HOST = "claude.ai";
    static final String[] DOWNLOAD_HOSTS = {"claudeusercontent.com"};

    /** A fake page + clock. */
    static final class Page implements FileCaptureFlow.Driver {
        long now = 1000;
        final PriorityQueue<Object[]> queue = new PriorityQueue<>((a, b) -> (Long) a[0] != (Long) b[0] ? Long.compare((Long) a[0], (Long) b[0]) : Long.compare((Long) a[1], (Long) b[1]));
        long seq;
        String conversation = "conv-1";
        String offersJson = "[]";
        String nextOffersJson = null;   // the page changes right after the app's scan (time-of-check/time-of-use)
        byte[] fileBytes = new byte[0];
        final Map<String, byte[]> bytesByHref = new HashMap<>();   // different files behind different addresses
        String fileMime = "text/plain";
        String fetchError = null;       // the page's fetch fails with this
        int pollsBeforeReady = 0;       // status says pending this many times first
        boolean neverReady, hang, beginRefuses, brokenChunk, shortChunks, missingChunk, clickRefuses, silentClick;
        int chunkSize = 4;
        long announcedSizeDelta = 0;
        String downloadOnClick = null;  // url the page "downloads" after a click
        List<String> log = new ArrayList<>();
        FileCaptureFlow.DownloadSink sink;
        int armed, disarmed, backgrounds, clicked;
        final List<String> fetchedHrefs = new ArrayList<>();
        // capture state in the page
        String capState = "none"; int polls;

        @Override public void eval(String e, FileCaptureFlow.Done<String> cb) {
            log.add(e);
            if (hang) return;
            cb.done(answer(e));
        }

        String answer(String e) {
            Matcher m;
            if (e.equals("window.__agc.fileOffers()")) { String now = offersJson; if (nextOffersJson != null) { offersJson = nextOffersJson; nextOffersJson = null; } return now; }
            if ((m = Pattern.compile("^window\\.__agc\\.captureBegin\\(\"[^\"]*\",(\\{.*\\}),(\\d+)\\)$").matcher(e)).matches()) {
                if (beginRefuses) return "{\"ok\":false,\"error\":\"offer-changed\"}";
                FileOffer o = current(m.group(1));
                if (o == null) return "{\"ok\":false,\"error\":\"offer-changed\"}";
                if (!o.fetchable()) return "{\"ok\":false,\"error\":\"" + (o.mayClick() ? "click-only" : "not-fetchable") + "\"}";
                if (bytesByHref.containsKey(o.href)) fileBytes = bytesByHref.get(o.href);
                fetchedHrefs.add(o.href);
                startFetch();
                return "{\"ok\":true}";
            }
            if ((m = Pattern.compile("^window\\.__agc\\.captureUrl\\((\"[^)]*?\"),(\".*\"),(\\d+)\\)$").matcher(e)).matches()) { startFetch(); return "{\"ok\":true}"; }
            if (e.startsWith("window.__agc.captureStatus(")) {
                if (capState.equals("none")) return "{\"state\":\"none\"}";
                if (capState.equals("pending")) { if (!neverReady && ++polls > pollsBeforeReady) capState = fetchError != null ? "failed" : "ready"; }
                if (capState.equals("pending")) return "{\"state\":\"pending\"}";
                if (capState.equals("failed")) return "{\"state\":\"failed\",\"error\":\"" + fetchError + "\"}";
                long chunks = (fileBytes.length + chunkSize - 1) / chunkSize;
                return "{\"state\":\"ready\",\"size\":" + (fileBytes.length + announcedSizeDelta) + ",\"mime\":\"" + fileMime + "\",\"chunk\":" + chunkSize + ",\"chunks\":" + chunks + "}";
            }
            if ((m = Pattern.compile("^window\\.__agc\\.captureChunk\\(\"[^\"]*\",(\\d+)\\)$").matcher(e)).matches()) {
                int n = Integer.parseInt(m.group(1));
                if (!capState.equals("ready")) return "!notready";
                if (missingChunk && n == 1) return "!notready";
                if (brokenChunk && n == 1) return "***";
                int from = n * chunkSize;
                if (from >= fileBytes.length) return "";
                int to = Math.min(fileBytes.length, from + chunkSize);
                if (shortChunks && n == 0) to = Math.min(to, from + 1);
                return Base64.getEncoder().encodeToString(Arrays.copyOfRange(fileBytes, from, to));
            }
            if (e.startsWith("window.__agc.captureEnd(")) { capState = "none"; return "ok"; }
            if ((m = Pattern.compile("^window\\.__agc\\.clickOffer\\((\\{.*\\})\\)$").matcher(e)).matches()) {
                if (clickRefuses) return "{\"ok\":false,\"error\":\"offer-changed\"}";
                FileOffer o = current(m.group(1));
                if (o == null) return "{\"ok\":false,\"error\":\"offer-changed\"}";
                if (!o.mayClick()) return "{\"ok\":false,\"error\":\"not-clickable\"}";
                clicked++;
                if (downloadOnClick != null && !silentClick && sink != null) { final FileCaptureFlow.DownloadSink s = sink; final String u = downloadOnClick; post(() -> s.onDownload(u, "UA/1", "application/octet-stream", -1), 400); }
                return "{\"ok\":true}";
            }
            throw new AssertionError("unexpected expression: " + e);
        }

        /** The page's own check: the offer at the fingerprint's index must STILL be exactly the described one (index, name, kind, address, position, reply id). */
        FileOffer current(String fingerprintJson) {
            Map<String, Object> fp = MiniJson.parseObject(fingerprintJson);
            if (fp == null || !(fp.get("index") instanceof Long)) return null;
            for (FileOffer o : FileOffer.parseList(offersJson)) {
                if (o.index != ((Long) fp.get("index")).intValue()) continue;
                boolean same = o.name.equals(fp.get("name")) && (o.kind == FileOffer.Kind.LINK ? "link" : "button").equals(fp.get("kind")) && o.href.equals(fp.get("href"))
                        && Long.valueOf(o.fromEnd).equals(fp.get("fromEnd")) && o.msgId.equals(fp.get("msgId"));
                return same ? o : null;
            }
            return null;
        }

        void startFetch() { capState = "pending"; polls = 0; }

        static String unjs(String lit) {
            String s = lit.substring(1, lit.length() - 1);
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c != '\\') { b.append(c); continue; }
                char n = s.charAt(++i);
                if (n == 'u') { b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; } else b.append(n);
            }
            return b.toString();
        }

        @Override public void post(Runnable r, long delay) { queue.add(new Object[]{now + delay, seq++, r}); }
        @Override public void background(Runnable r) { backgrounds++; /* never run: no network in tests */ }
        @Override public long now() { return now; }
        @Override public String conversationId() { return conversation; }
        @Override public String pageHost() { return PAGE_HOST; }
        @Override public String cookieFor(String url) { return null; }
        @Override public void armDownloads(FileCaptureFlow.DownloadSink s) { if (s != null) armed++; else disarmed++; sink = s; }

        void runAll() { int guard = 0; while (!queue.isEmpty() && guard++ < 10000) { Object[] t = queue.poll(); now = (Long) t[0]; ((Runnable) t[2]).run(); } }
        int count(String prefix) { int n = 0; for (String l : log) if (l.startsWith(prefix)) n++; return n; }
    }

    static final class Result implements FileCaptureFlow.Listener {
        File file; String mime, reason; int files, fails;
        @Override public void onFile(File f, String m) { file = f; mime = m; files++; }
        @Override public void onFailed(String r) { reason = r; fails++; }
    }

    static File tmp;
    static FileCaptureFlow.Request req(String name) {
        FileCaptureFlow.Request r = new FileCaptureFlow.Request();
        r.conversationId = "conv-1"; r.displayName = name; r.captureId = "cap"; r.tmpDir = tmp; r.downloadHosts = DOWNLOAD_HOSTS; r.timeoutMs = 60_000; r.maxBytes = 1000; r.userAgent = "UA/0";
        return r;
    }
    static String link(String name, String href, int idx, int fromEnd, String msgId) { return link(name, href, idx, fromEnd).replace("\"mime\":\"\"}", "\"mime\":\"\",\"msgId\":\"" + msgId + "\"}"); }
    static String link(String name, String href, int idx, int fromEnd) { return "{\"name\":" + FileCaptureFlow.jsLiteral(name) + ",\"kind\":\"link\",\"index\":" + idx + ",\"fromEnd\":" + fromEnd + ",\"href\":\"" + href + "\",\"mime\":\"\"}"; }
    static String button(String name, int idx, int fromEnd) { return "{\"name\":" + FileCaptureFlow.jsLiteral(name) + ",\"kind\":\"button\",\"index\":" + idx + ",\"fromEnd\":" + fromEnd + "}"; }
    static int tmpFiles() { File[] f = tmp.listFiles(); return f == null ? 0 : f.length; }
    static byte[] bytes(String s) { return s.getBytes(StandardCharsets.UTF_8); }

    static Result run(Page p, FileCaptureFlow.Request r) { Result res = new Result(); new FileCaptureFlow(p, r, res).start(); p.runAll(); return res; }

    public static void main(String[] args) throws Exception {
        tmp = Files.createTempDirectory("flow-test").toFile();
        tmp.deleteOnExit();

        // 1. the normal path: a link on the page's own host, fetched by the page, pulled in chunks
        Page p = new Page();
        p.offersJson = "[" + link("report.txt", "https://claude.ai/files/1", 0, 0) + "]";
        p.fileBytes = bytes("The quick brown fox"); p.fileMime = "text/plain"; p.pollsBeforeReady = 3;
        Result r = run(p, req("report.txt"));
        check(r.files == 1 && r.fails == 0 && "text/plain".equals(r.mime) && Arrays.equals(Files.readAllBytes(r.file.toPath()), bytes("The quick brown fox")), "a link offer is fetched by the page and pulled chunk by chunk into the exact bytes");
        check(p.count("window.__agc.captureChunk") == 5 && p.count("window.__agc.captureStatus") == 4 && p.count("window.__agc.captureEnd") == 1 && p.armed == 0, "chunks are pulled once each, the status is polled until ready, the page is told to free the file, no download is armed");
        r.file.delete();

        // 2. empty file and mime fallback
        p = new Page(); p.offersJson = "[{\"name\":\"e.bin\",\"kind\":\"link\",\"index\":0,\"fromEnd\":0,\"href\":\"https://claude.ai/e\",\"mime\":\"application/x-e\"}]"; p.fileBytes = new byte[0]; p.fileMime = "";
        r = run(p, req("e.bin"));
        check(r.files == 1 && r.file.length() == 0 && "application/x-e".equals(r.mime), "an empty file is delivered, and a type missing from the page falls back to the offer's type");
        r.file.delete();

        // 3. before touching the page script: the page must be on the file's conversation
        p = new Page(); p.conversation = "conv-OTHER"; p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]";
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.files == 0 && r.reason.contains("open that conversation") && p.log.isEmpty(), "on another conversation nothing is asked of the page at all");
        p = new Page(); p.conversation = null;
        r = run(p, req("a.txt"));
        check(r.fails == 1 && p.log.isEmpty(), "not on any conversation: refused without touching the page");
        r = run(new Page(), req(""));
        check(r.fails == 1 && r.reason.contains("no file name"), "an empty file name is refused");

        // 4. not found / ambiguous: never guessed
        p = new Page(); p.offersJson = "[" + link("other.txt", "https://claude.ai/o", 0, 0) + "]";
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("a.txt") && p.count("window.__agc.capture") == 0, "a missing file fails with its name and nothing is fetched");
        p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/1", 0, 0) + "," + link("a.txt", "https://claude.ai/2", 1, 0) + "]";
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("more than one") && p.count("window.__agc.capture") == 0, "two different files with one name fail and nothing is fetched");
        p = new Page(); p.offersJson = "not json";
        r = run(p, req("a.txt"));
        check(r.fails == 1, "unreadable page output fails closed");

        // 5. the page refuses, or its fetch fails
        p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]"; p.beginRefuses = true;
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("offer-changed"), "a page that says the offer changed fails the capture");
        p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]"; p.fetchError = "http-404"; p.fileBytes = bytes("x");
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("http-404") && p.count("window.__agc.captureEnd") == 1 && tmpFiles() == 0, "a failed page fetch is reported, the page is told to free it, nothing is left behind");

        // 6. size limits
        p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]"; p.fileBytes = new byte[2000];
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("larger") && p.count("window.__agc.captureChunk") == 0 && tmpFiles() == 0, "a file over the cap is refused before any chunk is pulled");

        // 7. damaged transfers leave nothing behind
        for (int k = 0; k < 4; k++) {
            p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]"; p.fileBytes = bytes("0123456789ABCDEF");
            String what;
            if (k == 0) { p.missingChunk = true; what = "a chunk the page no longer has"; }
            else if (k == 1) { p.brokenChunk = true; what = "a chunk that is not valid base64"; }
            else if (k == 2) { p.announcedSizeDelta = 3; what = "a size that differs from what was announced"; }
            else { p.shortChunks = true; what = "a short chunk"; }
            r = run(p, req("a.txt"));
            check(r.fails == 1 && r.files == 0 && tmpFiles() == 0 && p.count("window.__agc.captureEnd") == 1, what + " fails the capture and leaves no file");
        }

        // 8. time
        p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]"; p.fileBytes = bytes("x"); p.neverReady = true;
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("in time") && r.files == 0, "a page that stays pending forever fails at the deadline");
        p = new Page(); p.hang = true;
        r = run(p, req("a.txt"));
        check(r.fails == 1 && r.reason.contains("in time") && p.now <= 1000 + 60_000 + 500 + 1, "a page that never answers at all is failed by the timer");

        // 9. click-only offers: arm first, click, then the page's download decides
        p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0) + "]"; p.downloadOnClick = "blob:https://claude.ai/abc"; p.fileBytes = bytes("a,b\n1,2\n"); p.fileMime = "text/csv";
        r = run(p, req("data.csv"));
        check(r.files == 1 && "text/csv".equals(r.mime) && Arrays.equals(Files.readAllBytes(r.file.toPath()), bytes("a,b\n1,2\n")), "a button offer: the click starts the page's download and the blob is pulled");
        check(p.armed == 1 && p.disarmed >= 1 && p.sink == null && p.log.get(1).startsWith("window.__agc.clickOffer({") && p.count("window.__agc.captureUrl") == 1, "downloads are armed before the click and disarmed afterwards");
        r.file.delete();
        p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0) + "]"; p.downloadOnClick = "https://files.claudeusercontent.com/s/xyz?sig=1";
        r = run(p, req("data.csv"));
        check(r.files == 0 && p.backgrounds == 1 && p.count("window.__agc.capture") == 0, "a download from another allowed host is fetched natively (off the main thread), not through the page");
        check(r.fails == 1 && r.reason.contains("in time"), "and a native download that never finishes is failed by the deadline timer");
        for (String bad : new String[]{"https://evil.example/x", "http://claude.ai/x", "javascript:alert(1)", "file:///x", "", "https://claude.ai.evil.example/x"}) {
            p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0) + "]"; p.downloadOnClick = bad;
            r = run(p, req("data.csv"));
            check(r.fails == 1 && r.files == 0 && p.backgrounds == 0 && p.count("window.__agc.capture") == 0, "a download address '" + bad + "' is refused");
        }
        p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0) + "]"; p.clickRefuses = true;
        r = run(p, req("data.csv"));
        check(r.fails == 1 && r.reason.contains("could not be opened") && p.sink == null, "a click the page refuses fails and disarms downloads");
        p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0) + "]"; p.downloadOnClick = "blob:https://claude.ai/abc"; p.silentClick = true;
        r = run(p, req("data.csv"));
        check(r.fails == 1 && r.reason.contains("did not start a download") && p.sink == null, "no download after the click fails at the deadline and disarms downloads");
        p = new Page(); p.offersJson = "[" + link("sb.txt", "sandbox:/mnt/data/sb.txt", 0, 0) + "]"; p.downloadOnClick = "blob:https://claude.ai/abc"; p.fileBytes = bytes("s");
        r = run(p, req("sb.txt"));
        check(r.files == 1 && p.count("window.__agc.clickOffer") == 1 && p.count("window.__agc.captureBegin") == 0, "a sandbox: link is clicked, never fetched directly");
        r.file.delete();
        p = new Page(); p.offersJson = "[" + link("x.bin", "https://files.claudeusercontent.com/direct", 0, 0) + "]";
        r = run(p, req("x.bin"));
        check(p.backgrounds == 1 && p.count("window.__agc.capture") == 0, "a direct link to another allowed host is downloaded natively");
        p = new Page(); p.offersJson = "[" + link("x.bin", "https://evil.example/direct", 0, 0) + "]";
        r = run(p, req("x.bin"));
        check(r.fails == 1 && p.backgrounds == 0, "a direct link to a host that is not allowed is refused");

        // 10. cancel is silent and frees everything
        p = new Page(); p.offersJson = "[" + link("a.txt", "https://claude.ai/a", 0, 0) + "]"; p.fileBytes = bytes("0123456789"); p.pollsBeforeReady = 5;
        Result cr = new Result();
        FileCaptureFlow f = new FileCaptureFlow(p, req("a.txt"), cr);
        f.start();
        f.cancel();
        p.runAll();
        check(cr.files == 0 && cr.fails == 0 && p.count("window.__agc.captureEnd") == 1 && tmpFiles() == 0, "a cancelled flow reports nothing, frees the page's copy and keeps no file");
        f.cancel(); f.start();
        check(cr.files == 0 && cr.fails == 0, "cancelling again or starting after the end does nothing");
        p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0) + "]"; p.downloadOnClick = "blob:https://claude.ai/abc"; p.fileBytes = bytes("x");
        cr = new Result(); f = new FileCaptureFlow(p, req("data.csv"), cr); f.start(); f.cancel(); p.runAll();
        check(cr.files == 0 && cr.fails == 0 && p.sink == null && p.count("window.__agc.captureUrl") == 0, "cancelling while waiting for a download disarms it and ignores the late download");

        // 10b. THE RETRY BUG: old report.pdf, later a newer DIFFERENT report.pdf; the old artifact's capture must never take the new bytes
        {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.createRoom("A", "A", RoomKind.LIVE, 1); s.upsertParticipant("A", "claude", 0);
            s.putBinding("A", new ProviderBinding("claude", "conv-1", "l", "t", 1L));
            s.appendMessage("A", "u1", "USER", "user", "make a report", null, 10L);
            s.appendMessage("A", "r1", "PROVIDER", "claude", "v1 attached", "u1", 11L);
            s.createDelivery("d1", "A", "u1", "claude", 1L, 12L); s.recordProviderIds("d1", "pu1", "asst-1"); s.setDeliveryReply("d1", "r1");
            s.createArtifact("old", "A", "claude", s.activeBindingId("A", "claude"), "report.pdf", "", 13L); s.attachArtifact("r1", "old", 0);
            s.appendMessage("A", "u2", "USER", "user", "update it", null, 20L);
            s.appendMessage("A", "r2", "PROVIDER", "claude", "v2 attached", "u2", 21L);
            s.createDelivery("d2", "A", "u2", "claude", 3L, 22L); s.recordProviderIds("d2", "pu2", "asst-2"); s.setDeliveryReply("d2", "r2");
            s.createArtifact("new", "A", "claude", s.activeBindingId("A", "claude"), "report.pdf", "", 23L); s.attachArtifact("r2", "new", 0);
            String refOld = s.sourceReplyRef("old"), refNew = s.sourceReplyRef("new");
            check("asst-1".equals(refOld) && "asst-2".equals(refNew), "the store resolves each file to the reply that produced it");

            p = new Page();
            p.offersJson = "[" + link("report.pdf", "https://claude.ai/v1", 0, 2, "asst-1") + "," + link("report.pdf", "https://claude.ai/v2", 1, 0, "asst-2") + "]";
            p.bytesByHref.put("https://claude.ai/v1", bytes("OLD VERSION")); p.bytesByHref.put("https://claude.ai/v2", bytes("NEW VERSION"));
            FileCaptureFlow.Request rq = req("report.pdf"); rq.replyRef = refOld;
            r = run(p, rq);
            check(r.files == 1 && Arrays.equals(Files.readAllBytes(r.file.toPath()), bytes("OLD VERSION")), "RETRY of the OLD artifact captures the OLD file, never the newer one with the same name");
            r.file.delete();
            p = new Page();
            p.offersJson = "[" + link("report.pdf", "https://claude.ai/v1", 0, 2, "asst-1") + "," + link("report.pdf", "https://claude.ai/v2", 1, 0, "asst-2") + "]";
            p.bytesByHref.put("https://claude.ai/v1", bytes("OLD VERSION")); p.bytesByHref.put("https://claude.ai/v2", bytes("NEW VERSION"));
            rq = req("report.pdf"); rq.replyRef = refNew;
            r = run(p, rq);
            check(r.files == 1 && Arrays.equals(Files.readAllBytes(r.file.toPath()), bytes("NEW VERSION")), "the NEW artifact captures the new file");
            r.file.delete();
            // the old reply has scrolled out of the page: fail, never fall back to the newer file
            p = new Page();
            p.offersJson = "[" + link("report.pdf", "https://claude.ai/v2", 0, 0, "asst-2") + "]";
            p.bytesByHref.put("https://claude.ai/v2", bytes("NEW VERSION"));
            rq = req("report.pdf"); rq.replyRef = refOld;
            r = run(p, rq);
            check(r.fails == 1 && r.files == 0 && r.reason.contains("no longer on the page") && p.count("window.__agc.capture") == 0 && tmpFiles() == 0, "when the old reply is gone the retry FAILS (nothing is fetched) instead of taking the newer file");
            // a page that gives no ids: the first capture takes the newest, which is exactly why a manual retry is refused by the service
            p = new Page();
            p.offersJson = "[" + link("report.pdf", "https://claude.ai/v2", 0, 0) + "]";
            p.bytesByHref.put("https://claude.ai/v2", bytes("NEW VERSION"));
            rq = req("report.pdf"); rq.replyRef = "";
            r = run(p, rq);
            check(r.files == 1, "without an id the automatic first capture still works (newest message)");
            if (r.file != null) r.file.delete();
        }

        // 10c. TIME-OF-CHECK / TIME-OF-USE: the page changes between the app's scan and the page's action. The page re-checks the full fingerprint and refuses.
        String oldOffer = link("report.pdf", "https://claude.ai/v1", 0, 2, "asst-1");
        String[] changed = {
                "[" + link("report.pdf", "https://claude.ai/v2", 0, 0, "asst-2") + "," + link("report.pdf", "https://claude.ai/v1", 1, 3, "asst-1") + "]",   // a newer same-name offer is inserted and the old one moves
                "[" + link("report.pdf", "https://claude.ai/SWAPPED", 0, 2, "asst-1") + "]",                                                                      // same place, same name, same reply, a DIFFERENT address
                "[" + link("report.pdf", "https://claude.ai/v1", 0, 2, "asst-OTHER") + "]",                                                                       // only the reply id differs
                "[" + link("report.pdf", "https://claude.ai/v1", 0, 5, "asst-1") + "]",                                                                           // only the position among the messages differs
                "[" + button("report.pdf", 0, 2) + "]",                                                                                                           // a button took the place of the link
                "[]"};
        String[] why = {"a newer same-name offer is inserted before the capture", "the address is swapped for another one", "only the reply id changes", "only the message position changes", "a button replaces the link", "the offer disappears"};
        for (int k = 0; k < changed.length; k++) {
            p = new Page(); p.offersJson = "[" + oldOffer + "]"; p.nextOffersJson = changed[k]; p.fileBytes = bytes("NEW"); p.bytesByHref.put("https://claude.ai/v2", bytes("NEW")); p.bytesByHref.put("https://claude.ai/SWAPPED", bytes("NEW"));
            FileCaptureFlow.Request rq = req("report.pdf"); rq.replyRef = "asst-1";
            r = run(p, rq);
            check(r.fails == 1 && r.files == 0 && p.fetchedHrefs.isEmpty() && p.capState.equals("none") && tmpFiles() == 0, "capture: " + why[k] + " -> refused, nothing is fetched");
        }
        p = new Page(); p.offersJson = "[" + oldOffer + "]"; p.fileBytes = bytes("OLD"); p.bytesByHref.put("https://claude.ai/v1", bytes("OLD"));
        { FileCaptureFlow.Request rq = req("report.pdf"); rq.replyRef = "asst-1"; r = run(p, rq); }
        check(r.files == 1 && p.fetchedHrefs.equals(Arrays.asList("https://claude.ai/v1")) && p.log.stream().anyMatch(l -> l.startsWith("window.__agc.captureBegin(") && l.contains("\"href\":\"https://claude.ai/v1\"") && l.contains("\"msgId\":\"asst-1\"") && l.contains("\"fromEnd\":2") && l.contains("\"kind\":\"link\"") && l.contains("\"index\":0")), "control: an unchanged page works, and the page was sent the complete fingerprint with exactly the approved address");
        if (r.file != null) r.file.delete();
        String[] changedClick = {"[" + button("data.csv", 0, 0).replace("\"fromEnd\":0}", "\"fromEnd\":0,\"msgId\":\"asst-NEW\"}") + "]", "[" + button("other.csv", 0, 0) + "]", "[" + link("data.csv", "https://claude.ai/x", 0, 0) + "]", "[]"};
        for (int k = 0; k < changedClick.length; k++) {
            p = new Page(); p.offersJson = "[" + button("data.csv", 0, 0).replace("\"fromEnd\":0}", "\"fromEnd\":0,\"msgId\":\"asst-1\"}") + "]"; p.nextOffersJson = changedClick[k]; p.downloadOnClick = "blob:https://claude.ai/abc"; p.fileBytes = bytes("x");
            FileCaptureFlow.Request rq = req("data.csv"); rq.replyRef = "asst-1";
            r = run(p, rq);
            check(r.fails == 1 && r.files == 0 && p.clicked == 0 && p.sink == null && p.count("window.__agc.captureUrl") == 0, "click: the button changed before the click (variant " + k + ") -> nothing is clicked and downloads are disarmed");
        }

        // 10d. a link is never clicked just because it cannot be fetched
        for (String badHref : new String[]{"javascript:alert(1)", "file:///etc/passwd", "http://claude.ai/x", "ftp://claude.ai/x", "", "intent://x#Intent;end"}) {
            p = new Page(); p.offersJson = "[" + link("a.txt", badHref, 0, 0) + "]"; p.downloadOnClick = "blob:https://claude.ai/abc"; p.fileBytes = bytes("x");
            r = run(p, req("a.txt"));
            check(r.fails == 1 && r.files == 0 && p.clicked == 0 && p.armed == 0 && p.count("window.__agc.click") == 0 && p.count("window.__agc.capture") == 0 && p.backgrounds == 0, "a LINK to '" + badHref + "' is refused: no click, no fetch, no download armed");
        }
        p = new Page(); p.offersJson = "[" + link("sb.txt", "sandbox:/mnt/data/sb.txt", 0, 0) + "]"; p.downloadOnClick = "blob:https://claude.ai/abc"; p.fileBytes = bytes("s");
        r = run(p, req("sb.txt"));
        check(r.files == 1 && p.clicked == 1, "the provider's own sandbox: link is still clicked");
        if (r.file != null) r.file.delete();

        // 11. names with quotes, backslashes, line breaks and angle brackets survive the trip into script text
        String raw = "we\"ird\\na\nme</script>\u2028.txt";
        String clean = ArtifactNames.clean(raw);
        p = new Page(); p.offersJson = "[" + link(raw, "https://claude.ai/w", 0, 0) + "]"; p.fileBytes = bytes("w");
        r = run(p, req(clean));
        check(r.files == 1 && p.log.stream().noneMatch(l -> l.indexOf('\n') >= 0 || l.indexOf('\u2028') >= 0 || l.contains("</script")), "an awkward file name is sent to the page as a safe script string (the page still finds the offer by its exact name)");
        if (r.file != null) r.file.delete();
        check(FileCaptureFlow.jsLiteral("a\"b\\c\n\u2029<>").equals("\"a\\\"b\\\\c\\u000a\\u2029\\u003c\\u003e\""), "the script string escaping is exact");

        System.out.println("File capture flow: " + checks + " checks, " + failures + " failures");
        if (failures > 0) System.exit(1);
    }
}
