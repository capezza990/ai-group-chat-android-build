import com.aigroupchat.bridge.engine.ProviderSurfaceLease;

public final class ProviderSurfaceLeaseTest {
    private static int checks;

    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        ProviderSurfaceLease lease = new ProviderSurfaceLease();

        ProviderSurfaceLease.Token first = lease.acquire("delivery-1");
        check(first != null, "first holder acquires");
        check(lease.isCurrent(first), "first token is current");
        check(lease.acquire("delivery-1") == first, "same holder reuses token");
        check(lease.acquire("delivery-2") == null, "different holder is excluded");
        check("delivery-1".equals(lease.holder()), "holder is reported");

        check(lease.release(first), "current holder releases");
        check(!lease.isHeld(), "released lease is idle");
        ProviderSurfaceLease.Token second = lease.acquire("delivery-2");
        check(second != null && second != first, "next holder receives new token");

        check(lease.retire(), "dead holder is retired");
        check(!lease.isCurrent(second), "retired token is invalid");
        ProviderSurfaceLease.Token third = lease.acquire("delivery-3");
        check(third != null, "surface can be acquired after retirement");
        check(!lease.release(second), "late stale release cannot unlock new holder");
        check(lease.isCurrent(third), "new holder remains current");
        check(lease.release(third), "new holder releases normally");
        check(!lease.retire(), "retiring an idle lease is a no-op");

        System.out.println("Provider surface lease: " + checks + " checks, 0 failures");
    }
}
