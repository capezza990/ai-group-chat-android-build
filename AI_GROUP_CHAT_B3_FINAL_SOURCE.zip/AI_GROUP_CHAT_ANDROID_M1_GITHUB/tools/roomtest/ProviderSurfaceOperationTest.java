import com.aigroupchat.bridge.engine.ProviderSurfaceLease;
import com.aigroupchat.bridge.engine.ProviderSurfaceOperation;

public final class ProviderSurfaceOperationTest {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        ProviderSurfaceLease lease = new ProviderSurfaceLease();
        ProviderSurfaceOperation op = new ProviderSurfaceOperation(lease);

        ProviderSurfaceOperation.Stage one = op.beginStage("binding-a");
        check(one != null && one.expectedVisibleCount == 1, "first upload starts");
        check(op.beginStage("binding-a") == null, "a second upload cannot overlap");
        check(op.markStaged(one) && op.stagedCount() == 1, "first file becomes staged");
        long idleV = op.version();
        check(op.isIdleStaged("binding-a", idleV) && !op.hasActiveTurn() && !op.hasActiveStage(), "a completed stage is an idle retained batch eligible for bounded cleanup");
        ProviderSurfaceOperation.Stage two = op.beginStage("binding-a");
        check(two != null && two.expectedVisibleCount == 2, "second file reuses batch sequentially");
        check(op.markStaged(two) && op.stagedCount() == 2, "second file becomes staged");
        check(op.beginStage("binding-b") == null, "another binding cannot reuse the batch");

        ProviderSurfaceOperation.Turn turn = op.beginTurn("binding-a");
        check(turn != null && op.isCurrent(turn), "send reuses the staged batch lease");
        check(op.hasActiveTurn() && !op.isIdleStaged("binding-a"), "an active turn is never eligible for staged-surface cleanup");
        check(op.beginStage("binding-a") == null && op.beginTurn("binding-a") == null, "nothing mutates the page during the turn");
        check(op.finishTurn(turn) && !op.isHeld() && !lease.isHeld(), "accepted/failed turn releases the lease");
        check(!op.finishTurn(turn), "late turn completion is ignored");

        ProviderSurfaceOperation.Stage cancelled = op.beginStage("binding-a");
        check(cancelled != null && op.retire(), "Stop retires an upload");
        check(!op.markStaged(cancelled), "late upload success after Stop is ignored");
        ProviderSurfaceOperation.Stage retry = op.beginStage("binding-a");
        check(retry != null && retry != cancelled, "retry gets a fresh operation");
        lease.retire(); // renderer/page death underneath the session
        check(!op.isCurrent(retry), "dead-holder cleanup invalidates the operation token");
        check(op.beginTurn("binding-a") == null, "invalid retained token is never reused");
        check(op.retire(), "invalid session can still be cleared locally");

        ProviderSurfaceOperation.Stage timedOut = op.beginStage("binding-a");
        check(timedOut != null && op.retire(), "upload timeout retires the whole batch");
        check(!op.markStaged(timedOut), "late chooser/visibility callback after timeout is ignored");

        ProviderSurfaceOperation.Turn plain = op.beginTurn("binding-a");
        check(plain != null && op.stagedCount() == 0, "text-only turn also owns the surface");
        check(op.finishTurn(plain), "text-only turn releases normally");

        // review additions: the idle checks must be exact
        ProviderSurfaceLease lease3 = new ProviderSurfaceLease();
        ProviderSurfaceOperation op3 = new ProviderSurfaceOperation(lease3);
        ProviderSurfaceOperation.Stage s1 = op3.beginStage("conv-a");
        check(s1 != null && op3.hasActiveStage() && !op3.hasActiveTurn() && !op3.isIdleStaged("conv-a"), "a running upload is not an idle batch");
        check(op3.markStaged(s1) && !op3.hasActiveStage(), "once staged, no upload is running");
        long v1 = op3.version();
        check(op3.isIdleStaged("conv-a", v1) && op3.isIdleStaged("conv-a"), "the retained conversation's batch is idle");
        check(!op3.isIdleStaged("conv-b") && !op3.isIdleStaged("conv-b", v1), "an idle batch belongs to ITS conversation only");
        ProviderSurfaceOperation.Stage s2 = op3.beginStage("conv-a");
        check(s2 != null && op3.markStaged(s2), "a newer file is staged");
        check(!op3.isIdleStaged("conv-a", v1) && op3.isIdleStaged("conv-a", op3.version()), "an older expiry timer is stale after newer activity");

        // captures (fetching a file an AI produced) need the page for themselves
        ProviderSurfaceLease leaseC = new ProviderSurfaceLease();
        ProviderSurfaceOperation opC = new ProviderSurfaceOperation(leaseC);
        ProviderSurfaceOperation.Capture cap = opC.beginCapture("conv-a");
        check(cap != null && opC.hasActiveCapture() && opC.isCurrent(cap) && opC.isHeld() && "conv-a".equals(opC.bindingId()), "a capture takes the free surface");
        check(opC.beginCapture("conv-a") == null && opC.beginStage("conv-a") == null && opC.beginTurn("conv-a") == null, "nothing else can start on the same surface while a capture runs, not even for the same conversation");
        check(opC.finishCapture(cap) && !opC.isHeld() && !opC.hasActiveCapture() && !opC.isCurrent(cap) && !opC.finishCapture(cap), "finishing a capture releases the surface exactly once");
        check(opC.beginCapture("") == null && opC.beginCapture(null) == null, "a capture needs a conversation");
        ProviderSurfaceOperation.Stage stageC = opC.beginStage("conv-a");
        check(stageC != null && opC.beginCapture("conv-a") == null, "a capture is refused while an upload holds the surface");
        check(opC.markStaged(stageC) && opC.beginCapture("conv-a") == null, "a capture is refused while a staged batch is waiting to be sent");
        check(opC.retire() && opC.beginCapture("conv-a") != null, "after the batch is retired a capture can start");
        check(opC.retire() && opC.beginCapture("conv-a") != null && opC.retire() && opC.beginTurn("conv-a") != null && opC.beginCapture("conv-a") == null, "a capture is refused while a turn runs");
        check(opC.retire(), "the turn from the previous check is ended");
        ProviderSurfaceOperation opD = new ProviderSurfaceOperation(leaseC);
        ProviderSurfaceOperation.Capture capD = opD.beginCapture("conv-b");
        check(capD != null && new ProviderSurfaceOperation(leaseC).beginCapture("conv-b") == null, "the lease keeps two operation objects from using the same surface");
        check(opD.retire() && !opD.isCurrent(capD) && !opD.finishCapture(capD) && opD.beginCapture("conv-b") != null, "retire() ends a capture (Stop, renderer loss) and a stale capture handle is dead");

        System.out.println("Provider surface operation: " + checks + " checks, 0 failures");
    }
}
