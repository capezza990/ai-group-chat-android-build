import com.aigroupchat.bridge.engine.ProviderTransferIdentity;
import com.aigroupchat.bridge.room.ArtifactTransfer;
import com.aigroupchat.bridge.room.BindingRecord;
import com.aigroupchat.bridge.room.TransferState;

import java.util.Arrays;

public final class ProviderTransferIdentityTest {
    private static int checks;
    private static void check(boolean v, String m) { checks++; if (!v) throw new AssertionError(m); }

    public static void main(String[] args) {
        BindingRecord active = new BindingRecord("row-X", "room-A", "chatgpt", BindingRecord.ACTIVE, "thread-Y", "/c/Y", "Y", 1L);
        ArtifactTransfer t = new ArtifactTransfer("art", "room-A", "chatgpt", "row-X", TransferState.PENDING, 0, "", 1L);
        ProviderTransferIdentity.Target target = ProviderTransferIdentity.forUpload(t, Arrays.asList(active));
        check(target != null && target.bindingRowId.equals("row-X") && target.conversationId.equals("thread-Y"), "row id resolves to its separate provider conversation id");
        check(!target.conversationId.equals(t.bindingId), "the old bug (treating row id as provider thread id) is detectably wrong");
        check(target.matchesPhysical("chatgpt", "thread-Y"), "the correct physical provider conversation matches");
        check(!target.matchesPhysical("chatgpt", "thread-Z"), "a wrong physical conversation is refused");
        ArtifactTransfer wrongRow = new ArtifactTransfer("art", "room-A", "chatgpt", "thread-Y", TransferState.PENDING, 0, "", 1L);
        check(ProviderTransferIdentity.forUpload(wrongRow, Arrays.asList(active)) == null, "a provider conversation id cannot masquerade as the binding-row id");
        BindingRecord retired = active.copy(); retired.state = BindingRecord.RETIRED;
        check(ProviderTransferIdentity.forUpload(t, Arrays.asList(retired)) == null, "new uploads refuse a retired binding row");
        check(ProviderTransferIdentity.forCleanup("room-A", "chatgpt", "row-X", Arrays.asList(retired)) != null, "cleanup can still resolve a retired real conversation");
        check(ProviderTransferIdentity.forCleanup("room-B", "chatgpt", "row-X", Arrays.asList(active)) == null, "another room cannot reuse the row");
        // review additions: every part of the identity must really matter
        BindingRecord otherProvider = new BindingRecord("row-X", "room-A", "claude", BindingRecord.ACTIVE, "thread-Y", "/c/Y", "Y", 1L);
        BindingRecord otherRoom = new BindingRecord("row-X", "room-B", "chatgpt", BindingRecord.ACTIVE, "thread-Y", "/c/Y", "Y", 1L);
        check(ProviderTransferIdentity.forUpload(t, Arrays.asList(otherProvider)) == null, "a row that belongs to another AI is refused");
        check(ProviderTransferIdentity.forUpload(t, Arrays.asList(otherRoom)) == null, "a row that belongs to another room is refused");
        check(!target.matchesPhysical("claude", "thread-Y"), "the right thread id on the wrong provider page is refused");
        BindingRecord neverOpened = active.copy(); neverOpened.state = BindingRecord.PENDING_NEW;
        check(ProviderTransferIdentity.forCleanup("room-A", "chatgpt", "row-X", Arrays.asList(neverOpened)) == null, "a binding that was never opened is never a cleanup target");
        System.out.println("Provider transfer identity: " + checks + " checks, 0 failures");
    }
}
