import com.aigroupchat.bridge.engine.ProviderBinding;
import com.aigroupchat.bridge.room.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Deterministic harness for the canonical-room core (no Android, no network). Run: tools/roomtest/run_tests.sh */
public final class RoomControllerTest {
    static int checks, failures;
    static final String ROOM = "default";

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) { failures++; System.out.println("    FAIL: " + what); }
    }

    static final class Fixture {
        final InMemoryRoomStore store = new InMemoryRoomStore();
        final MockProvider a = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
        final MockProvider b = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
        final List<String> finished = new ArrayList<>();
        final List<RoomMessage> seen = new ArrayList<>();
        final AtomicInteger clock = new AtomicInteger(1000);
        RoomController c;

        Fixture() { store.ensureMockProvider("mock-delta", "Mock Delta"); c = controller(); c.addParticipant("chatgpt", false); c.addParticipant("claude", false); }

        RoomController controller() {
            RoomController rc = new RoomController(store, ROOM, new RoomController.Events() {
                @Override public void onMessage(RoomMessage m) { seen.add(m); }
                @Override public void onRunFinished(String s) { finished.add(s); }
            }, () -> clock.incrementAndGet(), new java.util.function.Supplier<String>() {
                int n; public String get() { return "id" + (++n) + "-" + System.nanoTime(); }
            });
            rc.registerProvider(a);
            rc.registerProvider(b);
            return rc;
        }

        List<RoomMessage> all() { return store.messagesBetween(ROOM, 0, Long.MAX_VALUE); }
        long count(String type) { return all().stream().filter(m -> m.authorType.equals(type)).count(); }
        RoomParticipant part(String id) { return store.participants(ROOM).stream().filter(p -> p.providerId.equals(id)).findFirst().get(); }
    }


    static Object unwrap(java.lang.reflect.Method m, Object target, Object[] a) throws Throwable {
        try { return m.invoke(target, a); } catch (java.lang.reflect.InvocationTargetException e) { throw e.getCause(); }
    }

    interface T { void run() throws Exception; }
    static void test(String name, T t) {
        int before = failures;
        try { t.run(); } catch (Throwable e) { failures++; System.out.println("    EXCEPTION: " + e); e.printStackTrace(System.out); }
        System.out.println((failures == before ? "PASS  " : "FAIL  ") + name);
    }

    public static void main(String[] args) {
        test("user message is persisted before dispatch; delivery is SENDING at send time", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.a.onSend = prompt -> {
                boolean userSaved = f.store.latestMessages(ROOM, 5).stream().anyMatch(m -> m.authorType.equals("USER") && m.text.equals("hello"));
                boolean sending = f.store.deliveriesInState(DeliveryState.SENDING).size() == 1;
                ok[0] = userSaved && sending;
            };
            f.c.submitUserMessage("hello");
            check(ok[0], "at send(): user message saved and delivery SENDING");
            check(f.count("PROVIDER") == 1, "reply stored");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 1, "delivery CAPTURED");
        });

        test("provider failure leaves the canonical user message intact and the delivery FAILED", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.FAIL_BEFORE_SEND;
            f.c.submitUserMessage("keep me");
            check(f.count("USER") == 1 && f.count("PROVIDER") == 0, "user message kept, no reply");
            check(f.store.deliveriesInState(DeliveryState.FAILED).size() == 1, "delivery FAILED (safe to retry)");
            check(f.part("chatgpt").contextSeq == 0, "context not advanced by a failed request");
            check(!f.c.isBusy(), "run cleared");
            f.a.behavior = MockProvider.Behavior.REPLY;
            check(f.c.submitUserMessage("again") != null, "next message accepted after a failure");
            check(f.count("PROVIDER") == 1, "next message answered");
        });

        test("captured reply is persisted before the next provider receives it (collaborate)", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            final boolean[] ok = {false};
            f.b.onSend = prompt -> {
                boolean stored = f.store.latestMessages(ROOM, 10).stream().anyMatch(m -> m.authorType.equals("PROVIDER") && m.authorId.equals("chatgpt"));
                ok[0] = stored && prompt.contains("ChatGPT reply #1");
            };
            f.c.submitUserMessage("design X");
            check(ok[0], "ChatGPT's reply was already stored and is in Claude's prompt");
            check(f.count("PROVIDER") == 3, "propose, review, revise = 3 provider messages");
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 3, "3 deliveries CAPTURED");
            check(f.finished.size() == 1 && f.finished.get(0).equals("done"), "run finished cleanly");
        });

        test("restart: SENDING and SENT become UNCERTAIN and nothing is auto-resent", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("one");
            check(f.store.deliveriesInState(DeliveryState.SENDING).size() == 1, "stuck in SENDING");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            g.c.submitUserMessage("two");
            check(g.store.deliveriesInState(DeliveryState.SENT).size() == 1, "stuck in SENT");
            // "restart": a brand-new controller on the same stores
            RoomController f2 = f.controller();
            check(f2.recoverOnStart() == 1, "f: one delivery recovered");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "f: now UNCERTAIN");
            check(f.store.deliveriesInState(DeliveryState.SENDING).isEmpty(), "f: no SENDING left");
            check(f.a.prompts.size() == 1, "f: no automatic resend (still exactly 1 prompt)");
            RoomController g2 = g.controller();
            check(g2.recoverOnStart() == 1 && g.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "g: SENT -> UNCERTAIN");
            check(g.count("USER") == 1, "canonical user message survived the restart");
        });

        test("disabled participant keeps history and binding; re-adding restores context position", () -> {
            Fixture f = new Fixture();
            f.store.putBinding(ROOM, new ProviderBinding("claude", "conv-1", "https://claude.ai/chat/conv-1", "t", 5L));
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("q1");
            long ctx = f.part("claude").contextSeq;
            check(ctx > 0, "claude accepted a request, context advanced");
            int bPrompts = f.b.prompts.size();
            f.c.removeParticipant("claude");
            check(!f.part("claude").enabled, "claude disabled");
            check(f.store.getBinding(ROOM, "claude") != null, "binding kept");
            check(f.count("PROVIDER") == 2, "old replies kept");
            f.c.submitUserMessage("q2");
            check(f.b.prompts.size() == bPrompts, "disabled participant receives nothing");
            f.c.addParticipant("claude", false);
            check(f.part("claude").enabled && f.part("claude").contextSeq == ctx, "re-enabled with the same context position");
        });

        test("duplicate provider callbacks create one message", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            f.c.submitUserMessage("dup?");
            check(f.count("PROVIDER") == 1, "exactly one provider message");
            RoomMessage m = f.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get();
            RoomMessage again = f.store.appendMessage(ROOM, m.id, "PROVIDER", "chatgpt", "different", null, 9L);
            check(again.seq == m.seq && again.text.equals(m.text), "appendMessage is idempotent on id and never rewrites text");
            check(f.count("PROVIDER") == 1, "still one after re-append");
        });

        test("router: collaborate sequences match the legacy relay", () -> {
            List<RoomParticipant> two = new ArrayList<>();
            two.add(new RoomParticipant(ROOM, "chatgpt", true, 0, 0, "UNKNOWN"));
            two.add(new RoomParticipant(ROOM, "claude", true, 1, 0, "UNKNOWN"));
            RoomSettings s1 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "chatgpt", 1, 0);
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "1 round = propose, review, revise");
            RoomSettings s2 = new RoomSettings(ROOM, RoutingMode.COLLABORATE, "claude", 2, 0);
            check(RoomRouter.plan(s2, two).toString().equals("[claude:ANSWER, chatgpt:REVIEW, claude:REVISE, chatgpt:REVIEW, claude:REVISE]"), "2 rounds, Claude first = 5 steps");
            check(new RoomSettings(ROOM, RoutingMode.COLLABORATE, "x", 9, 0).rounds == 2, "rounds clamp at 2 like the legacy control");
            List<RoomParticipant> three = new ArrayList<>(two);
            three.add(new RoomParticipant(ROOM, "gemini", true, 2, 0, "UNKNOWN"));
            check(RoomRouter.plan(s1, three).toString().equals("[chatgpt:ANSWER, claude:REVIEW, gemini:REVIEW, chatgpt:REVISE]"), "3 AIs: every other AI reviews in order");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.ASK_ALL, "", 1, 0), two).toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "ask all = independent");
            check(RoomRouter.plan(new RoomSettings(ROOM, RoutingMode.SINGLE, "claude", 1, 0), two).toString().equals("[claude:ANSWER]"), "single");
            two.get(1).enabled = false;
            check(RoomRouter.plan(s1, two).toString().equals("[chatgpt:ANSWER]"), "disabled AI is skipped; lone AI just answers");
            two.get(0).enabled = false;
            check(RoomRouter.plan(s1, two).isEmpty(), "nobody enabled = empty plan");
        });

        test("independent prompts exclude the other AI's reply; later prompts include what the AI has not seen", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.ASK_ALL, "", 1);
            f.c.submitUserMessage("first question");
            check(!f.b.prompts.get(0).contains("ChatGPT reply #1"), "Claude's independent answer did not see ChatGPT's reply");
            f.c.submitUserMessage("second question");
            String p = f.a.prompts.get(1);
            check(p.contains("Claude reply #1") && p.contains("ROOM CONTEXT"), "ChatGPT's next prompt includes Claude's earlier reply as context");
            check(!p.contains("ChatGPT reply #1"), "ChatGPT's own earlier reply is not echoed back");
            check(p.contains("REQUEST") && p.contains("[User] second question"), "request clearly separated from context");
        });

        test("context only advances for requests the provider accepted", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.c.submitUserMessage("a");
            check(f.part("chatgpt").contextSeq == 0, "SILENT (never accepted) leaves context at 0");
            f.c.stop();
            f.a.behavior = MockProvider.Behavior.REPLY;
            f.c.submitUserMessage("b");
            check(f.part("chatgpt").contextSeq > 0, "accepted request advances context");
        });

        test("store: createDelivery idempotent, transition is compare-and-set, atomic rolls back", () -> {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.ensureRoom(ROOM, 1L);
            s.upsertParticipant(ROOM, "chatgpt", 0); // a delivery needs the AI's seat in that room (the old schema let it through without one)
            RoomMessage m = s.appendMessage(ROOM, "m1", "USER", "user", "x", null, 1L);
            Delivery d1 = s.createDelivery("d1", ROOM, m.id, "chatgpt", m.seq, 1L);
            Delivery d2 = s.createDelivery("d2", ROOM, m.id, "chatgpt", m.seq, 2L);
            check(d1.id.equals(d2.id), "same (trigger, provider) returns the same delivery");
            check(s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 2L), "PENDING -> SENDING");
            check(!s.transition("d1", new DeliveryState[]{DeliveryState.PENDING}, DeliveryState.SENDING, null, 3L), "second PENDING -> SENDING is refused");
            try {
                s.atomic(() -> { s.appendMessage(ROOM, "m2", "USER", "user", "y", null, 2L); throw new IllegalStateException("boom"); });
            } catch (IllegalStateException expected) { }
            check(s.getMessage("m2") == null, "rolled back: m2 does not exist");
            check(s.appendMessage(ROOM, "m3", "USER", "user", "z", null, 3L).seq == 2, "seq not consumed by the rolled-back insert");
        });

        test("stop mid-run (C2): an accepted delivery is DRAINED, nothing further is dispatched; a timeout then makes it a neutral UNCERTAIN", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("long task");
            check(f.c.isBusy(), "busy while waiting");
            check(f.c.submitUserMessage("interrupt") == null, "a second message is refused while busy");
            f.c.stop();
            check(f.c.isBusy() && f.c.isStopping(), "C2: still draining after Stop (was: not busy)");
            check(f.store.deliveriesInState(DeliveryState.SENT).size() == 1 && f.store.deliveriesInState(DeliveryState.UNCERTAIN).isEmpty(),
                    "C2: the delivery is still SENT (observed), not UNCERTAIN yet (was: UNCERTAIN)");
            check(f.b.prompts.isEmpty(), "Claude was never asked");
            check(f.count("USER") == 1, "only the first user message exists");
            check(f.c.submitUserMessage("again") == null, "no new send while draining");
            f.a.fireTimeout("timed out while waiting for the reply");
            check(!f.c.isBusy() && !f.c.isStopping(), "the drain resolved");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "now UNCERTAIN, never resent");
            Delivery u = f.store.deliveriesInState(DeliveryState.UNCERTAIN).get(0);
            check(u.error.startsWith("stopped by user") && StatusRules.isNeutralStop(DeliveryState.UNCERTAIN, u.error), "neutral error, not a red failure: " + u.error);
            check(f.finished.get(f.finished.size() - 1).equals("stopped by user") && f.a.prompts.size() == 1, "run summary is the stop reason; nothing was resent");
        });

        test("participant removed mid-run is skipped without a crash", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.a.onSend = p -> { if (f.a.prompts.size() == 1) f.c.removeParticipant("claude"); };
            f.c.submitUserMessage("go");
            check(f.b.prompts.isEmpty(), "Claude's review turn was skipped");
            check(f.count("PROVIDER") >= 1 && !f.c.isBusy(), "run completed");
        });

        test("empty reply is UNCERTAIN, not stored, and ends the run", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.EMPTY_REPLY;
            f.c.submitUserMessage("hi");
            check(f.count("PROVIDER") == 0, "blank reply not stored");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "delivery UNCERTAIN");
        });

        test("no enabled participants: the user message is still saved", () -> {
            Fixture f = new Fixture();
            f.c.removeParticipant("chatgpt");
            f.c.removeParticipant("claude");
            RoomMessage m = f.c.submitUserMessage("anyone there?");
            check(m != null && f.count("USER") == 1, "user message persisted");
            check(f.finished.size() == 1 && f.finished.get(0).startsWith("no enabled"), "run reports nobody to answer");
        });

        test("late duplicate callbacks after the run moved on change nothing (queued scheduler, like the phone)", () -> {
            final java.util.ArrayDeque<Runnable> queue = new java.util.ArrayDeque<>();
            MockProvider.Scheduler q = (r, d) -> queue.add(r);
            InMemoryRoomStore store = new InMemoryRoomStore();
            MockProvider a = new MockProvider("chatgpt", "ChatGPT", q), b = new MockProvider("claude", "Claude", q);
            a.behavior = MockProvider.Behavior.LATE_DUPLICATE;
            b.behavior = MockProvider.Behavior.DUPLICATE_REPLY;
            RoomController c = new RoomController(store, "r", null);
            c.registerProvider(a); c.registerProvider(b);
            c.addParticipant("chatgpt", false); c.addParticipant("claude", false);
            c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 2);
            c.submitUserMessage("two rounds");
            check(c.isBusy() && c.activeProviderId().equals("chatgpt"), "A is working after submit");
            check(c.runStatus().equals("step 1 of 5: ChatGPT (answer)"), "run status reads \"" + c.runStatus() + "\"");
            int guard = 0;
            while (!queue.isEmpty() && guard++ < 100) queue.poll().run();
            long providerMsgs = store.messagesBetween("r", 0, Long.MAX_VALUE).stream().filter(m -> m.authorType.equals("PROVIDER")).count();
            check(!c.isBusy(), "run finished");
            check(providerMsgs == 5, "2 rounds = 5 provider messages exactly (no duplicates), got " + providerMsgs);
            check(store.deliveriesInState(DeliveryState.CAPTURED).size() == 5, "5 CAPTURED deliveries");
            String order = "";
            for (RoomMessage m : store.messagesBetween("r", 0, Long.MAX_VALUE)) if (m.authorType.equals("PROVIDER")) order += m.authorId.charAt(1) + ",";
            check(order.equals("h,l,h,l,h,"), "legacy 2-round order chatgpt,claude,chatgpt,claude,chatgpt, got " + order);
            check(c.runStatus().isEmpty() && c.activeProviderId() == null, "idle status is empty");
        });

        test("provider catalog is data-driven and has more than two AIs", () -> {
            check(ProviderCatalog.all().size() >= 4, "catalog offers at least 4 AIs");
            check(ProviderCatalog.nameOf("gemini").equals("Gemini") && ProviderCatalog.nameOf("unknown-x").equals("unknown-x"), "nameOf");
            Fixture f = new Fixture();
            MockProvider delta = new MockProvider("mock-delta", "Mock Delta", MockProvider.Scheduler.IMMEDIATE);
            f.c.registerProvider(delta);
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.c.submitUserMessage("two AIs");
            long before = f.count("PROVIDER");
            f.c.addParticipant("mock-delta", false);
            check(f.store.participants(ROOM).size() == 3, "a third AI joins the same room");
            f.c.submitUserMessage("three AIs");
            check(f.count("PROVIDER") - before == 4, "3 AIs, 1 round = propose, 2 reviews, revise (4 messages)");
            check(f.count("USER") == 2 && before == 3, "earlier history untouched by adding an AI");
        });

        test("scroll follow: follows at the bottom, never yanks a reader, resumes on send or return", () -> {
            ScrollFollow f = new ScrollFollow();
            check(f.shouldFollowNewContent(), "starts following");
            f.onScrolled(false);
            check(!f.shouldFollowNewContent() && !f.isFollowing(), "user scrolled up: new replies do not move the view");
            f.onScrolled(false);
            check(!f.shouldFollowNewContent(), "still reading");
            f.onUserSent();
            check(f.shouldFollowNewContent(), "sending a message follows the conversation again");
            f.onScrolled(false);
            f.onScrolled(true);
            check(f.shouldFollowNewContent(), "returning near the bottom resumes following");
        });

        test("reply cleaner strips hidden speaker headings and invisible characters", () -> {
            check(ReplyCleaner.clean("ChatGPT said:\nHello there").equals("Hello there"), "removes the hidden \"ChatGPT said:\" heading");
            check(ReplyCleaner.clean("Claude said\n\nHi").equals("Hi"), "heading without colon");
            check(ReplyCleaner.clean("  a\u200Bb\r\n\r\n\r\n\r\nc  ").equals("ab\n\nc"), "zero-width chars, CRLF and blank-line runs");
            check(ReplyCleaner.clean("Mention that ChatGPT said: nothing special").equals("Mention that ChatGPT said: nothing special"), "only a LEADING heading is removed");
            check(ReplyCleaner.clean(null).isEmpty(), "null is empty");
        });

        test("routing marker tolerates trailing decoration but rejects prose and mid-line markers", () -> {
            java.util.function.Function<String, Boolean> m = t -> RoutingMarkers.PATTERN.matcher(t).find();
            check(m.apply("text\n[[NEXT:CLAUDE]]"), "plain marker");
            check(m.apply("text\n[[NEXT:CLAUDE]] \u2776"), "marker + circled digit (the Accessibility attachment decoration)");
            check(m.apply("text\n  [[DONE]] \u2460"), "indented DONE + decoration");
            check(m.apply("[[NEXT:USER]]\u200B"), "marker + zero-width character");
            check(m.apply("a\n[[NEXT:CHATGPT]]\u2776 \u2777\nmore"), "decoration on a middle line, marker still alone on its line");
            check(!m.apply("see [[NEXT:CLAUDE]]"), "mid-line marker rejected");
            check(!m.apply("[[NEXT:CLAUDE]] and some words"), "prose after the marker rejected");
            check(!m.apply("[[NEXT:BOB]]"), "unknown target rejected");
            check(!m.apply("[[NEXT:CLAUDE]] \u2776 text"), "decoration followed by prose rejected");
            check(!m.apply("no marker here"), "no marker");
            String cleaned = RoutingMarkers.PATTERN.matcher("answer\n[[NEXT:CLAUDE]] \u2776").replaceAll("");
            check(cleaned.trim().equals("answer"), "the whole marker line including the decoration is removed from the text");
        });

        test("transcript search: counts, order, wrap-around, case-insensitive", () -> {
            java.util.List<RoomMessage> msgs = new java.util.ArrayList<>();
            msgs.add(new RoomMessage(1, "a", "r", "USER", "user", "Test the test", 1, null));
            msgs.add(new RoomMessage(2, "b", "r", "PROVIDER", "claude", "no hit here", 2, null));
            msgs.add(new RoomMessage(3, "c", "r", "PROVIDER", "chatgpt", "TEST again", 3, null));
            java.util.List<TranscriptSearch.Match> hits = TranscriptSearch.find(msgs, "test", m -> m.text);
            check(hits.size() == 3, "3 matches across messages, got " + hits.size());
            check(hits.get(0).seq == 1 && hits.get(0).start == 0 && hits.get(1).start == 9 && hits.get(2).seq == 3, "positions and order");
            check(TranscriptSearch.find(msgs, "  ", m -> m.text).isEmpty() && TranscriptSearch.find(msgs, "zzz", m -> m.text).isEmpty(), "blank / missing query");
            check(TranscriptSearch.next(2, 3) == 0 && TranscriptSearch.next(-1, 3) == 0 && TranscriptSearch.prev(0, 3) == 2 && TranscriptSearch.prev(-1, 3) == 2, "next/prev wrap");
            check(TranscriptSearch.next(0, 0) == -1, "no matches: no position");
        });

        test("status rules: stop/removal are neutral, only real failures are red", () -> {
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "stopped by user"), "user stop is not a failure");
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "participant removed"), "removal is not a failure");
            check(!StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "interrupted (app restart)"), "restart interruption is not a failure");
            check(StatusRules.isRealFailure(DeliveryState.UNCERTAIN, "timeout after 240s"), "an unexplained UNCERTAIN is a real problem");
            check(StatusRules.isRealFailure(DeliveryState.FAILED, "composer not empty"), "FAILED is a real failure");
            check(StatusRules.of(false, true, false, true) == StatusRules.Status.NEUTRAL, "neutral stop shows neutral");
            check(StatusRules.of(true, true, true, true) == StatusRules.Status.WORKING, "working wins");
            check(StatusRules.of(false, false, true, false) == StatusRules.Status.NOT_CONNECTED, "not connected wins over problems");
            check(StatusRules.of(false, true, true, true) == StatusRules.Status.PROBLEM, "a real problem outranks neutral");
        });

        test("long requests are shortened with a visible notice; short ones are untouched; mock never fakes an ellipsis", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            StringBuilder big = new StringBuilder();
            for (int i = 0; i < 6000; i++) big.append("word").append(i).append(' ');
            f.c.submitUserMessage(big.toString());
            String p = f.a.prompts.get(0);
            check(p.length() < 20000, "prompt capped, got " + p.length());
            check(p.contains("characters omitted by AI Group Chat"), "visible omission notice");
            check(p.contains("word0 ") && p.contains("word5999"), "start and end of the request are kept");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.c.submitUserMessage("short message");
            check(!g.a.prompts.get(0).contains("omitted"), "short request untouched");
            String reply = g.all().stream().filter(x -> x.authorType.equals("PROVIDER")).findFirst().get().text;
            check(!reply.contains("\u2026") && !reply.contains("...") && reply.endsWith("short message"), "mock reply is complete with no ellipsis: " + reply);
        });

        test("B2.1: Claude 'responded' block and ref tags are removed from captured replies", () -> {
            check(ReplyCleaner.clean("Claude responded: ok\n\nok").equals("ok"), "the exact captured form from the video");
            check(ReplyCleaner.clean("Claude responded: The sentence is accurate and clear.\n\nThe sentence is accurate and clear. A few improvements:\n1. x")
                    .equals("The sentence is accurate and clear. A few improvements:\n1. x"), "long reply: hidden summary line dropped, real reply kept intact");
            check(ReplyCleaner.clean("Claude responded:\nHello").equals("Hello"), "heading with nothing after the colon");
            check(ReplyCleaner.clean("ChatGPT said:\nHi there").equals("Hi there"), "ChatGPT heading still handled");
            check(ReplyCleaner.clean("Claude responded: only this").equals("Claude responded: only this"), "a lone line is left alone (nothing to separate)");
            check(ReplyCleaner.clean("[ref 7f3a9c] Sure thing").equals("Sure thing"), "echoed ref tag removed");
            check(ReplyCleaner.clean("Answer mentions that Claude responded: to the user").equals("Answer mentions that Claude responded: to the user"), "only a LEADING heading is removed");
        });

        test("B2.1: failure text is short and never carries a JSON diagnostic", () -> {
            String blob = "unhealthy provider surface: {\"url\":\"https://chatgpt.com/c/6abe\",\"healthy\":false,\"composer\":false}";
            check(FailureText.shorten(blob).equals("page isn't ready"), "unhealthy surface -> " + FailureText.shorten(blob));
            check(FailureText.shorten("timeout after 240s; last poll {\"sendResult\":\"clicked\"}").equals("timed out while waiting for the reply"), "timeout");
            check(FailureText.shorten("could not settle on the bound conversation").startsWith("couldn't open"), "settle");
            check(FailureText.shorten("send failed: no-unique-send-button").equals("couldn't send (no-unique-send-button)"), "send failed code");
            check(FailureText.shorten("something odd: {\"a\":1,\"b\":2}").equals("something odd"), "unknown + JSON: JSON dropped");
            check(!FailureText.shorten("{\"only\":\"json\"}").contains("{"), "pure JSON becomes a short word");
            check(FailureText.shorten(null).equals("failed") && FailureText.shorten("  ").equals("failed"), "null/blank");
            String longTxt = "x".repeat(500);
            check(FailureText.shorten(longTxt).length() <= 100, "length capped");
        });

        test("B2.1: system audit lines never become provider context", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "claude", 1);
            f.store.appendMessage(ROOM, "sys1", "SYSTEM", "system", "Run ended early: ChatGPT: unhealthy provider surface: {\"huge\":\"blob\"}", null, 5L);
            f.c.submitUserMessage("hello");
            String p = f.b.prompts.get(0);
            check(!p.contains("unhealthy") && !p.contains("blob") && !p.contains("[System]"), "no system line in the prompt");
            check(p.contains("[User] hello"), "request intact");
        });

        test("B2.1: only APP background time pauses a turn timeout; a hidden page under the foreground room does not", () -> {
            long t0 = 1_000_000L, timeout = 240_000L, cap = 20L * 60_000L;
            BackgroundTracker bg = new BackgroundTracker();
            TurnClock clock = new TurnClock(t0, timeout, cap, bg.totalBackgroundMs(t0));
            check(!clock.expired(t0 + 239_000L, bg.totalBackgroundMs(t0 + 239_000L)), "foreground: not expired at 239 s");
            check(clock.expired(t0 + 241_000L, bg.totalBackgroundMs(t0 + 241_000L)), "foreground (page may report hidden): expires at 241 s, NOT extended");
            BackgroundTracker b2 = new BackgroundTracker();
            TurnClock c2 = new TurnClock(t0, timeout, cap, b2.totalBackgroundMs(t0));
            b2.setForeground(false, t0 + 60_000L);
            check(b2.totalBackgroundMs(t0 + 120_000L) == 60_000L, "an open background interval counts up to now");
            b2.setForeground(true, t0 + 360_000L);
            check(b2.totalBackgroundMs(t0 + 360_000L) == 300_000L, "closed background interval is 300 s");
            check(!c2.expired(t0 + 400_000L, b2.totalBackgroundMs(t0 + 400_000L)), "300 s in the background is excluded: active time only 100 s");
            check(c2.expired(t0 + 600_000L, b2.totalBackgroundMs(t0 + 600_000L)), "after enough foreground time it expires");
            BackgroundTracker b3 = new BackgroundTracker();
            TurnClock c3 = new TurnClock(t0, timeout, cap, 0);
            b3.setForeground(false, t0 + 1_000L);
            check(c3.expired(t0 + cap + 1L, b3.totalBackgroundMs(t0 + cap + 1L)), "hard 20-minute cap always applies, even in the background");
            BackgroundTracker b4 = new BackgroundTracker();
            b4.setForeground(false, 5_000L); b4.setForeground(true, 9_000L);
            TurnClock c4 = new TurnClock(10_000L, timeout, cap, b4.totalBackgroundMs(10_000L));
            check(c4.activeMs(20_000L, b4.totalBackgroundMs(20_000L)) == 10_000L, "background before the turn started is not subtracted from it");
        });

        test("B2.1: the prompt tag exists only on the provider page and is stripped everywhere it could echo", () -> {
            String tagged = RefTag.tag("7f3a9c", "hello there");
            check(tagged.equals("[ref 7f3a9c] hello there"), "tag format");
            check(RefTag.strip(tagged).equals("hello there"), "strip restores the original");
            check(ReplyCleaner.clean("Sure. You wrote [ref 7f3a9c] hello there, and I agree.").equals("Sure. You wrote hello there, and I agree."), "a tag echoed in the MIDDLE of a reply is removed");
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.c.submitUserMessage("plain user text");
            boolean clean = true;
            for (RoomMessage m : f.all()) if (m.text.contains("[ref ")) clean = false;
            check(clean, "no canonical room message contains a ref tag");
        });

        test("B2.1: nonce identity is accepted even when legacy counts are negative (the real Claude virtualization case)", () -> {
            check(TurnAcceptance.accept("Real reply text", true, true, "nonce", -2, -3), "mode=nonce identity=true newA=-2 newU=-3 -> ACCEPTED");
            check(TurnAcceptance.accept("Real reply text", true, true, "nonce", 0, 0), "nonce with zero counts -> accepted");
            check(!TurnAcceptance.accept("Real reply text", true, false, "nonce", 1, 1), "nonce but identity NOT proven -> rejected (fails closed)");
            check(!TurnAcceptance.accept("", true, true, "nonce", -2, -3), "empty reply -> rejected");
            check(!TurnAcceptance.accept("   \n ", true, true, "nonce", 2, 2), "whitespace-only reply -> rejected");
            check(!TurnAcceptance.accept("Real reply text", false, true, "nonce", 2, 2), "expected token missing -> rejected");
            check(!TurnAcceptance.accept("Real reply text", true, true, "counts", -2, -3), "legacy counts mode with negative growth -> rejected");
            check(!TurnAcceptance.accept("Real reply text", true, true, "ids", 0, 1), "legacy ids mode still needs new assistant growth");
            check(TurnAcceptance.accept("Real reply text", true, true, "ids", 1, 1), "legacy ids mode with growth -> accepted (ChatGPT unchanged)");
            check(TurnAcceptance.accept("Real reply text", true, true, "counts", 1, 1), "legacy counts mode with growth -> accepted");
            check(!TurnAcceptance.accept(null, true, true, "nonce", 1, 1), "null reply -> rejected");
            BackgroundTracker bg = new BackgroundTracker();
            TurnClock clock = new TurnClock(10_000L, 240_000L, 1_200_000L, bg.totalBackgroundMs(10_000L));
            bg.setForeground(false, 40_000L);
            check(clock.backgroundDuringTurnMs(bg.totalBackgroundMs(100_000L)) == 60_000L, "diagnostic background duration is correct while an interval is still open");
        });


        // ------------------------------------------------------------------ B2.2A: recipient routing + natural conversation
        test("recipient parser: phrase table (direct / group / independent / not an address)", () -> {
            java.util.Map<String, String[]> al = ProviderCatalog.aliases();
            Object[][] table = {
                {"Claude, what do you think about turtles?", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude, what do you think about turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"Hey Claude what do you think about turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"@Claude can you review this?", RecipientParser.Kind.DIRECT, "claude"},
                {"ChatGPT: summarize this", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"chatgpt, write a haiku", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"Hi ChatGPT - how are you", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"ask Claude what he thinks about turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"Tell ChatGPT to write a poem", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"what do you think, Claude?", RecipientParser.Kind.DIRECT, "claude"},
                {"Can you help me with this, ChatGPT?", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"Hello @ChatGPT, thoughts?", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"gpt, what's up", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"Claude", RecipientParser.Kind.DIRECT, "claude"},
                {"What does Claude think about this?", RecipientParser.Kind.NONE, ""},
                {"I asked Claude yesterday and he agreed", RecipientParser.Kind.NONE, ""},
                {"Claude is better than ChatGPT at poetry", RecipientParser.Kind.NONE, ""},
                {"ChatGPT said turtles are reptiles, what do you think?", RecipientParser.Kind.NONE, ""},
                {"What do you think about Claude?", RecipientParser.Kind.NONE, ""},
                {"Compare Claude and ChatGPT on coding", RecipientParser.Kind.NONE, ""},
                {"Please explain how turtles breathe", RecipientParser.Kind.NONE, ""},
                {"Tell me about turtles", RecipientParser.Kind.NONE, ""},
                {"Claude and ChatGPT, what do you think about turtles?", RecipientParser.Kind.GROUP, "claude,chatgpt"},
                {"ChatGPT and Claude: thoughts?", RecipientParser.Kind.GROUP, "chatgpt,claude"},
                {"@Claude and @ChatGPT what do you think", RecipientParser.Kind.GROUP, "claude,chatgpt"},
                {"both of you, what do you think?", RecipientParser.Kind.GROUP, ""},
                {"What do you guys think about turtles?", RecipientParser.Kind.GROUP, ""},
                {"Hey, what do you guys think?", RecipientParser.Kind.GROUP, ""},
                {"you two should discuss this", RecipientParser.Kind.GROUP, ""},
                {"What do you all think?", RecipientParser.Kind.GROUP, ""},
                {"Everyone, what's your favorite color?", RecipientParser.Kind.GROUP, ""},
                {"Claude and ChatGPT, what do you each think?", RecipientParser.Kind.INDEPENDENT, "claude,chatgpt"},
                {"Each of you, give me one sentence about dogs", RecipientParser.Kind.INDEPENDENT, ""},
                {"Answer separately: what is 2+2?", RecipientParser.Kind.INDEPENDENT, ""},
                {"", RecipientParser.Kind.NONE, ""},
            };
            for (Object[] row : table) {
                RecipientParser.Result r = RecipientParser.parse((String) row[0], al);
                String got = String.join(",", r.ids);
                check(r.kind == row[1] && got.equals(row[2]), "\"" + row[0] + "\" -> " + r.kind + " [" + got + "], expected " + row[1] + " [" + row[2] + "]");
            }
            check(RecipientParser.parse(null, al).kind == RecipientParser.Kind.NONE, "null text");
        });

        test("run planner: direct address bypasses every other AI, in any room style", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            for (RoutingMode m : new RoutingMode[]{RoutingMode.AUTO_PICK, RoutingMode.COLLABORATE, RoutingMode.ASK_ALL, RoutingMode.SINGLE}) {
                f.c.setRouting(m, "chatgpt", 1);
                RunPlanner.Plan p = RunPlanner.plan("hey Claude, what do you think about turtles", f.store.getRoom(ROOM), f.store.participants(ROOM),
                        ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
                check(p.steps.size() == 1 && p.steps.get(0).providerId.equals("claude") && p.steps.get(0).role == RoomRouter.Role.ANSWER,
                        m + ": exactly one step, Claude: " + p.steps);
            }
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            f.c.submitUserMessage("hey Claude, what do you think about turtles",
                    RunPlanner.plan("hey Claude, what do you think about turtles", f.store.getRoom(ROOM), f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0).steps);
            check(f.a.prompts.isEmpty(), "ChatGPT was never asked");
            check(f.b.prompts.size() == 1, "Claude was asked once");
            check(f.count("USER") == 1 && f.count("PROVIDER") == 1, "User -> Claude -> done (2 messages)");
            check(f.finished.size() == 1 && f.finished.get(0).equals("done") && !f.c.isBusy(), "run finished cleanly");
        });

        test("run planner: natural group conversation = ChatGPT -> Claude -> ChatGPT, all CONVERSE", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "", 1);
            RunPlanner.Plan p = RunPlanner.plan("What do you guys think about turtles?", f.store.getRoom(ROOM), f.store.participants(ROOM),
                    ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(p.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "default two-AI plan: " + p.steps);
            check(p.label.equals("ChatGPT \u2192 Claude \u2192 ChatGPT"), "chip label: " + p.label);
            f.c.submitUserMessage("What do you guys think about turtles?", p.steps);
            check(f.count("PROVIDER") == 3 && !f.c.isBusy(), "three AI turns, then done");
            String third = f.a.prompts.get(1); // ChatGPT's second turn
            check(third.contains("[Claude] Claude reply #1 [converse]"), "the last ChatGPT turn receives Claude's immediately preceding message as the request: " + third);
            check(!third.contains("[User]"), "...and does NOT re-ask the original user message");
            check(f.b.prompts.get(0).contains("[ChatGPT] ChatGPT reply #1 [converse]") && f.b.prompts.get(0).contains("[User] What do you guys think"),
                    "Claude sees ChatGPT's reply as the request and the user's question as context");
            check(!f.a.prompts.get(0).contains("revise") && !f.a.prompts.get(1).contains("review"), "no propose/review/revise wording anywhere");
        });

        test("run planner: other group shapes and styles", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "", 1);
            RoomSettings st = f.store.getRoom(ROOM);
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            RunPlanner.Plan indep = RunPlanner.plan("Claude and ChatGPT, what do you each think?", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(indep.steps.toString().equals("[claude:INDEPENDENT, chatgpt:INDEPENDENT]"), "'each' = independent answers, not a chain: " + indep.steps);
            RunPlanner.Plan sep = RunPlanner.plan("please answer separately: what is 2+2", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(sep.steps.toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "'separately' with nobody named = everyone independently: " + sep.steps);
            RunPlanner.Plan named = RunPlanner.plan("Claude and ChatGPT, what do you think about turtles?", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(named.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "named group starts with the first name: " + named.steps);
            RunPlanner.Plan plain = RunPlanner.plan("tell me about turtles", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(plain.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "no address in a natural room = natural group: " + plain.steps);
            RunPlanner.Plan two = RunPlanner.plan("hello everyone", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 2);
            check(two.steps.size() == 2, "turn setting 2 gives two turns: " + two.steps);
            RunPlanner.Plan four = RunPlanner.plan("hello everyone", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 4);
            check(four.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "four turns alternate: " + four.steps);
            // structured style keeps today's propose/review/revise for un-addressed and group messages
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            RoomSettings sc = f.store.getRoom(ROOM);
            RunPlanner.Plan structured = RunPlanner.plan("design a cache", sc, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(structured.steps.toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "structured unchanged: " + structured.steps);
            check(structured.label.startsWith("Structured: "), "structured label: " + structured.label);
            RunPlanner.Plan sg = RunPlanner.plan("what do you guys think of this design", sc, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(sg.steps.toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "group message in a structured room stays structured: " + sg.steps);
            // the chip override beats the parser
            RunPlanner.Plan ov = RunPlanner.plan("hey Claude, hi", st, ps, ProviderCatalog.aliases(), names, "chatgpt", 0);
            check(ov.overridden && ov.steps.toString().equals("[chatgpt:ANSWER]"), "override to ChatGPT beats 'hey Claude': " + ov.steps);
            RunPlanner.Plan ovg = RunPlanner.plan("hey Claude, hi", st, ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0);
            check(ovg.overridden && ovg.steps.size() == 3, "override to group beats a direct address: " + ovg.steps);
            RunPlanner.Plan ove = RunPlanner.plan("hey Claude, hi", st, ps, ProviderCatalog.aliases(), names, RunPlanner.EACH, 0);
            check(ove.steps.toString().equals("[chatgpt:INDEPENDENT, claude:INDEPENDENT]"), "override to each: " + ove.steps);
            // an addressed AI that is not in the room falls back to the default and says so
            f.c.removeParticipant("claude");
            RunPlanner.Plan gone = RunPlanner.plan("Claude, are you there?", st, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(gone.steps.toString().equals("[chatgpt:CONVERSE]") && gone.note.contains("Claude isn't in this chat"), "absent Claude: " + gone.steps + " / " + gone.note);
            f.c.removeParticipant("chatgpt");
            check(RunPlanner.plan("hi", st, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0).steps.isEmpty(), "nobody in the chat: empty plan");
        });

        test("natural conversation: Stop works, deliveries stay idempotent, structured submit is unchanged", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "", 1);
            f.b.behavior = MockProvider.Behavior.NEVER_REPLY;
            RunPlanner.Plan p = RunPlanner.plan("what do you guys think", f.store.getRoom(ROOM), f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            f.c.submitUserMessage("what do you guys think", p.steps);
            check(f.c.isBusy() && f.count("PROVIDER") == 1, "ChatGPT answered, Claude is pending");
            f.c.stop();
            check(f.c.isStopping() && f.count("PROVIDER") == 1 && f.a.prompts.size() == 1, "Stop: completed ChatGPT message stays, no third turn starts (C2: still draining)");
            f.b.fireTimeout("timed out while waiting for the reply");
            check(!f.c.isBusy() && f.a.prompts.size() == 1, "after the drain resolves nothing further starts");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "the stopped delivery is UNCERTAIN, never resent");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            g.c.submitUserMessage("plain old call without a plan");
            check(g.count("PROVIDER") == 3 && g.store.deliveriesInState(DeliveryState.CAPTURED).size() == 3, "the one-argument submit still runs the structured plan");
        });


        // ------------------------------------------------------------------ B2.2A fix: typed order beats the stored first speaker (one run only)
        test("named group: the order the user typed wins over the stored first-speaker preference", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude"); names.put("mock-delta", "Mock Delta");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RunPlanner.Plan a = RunPlanner.plan("Claude and ChatGPT, what do you think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(a.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "preference chatgpt + 'Claude and ChatGPT...' -> Claude first: " + a.steps);
            RunPlanner.Plan a2 = RunPlanner.plan("ChatGPT and Claude, what do you think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(a2.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "preference chatgpt + 'ChatGPT and Claude...' -> ChatGPT first: " + a2.steps);
            f.c.setRouting(RoutingMode.AUTO_PICK, "claude", 1);
            RunPlanner.Plan b = RunPlanner.plan("ChatGPT and Claude, what do you think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(b.steps.toString().equals("[chatgpt:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE]"), "preference claude + 'ChatGPT and Claude...' -> ChatGPT first: " + b.steps);

            // three named AIs keep the typed order across all four turns
            f.c.registerProvider(new MockProvider("mock-delta", "Mock Delta", MockProvider.Scheduler.IMMEDIATE));
            f.c.addParticipant("mock-delta", false);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            java.util.List<RoomParticipant> three = f.store.participants(ROOM);
            RunPlanner.Plan c3 = RunPlanner.plan("Delta, Claude and ChatGPT, thoughts?", f.store.getRoom(ROOM), three, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(c3.steps.toString().equals("[mock-delta:CONVERSE, claude:CONVERSE, chatgpt:CONVERSE, mock-delta:CONVERSE]"), "three named AIs preserve typed order: " + c3.steps);
            // a named subset that does not include the stored preference simply starts with the first name
            RunPlanner.Plan sub = RunPlanner.plan("Claude and Delta, thoughts?", f.store.getRoom(ROOM), three, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(sub.steps.toString().equals("[claude:CONVERSE, mock-delta:CONVERSE, claude:CONVERSE]"), "named subset without the preferred AI: " + sub.steps);
        });

        test("unnamed group and the Both chip still honor the stored first-speaker preference", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "claude", 1);
            RunPlanner.Plan g1 = RunPlanner.plan("What do you guys think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(g1.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "'you guys' + preference claude -> Claude first: " + g1.steps);
            RunPlanner.Plan n1 = RunPlanner.plan("tell me about turtles", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(n1.steps.get(0).providerId.equals("claude"), "no address in a natural room + preference claude -> Claude first: " + n1.steps);
            RunPlanner.Plan chip = RunPlanner.plan("hey Claude, hi", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0);
            check(chip.steps.toString().equals("[claude:CONVERSE, chatgpt:CONVERSE, claude:CONVERSE]"), "Both chip + preference claude -> Claude first: " + chip.steps);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RunPlanner.Plan chip2 = RunPlanner.plan("hey Claude, hi", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0);
            check(chip2.steps.get(0).providerId.equals("chatgpt"), "Both chip + preference chatgpt -> ChatGPT first: " + chip2.steps);
            RunPlanner.Plan g2 = RunPlanner.plan("What do you guys think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(g2.steps.get(0).providerId.equals("chatgpt"), "'you guys' + preference chatgpt -> ChatGPT first: " + g2.steps);
        });

        test("end to end: the first stored AI message is the first named AI, and the stored preference is never changed", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RoomSettings before = f.store.getRoom(ROOM);
            RunPlanner.Plan p = RunPlanner.plan("Claude and ChatGPT, what do you think?", before, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            f.c.submitUserMessage("Claude and ChatGPT, what do you think?", p.steps);
            StringBuilder order = new StringBuilder();
            for (RoomMessage m : f.all()) if (m.authorType.equals("PROVIDER")) order.append(m.authorId).append(',');
            check(order.toString().equals("claude,chatgpt,claude,"), "stored provider messages in order: " + order);
            check(!f.c.isBusy() && f.finished.get(f.finished.size() - 1).equals("done"), "run finished cleanly");
            RoomSettings after = f.store.getRoom(ROOM);
            check(after.modeArg.equals("chatgpt") && after.mode == before.mode && after.rounds == before.rounds, "planning and submitting did not change the stored preference: " + after.modeArg);
            // the NEXT unaddressed group message still starts with the stored preference
            RunPlanner.Plan next = RunPlanner.plan("What do you guys think now?", after, f.store.participants(ROOM), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(next.steps.get(0).providerId.equals("chatgpt"), "a later unnamed group message starts with ChatGPT again: " + next.steps);
        });

        test("unchanged by the fix: independent answers keep typed order; structured rooms keep today's behavior", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RunPlanner.Plan ind = RunPlanner.plan("Claude and ChatGPT, what do you each think?", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(ind.steps.toString().equals("[claude:INDEPENDENT, chatgpt:INDEPENDENT]"), "independent order is the typed order: " + ind.steps);
            RunPlanner.Plan dir = RunPlanner.plan("hey Claude, hi", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(dir.steps.toString().equals("[claude:ANSWER]"), "direct address unchanged: " + dir.steps);
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            RunPlanner.Plan st = RunPlanner.plan("Claude and ChatGPT, review this design", f.store.getRoom(ROOM), ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(st.steps.toString().equals("[chatgpt:ANSWER, claude:REVIEW, chatgpt:REVISE]"), "structured room unchanged (named order not applied; separate decision): " + st.steps);
        });


        // ------------------------------------------------------------------ B3 C1: hybrid vocative grammar
        test("parser C1: greeting + name is a strong vocative; bare openers need a real continuation; subject/product uses are not addresses", () -> {
            java.util.Map<String, String[]> al = ProviderCatalog.aliases();
            Object[][] table = {
                // reported on the phone (these fell through to the room default)
                {"hey Claude I'm testing something", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude tell me a joke", RecipientParser.Kind.DIRECT, "claude"},
                {"Claude can you check this", RecipientParser.Kind.DIRECT, "claude"},
                {"Claude please look at this", RecipientParser.Kind.DIRECT, "claude"},
                {"Claude I need a favor", RecipientParser.Kind.DIRECT, "claude"},
                {"Hey Claude I need a favor", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude, I'm testing something", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude. I'm testing something", RecipientParser.Kind.DIRECT, "claude"},
                // more natural phrasings
                {"ChatGPT I have a question", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"claude test message", RecipientParser.Kind.DIRECT, "claude"},
                {"hi ChatGPT how are you doing", RecipientParser.Kind.DIRECT, "chatgpt"},
                {"hey Claude Opus, what do you think?", RecipientParser.Kind.DIRECT, "claude"},
                {"Claude do you know turtles", RecipientParser.Kind.DIRECT, "claude"},
                {"Claude are you there", RecipientParser.Kind.DIRECT, "claude"},
                {"hello hey Claude what's up", RecipientParser.Kind.DIRECT, "claude"},
                {"hey Claude and ChatGPT I have a question", RecipientParser.Kind.GROUP, "claude,chatgpt"},
                {"Claude and ChatGPT can you both look at this", RecipientParser.Kind.GROUP, "claude,chatgpt"},
                // greeting + capitalized name-like word (found in review): part of a name unless punctuation closes it
                {"Hey Claude Shannon was an important researcher", RecipientParser.Kind.NONE, ""},
                {"hello Claude Monet painted lilies", RecipientParser.Kind.NONE, ""},
                {"Hi ChatGPT Plus users get more", RecipientParser.Kind.NONE, ""},
                {"hey Claude Opus is better than Sonnet", RecipientParser.Kind.NONE, ""},
                {"Hey Claude Tell me a joke", RecipientParser.Kind.DIRECT, "claude"},
                {"Hey Claude Can you check this", RecipientParser.Kind.DIRECT, "claude"},
                {"Hey Claude I'm testing something", RecipientParser.Kind.DIRECT, "claude"},
                {"Hey Claude, what do you think?", RecipientParser.Kind.DIRECT, "claude"},
                // must NOT be addresses
                {"Claude Shannon invented information theory", RecipientParser.Kind.NONE, ""},
                {"Claude Opus is a model", RecipientParser.Kind.NONE, ""},
                {"ChatGPT Plus costs money", RecipientParser.Kind.NONE, ""},
                {"Claude said turtles are reptiles", RecipientParser.Kind.NONE, ""},
                {"Claude's answer was longer", RecipientParser.Kind.NONE, ""},
                {"hey Claude's answer was longer", RecipientParser.Kind.NONE, ""},
                {"Claude is better than ChatGPT", RecipientParser.Kind.NONE, ""},
                {"so Claude said something odd", RecipientParser.Kind.NONE, ""},
                {"and Claude is wrong", RecipientParser.Kind.NONE, ""},
                {"Claude and ChatGPT are different", RecipientParser.Kind.NONE, ""},
                {"Claude vs ChatGPT for coding", RecipientParser.Kind.NONE, ""},
                {"Claude or ChatGPT, which is better?", RecipientParser.Kind.NONE, ""},
                {"I talked to Claude yesterday", RecipientParser.Kind.NONE, ""},
                {"What does Claude think?", RecipientParser.Kind.NONE, ""},
                {"ChatGPT said turtles are reptiles, what do you think?", RecipientParser.Kind.NONE, ""},
            };
            for (Object[] row : table) {
                RecipientParser.Result r = RecipientParser.parse((String) row[0], al);
                String got = String.join(",", r.ids);
                check(r.kind == row[1] && got.equals(row[2]), "\"" + row[0] + "\" -> " + r.kind + " [" + got + "], expected " + row[1] + " [" + row[2] + "]");
            }
        });

        // ------------------------------------------------------------------ B3 C1: reply ownership
        test("reply ownership: only an AI's direct ask owns the next message; sign-offs and handoffs do not", () -> {
            java.util.Map<String, String[]> al = ProviderCatalog.aliases();
            java.util.Set<String> both = new java.util.HashSet<>(java.util.Arrays.asList("chatgpt", "claude"));
            long now = 10_000_000L;
            String[] asks = {
                "That depends on the setup.\n\nWhat do you mean by that?",
                "Could you clarify that?",
                "Explain what you mean.",
                "Tell me what you mean by that.",
                "Please share more details about the error.",
                "Which one do you prefer?",
                "Would you like me to expand on any of these?",
                "Should I use Python or Java?",
                "Want me to draft it?",
                "**Does that make sense?**",
                "Let me know which option you want.",
            };
            for (String a : asks) {
                java.util.List<RoomMessage> l = new java.util.ArrayList<>();
                l.add(new RoomMessage(1, "u", "r", "USER", "user", "hi", now - 5000, null));
                l.add(new RoomMessage(2, "m", "r", "PROVIDER", "claude", a, now - 1000, null));
                check("claude".equals(ReplyOwnership.owner(l, both, al, now)), "asks the user -> Claude owns the reply: \"" + a + "\"");
            }
            String[] notAsks = {
                "Let me know if you have any questions.",
                "Hope that helps! Let me know if you'd like me to expand.",
                "Isn't that fun?",
                "Great question.",
                "Turtles are reptiles.\n\nChatGPT, what do you think?",
                "Here is the code:\n\n```python\nprint('hi?')\n```",
                "Do turtles have shells? Yes. They are part of the skeleton.",
            };
            for (String a : notAsks) {
                java.util.List<RoomMessage> l = new java.util.ArrayList<>();
                l.add(new RoomMessage(1, "m", "r", "PROVIDER", "claude", a, now - 1000, null));
                check(ReplyOwnership.owner(l, both, al, now) == null, "no ownership: \"" + a.replace("\n", " / ") + "\"");
            }
            java.util.List<RoomMessage> l = new java.util.ArrayList<>();
            l.add(new RoomMessage(1, "m", "r", "PROVIDER", "claude", "What do you mean?", now - 1000, null));
            l.add(new RoomMessage(2, "s", "r", "SYSTEM", "system", "Run ended early: stopped by user", now - 500, null));
            check("claude".equals(ReplyOwnership.owner(l, both, al, now)), "a SYSTEM line after the question does not hide it");
            l.add(new RoomMessage(3, "u2", "r", "USER", "user", "I mean this", now - 400, null));
            check(ReplyOwnership.owner(l, both, al, now) == null, "once the user has replied, nobody owns the next message (one-shot)");
            java.util.List<RoomMessage> old = new java.util.ArrayList<>();
            old.add(new RoomMessage(1, "m", "r", "PROVIDER", "claude", "What do you mean?", now - ReplyOwnership.MAX_AGE_MS - 1, null));
            check(ReplyOwnership.owner(old, both, al, now) == null, "a question from hours ago is not silently owned");
            java.util.List<RoomMessage> q = new java.util.ArrayList<>();
            q.add(new RoomMessage(1, "m", "r", "PROVIDER", "claude", "What do you mean?", now - 1000, null));
            check(ReplyOwnership.owner(q, new java.util.HashSet<>(java.util.Arrays.asList("chatgpt")), al, now) == null, "an AI that is no longer in the room owns nothing");
        });

        test("planner C1: override > explicit address > reply owner > room default", () -> {
            Fixture f = new Fixture();
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            java.util.List<RoomParticipant> ps = f.store.participants(ROOM);
            f.c.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            RoomSettings st = f.store.getRoom(ROOM);
            RunPlanner.Plan own = RunPlanner.plan("I mean the second one", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0, "claude");
            check(own.replying && own.steps.toString().equals("[claude:ANSWER]") && own.label.equals("Replying \u2192 Claude"), "unaddressed message goes to the owner: " + own.steps + " " + own.label);
            RunPlanner.Plan addr = RunPlanner.plan("hey ChatGPT, new topic", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0, "claude");
            check(!addr.replying && addr.steps.toString().equals("[chatgpt:ANSWER]"), "an explicit address beats the owner: " + addr.steps);
            RunPlanner.Plan ov = RunPlanner.plan("I mean the second one", st, ps, ProviderCatalog.aliases(), names, RunPlanner.GROUP, 0, "claude");
            check(!ov.replying && ov.overridden && ov.steps.size() == 3, "the chip override beats the owner: " + ov.steps);
            RunPlanner.Plan none = RunPlanner.plan("I mean the second one", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0, null);
            check(!none.replying && none.steps.size() == 3, "no owner -> the room default (natural group): " + none.steps);
            RunPlanner.Plan absent = RunPlanner.plan("I mean the second one", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0, "gemini");
            check(!absent.replying, "an owner who is not in the room is ignored");
            check(RunPlanner.plan("hello", st, ps, ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0).steps.size() == 3, "the 7-argument form is unchanged");
        });


        // ------------------------------------------------------------------ B3 C2: Stop-drain
        test("C2: a real reply that arrives after Stop is persisted, never routed onward", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.COLLABORATE, "chatgpt", 1);
            f.b.behavior = MockProvider.Behavior.NEVER_REPLY; // Claude receives the review request and answers later
            f.c.submitUserMessage("design a cache");
            check(f.count("PROVIDER") == 1 && f.c.isBusy(), "ChatGPT answered; Claude's review is in flight");
            f.c.stop();
            check(f.c.isStopping() && f.b.prompts.size() == 1, "draining Claude's already-sent request");
            f.b.fireLateReply("Claude's real review");
            check(f.count("PROVIDER") == 2, "the late reply is now in the canonical room");
            RoomMessage last = f.all().get(f.all().size() - 1);
            check(last.authorType.equals("PROVIDER") && last.authorId.equals("claude") && last.text.equals("Claude's real review"), "stored as Claude's message: " + last.text);
            check(f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 2 && f.store.deliveriesInState(DeliveryState.UNCERTAIN).isEmpty(), "both deliveries CAPTURED");
            check(f.a.prompts.size() == 1, "ChatGPT's revise step never started");
            check(!f.c.isBusy() && f.finished.get(f.finished.size() - 1).equals("stopped by user"), "run ended as stopped by user");
            f.b.fireLateReply("Claude's real review");
            check(f.count("PROVIDER") == 2, "a duplicate late reply changes nothing");
        });

        test("C2: Stop before the request left is NOT_SUBMITTED: cancelled, nothing stored, retry allowed", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT; // never accepted
            f.c.submitUserMessage("a");
            f.c.stop();
            check(!f.c.isBusy(), "finished immediately");
            check(f.store.deliveriesInState(DeliveryState.CANCELLED).size() == 1 && f.store.deliveriesInState(DeliveryState.UNCERTAIN).isEmpty(), "delivery CANCELLED (not UNCERTAIN)");
            check(f.count("PROVIDER") == 0 && f.part("chatgpt").contextSeq == 0, "no reply, context unchanged");
            f.a.behavior = MockProvider.Behavior.REPLY;
            check(f.c.submitUserMessage("b") != null && f.count("PROVIDER") == 1, "the user can simply send again");
        });

        test("C2: the page said 'clicked' before the room saw onAccepted: treated as possibly sent, never retried", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;                          // the room never observed onAccepted...
            f.a.stopAnswer = RoomProvider.SubmitPhase.MAYBE_SUBMITTED;            // ...but the page authority says the click happened
            f.c.submitUserMessage("a");
            check(f.store.deliveriesInState(DeliveryState.SENDING).size() == 1, "delivery still SENDING");
            f.c.stop();
            check(f.c.isStopping() && f.store.deliveriesInState(DeliveryState.CANCELLED).isEmpty(), "NOT cancelled: it may have been sent, so it is observed");
            f.a.fireTimeout("timed out while waiting for the reply");
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1 && f.store.deliveriesInState(DeliveryState.FAILED).isEmpty(), "UNCERTAIN, never FAILED (FAILED would mean retry-safe)");
            check(f.a.prompts.size() == 1, "never automatically resent");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.a.behavior = MockProvider.Behavior.SILENT;
            g.a.stopAnswer = RoomProvider.SubmitPhase.MAYBE_SUBMITTED;
            g.c.submitUserMessage("a");
            g.c.stop();
            g.a.fireLateReply("it did go through");
            check(g.count("PROVIDER") == 1 && g.part("chatgpt").contextSeq > 0, "a late reply proves acceptance: captured and context advanced");
        });

        test("C2: late reply after the drain already resolved is ignored; Stop twice and Stop when idle are harmless", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("a");
            f.c.stop(); f.c.stop();
            check(f.c.isStopping(), "second Stop is a no-op");
            f.a.fireTimeout("timed out while waiting for the reply");
            check(!f.c.isBusy() && f.finished.size() == 1, "finished exactly once");
            f.a.fireLateReply("too late");
            check(f.count("PROVIDER") == 0, "a reply after the drain resolved is ignored (stale)");
            f.c.stop();
            check(f.finished.size() == 1, "Stop when idle does nothing");
        });

        test("C2: removing the ACTIVE AI drains like Stop (its submitted reply is kept)", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("a");
            f.c.removeParticipant("chatgpt");
            check(f.c.isStopping() && !f.part("chatgpt").enabled, "draining after removal");
            f.a.fireLateReply("answer sent before it left");
            check(f.count("PROVIDER") == 1 && f.store.deliveriesInState(DeliveryState.CAPTURED).size() == 1, "the reply was not discarded");
            check(f.finished.get(f.finished.size() - 1).equals("participant removed"), "summary: participant removed");
        });

        test("C2: abandon (room closed / surfaces destroyed) ends the drain at once as a neutral UNCERTAIN", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            f.c.submitUserMessage("a");
            f.c.abandon("room closed");
            check(!f.c.isBusy() && f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "immediately UNCERTAIN");
            check(StatusRules.isNeutralStop(DeliveryState.UNCERTAIN, f.store.deliveriesInState(DeliveryState.UNCERTAIN).get(0).error), "closing the room is neutral, not a red failure: " + f.store.deliveriesInState(DeliveryState.UNCERTAIN).get(0).error);
            check(StatusRules.isNeutralStop(DeliveryState.UNCERTAIN, "stopped by user; x") && !StatusRules.isRealFailure(DeliveryState.CANCELLED, "stopped by user (request not sent)") ,"neutral status rules still hold");
            f.a.fireLateReply("never observed");
            check(f.count("PROVIDER") == 0, "late reply after abandon is stale");
        });


        test("C2: Stop that wins the race between persisting SENDING and handing the prompt over never dispatches it", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            final RoomController[] holder = new RoomController[1];
            final java.util.List<String> finished = new java.util.ArrayList<>();
            RoomController c = new RoomController(store, ROOM, new RoomController.Events() {
                @Override public void onDelivery(Delivery d) { if (holder[0] != null && d.state == DeliveryState.SENDING) holder[0].stop(); } // Stop lands exactly here
                @Override public void onRunFinished(String s) { finished.add(s); }
            });
            holder[0] = c;
            MockProvider a = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
            c.registerProvider(a);
            c.addParticipant("chatgpt", false);
            c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            c.submitUserMessage("race");
            check(a.prompts.isEmpty(), "the prompt was never sent to the provider");
            check(!c.isBusy() && store.deliveriesInState(DeliveryState.CANCELLED).size() == 1, "delivery CANCELLED (never left), run finished");
            check(finished.size() == 1 && finished.get(0).equals("stopped by user"), "finished once: " + finished);
        });


        test("C2 (review fix): once Stop says MAYBE_SUBMITTED, a later 'not sent' report can NEVER turn it into CANCELLED / retry-safe", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.a.stopAnswer = RoomProvider.SubmitPhase.MAYBE_SUBMITTED;
            f.c.submitUserMessage("a");
            f.c.stop();
            check(f.c.isStopping(), "draining");
            f.a.fireError("cancelled", false); // a later callback claims "not submitted": it must not downgrade the delivery
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1, "UNCERTAIN");
            check(f.store.deliveriesInState(DeliveryState.CANCELLED).isEmpty() && f.store.deliveriesInState(DeliveryState.FAILED).isEmpty(), "never CANCELLED or FAILED (both mean retry-safe)");
            Delivery d = f.store.deliveriesInState(DeliveryState.UNCERTAIN).get(0);
            check(d.error.startsWith("stopped by user") && StatusRules.isNeutralStop(DeliveryState.UNCERTAIN, d.error), "still neutral wording: " + d.error);
            check(f.a.prompts.size() == 1, "never automatically resent");
            // SUBMITTED behaves the same
            Fixture s2 = new Fixture();
            s2.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            s2.a.behavior = MockProvider.Behavior.NEVER_REPLY; // accepted -> phase SUBMITTED
            s2.c.submitUserMessage("a");
            s2.c.stop();
            s2.a.fireError("cancelled", false);
            check(s2.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1 && s2.store.deliveriesInState(DeliveryState.CANCELLED).isEmpty(), "SUBMITTED + later not-sent report -> UNCERTAIN");
        });

        test("C2 (review fix): an error that arrives BEFORE the page answers the stop request is also never retry-safe; an authoritative NOT_SUBMITTED still cancels", () -> {
            Fixture f = new Fixture();
            f.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            f.a.behavior = MockProvider.Behavior.SILENT;
            f.a.holdStop = true;                      // the page has not answered yet
            f.c.submitUserMessage("a");
            f.c.stop();
            check(f.c.isStopping(), "draining while the answer is pending");
            f.a.fireError("refused", false);          // arrives first
            check(f.store.deliveriesInState(DeliveryState.UNCERTAIN).size() == 1 && f.store.deliveriesInState(DeliveryState.CANCELLED).isEmpty(), "UNCERTAIN (the worst is assumed until the page says NOT_SUBMITTED)");
            f.a.answerStop(RoomProvider.SubmitPhase.NOT_SUBMITTED); // the late answer finds the run already resolved
            check(f.store.deliveriesInState(DeliveryState.CANCELLED).isEmpty() && !f.c.isBusy(), "a late answer changes nothing");
            Fixture g = new Fixture();
            g.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            g.a.behavior = MockProvider.Behavior.SILENT;
            g.a.holdStop = true;
            g.c.submitUserMessage("a");
            g.c.stop();
            g.a.answerStop(RoomProvider.SubmitPhase.NOT_SUBMITTED);
            check(g.store.deliveriesInState(DeliveryState.CANCELLED).size() == 1 && g.store.deliveriesInState(DeliveryState.UNCERTAIN).isEmpty(), "the page's authoritative NOT_SUBMITTED still cancels safely");
            Fixture h = new Fixture();
            h.c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            h.a.behavior = MockProvider.Behavior.NEVER_REPLY;
            h.c.submitUserMessage("a");
            h.c.stop();
            h.c.removeParticipant("chatgpt"); // a second reason arrives while already stopping
            h.a.fireTimeout("timed out while waiting for the reply");
            check(h.finished.size() == 1 && h.finished.get(0).equals("stopped by user"), "the first stop reason still wins: " + h.finished);
        });


        // ------------------------------------------------------------------ C3a: rooms, registry, room-scoped bindings
        test("rooms are isolated: membership, routing, messages, prompts and context are per room", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("roomA", "Room A", RoomKind.LIVE, 1);
            store.createRoom("roomB", "Room B", RoomKind.LIVE, 2);
            AtomicInteger clk = new AtomicInteger(1000);
            java.util.function.Supplier<String> ids = new java.util.function.Supplier<String>() { int n; public String get() { return "r" + (++n); } };
            MockProvider aA = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE), bA = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
            MockProvider aB = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE);
            RoomController cA = new RoomController(store, "roomA", null, () -> clk.incrementAndGet(), ids);
            RoomController cB = new RoomController(store, "roomB", null, () -> clk.incrementAndGet(), ids);
            cA.registerProvider(aA); cA.registerProvider(bA); cB.registerProvider(aB);
            cA.addParticipant("chatgpt", false); cA.addParticipant("claude", false); cB.addParticipant("chatgpt", false);
            check(store.participants("roomA").size() == 2 && store.participants("roomB").size() == 1, "two rooms, different membership (2 AIs vs 1 AI)");
            check(store.participants("roomB").get(0).providerId.equals("chatgpt"), "the same registry AI is seated in both rooms");
            cA.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            cB.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            check(store.getRoom("roomA").mode == RoutingMode.SINGLE && store.getRoom("roomB").mode == RoutingMode.SINGLE, "routing is saved per room");
            cB.setRouting(RoutingMode.ASK_ALL, "", 1);
            check(store.getRoom("roomA").mode == RoutingMode.SINGLE && store.getRoom("roomB").mode == RoutingMode.ASK_ALL, "changing one room's routing leaves the other alone");
            cB.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            cA.submitUserMessage("SECRET-A apples");
            cB.submitUserMessage("SECRET-B pears");
            boolean aSeesOnlyA = !aA.prompts.isEmpty(), bSeesOnlyB = !aB.prompts.isEmpty();
            for (String pr : aA.prompts) if (!pr.contains("SECRET-A") || pr.contains("SECRET-B")) aSeesOnlyA = false;
            for (String pr : aB.prompts) if (!pr.contains("SECRET-B") || pr.contains("SECRET-A")) bSeesOnlyB = false;
            check(aSeesOnlyA, "room A's prompts never contain room B's messages");
            check(bSeesOnlyB, "room B's prompts never contain room A's messages");
            check(store.messagesBetween("roomA", 0, Long.MAX_VALUE).size() == 2 && store.messagesBetween("roomB", 0, Long.MAX_VALUE).size() == 2, "each room stored only its own user message and reply");
            check(bA.prompts.isEmpty(), "an AI seated only in room A is never asked by room B's traffic");
            boolean latestOk = store.latestMessages("roomA", 10).size() == 2 && store.latestMessages("roomB", 10).size() == 2;
            for (RoomMessage m : store.latestMessages("roomA", 10)) if (!m.roomId.equals("roomA")) latestOk = false;
            for (RoomMessage m : store.latestMessages("roomB", 10)) if (!m.roomId.equals("roomB")) latestOk = false;
            check(latestOk && store.latestSeq("roomA") < store.latestSeq("roomB"), "the transcript view (latest messages, latest sequence) is per room");
            long ctxA = store.participants("roomA").get(0).contextSeq, ctxB = store.participants("roomB").get(0).contextSeq;
            check(ctxA > 0 && ctxB > ctxA, "the same AI has its own context position in each room (" + ctxA + " vs " + ctxB + ")");
            cA.submitUserMessage("SECRET-A bananas");
            check(store.participants("roomB").get(0).contextSeq == ctxB && store.participants("roomA").get(0).contextSeq > ctxA, "advancing context in room A does not move room B's");
            store.setParticipantEnabled("roomB", "chatgpt", false);
            check(store.participants("roomA").get(0).enabled && !store.participants("roomB").get(0).enabled, "removing an AI from one room leaves it seated in the other");
            store.setParticipantEnabled("roomB", "chatgpt", true);
        });

        test("RunPlanner plans from each room's own membership and routing", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("roomA", "Room A", RoomKind.LIVE, 1);
            store.createRoom("roomB", "Room B", RoomKind.LIVE, 2);
            AtomicInteger clk = new AtomicInteger(1000);
            RoomController cA = new RoomController(store, "roomA", null, () -> clk.incrementAndGet(), () -> java.util.UUID.randomUUID().toString());
            RoomController cB = new RoomController(store, "roomB", null, () -> clk.incrementAndGet(), () -> java.util.UUID.randomUUID().toString());
            cA.addParticipant("chatgpt", false); cA.addParticipant("claude", false); cB.addParticipant("claude", false);
            cA.setRouting(RoutingMode.AUTO_PICK, "chatgpt", 1);
            cB.setRouting(RoutingMode.AUTO_PICK, "claude", 1);
            java.util.Map<String, String> names = new java.util.LinkedHashMap<>();
            names.put("chatgpt", "ChatGPT"); names.put("claude", "Claude");
            RunPlanner.Plan pa = RunPlanner.plan("hello everyone", store.getRoom("roomA"), store.participants("roomA"), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            RunPlanner.Plan pb = RunPlanner.plan("hello everyone", store.getRoom("roomB"), store.participants("roomB"), ProviderCatalog.aliases(), names, RunPlanner.AUTO, 0);
            check(pa.steps.toString().startsWith("[chatgpt:") && pa.steps.toString().contains("claude:"), "room A (two AIs, ChatGPT first): " + pa.steps);
            check(pb.steps.toString().startsWith("[claude:") && !pb.steps.toString().contains("chatgpt"), "room B (only Claude seated): " + pb.steps);
        });

        test("createRoom / listRooms / room kind", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            check(store.listRooms().isEmpty() && store.getRoomInfo("x") == null, "a fresh store has no rooms");
            RoomInfo live = store.createRoom("default", "Main room", RoomKind.LIVE, 5);
            RoomInfo mock = store.createRoom("mock-1", "Mock room", RoomKind.MOCK, 7);
            check(live.kind == RoomKind.LIVE && live.name.equals("Main room") && live.naturalMaxTurns == 0 && mock.kind == RoomKind.MOCK, "kind, name and defaults stored");
            check(store.listRooms().size() == 2 && store.listRooms().get(0).id.equals("default") && store.listRooms().get(1).id.equals("mock-1"), "listRooms is oldest first");
            boolean dup = false;
            try { store.createRoom("default", "Again", RoomKind.MOCK, 9); } catch (IllegalStateException e) { dup = true; }
            check(dup && store.getRoomInfo("default").kind == RoomKind.LIVE && store.getRoomInfo("default").name.equals("Main room"), "creating an existing room id is refused and changes nothing");
            store.ensureRoom("implicit", 11);
            check(store.getRoomInfo("implicit").kind == RoomKind.MOCK && store.getRoomInfo("implicit").name.equals("implicit"), "implicit creation (tests, self-check) makes a developer MOCK room, never a live one");
            check(store.getRoom("default") != null && store.getRoom("default").mode == RoutingMode.AUTO_PICK, "a new room starts in natural conversation");
        });

        test("provider registry: live rooms see CORE/CUSTOM only, developer mocks stay out", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            check(store.listProviders(true).size() == 2 && store.listProviders(true).get(0).id.equals("chatgpt") && store.listProviders(true).get(1).id.equals("claude"), "a fresh registry offers ChatGPT and Claude");
            store.ensureMockProvider("mock-delta", "Mock Delta");
            store.ensureMockProvider("mock-delta", "Renamed");
            check(store.listProviders(true).size() == 2, "a developer mock never appears in the live list");
            check(store.listProviders(false).size() == 3 && store.listProviders(false).get(2).id.equals("mock-delta") && store.listProviders(false).get(2).displayName.equals("Mock Delta"), "developer list = live + mocks (CORE first, MOCK last); registering twice changes nothing");
            store.ensureMockProvider("chatgpt", "Impostor");
            check(store.getProvider("chatgpt").kind.equals("CORE") && store.getProvider("chatgpt").displayName.equals("ChatGPT"), "registering a mock under a core id cannot replace the core AI");
            check(store.getProvider("mock-delta").kind.equals("MOCK") && !store.getProvider("mock-delta").isLive() && store.getProvider("chatgpt").isLive() && store.getProvider("nope") == null, "getProvider / isLive");
        });

        test("only registered AIs can be seated; a failed seating changes nothing", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("r", "R", RoomKind.LIVE, 1);
            RoomController c = new RoomController(store, "r", null);
            c.addParticipant("chatgpt", false);
            boolean rejected = false;
            try { c.addParticipant("nobody", false); } catch (RuntimeException e) { rejected = true; }
            check(rejected && store.participants("r").size() == 1, "an AI that is not in the registry is rejected");
            rejected = false;
            try { store.upsertParticipant("no-such-room", "chatgpt", 0); } catch (RuntimeException e) { rejected = true; }
            check(rejected, "seating in a room that does not exist is rejected");
            store.ensureMockProvider("mock-delta", "Mock Delta");
            c.addParticipant("mock-delta", false);
            check(store.participants("r").size() == 2, "after registering a developer AI it can be seated");
        });

        test("Natural-turn limit is stored per room and validated", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("a", "A", RoomKind.LIVE, 1); store.createRoom("b", "B", RoomKind.LIVE, 2);
            store.setNaturalMaxTurns("a", 3);
            check(store.getRoomInfo("a").naturalMaxTurns == 3 && store.getRoomInfo("b").naturalMaxTurns == 0, "set for room a, room b untouched");
            store.setNaturalMaxTurns("b", 4); store.setNaturalMaxTurns("a", 0);
            check(store.getRoomInfo("a").naturalMaxTurns == 0 && store.getRoomInfo("b").naturalMaxTurns == 4, "each room keeps its own value");
            boolean low = false, high = false, unknown = false;
            try { store.setNaturalMaxTurns("a", -1); } catch (IllegalArgumentException e) { low = true; }
            try { store.setNaturalMaxTurns("a", 21); } catch (IllegalArgumentException e) { high = true; }
            try { store.setNaturalMaxTurns("zzz", 3); } catch (IllegalStateException e) { unknown = true; }
            check(low && high && unknown && store.getRoomInfo("a").naturalMaxTurns == 0, "out-of-range values and unknown rooms are rejected without changing anything");
        });

        test("room-scoped bindings: one current binding per room and AI, history kept", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("A", "A", RoomKind.LIVE, 1); store.createRoom("B", "B", RoomKind.LIVE, 2);
            store.upsertParticipant("A", "chatgpt", 0); store.upsertParticipant("A", "claude", 1); store.upsertParticipant("B", "chatgpt", 0);
            check(store.getBinding("A", "chatgpt") == null, "no binding yet");
            store.putBinding("A", new ProviderBinding("chatgpt", "conv-1", "https://chatgpt.com/c/conv-1", "one", 10L));
            check(store.getBinding("A", "chatgpt").providerConversationId.equals("conv-1") && store.getBinding("B", "chatgpt") == null && store.getBinding("A", "claude") == null, "a binding belongs to exactly one room and one AI");
            store.putBinding("A", new ProviderBinding("chatgpt", "conv-1", "https://chatgpt.com/c/conv-1", "one again", 11L));
            check(store.bindingHistory("A", "chatgpt").size() == 1 && store.getBinding("A", "chatgpt").boundAt == 10L, "binding the same thread again changes nothing");
            store.putBinding("A", new ProviderBinding("chatgpt", "conv-2", "https://chatgpt.com/c/conv-2", "two", 20L));
            java.util.List<BindingRecord> h = store.bindingHistory("A", "chatgpt");
            check(h.size() == 2 && h.get(0).conversationId.equals("conv-2") && h.get(0).state.equals("ACTIVE") && h.get(1).conversationId.equals("conv-1") && h.get(1).state.equals("RETIRED")
                    && h.get(1).retiredReason.equals("rebound") && h.get(1).retiredAt == 20L, "rebinding retires the old thread as history (newest first)");
            check(store.getBinding("A", "chatgpt").providerConversationId.equals("conv-2"), "only the new thread is current");
            store.clearBinding("A", "chatgpt", 30L);
            h = store.bindingHistory("A", "chatgpt");
            check(store.getBinding("A", "chatgpt") == null && h.size() == 2 && h.get(0).state.equals("RETIRED") && h.get(0).retiredReason.equals("cleared") && h.get(0).retiredAt == 30L, "clearing retires the current binding and keeps it");
            store.putBinding("A", new ProviderBinding("chatgpt", "conv-1", "https://chatgpt.com/c/conv-1", "back", 40L));
            check(store.getBinding("A", "chatgpt") != null && store.bindingHistory("A", "chatgpt").size() == 3, "after clearing, the same thread can be bound again as a new entry");
            store.clearBinding("B", "chatgpt", 50L);
            check(store.getBinding("A", "chatgpt") != null, "clearing a binding in room B never touches room A");
        });

        test("bindings need a seat and a conversation id; thread sharing is detectable", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("A", "A", RoomKind.LIVE, 1); store.createRoom("B", "B", RoomKind.LIVE, 2); store.createRoom("C", "C", RoomKind.LIVE, 3);
            store.upsertParticipant("A", "chatgpt", 0); store.upsertParticipant("B", "chatgpt", 0); store.upsertParticipant("C", "chatgpt", 0);
            boolean noSeat = false, noId = false;
            try { store.putBinding("A", new ProviderBinding("claude", "conv-x", "l", "t", 1L)); } catch (IllegalStateException e) { noSeat = true; }
            try { store.putBinding("A", new ProviderBinding("chatgpt", "", "l", "t", 1L)); } catch (IllegalArgumentException e) { noId = true; }
            check(noSeat && noId && store.getBinding("A", "claude") == null && store.getBinding("A", "chatgpt") == null, "a binding for an unseated AI or without a conversation id is rejected and nothing is stored");
            store.putBinding("A", new ProviderBinding("chatgpt", "shared", "l", "t", 1L));
            store.putBinding("B", new ProviderBinding("chatgpt", "shared", "l", "t", 2L));
            store.putBinding("C", new ProviderBinding("chatgpt", "private", "l", "t", 3L));
            check(store.otherRoomsUsingThread("chatgpt", "shared", "A").equals(java.util.Arrays.asList("B")), "room A is warned that room B uses the same thread");
            check(store.otherRoomsUsingThread("chatgpt", "private", "C").isEmpty() && store.otherRoomsUsingThread("claude", "shared", "A").isEmpty(), "no warning for a private thread or for another AI");
            store.putBinding("B", new ProviderBinding("chatgpt", "moved", "l", "t", 4L));
            check(store.otherRoomsUsingThread("chatgpt", "shared", "A").isEmpty(), "a RETIRED binding no longer counts as use");
        });

        test("a failed atomic block restores bindings, rooms and the registry", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("A", "A", RoomKind.LIVE, 1);
            store.upsertParticipant("A", "chatgpt", 0);
            store.putBinding("A", new ProviderBinding("chatgpt", "conv-1", "l", "t", 1L));
            try {
                store.atomic(() -> {
                    store.putBinding("A", new ProviderBinding("chatgpt", "conv-2", "l", "t", 2L));
                    store.createRoom("Z", "Z", RoomKind.MOCK, 3);
                    store.ensureMockProvider("mock-x", "X");
                    store.setNaturalMaxTurns("A", 5);
                    throw new IllegalStateException("probe");
                });
            } catch (IllegalStateException expected) { }
            check(store.getBinding("A", "chatgpt").providerConversationId.equals("conv-1") && store.bindingHistory("A", "chatgpt").size() == 1, "the rebind was rolled back (no ghost history)");
            check(store.getRoomInfo("Z") == null && store.getProvider("mock-x") == null && store.getRoomInfo("A").naturalMaxTurns == 0, "room, mock AI and Natural setting were rolled back too");
        });


        // ------------------------------------------------------------------ C3a review: binding writes fail visibly and are confirmed by reading back
        test("BindingWriter: success is confirmed; every failure is reported and nothing is claimed", () -> {
            InMemoryRoomStore real = new InMemoryRoomStore();
            real.createRoom("A", "A", RoomKind.LIVE, 1);
            real.upsertParticipant("A", "chatgpt", 0);
            ProviderBinding b = new ProviderBinding("chatgpt", "conv-1", "https://chatgpt.com/c/conv-1", "t", 5L);
            check(BindingWriter.bind(real, "A", b) == null && real.getBinding("A", "chatgpt").providerConversationId.equals("conv-1"), "a normal save returns null (success) and is stored");
            check(BindingWriter.bind(real, "A", b) == null, "saving the same thread again is still a success");
            String unseated = BindingWriter.bind(real, "A", new ProviderBinding("claude", "conv-2", "l", "t", 6L));
            check(unseated != null && unseated.contains("not seated") && real.getBinding("A", "claude") == null, "an AI that is not seated is reported with a reason, nothing stored: " + unseated);
            String noRoom = BindingWriter.bind(real, "nope", b);
            check(noRoom != null && real.getBinding("nope", "chatgpt") == null, "an unknown room is reported: " + noRoom);
            String blank = BindingWriter.bind(real, "A", new ProviderBinding("chatgpt", "", "l", "t", 7L));
            check(blank != null && real.getBinding("A", "chatgpt").providerConversationId.equals("conv-1"), "a binding without a conversation id is reported and the old one is untouched: " + blank);

            // a store that ACCEPTS the write but does not keep it: the read-back must catch it
            RoomStore dropping = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> m.getName().equals("putBinding") ? null : unwrap(m, real, a));
            String dropped = BindingWriter.bind(dropping, "A", new ProviderBinding("chatgpt", "conv-9", "l", "t", 8L));
            check(dropped != null && dropped.contains("did not keep"), "a write that silently did nothing is NOT reported as success: " + dropped);
            RoomStore wrong = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> m.getName().equals("putBinding") ? null : unwrap(m, real, a)); // still holds conv-1, the new thread is conv-9
            check(BindingWriter.bind(wrong, "A", new ProviderBinding("chatgpt", "conv-9", "l", "t", 9L)) != null, "a different thread read back than the one written is a failure");

            RoomStore failingWrite = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> { if (m.getName().equals("putBinding")) throw new IllegalStateException("disk full"); return unwrap(m, real, a); });
            String failed = BindingWriter.bind(failingWrite, "A", new ProviderBinding("chatgpt", "conv-3", "l", "t", 10L));
            check(failed != null && failed.contains("disk full"), "a database error is reported WITH its reason, not swallowed: " + failed);
            RoomStore failingRead = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> { if (m.getName().equals("getBinding")) throw new IllegalStateException("cannot read"); return unwrap(m, real, a); });
            String unconfirmed = BindingWriter.bind(failingRead, "A", new ProviderBinding("chatgpt", "conv-4", "l", "t", 11L));
            check(unconfirmed != null && unconfirmed.contains("cannot read"), "a save that cannot be confirmed is not claimed as success: " + unconfirmed);

            check(BindingWriter.clear(real, "A", "chatgpt", 20L) == null && real.getBinding("A", "chatgpt") == null && real.bindingHistory("A", "chatgpt").size() >= 1, "clear returns null, removes the current binding, keeps history");
            RoomStore notClearing = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> m.getName().equals("clearBinding") ? null : unwrap(m, real, a));
            real.putBinding("A", new ProviderBinding("chatgpt", "conv-5", "l", "t", 21L));
            String stillThere = BindingWriter.clear(notClearing, "A", "chatgpt", 22L);
            check(stillThere != null && stillThere.contains("still has"), "a clear that did nothing is reported: " + stillThere);
            RoomStore failingClear = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> { if (m.getName().equals("clearBinding")) throw new IllegalStateException("locked"); return unwrap(m, real, a); });
            String clearFailed = BindingWriter.clear(failingClear, "A", "chatgpt", 23L);
            check(clearFailed != null && clearFailed.contains("locked"), "a clear that throws is reported with its reason: " + clearFailed);
        });


        // ------------------------------------------------------------------ C3a review: startup room creation and the old Natural-turn preference
        test("RoomBootstrap: only the historical live room inherits the old Natural-turn preference, once", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            RoomBootstrap.prepare(store, "default", true, "Main room", 1L, 3);
            check(store.getRoomInfo("default").kind == RoomKind.LIVE && store.getRoomInfo("default").naturalMaxTurns == 3 && store.getRoomInfo("default").name.equals("Main room"),
                    "the historical live room is created LIVE and gets the old preference (3)");
            RoomBootstrap.prepare(store, "second-live", true, "Second", 2L, 3);
            check(store.getRoomInfo("second-live").kind == RoomKind.LIVE && store.getRoomInfo("second-live").naturalMaxTurns == 0, "a brand-new second LIVE room starts at the default (0), it does not inherit the old global preference");
            store.setNaturalMaxTurns("default", 4);
            RoomBootstrap.prepare(store, "default", true, "Main room", 3L, 2);
            check(store.getRoomInfo("default").naturalMaxTurns == 4 && store.listRooms().size() == 2, "opening an existing room changes nothing: the preference is applied only when the room is created");
            RoomBootstrap.prepare(store, "third", true, "Third", 4L, 99);
            check(store.getRoomInfo("third").naturalMaxTurns == 0, "an out-of-range old value cannot reach any other room either");
            InMemoryRoomStore s2 = new InMemoryRoomStore();
            RoomBootstrap.prepare(s2, "default", true, "Main room", 1L, 99);
            check(s2.getRoomInfo("default").naturalMaxTurns == 20, "an out-of-range old value is clamped to 20 for the historical room");
            InMemoryRoomStore s3 = new InMemoryRoomStore();
            RoomBootstrap.prepare(s3, "default", true, "Main room", 1L, -4);
            check(s3.getRoomInfo("default").naturalMaxTurns == 0, "a negative old value becomes 0");
        });

        test("RoomBootstrap: mode must match the room kind; developer mode registers the mock AIs", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            RoomBootstrap.prepare(store, "default", true, "Main room", 1L, 0);
            check(store.listProviders(false).size() == 2, "opening a live room registers no developer AI");
            boolean liveAsMock = false, mockAsLive = false;
            try { RoomBootstrap.prepare(store, "default", false, "x", 2L, 0); } catch (IllegalStateException e) { liveAsMock = true; }
            check(liveAsMock && store.listProviders(false).size() == 2, "an existing LIVE room cannot be opened in developer mode (and nothing is registered)");
            RoomBootstrap.prepare(store, "mock-room", false, "Mock room", 3L, 7);
            check(store.getRoomInfo("mock-room").kind == RoomKind.MOCK && store.getRoomInfo("mock-room").name.equals("Mock room") && store.getRoomInfo("mock-room").naturalMaxTurns == 0, "a developer room is created as MOCK and never receives the old preference");
            check(store.getProvider("gemini") != null && store.getProvider("mock-delta") != null && store.listProviders(true).size() == 2, "developer mode registers the catalog mocks, and they stay out of the live list");
            try { RoomBootstrap.prepare(store, "mock-room", true, "x", 4L, 0); } catch (IllegalStateException e) { mockAsLive = true; }
            check(mockAsLive, "an existing MOCK room cannot be opened as a live room");
            RoomBootstrap.prepare(store, "default", true, "Main room", 5L, 0);
            check(store.getRoomInfo("default").kind == RoomKind.LIVE, "a refused open leaves every room as it was");
            InMemoryRoomStore ghost = new InMemoryRoomStore();
            RoomStore failsAfterCreate = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> { if (m.getName().equals("ensureMockProvider")) throw new IllegalStateException("registry unavailable"); return unwrap(m, ghost, a); });
            boolean threw = false;
            try { RoomBootstrap.prepare(failsAfterCreate, "dev-room", false, "Dev", 1L, 0); } catch (IllegalStateException e) { threw = true; }
            check(threw && ghost.getRoomInfo("dev-room") == null && ghost.participants("dev-room").isEmpty(), "startup is atomic on its own: if a later step fails, the room AND its first seats are rolled back too (no half-created room)");
        });


        // ------------------------------------------------------------------ C3a review: a room's messages and deliveries can never reach into another room
        test("isolation: messages and deliveries cannot cross rooms (both directions, new rows and idempotent repeats)", () -> {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.createRoom("A", "A", RoomKind.LIVE, 1); s.createRoom("B", "B", RoomKind.LIVE, 2);
            s.upsertParticipant("A", "chatgpt", 0); s.upsertParticipant("B", "chatgpt", 0); s.upsertParticipant("A", "claude", 1);
            RoomMessage mA = s.appendMessage("A", "mA", "USER", "user", "in A", null, 1L);
            RoomMessage mB = s.appendMessage("B", "mB", "USER", "user", "in B", null, 2L);
            // duplicate canonical message id requested from another room
            boolean dupA = false, dupB = false;
            try { s.appendMessage("B", "mA", "USER", "user", "sneaky", null, 3L); } catch (IllegalStateException e) { dupA = true; }
            try { s.appendMessage("A", "mB", "USER", "user", "sneaky", null, 3L); } catch (IllegalStateException e) { dupB = true; }
            check(dupA && dupB, "re-using a message id that belongs to another room throws (it is not an idempotent repeat)");
            check(s.getMessage("mA").text.equals("in A") && s.getMessage("mA").roomId.equals("A") && s.messagesBetween("B", 0, Long.MAX_VALUE).size() == 1, "and nothing changed in either room");
            check(s.appendMessage("A", "mA", "USER", "user", "in A", null, 4L).seq == mA.seq, "the same id in the SAME room is still an idempotent repeat");
            // deliveries
            boolean trigAB = false, trigBA = false;
            try { s.createDelivery("x1", "B", "mA", "chatgpt", 1L, 5L); } catch (IllegalStateException e) { trigAB = true; }
            try { s.createDelivery("x2", "A", "mB", "chatgpt", 1L, 5L); } catch (IllegalStateException e) { trigBA = true; }
            check(trigAB && trigBA, "a delivery whose trigger message belongs to another room is rejected (both directions)");
            Delivery dA = s.createDelivery("dA", "A", "mA", "chatgpt", mA.seq, 6L);
            Delivery dB = s.createDelivery("dB", "B", "mB", "chatgpt", mB.seq, 6L);
            check(dA.roomId.equals("A") && dB.roomId.equals("B"), "the correct same-room deliveries are accepted");
            boolean idem = false;
            try { s.createDelivery("x3", "B", "mA", "chatgpt", 1L, 7L); } catch (IllegalStateException e) { idem = true; }
            check(idem, "asking room B for the delivery that room A already has (same trigger + AI) throws instead of handing back room A's delivery");
            check(s.createDelivery("again", "A", "mA", "chatgpt", mA.seq, 8L).id.equals("dA"), "the same request in the SAME room is still an idempotent repeat");
            boolean replyAB = false, replyBA = false;
            try { s.setDeliveryReply("dB", "mA"); } catch (IllegalStateException e) { replyAB = true; }
            try { s.setDeliveryReply("dA", "mB"); } catch (IllegalStateException e) { replyBA = true; }
            check(replyAB && replyBA && s.getDelivery("dA").replyMessageId.isEmpty() && s.getDelivery("dB").replyMessageId.isEmpty(), "a reply message from another room is rejected (both directions) and nothing is recorded");
            boolean ghost = false;
            try { s.setDeliveryReply("dA", "no-such-message"); } catch (IllegalStateException e) { ghost = true; }
            check(ghost, "a reply that is no message at all is rejected");
            RoomMessage rA = s.appendMessage("A", "rA", "PROVIDER", "chatgpt", "reply in A", "mA", 9L);
            RoomMessage rB = s.appendMessage("B", "rB", "PROVIDER", "chatgpt", "reply in B", "mB", 9L);
            s.setDeliveryReply("dA", "rA"); s.setDeliveryReply("dB", "rB");
            check(s.getDelivery("dA").replyMessageId.equals("rA") && s.getDelivery("dB").replyMessageId.equals("rB"), "the correct same-room replies are accepted");
            // seats
            boolean unseated = false;
            try { s.createDelivery("x4", "B", "rB", "claude", 1L, 10L); } catch (IllegalStateException e) { unseated = true; }
            check(unseated && s.getDelivery("x4") == null, "a delivery for an AI with no seat in that room is rejected");
            s.setParticipantEnabled("A", "claude", false);
            RoomMessage mA2 = s.appendMessage("A", "mA2", "USER", "user", "later", null, 11L);
            check(s.createDelivery("dA2", "A", "mA2", "claude", mA2.seq, 12L).roomId.equals("A"), "a REMOVED AI keeps its seat row, so its history is still valid");
            // a failed attempt leaves nothing behind when it runs inside a transaction
            boolean rolled = false;
            try { s.atomic(() -> { s.createDelivery("tmp", "A", "mA2", "chatgpt", 1L, 13L); s.createDelivery("tmp2", "B", "mA", "chatgpt", 1L, 13L); return null; }); } catch (IllegalStateException e) { rolled = s.getDelivery("tmp") == null; }
            check(rolled, "a cross-room attempt inside a transaction rolls the whole transaction back");
        });

        test("RoomIntegrity: the shared guards", () -> {
            RoomMessage m = new RoomMessage(1, "m", "A", "USER", "user", "t", 1L, null);
            Delivery d = new Delivery("d", "A", "m", "chatgpt", 1L, DeliveryState.PENDING, 1L, 1L);
            check(RoomIntegrity.messageInRoom(m, "A") == m && RoomIntegrity.deliveryInRoom(d, "A") == d, "same room: the existing row is returned unchanged");
            boolean a = false, b = false;
            try { RoomIntegrity.messageInRoom(m, "B"); } catch (IllegalStateException e) { a = true; }
            try { RoomIntegrity.deliveryInRoom(d, "B"); } catch (IllegalStateException e) { b = true; }
            check(a && b, "another room: both throw");
        });


        test("an ordinary new delivery starts with no reply, then a same-room reply attaches and reads back", () -> {
            InMemoryRoomStore s = new InMemoryRoomStore();
            s.createRoom("R", "R", RoomKind.LIVE, 1);
            s.upsertParticipant("R", "chatgpt", 0);
            RoomMessage trig = s.appendMessage("R", "t1", "USER", "user", "hello", null, 1L);
            Delivery d = s.createDelivery("d1", "R", trig.id, "chatgpt", trig.seq, 2L);
            check(d.replyMessageId.isEmpty() && s.getDelivery("d1").replyMessageId.isEmpty(), "a brand-new delivery has no reply yet (empty text in the app)");
            RoomMessage reply = s.appendMessage("R", "a1", "PROVIDER", "chatgpt", "hi", "t1", 3L);
            s.setDeliveryReply("d1", reply.id);
            check(s.getDelivery("d1").replyMessageId.equals("a1"), "a same-room reply attaches and reads back");
        });


        // ------------------------------------------------------------------ C3b: join / leave / rejoin notices and the registry-driven Add AI list
        test("join, leave and rejoin notices: silent when a room is created, announced afterwards, never sent to an AI", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("R", "R", RoomKind.LIVE, 1);
            AtomicInteger clk = new AtomicInteger(1000);
            java.util.function.Supplier<String> ids = new java.util.function.Supplier<String>() { int n; public String get() { return "e" + (++n); } };
            MockProvider gpt = new MockProvider("chatgpt", "ChatGPT", MockProvider.Scheduler.IMMEDIATE), cl = new MockProvider("claude", "Claude", MockProvider.Scheduler.IMMEDIATE);
            RoomController c = new RoomController(store, "R", null, () -> clk.incrementAndGet(), ids);
            c.registerProvider(gpt); c.registerProvider(cl);
            c.addParticipant("chatgpt", false);
            check(store.latestMessages("R", 10).isEmpty(), "creating the room: the first seat is silent");
            c.addParticipant("claude", true);
            java.util.List<RoomMessage> msgs = store.latestMessages("R", 10);
            check(msgs.size() == 1 && msgs.get(0).authorType.equals(RoomMessage.SYSTEM) && msgs.get(0).authorId.equals("system") && msgs.get(0).text.equals("Claude has taken a seat at the Roundtable."), "a later addition is announced with the exact wording: " + msgs);
            c.addParticipant("claude", true);
            check(store.latestMessages("R", 10).size() == 1, "adding someone who is already seated changes and says nothing");
            c.setRouting(RoutingMode.SINGLE, "chatgpt", 1);
            c.submitUserMessage("first question");
            long ctxBefore = store.participants("R").get(0).contextSeq;
            c.removeParticipant("claude");
            msgs = store.latestMessages("R", 20);
            check(msgs.get(msgs.size() - 1).text.equals("Claude has left the Roundtable.") && msgs.get(msgs.size() - 1).authorType.equals(RoomMessage.SYSTEM), "removing is announced: " + msgs.get(msgs.size() - 1).text);
            int n = msgs.size();
            c.removeParticipant("claude"); c.removeParticipant("nobody-here");
            check(store.latestMessages("R", 30).size() == n, "removing someone who is not seated (or twice) says nothing");
            RoomParticipant before = null;
            for (RoomParticipant p : store.participants("R")) if (p.providerId.equals("claude")) before = p;
            c.addParticipant("claude", true);
            msgs = store.latestMessages("R", 30);
            check(msgs.get(msgs.size() - 1).text.equals("Claude has rejoined the Roundtable."), "coming back is announced as a rejoin: " + msgs.get(msgs.size() - 1).text);
            RoomParticipant after = null;
            for (RoomParticipant p : store.participants("R")) if (p.providerId.equals("claude")) after = p;
            check(before != null && after != null && after.enabled && !before.enabled && after.position == before.position && after.contextSeq == before.contextSeq && store.participants("R").size() == 2, "rejoining re-enables the SAME seat (position and context kept, no second row)");
            c.addParticipant("chatgpt", false);
            check(store.latestMessages("R", 30).size() == msgs.size(), "a silent add of an existing seat adds nothing");
            gpt.prompts.clear(); cl.prompts.clear();
            c.setRouting(RoutingMode.ASK_ALL, "", 1);
            c.submitUserMessage("second question");
            boolean clean = !gpt.prompts.isEmpty() && !cl.prompts.isEmpty();
            for (String pr : gpt.prompts) if (pr.contains("Roundtable") || pr.contains("taken a seat") || pr.contains("has left") || pr.contains("rejoined")) clean = false;
            for (String pr : cl.prompts) if (pr.contains("Roundtable") || pr.contains("taken a seat") || pr.contains("has left") || pr.contains("rejoined")) clean = false;
            check(clean, "join/leave notices never appear in any AI's prompt");
            boolean threw = false; int before2 = store.latestMessages("R", 50).size();
            try { c.addParticipant("not-in-registry", true); } catch (RuntimeException e) { threw = true; }
            check(threw && store.latestMessages("R", 50).size() == before2 && store.participants("R").size() == 2, "an AI that is not in the registry is rejected and NO notice is left behind (seat and notice are one transaction)");
        });

        test("a notice for a developer AI uses its registered name; the Add AI list comes from the registry", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            store.createRoom("L", "L", RoomKind.LIVE, 1); store.createRoom("D", "D", RoomKind.MOCK, 2);
            store.ensureMockProvider("mock-delta", "Mock Delta");
            RoomController live = new RoomController(store, "L", null), dev = new RoomController(store, "D", null);
            live.addParticipant("chatgpt", false);
            java.util.List<String> liveIds = new java.util.ArrayList<>();
            for (ProviderInfo p : live.addableProviders(true)) liveIds.add(p.id);
            check(liveIds.equals(java.util.Arrays.asList("claude")), "a live room offers real AIs that are not seated (no developer mocks): " + liveIds);
            java.util.List<String> devIds = new java.util.ArrayList<>();
            for (ProviderInfo p : dev.addableProviders(false)) devIds.add(p.id);
            check(devIds.equals(java.util.Arrays.asList("chatgpt", "claude", "mock-delta")), "a developer room is offered everything in the registry: " + devIds);
            dev.addParticipant("mock-delta", true);
            check(store.latestMessages("D", 5).get(0).text.equals("Mock Delta has taken a seat at the Roundtable."), "the notice uses the registry's display name");
            dev.removeParticipant("mock-delta");
            java.util.List<String> devIds2 = new java.util.ArrayList<>();
            for (ProviderInfo p : dev.addableProviders(false)) devIds2.add(p.id);
            check(devIds2.contains("mock-delta") && !live.addableProviders(true).isEmpty(), "a removed AI can be added again");
            check(store.latestMessages("L", 5).isEmpty(), "notices in room D never appear in room L");
        });


        test("a seat change and its notice are one transaction", () -> {
            InMemoryRoomStore real = new InMemoryRoomStore();
            real.createRoom("T", "T", RoomKind.LIVE, 1);
            RoomStore noticeFails = (RoomStore) java.lang.reflect.Proxy.newProxyInstance(RoomStore.class.getClassLoader(), new Class<?>[]{RoomStore.class},
                    (proxy, m, a) -> { if (m.getName().equals("appendMessage")) throw new IllegalStateException("cannot write the notice"); return unwrap(m, real, a); });
            RoomController c = new RoomController(noticeFails, "T", null);
            c.addParticipant("chatgpt", false);
            boolean addThrew = false, removeThrew = false;
            try { c.addParticipant("claude", true); } catch (IllegalStateException e) { addThrew = true; }
            check(addThrew && real.participants("T").size() == 1, "if the 'taken a seat' notice cannot be written, the seat is not added either");
            try { c.removeParticipant("chatgpt"); } catch (IllegalStateException e) { removeThrew = true; }
            check(removeThrew && real.participants("T").get(0).enabled, "if the 'has left' notice cannot be written, the AI is not removed either");
            real.setParticipantEnabled("T", "chatgpt", false);
            boolean rejoinThrew = false;
            try { c.addParticipant("chatgpt", true); } catch (IllegalStateException e) { rejoinThrew = true; }
            check(rejoinThrew && !real.participants("T").get(0).enabled, "if the 'rejoined' notice cannot be written, the AI is not re-seated either");
        });


        test("New room: an empty LIVE room named 'Room N', unique ids, other rooms untouched", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            RoomBootstrap.prepare(store, "default", true, "Main room", 1L, 0);
            store.createRoom("mock-1", "Room 2", RoomKind.MOCK, 2L); // a developer room that happens to be called Room 2
            java.util.function.Supplier<String> ids = new java.util.function.Supplier<String>() { int n; public String get() { return "id" + (++n); } };
            RoomInfo r1 = RoomBootstrap.createLiveRoom(store, ids, 10L);
            RoomInfo r2 = RoomBootstrap.createLiveRoom(store, ids, 11L);
            check(r1.name.equals("Room 3") && r2.name.equals("Room 4") && r1.kind == RoomKind.LIVE && r2.kind == RoomKind.LIVE, "names count up from 2 and skip names already used by ANY room: " + r1.name + ", " + r2.name);
            check(!r1.id.equals(r2.id) && !r1.id.equals("default") && r1.naturalMaxTurns == 0, "each new room gets its own id and the default Natural setting (the old preference is not inherited)");
            check(store.participants(r1.id).size() == 2 && store.latestMessages(r1.id, 5).isEmpty(), "a new room is created with its first two seats and NO notice (initial seating is silent)");
            check(store.getRoom(r1.id).mode == RoutingMode.AUTO_PICK && store.getRoom(r1.id).modeArg.equals("chatgpt") && store.getRoom(r1.id).rounds == 1, "...and starts in natural conversation led by ChatGPT");
            check(store.listRooms().size() == 4 && store.listRooms().get(0).id.equals("default") && store.getRoomInfo("default").name.equals("Main room"), "the main room is untouched and the list stays oldest first");
            RoomBootstrap.prepare(store, r1.id, true, "x", 12L, 7);
            check(store.getRoomInfo(r1.id).naturalMaxTurns == 0 && store.getRoomInfo(r1.id).name.equals("Room 3"), "opening a new room later does not rename it or give it the old preference");
            InMemoryRoomStore s2 = new InMemoryRoomStore();
            boolean clash = false;
            s2.createRoom("room-same", "Room 9", RoomKind.LIVE, 1L);
            try { RoomBootstrap.createLiveRoom(s2, () -> "same", 2L); } catch (IllegalStateException e) { clash = true; }
            check(clash && s2.listRooms().size() == 1, "an id clash is refused and nothing is created");
        });


        // ------------------------------------------------------------------ C3b review: first seats exist only because a room was CREATED; opening a room never seats anyone
        test("first seats are made at creation (silent) and never inferred from an empty room", () -> {
            InMemoryRoomStore store = new InMemoryRoomStore();
            RoomBootstrap.prepare(store, "default", true, "Main room", 1L, 0);
            java.util.List<RoomParticipant> seats = store.participants("default");
            check(seats.size() == 2 && seats.get(0).providerId.equals("chatgpt") && seats.get(0).position == 0 && seats.get(1).providerId.equals("claude") && seats.get(1).position == 1 && seats.get(0).enabled && seats.get(1).enabled,
                    "a newly created room (opened for the first time) has ChatGPT and Claude seated, enabled, in that order");
            check(store.latestMessages("default", 5).isEmpty() && store.getRoom("default").modeArg.equals("chatgpt") && store.getRoom("default").mode == RoutingMode.AUTO_PICK, "initial seating is silent and sets natural conversation led by ChatGPT");
            RoomBootstrap.prepare(store, "mock-room", false, "Mock room", 2L, 0);
            check(store.participants("mock-room").size() == 2 && store.latestMessages("mock-room", 5).isEmpty(), "a new developer room is seated the same way, silently");

            // the user removes BOTH AIs: notices appear, the rows stay (disabled)
            RoomController c = new RoomController(store, "default", null);
            c.removeParticipant("chatgpt"); c.removeParticipant("claude");
            int notices = store.latestMessages("default", 10).size();
            check(notices == 2 && !store.participants("default").get(0).enabled && !store.participants("default").get(1).enabled, "removing both AIs leaves two disabled rows and two 'left' notices");
            RoomBootstrap.prepare(store, "default", true, "Main room", 3L, 5);   // reopening
            RoomBootstrap.prepare(store, "default", true, "Main room", 4L, 5);   // and again
            check(store.participants("default").size() == 2 && !store.participants("default").get(0).enabled && !store.participants("default").get(1).enabled && store.latestMessages("default", 10).size() == notices,
                    "reopening a room where everyone was removed does not bring anyone back, and adds no notice");

            // removing both, switching away to another room and back
            RoomInfo other = RoomBootstrap.createLiveRoom(store, () -> "other", 10L);
            RoomBootstrap.prepare(store, other.id, true, "x", 11L, 0);
            RoomBootstrap.prepare(store, "default", true, "Main room", 12L, 0);
            check(store.participants(other.id).size() == 2 && store.participants(other.id).get(0).enabled, "the other room has its own two seats");
            check(!store.participants("default").get(0).enabled && !store.participants("default").get(1).enabled && store.participants("default").size() == 2, "switching away and back does not resurrect either AI");

            // an existing room with genuinely zero seat rows (like the one the migration preserves) stays empty
            store.createRoom("no-seats", "No seats", RoomKind.LIVE, 20L);
            RoomBootstrap.prepare(store, "no-seats", true, "x", 21L, 0);
            RoomBootstrap.prepare(store, "no-seats", true, "x", 22L, 0);
            check(store.participants("no-seats").isEmpty() && store.latestMessages("no-seats", 5).isEmpty(), "an existing room with no seat rows at all stays empty after reopening");
            // the controller never seats anyone on its own either
            RoomController empty = new RoomController(store, "no-seats", null);
            check(empty.participants().isEmpty() && empty.addableProviders(true).size() == 2, "building a controller for an empty room seats nobody (both AIs are offered under Add)");
        });

        System.out.println("\n" + checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
