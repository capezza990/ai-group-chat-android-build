import com.aigroupchat.bridge.room.sqlite.SqlScript;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/** Checks the REAL statement splitter on the REAL asset scripts. Usage: SqlScriptTest <assets dir> [dump file]
 *  With a dump file it also writes the statements (one per block, separated by a line "=====") so migration_test.py can compare them with its own split. */
public final class SqlScriptTest {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }

    public static void main(String[] a) throws Exception {
        String dir = a[0];
        String schema = new String(Files.readAllBytes(Paths.get(dir, "room_schema_v1.sql")), StandardCharsets.UTF_8);
        String mig = new String(Files.readAllBytes(Paths.get(dir, "room_migration_v1_to_v2.sql")), StandardCharsets.UTF_8);
        List<String> ms = SqlScript.statements(mig, 1_800_000_000_000L, 3), ss = SqlScript.statements(schema, 0L, 0);
        check(ss.size() == 9 && ms.size() >= 40, "both scripts produce statements: schema " + ss.size() + ", migration " + ms.size());
        boolean clean = true;
        for (String s : ms) {
            if (s.isEmpty() || s.contains("\n--") || s.startsWith("--") || s.contains(":now") || s.contains(":natural_turns")) clean = false;
            if (!(s.startsWith("CREATE") || s.startsWith("INSERT") || s.startsWith("ALTER") || s.startsWith("UPDATE") || s.startsWith("DROP"))) clean = false;
        }
        check(clean, "no statement is empty, carries a comment line, keeps a placeholder, or starts with something unexpected");
        check(ms.stream().anyMatch(s -> s.contains("1800000000000")) && ms.stream().anyMatch(s -> s.contains("natural_max_turns = 3 WHERE")), "':now' and ':natural_turns' are filled in");
        check(ms.get(0).startsWith("CREATE TABLE provider_profiles"), "the first migration statement is the registry table (leading comment dropped)");
        check(SqlScript.statements("-- only a comment\n-- @@\nSELECT 1\n-- @@\n\n-- @@\nSELECT 2", 0, 0).toString().equals("[SELECT 1, SELECT 2]"), "comment-only and empty chunks are skipped");
        check(SqlScript.statements("SELECT 1\r\n-- @@\r\nSELECT 2", 0, 0).size() == 2, "Windows line endings split the same way");
        check(!java.util.regex.Pattern.compile(":(now|natural_turns)[A-Za-z0-9_]").matcher(mig).find(), "the scripts never put text right after a placeholder (the replacement is plain text substitution)");
        if (a.length > 1) {
            StringBuilder sb = new StringBuilder();
            for (String s : ms) sb.append(s).append("\n=====\n");
            Files.write(Paths.get(a[1]), sb.toString().getBytes(StandardCharsets.UTF_8));
        }
        System.out.println((failures == 0 ? "PASS  " : "FAIL  ") + "SQL script splitter (" + checks + " checks, " + failures + " failures)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
