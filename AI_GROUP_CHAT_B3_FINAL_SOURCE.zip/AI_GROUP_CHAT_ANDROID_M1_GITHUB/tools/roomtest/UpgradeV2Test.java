import com.aigroupchat.bridge.room.sqlite.UpgradeV2;

import java.util.ArrayList;
import java.util.List;

/** Proves the fixed order of the v1 -> v2 upgrade and that a failing step stops everything after it (the caller's transaction then rolls back). */
public final class UpgradeV2Test {
    static int checks, failures;
    static void check(boolean ok, String what) { checks++; if (!ok) { failures++; System.out.println("    FAIL: " + what); } }

    static final class Rec implements UpgradeV2.Steps {
        final List<String> log = new ArrayList<>();
        String failAt = null;
        private void step(String n) { log.add(n); if (n.equals(failAt)) throw new IllegalStateException("boom in " + n); }
        @Override public void importLegacyPreferenceBindings() { step("import"); }
        @Override public void runMigrationScript() { step("script"); }
        @Override public void checkForeignKeys() { step("fkcheck"); }
    }

    public static void main(String[] args) {
        Rec r = new Rec();
        UpgradeV2.run(r);
        check(r.log.toString().equals("[import, script, fkcheck]"), "order: old preference bindings are imported BEFORE the script that copies them into rooms, and the foreign-key check comes last: " + r.log);
        for (String bad : new String[]{"import", "script", "fkcheck"}) {
            Rec f = new Rec(); f.failAt = bad;
            boolean threw = false;
            try { UpgradeV2.run(f); } catch (IllegalStateException e) { threw = true; }
            String expect = bad.equals("import") ? "[import]" : bad.equals("script") ? "[import, script]" : "[import, script, fkcheck]";
            check(threw && f.log.toString().equals(expect), "a failure in '" + bad + "' reaches the caller (so the upgrade rolls back) and no later step runs: " + f.log);
        }
        System.out.println((failures == 0 ? "PASS  " : "FAIL  ") + "upgrade order (" + checks + " checks, " + failures + " failures)");
        System.exit(failures == 0 ? 0 : 1);
    }
}
