#!/usr/bin/env python3
"""Source-level safety rules for the Android-only part of FILE CAPTURE (the web view can only be compile-checked off-device). Each rule is checked on the real
source, and --selftest breaks every rule on purpose in a copy of the text and requires the check to notice."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[2]
E = ROOT / 'app/src/main/java/com/aigroupchat/bridge/engine'
files = {n: (E / (n + '.java')).read_text() for n in ('WebProviderSurface', 'WebCaptureTransport', 'WebRoomProvider', 'ProviderSpec', 'EngineLabActivity')}
script = (ROOT / 'app/src/main/assets/agc_engine.js').read_text()

def method(src, signature):
    i = src.find(signature)
    if i < 0: return ''
    depth, j = 0, src.index('{', i)
    for k in range(j, len(src)):
        if src[k] == '{': depth += 1
        elif src[k] == '}':
            depth -= 1
            if depth == 0: return src[i:k + 1]
    return ''

def rules(f, js):
    S, T, R, P, L = (f[k] for k in ('WebProviderSurface', 'WebCaptureTransport', 'WebRoomProvider', 'ProviderSpec', 'EngineLabActivity'))
    cap = method(S, 'public void captureFile(')
    cancel = method(S, 'public void cancelCapture()')
    destroy = method(S, 'public void destroy()')
    bridge = method(S, 'private final class Bridge')
    out = []
    def need(c, msg): out.append((bool(c), msg))
    need(S.count('@JavascriptInterface') == 1 and 'public void event(String json)' in bridge, 'the page-to-app bridge stays powerless: still exactly one tiny event() method, nothing receives file bytes')
    need('window.AGCBridge' not in js.split('function captureUrl')[1].split('function captureEnd')[0], 'the capture functions of the page script never push anything to the bridge (the app pulls)')
    need(re.search(r'setDownloadListener\(\(url, userAgent, contentDisposition, mimetype, contentLength\) -> \{\s*FileCaptureFlow\.DownloadSink sink = armedDownloads;\s*if \(sink != null\) sink\.onDownload', S) is not None, 'a download is ignored unless a capture armed it')
    need('rendererGone' in cap and cap.find('rendererGone') < cap.find('beginCapture('), 'a capture checks the renderer before taking the surface')
    need('beginCapture(conversationId)' in cap and cap.find('beginCapture(') < cap.find('new FileCaptureFlow('), 'the surface is taken (beginCapture) before a capture flow exists')
    need(cap.count('surfaceOperation.finishCapture(op)') == 2 and 'public void onFile' in cap and 'public void onFailed' in cap, 'the surface is released on BOTH endings of a capture (file and failure)')
    need(cap.find('if (cancelled[0]) { f.delete(); return; }') > 0 and 'if (cancelled[0]) return;' in cap, 'after a cancel a late result is dropped (and its file deleted), never delivered')
    need('surfaceOperation.hasActiveCapture()' in cancel and 'surfaceOperation.retire()' in cancel and cancel.find('hasActiveCapture') < cancel.find('retire()'), 'cancelling a capture retires the operation only while a CAPTURE holds it (never an upload or a turn)')
    need('armedDownloads = null' in cancel, 'cancelling a capture disarms downloads')
    need('cancelCapture();' in destroy and destroy.find('cancelCapture();') < destroy.find('cancelAttachmentOperation();'), 'closing the screen cancels a running capture first')
    need('FileOfferMatcher.replyOffers(r.fileOffers, r.providerAsstMsgId)' in S, 'a reply promises only the files of its own exact reply')
    need('req.replyRef = replyRef' in cap and 'req.downloadHosts = spec.downloadHosts' in cap, 'the capture request carries the exact reply and the provider\'s own download hosts')
    need('ProviderTransferIdentity.forCleanup(' in T and 'store.sourceReplyRef(artifact.id)' in T and T.find('target == null') < T.find('surface.captureFile('), 'the transport resolves the exact conversation and reply from the room and refuses without the conversation')
    need('ChunkedReceiver.openAndDelete(file)' in T, 'the captured temp file is handed over through a stream that deletes it when closed')
    need('public void onReplyWithFiles' in R and 'l.onReplyWithFiles(text, providerAsstMsgId, files)' in R and 'l.onReply(text, providerAsstMsgId)' in R, 'the room provider reports a reply with files, or plainly without')
    need(P.count('downloadHosts') >= 3 and 'offerLink' in P and 'offerButton' in P, 'both provider profiles declare their download hosts and file-offer selectors')
    need('Probe files' in L and 'Capture test' in L and 'withStableId' in L, 'the Engine Lab can probe file offers and test a capture')
    return out

def run(f, js): return rules(f, js)

if '--selftest' in sys.argv:
    S0 = files['WebProviderSurface']
    breaks = [
        ('a second JavascriptInterface method appears', 'WebProviderSurface', lambda s: s.replace('public void event(String json) {', 'public void file(String b64) { }\n        @JavascriptInterface\n        public void event(String json) {', 1)),
        ('downloads are accepted without being armed', 'WebProviderSurface', lambda s: s.replace('if (sink != null) sink.onDownload(url, userAgent, mimetype, contentLength);', 'if (sink != null) sink.onDownload(url, userAgent, mimetype, contentLength); else { }\n            sink = null;', 1).replace('FileCaptureFlow.DownloadSink sink = armedDownloads;', 'FileCaptureFlow.DownloadSink sink = armedDownloads;\n            if (sink == null) sink = (u, a, m, l) -> { };', 1)),
        ('the surface is taken after the flow is created', 'WebProviderSurface', lambda s: s.replace('final ProviderSurfaceOperation.Capture op = surfaceOperation.beginCapture(conversationId);', 'final ProviderSurfaceOperation.Capture op = null;', 1)),
        ('a failed capture does not release the surface', 'WebProviderSurface', lambda s: s.replace('            @Override public void onFailed(String reason) {\n                surfaceOperation.finishCapture(op);', '            @Override public void onFailed(String reason) {', 1)),
        ('cancelCapture retires any operation', 'WebProviderSurface', lambda s: s.replace('if (surfaceOperation.hasActiveCapture()) surfaceOperation.retire();', 'surfaceOperation.retire();', 1)),
        ('cancelCapture leaves downloads armed', 'WebProviderSurface', lambda s: s.replace('        armedDownloads = null;\n    }\n\n    private final class CaptureDriver', '    }\n\n    private final class CaptureDriver', 1)),
        ('destroy does not cancel a capture', 'WebProviderSurface', lambda s: s.replace('        cancelCapture();\n        cancelAttachmentOperation();', '        cancelAttachmentOperation();', 1)),
        ('a reply promises the newest message again', 'WebProviderSurface', lambda s: s.replace('replyOffers(r.fileOffers, r.providerAsstMsgId)', 'replyOffers(r.fileOffers)', 1)),
        ('the capture request forgets the reply', 'WebProviderSurface', lambda s: s.replace('req.replyRef = replyRef == null ? "" : replyRef; ', '', 1)),
        ('the transport forgets the reply identity', 'WebCaptureTransport', lambda s: s.replace('store.sourceReplyRef(artifact.id)', '""', 1)),
        ('the captured file is not deleted when closed', 'WebCaptureTransport', lambda s: s.replace('ChunkedReceiver.openAndDelete(file)', 'new java.io.FileInputStream(file)', 1)),
        ('the room provider drops the files', 'WebRoomProvider', lambda s: s.replace('l.onReplyWithFiles(text, providerAsstMsgId, files)', 'l.onReply(text, providerAsstMsgId)', 1)),
    ]
    problems = 0
    for what, key, fn in breaks:
        g = dict(files); g[key] = fn(files[key])
        if g[key] == files[key]: print('FAIL  self-test anchor missing: ' + what); problems += 1; continue
        if all(ok for ok, _ in run(g, script)): print('FAIL  not noticed: ' + what); problems += 1
    print(('PASS  ' if problems == 0 else 'FAIL  ') + 'capture source rules self-test (%d breakages, %d not noticed)' % (len(breaks), problems))
    sys.exit(1 if problems else 0)

bad = 0
for ok, msg in run(files, script):
    print(('PASS  ' if ok else 'FAIL  ') + msg)
    if not ok: bad += 1
sys.exit(1 if bad else 0)
