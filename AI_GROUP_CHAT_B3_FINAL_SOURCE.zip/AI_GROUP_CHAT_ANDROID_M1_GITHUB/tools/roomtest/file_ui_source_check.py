#!/usr/bin/env python3
"""Source-level safety checks for RoomActivity's attachment/status/retry UI.
The Android screen itself is compiled in the Android build; these checks make the wiring rules mutation-testable off-device."""
from pathlib import Path
import re, sys
HERE = Path(__file__).resolve().parent
REAL = HERE.parent.parent / 'app/src/main/java/com/aigroupchat/bridge/room/ui/RoomActivity.java'

def methods(src):
    starts=[(m.start(),m.group(1)) for m in re.finditer(r'(?m)^    (?:private|public|protected)(?:\s+static)?(?:\s+final)?\s+[\w<>\[\], ?]+\s+(\w+)\s*\([^)]*\)\s*\{',src)]
    out={}
    for i,(pos,name) in enumerate(starts): out[name]=src[pos:(starts[i+1][0] if i+1<len(starts) else len(src))]
    return out

def check(src):
    bad=[]; ms=methods(src)
    def need(cond,msg):
        if not cond: bad.append(msg)
    need('File sharing between the AIs is the next milestone.' not in src and 'attachBtn.setOnClickListener(v -> chooseFiles())' in src, 'paperclip must open the real file picker')
    choose=ms.get('chooseFiles','')
    need('Intent.ACTION_OPEN_DOCUMENT' in choose and 'Intent.EXTRA_ALLOW_MULTIPLE' in choose and 'controller.isBusy()' in choose, 'picker must be open-document, multi-select and blocked during a run')
    imp=ms.get('importPickedFiles','')
    need('new Thread(' in imp and 'svc.addUserFile(roomId, name, mime, in)' in imp, 'picked bytes must be copied through ArtifactService off the UI thread')
    send=ms.get('send','')
    submit=send.find('submitUserMessage(text, plan.steps, new ArrayList<>(pendingArtifactIds))')
    clear=send.find('pendingArtifactIds.clear()')
    nullcheck=send.find('if (m == null)')
    need(submit >= 0 and nullcheck > submit and clear > nullcheck, 'pending ids become immutable message attachments only after submit succeeds')
    remove=ms.get('removePendingFile','')
    destroy=ms.get('onDestroy','')
    need('svc.discard(artifactId)' in remove and 'svc.discard(id)' in destroy, 'unsent files must be discardable and cleaned on screen destruction')
    render=ms.get('renderMessageAttachments','') + ms.get('messageAttachmentCard','')
    need('db.artifactsOfMessage(messageId)' in render and 'ArtifactUiRules.transferStatus' in render, 'transcript cards must render canonical artifact and transfer status')
    need('artifactService.retryCapture(artifactId)' not in src and 'svc.retryCapture(artifactId)' in ms.get('retryCapture','') and 'svc.startCaptures(one)' in ms.get('retryCapture',''), 'capture Retry must use ArtifactService and restart the capture queue')
    need('svc.retryTransfer(artifactId, roomId, providerId)' in ms.get('retryTransfer',''), 'transfer Retry must use ArtifactService')
    need('db.sourceReplyRef(a.id)' in src and 'ArtifactUiRules.canRetryCapture(a, replyKnown)' in src and 'ArtifactUiRules.freshFileText()' in src, 'capture Retry is shown only when the exact reply is known; otherwise the screen explains why not')
    refresh=ms.get('refreshAll','')
    need('boolean anyBusy = busy || fileServiceBusy();' in refresh, 'Send/Stop must include standalone shared file jobs')
    for call in ('setText', 'setContentDescription', 'setBackground'):
        line=next((line for line in refresh.splitlines() if 'sendBtn.'+call+'(' in line), '')
        need('anyBusy ?' in line, 'Send/Stop '+call+' must use the common busy state')
    setter=ms.get('setArtifactService','')
    need('controller.setArtifactService(service)' in setter, 'final lifecycle wiring must have one explicit UI injection point')
    openp=ms.get('openProvider','')
    need('blockedByWork(' in openp and openp.find('blockedByWork(') < openp.find('surfaces.get(id)'), 'provider overlay must be blocked (run OR shared file service) before touching a provider surface')
    need('.transitionTransfer(' not in src and '.retryArtifact(' not in src, 'UI must not bypass ArtifactService/store transfer rules')
    return bad

def selftest(real):
    muts=[
      ('paperclip placeholder returns', real.replace('attachBtn.setOnClickListener(v -> chooseFiles());','attachBtn.setOnClickListener(v -> toast("File sharing between the AIs is the next milestone."));',1)),
      ('picker can open during a run', real.replace('if (controller != null && controller.isBusy()) { toast("Wait for the current run to finish before attaching files."); return; }','',1)),
      ('file copy bypasses service', real.replace('svc.addUserFile(roomId, name, mime, in)','null',1)),
      ('send forgets pending ids', real.replace('submitUserMessage(text, plan.steps, new ArrayList<>(pendingArtifactIds))','submitUserMessage(text, plan.steps)',1)),
      ('pending remove leaks bytes', real.replace('if (svc != null && !svc.discard(artifactId))','if (svc != null && false)',1)),
      ('transcript stops reading canonical attachments', real.replace('db.artifactsOfMessage(messageId)','new ArrayList<>()',1)),
      ('capture retry does not restart capture', real.replace('svc.startCaptures(one);','',1)),
      ('transfer retry bypass removed', real.replace('svc.retryTransfer(artifactId, roomId, providerId)','false',1)),
      ('capture retry offered without knowing the reply', real.replace('ArtifactUiRules.canRetryCapture(a, replyKnown)','ArtifactUiRules.canRetryCapture(a, true)',1)),
      ('the reply identity is never looked up', real.replace('!db.sourceReplyRef(a.id).isEmpty()','true',1)),
      ('service injection no longer reaches controller', real.replace('if (controller != null) controller.setArtifactService(service);','',1)),
      ('provider page opens during run', real.replace('if (blockedByWork("Wait for the current run to finish before opening a provider page.")) return;','',1)),
      ('destroy leaks unsent files', real.replace('for (String id : new ArrayList<>(pendingArtifactIds)) svc.discard(id);','',1)),
    ]
    for call in ('setText', 'setContentDescription', 'setBackground'):
        line=next(line for line in methods(real)['refreshAll'].splitlines() if 'sendBtn.'+call+'(' in line)
        muts.append(('standalone job ignored by '+call, real.replace(line, line.replace('anyBusy ?', 'busy ?'), 1)))
    muts.append(('standalone job omitted from common state', real.replace('boolean anyBusy = busy || fileServiceBusy();', 'boolean anyBusy = busy;', 1)))
    missed=0
    for name,mut in muts:
        if mut==real:
            print('    FAIL mutation did not apply: '+name); missed+=1; continue
        if check(mut):
            continue
        print('    FAIL not noticed: '+name); missed+=1
    print(('PASS  ' if missed==0 else 'FAIL  ')+f'file UI source rules self-test ({len(muts)} breakages, {missed} not noticed)')
    return missed

if __name__=='__main__':
    src=REAL.read_text(encoding='utf-8')
    if '--selftest' in sys.argv: sys.exit(1 if selftest(src) else 0)
    problems=check(src)
    for p in problems: print('    FAIL: '+p)
    print(('PASS  ' if not problems else 'FAIL  ')+'file attachment/status/retry UI source rules')
    sys.exit(1 if problems else 0)
