import os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'assets')
SCHEMA = os.path.abspath(os.path.join(ASSETS, 'room_schema_v1.sql'))
base = open(os.path.join(ASSETS, 'room_migration_v1_to_v2.sql')).read()
HEX_INS = "WHEN NEW.state = 'READY' AND (NEW.size < 0 OR length(NEW.sha256) <> 64 OR NEW.sha256 GLOB '*[^0-9A-Fa-f]*' OR NEW.storage_path = '')"
HEX_UPD = "WHEN NEW.state = 'READY' AND OLD.state <> 'READY' AND (NEW.size < 0 OR length(NEW.sha256) <> 64 OR NEW.sha256 GLOB '*[^0-9A-Fa-f]*' OR NEW.storage_path = '')"
# (No breakage for 'deliveries.room_id REFERENCES rooms(id)': it is an equivalent mutant. The composite key (trigger_message_id, room_id) -> messages(id, room_id)
#  already forces the delivery's room to be the room of an existing message, and messages.room_id references rooms.)
# Equivalent breakages that were removed on purpose (a second rule already blocks the same bad change, so removing one of them changes nothing):
#   N3  'READY -> FAILED' inside artifacts_ready_is_final: artifacts_state_path (C4) forbids it too.
#   T7  the transfer state CHECK: start_clean (inserts) and state_path (updates) already reject any value outside the four states.
#   T8  attempts >= 0: start_clean forces 0 and attempts_count only allows +1, so it can never go negative.
# (No breakage for CHECK (origin <> 'user' OR source_binding_id IS NULL): it is an equivalent mutant, because the foreign key (source_binding_id, room_id, origin)
#  already refuses a user file with a source: no binding belongs to an AI called 'user'.)
MUTS = [
 ("N1  default for rooms.kind is MOCK again", "ADD COLUMN kind TEXT NOT NULL DEFAULT 'LIVE'", "ADD COLUMN kind TEXT NOT NULL DEFAULT 'MOCK'"),
 ("N2  natural-turn preference not written", "SET natural_max_turns = :natural_turns WHERE", "SET natural_max_turns = 0 WHERE"),
 ("N4  MIME not frozen once READY", "OR NEW.mime <> OLD.mime", ""),
 ("N5  READY via UPDATE needs no file", HEX_UPD, "WHEN 0"),
 ("N6  READY via INSERT needs no file", HEX_INS, "WHEN 0"),
 ("N7  empty files rejected (size <= 0) on UPDATE", HEX_UPD, HEX_UPD.replace("NEW.size < 0","NEW.size <= 0")),
 ("N8  hash length not checked on INSERT", HEX_INS, HEX_INS.replace("length(NEW.sha256) <> 64 OR ","")),
 ("N10 negative size allowed on INSERT", HEX_INS, HEX_INS.replace("NEW.size < 0 OR ","")),
 ("N11 negative size allowed on UPDATE", HEX_UPD, HEX_UPD.replace("NEW.size < 0 OR ","")),
 ("N12 storage path not required on UPDATE", HEX_UPD, HEX_UPD.replace(" OR NEW.storage_path = ''","")),
 ("P1  non-hex hash accepted on INSERT", HEX_INS, HEX_INS.replace(" OR NEW.sha256 GLOB '*[^0-9A-Fa-f]*'","")),
 ("P2  non-hex hash accepted on UPDATE", HEX_UPD, HEX_UPD.replace(" OR NEW.sha256 GLOB '*[^0-9A-Fa-f]*'","")),
 ("P3  transfers allowed on any binding (trigger removed)", "WHEN (SELECT state FROM room_bindings WHERE id = NEW.binding_id) IS NOT 'ACTIVE'", "WHEN 0"),
 ("P4  transfers allowed on a RETIRED binding", "IS NOT 'ACTIVE'", "NOT IN ('ACTIVE','RETIRED')"),
 ("P5  transfers allowed on a PENDING_NEW binding", "IS NOT 'ACTIVE'", "NOT IN ('ACTIVE','PENDING_NEW')"),
 ("P7  a no-delete trigger on READY artifacts is back", "CREATE TRIGGER artifacts_ready_is_final", "CREATE TRIGGER artifacts_ready_no_delete BEFORE DELETE ON artifacts WHEN OLD.state = 'READY'\nBEGIN SELECT RAISE(ABORT, 'x'); END\n-- @@\nCREATE TRIGGER artifacts_ready_is_final"),
 ("M1  no 'one current binding' index", "CREATE UNIQUE INDEX room_bindings_one_current", "CREATE INDEX room_bindings_one_current"),
 ("M2  index only covers ACTIVE", "WHERE state IN ('ACTIVE','PENDING_NEW')", "WHERE state = 'ACTIVE'"),
 ("M3  binding FK to participants removed", "  FOREIGN KEY (room_id, provider_id) REFERENCES participants(room_id, provider_id),\n  CHECK ((state", "  CHECK ((state"),
 ("M4  message_artifacts loses its MESSAGE FK", "  FOREIGN KEY (message_id, room_id) REFERENCES messages(id, room_id),\n  FOREIGN KEY (artifact_id, room_id) REFERENCES artifacts(id, room_id)\n)", "  FOREIGN KEY (artifact_id, room_id) REFERENCES artifacts(id, room_id)\n)"),
 ("M4b message_artifacts loses its ARTIFACT FK", "  FOREIGN KEY (message_id, room_id) REFERENCES messages(id, room_id),\n  FOREIGN KEY (artifact_id, room_id) REFERENCES artifacts(id, room_id)\n)", "  FOREIGN KEY (message_id, room_id) REFERENCES messages(id, room_id)\n)"),
 ("M5  transfer FK ignores provider/room of the binding", "FOREIGN KEY (binding_id, room_id, provider_id) REFERENCES room_bindings(id, room_id, provider_id)", "FOREIGN KEY (binding_id) REFERENCES room_bindings(id)"),
 ("M5b transfer FK ignores the artifact's room", "  FOREIGN KEY (artifact_id, room_id) REFERENCES artifacts(id, room_id),\n  FOREIGN KEY (binding_id", "  FOREIGN KEY (artifact_id) REFERENCES artifacts(id),\n  FOREIGN KEY (binding_id"),
 ("M6  retired bindings editable", "BEFORE UPDATE ON room_bindings WHEN OLD.state = 'RETIRED'", "BEFORE UPDATE ON room_bindings WHEN 0"),
 ("M7  bindings not copied", "FROM provider_bindings b JOIN participants p ON p.room_id = 'default' AND p.provider_id = b.provider_id", "FROM provider_bindings b JOIN participants p ON p.room_id = 'default' AND p.provider_id = b.provider_id WHERE 0"),
 ("M8  participants rebuild drops the context position", "SELECT room_id, provider_id, enabled, position, context_seq, mirror_state FROM participants", "SELECT room_id, provider_id, enabled, position, 0, mirror_state FROM participants"),
 ("M9  participants no longer reference the registry", "provider_id TEXT NOT NULL REFERENCES providers(id),\n  enabled", "provider_id TEXT NOT NULL,\n  enabled"),
 ("M10 mock-room not marked MOCK", "SET kind = CASE WHEN id = 'default' THEN 'LIVE' ELSE 'MOCK' END", "SET kind = 'LIVE'"),
 ("M11 a Gemini row would be CORE (live placeholder)", "'', 'mock', 'MOCK', :now", "'', 'mock', 'CORE', :now"),
 ("Q1  any room that lacks Claude gets Claude (the bug ChatGPT found)", "SELECT 'default', 'claude', 1, 1, 0, 'UNKNOWN' WHERE EXISTS (SELECT 1 FROM _mig_new_default)", "SELECT 'default', 'claude', 1, 1, 0, 'UNKNOWN' WHERE EXISTS (SELECT 1 FROM rooms WHERE id='default') AND NOT EXISTS (SELECT 1 FROM participants WHERE room_id='default' AND provider_id='claude')"),
 ("Q2  ChatGPT is added to any default room with no seats", "SELECT 'default', 'chatgpt', 1, 0, 0, 'UNKNOWN' WHERE EXISTS (SELECT 1 FROM _mig_new_default)", "SELECT 'default', 'chatgpt', 1, 0, 0, 'UNKNOWN' WHERE EXISTS (SELECT 1 FROM rooms WHERE id='default') AND NOT EXISTS (SELECT 1 FROM participants WHERE room_id='default')"),
 ("Q3  the marker table is never dropped", "DROP TABLE _mig_new_default", "SELECT 1"),
 ("Q4  the legacy-room marker is always set", "AND EXISTS (SELECT 1 FROM provider_bindings)\n-- @@\nINSERT INTO rooms", "\n-- @@\nINSERT INTO rooms"),
 ("Q5  transfer identity not protected at all", "CREATE TRIGGER artifact_transfers_identity_fixed BEFORE UPDATE ON artifact_transfers\nWHEN NEW.artifact_id <> OLD.artifact_id OR NEW.room_id <> OLD.room_id OR NEW.provider_id <> OLD.provider_id OR NEW.binding_id <> OLD.binding_id", "CREATE TRIGGER artifact_transfers_identity_fixed BEFORE UPDATE ON artifact_transfers\nWHEN 0"),
 ("Q6  transfer binding_id may be re-pointed", " OR NEW.binding_id <> OLD.binding_id\nBEGIN SELECT RAISE(ABORT, 'a transfer is tied", "\nBEGIN SELECT RAISE(ABORT, 'a transfer is tied"),
 ("Q9  transfer artifact_id may change", "WHEN NEW.artifact_id <> OLD.artifact_id OR NEW.room_id <> OLD.room_id OR NEW.provider_id", "WHEN NEW.room_id <> OLD.room_id OR NEW.provider_id"),
 ("Q10 transfer state/attempts frozen too", "OR NEW.binding_id <> OLD.binding_id\nBEGIN", "OR NEW.binding_id <> OLD.binding_id OR NEW.attempts <> OLD.attempts\nBEGIN"),
 ("Q11 preference forced onto every room", "UPDATE rooms SET natural_max_turns = :natural_turns WHERE id = 'default'", "UPDATE rooms SET natural_max_turns = :natural_turns"),
 ("R1  binding rule back to the equivalence (a PENDING_NEW cannot be retired)", "  CHECK ((state = 'ACTIVE' AND conversation_id <> '')\n      OR (state = 'PENDING_NEW' AND conversation_id = '')\n      OR  state = 'RETIRED')", "  CHECK ((state = 'PENDING_NEW') = (conversation_id = ''))"),
 ("R2  ACTIVE may have an empty conversation id", "(state = 'ACTIVE' AND conversation_id <> '')", "state = 'ACTIVE'"),
 ("R3  PENDING_NEW may have a conversation id", "(state = 'PENDING_NEW' AND conversation_id = '')", "state = 'PENDING_NEW'"),
 ("R4  RETIRED rows are not allowed by the rule", "\n      OR  state = 'RETIRED')", ")"),
 ("R5  any state string accepted", "  CHECK ((state = 'ACTIVE' AND conversation_id <> '')\n      OR (state = 'PENDING_NEW' AND conversation_id = '')\n      OR  state = 'RETIRED')", "  CHECK (1)"),
 ("S1  delivery trigger may belong to another room (no key)", "  FOREIGN KEY (trigger_message_id, room_id) REFERENCES messages(id, room_id),\n  FOREIGN KEY (reply_message_id, room_id)", "  FOREIGN KEY (reply_message_id, room_id)"),
 ("S2  delivery reply may belong to another room (no key)", "  FOREIGN KEY (reply_message_id, room_id) REFERENCES messages(id, room_id),\n  FOREIGN KEY (room_id, provider_id) REFERENCES participants(room_id, provider_id)\n)", "  FOREIGN KEY (room_id, provider_id) REFERENCES participants(room_id, provider_id)\n)"),
 ("S3  delivery AI need not have a seat in the room", "  FOREIGN KEY (reply_message_id, room_id) REFERENCES messages(id, room_id),\n  FOREIGN KEY (room_id, provider_id) REFERENCES participants(room_id, provider_id)\n)", "  FOREIGN KEY (reply_message_id, room_id) REFERENCES messages(id, room_id)\n)"),
 ("S4  trigger key ignores the room (v1 behaviour)", "FOREIGN KEY (trigger_message_id, room_id) REFERENCES messages(id, room_id)", "FOREIGN KEY (trigger_message_id) REFERENCES messages(id)"),
 ("S5  reply key ignores the room", "FOREIGN KEY (reply_message_id, room_id) REFERENCES messages(id, room_id)", "FOREIGN KEY (reply_message_id) REFERENCES messages(id)"),
 ("S6  'no reply' copied as empty text, not NULL", "NULLIF(reply_message_id, ''), error", "reply_message_id, error"),
 ("S7  UNIQUE(trigger, AI) lost in the rebuild", "  UNIQUE (trigger_message_id, provider_id),\n  FOREIGN KEY (trigger_message_id, room_id)", "  FOREIGN KEY (trigger_message_id, room_id)"),
 ("S8  delivery state CHECK lost in the rebuild", "state TEXT NOT NULL CHECK (state IN ('PENDING','SENDING','SENT','CAPTURED','FAILED','UNCERTAIN','CANCELLED')),\n  provider_user_msg_id TEXT NOT NULL DEFAULT '',\n  provider_asst_msg_id TEXT NOT NULL DEFAULT '',\n  reply_message_id TEXT,", "state TEXT NOT NULL,\n  provider_user_msg_id TEXT NOT NULL DEFAULT '',\n  provider_asst_msg_id TEXT NOT NULL DEFAULT '',\n  reply_message_id TEXT,"),
 ("S9  deliveries_state index not recreated", "CREATE INDEX deliveries_state ON deliveries(state)", "SELECT 1"),
 ("S10 rebuild drops every delivery row", "NULLIF(reply_message_id, ''), error, created_at, updated_at FROM deliveries", "NULLIF(reply_message_id, ''), error, created_at, updated_at FROM deliveries WHERE 0"),
 ("S11 rebuild resets every delivery state", "SELECT id, room_id, trigger_message_id, provider_id, upto_seq, state, provider_user_msg_id", "SELECT id, room_id, trigger_message_id, provider_id, upto_seq, 'PENDING', provider_user_msg_id"),
 ("S12 rebuild loses the provider-side ids", "provider_user_msg_id, provider_asst_msg_id, NULLIF(reply_message_id, ''), error, created_at, updated_at FROM deliveries", "'', '', NULLIF(reply_message_id, ''), error, created_at, updated_at FROM deliveries"),
 ("S13 the unique key the new keys point at is never created", "CREATE UNIQUE INDEX messages_id_room ON messages(id, room_id)\n-- @@\nCREATE TABLE deliveries_v2", "SELECT 1\n-- @@\nCREATE TABLE deliveries_v2"),
 ("S14 'no reply' column is NOT NULL again", "  reply_message_id TEXT,\n  error TEXT NOT NULL DEFAULT '',\n  created_at INTEGER NOT NULL,\n  updated_at INTEGER NOT NULL,\n  UNIQUE (trigger_message_id, provider_id),", "  reply_message_id TEXT NOT NULL DEFAULT '',\n  error TEXT NOT NULL DEFAULT '',\n  created_at INTEGER NOT NULL,\n  updated_at INTEGER NOT NULL,\n  UNIQUE (trigger_message_id, provider_id),"),
 ("T1  artifact state domain not enforced", "state TEXT NOT NULL CHECK (state IN ('PENDING_CAPTURE','READY','FAILED')),", "state TEXT NOT NULL,"),
# (T2 'an artifact may have no origin' is an equivalent breakage since the provenance rule: an empty origin is not 'user', so the CHECK demands a source conversation and the foreign key can match none for an AI called '')
 ("T3  artifact state moves are not enforced", "CREATE TRIGGER artifacts_state_path BEFORE UPDATE OF state ON artifacts\nWHEN NEW.state <> OLD.state AND NOT", "CREATE TRIGGER artifacts_state_path BEFORE UPDATE OF state ON artifacts\nWHEN 0 AND NOT"),
 ("T4  FAILED may jump straight to READY", "(OLD.state = 'FAILED' AND NEW.state = 'PENDING_CAPTURE'))\nBEGIN SELECT RAISE(ABORT, 'an artifact moves", "(OLD.state = 'FAILED' AND NEW.state IN ('PENDING_CAPTURE','READY')))\nBEGIN SELECT RAISE(ABORT, 'an artifact moves"),
 ("T5  an attachment can be edited", "CREATE TRIGGER message_artifacts_no_update BEFORE UPDATE ON message_artifacts\nBEGIN", "CREATE TRIGGER message_artifacts_no_update BEFORE UPDATE ON message_artifacts WHEN 0\nBEGIN"),
 ("T6  an attachment can be removed", "CREATE TRIGGER message_artifacts_no_delete BEFORE DELETE ON message_artifacts\nBEGIN", "CREATE TRIGGER message_artifacts_no_delete BEFORE DELETE ON message_artifacts WHEN 0\nBEGIN"),
 ("T9  a transfer may exist for an artifact with no file", "WHEN (SELECT state FROM artifacts WHERE id = NEW.artifact_id) IS NOT 'READY'", "WHEN 0"),
 ("T10 a transfer may start in any state", "WHEN NEW.state <> 'PENDING' OR NEW.attempts <> 0\nBEGIN SELECT RAISE(ABORT, 'a new transfer starts", "WHEN 0\nBEGIN SELECT RAISE(ABORT, 'a new transfer starts"),
 ("T11 transfer state moves are not enforced", "WHEN NEW.state <> OLD.state AND NOT ((OLD.state = 'PENDING' AND NEW.state IN ('SENDING','FAILED'))", "WHEN 0 AND NOT ((OLD.state = 'PENDING' AND NEW.state IN ('SENDING','FAILED'))"),
 ("T12 PENDING may jump to VERIFIED (never sent)", "(OLD.state = 'PENDING' AND NEW.state IN ('SENDING','FAILED'))", "(OLD.state = 'PENDING' AND NEW.state IN ('SENDING','FAILED','VERIFIED'))"),
 ("T13 a VERIFIED transfer can change again", "CREATE TRIGGER artifact_transfers_verified_is_final BEFORE UPDATE ON artifact_transfers\nWHEN OLD.state = 'VERIFIED'", "CREATE TRIGGER artifact_transfers_verified_is_final BEFORE UPDATE ON artifact_transfers\nWHEN 0"),
 ("T14 a VERIFIED transfer keeps only its state", "WHEN OLD.state = 'VERIFIED'\nBEGIN SELECT RAISE(ABORT, 'a VERIFIED transfer is final'); END", "WHEN OLD.state = 'VERIFIED' AND NEW.state <> 'VERIFIED'\nBEGIN SELECT RAISE(ABORT, 'a VERIFIED transfer is final'); END"),
 ("T15 attempts are not checked", "CREATE TRIGGER artifact_transfers_attempts_count BEFORE UPDATE ON artifact_transfers\nWHEN NEW.attempts <>", "CREATE TRIGGER artifact_transfers_attempts_count BEFORE UPDATE ON artifact_transfers\nWHEN 0 AND NEW.attempts <>"),
 ("T16 attempts may only fall (anything else allowed)", "WHEN NEW.attempts <> OLD.attempts + (CASE WHEN OLD.state <> 'SENDING' AND NEW.state = 'SENDING' THEN 1 ELSE 0 END)", "WHEN NEW.attempts < OLD.attempts"),
 ("T17 starting to send counts two attempts", "THEN 1 ELSE 0 END)", "THEN 2 ELSE 0 END)"),
 ("T18 no global single-flight", "CREATE UNIQUE INDEX artifact_transfers_one_sending ON artifact_transfers(state) WHERE state = 'SENDING'", "SELECT 1"),
 ("T19 single-flight only per room", "artifact_transfers_one_sending ON artifact_transfers(state)", "artifact_transfers_one_sending ON artifact_transfers(room_id, state)"),
 ("SRC1 the source binding may belong to another room or AI (key on the binding id only)", "FOREIGN KEY (source_binding_id, room_id, origin) REFERENCES room_bindings(id, room_id, provider_id)", "FOREIGN KEY (source_binding_id) REFERENCES room_bindings(id)"),
 ("SRC2 the source binding is not checked at all", "  CHECK ((origin = 'user' AND source_binding_id IS NULL) OR (origin <> 'user' AND source_binding_id IS NOT NULL)),   -- a user file has no source; an AI file ALWAYS names the conversation it came from\n  FOREIGN KEY (source_binding_id, room_id, origin) REFERENCES room_bindings(id, room_id, provider_id)   -- same room, and the binding belongs to the AI named as origin\n", "  CHECK ((origin = 'user' AND source_binding_id IS NULL) OR (origin <> 'user' AND source_binding_id IS NOT NULL))\n"),
 ("SRC3 the source conversation can be changed later", " OR NEW.source_binding_id IS NOT OLD.source_binding_id\nBEGIN SELECT RAISE(ABORT, 'artifact identity is fixed (including", "\nBEGIN SELECT RAISE(ABORT, 'artifact identity is fixed (including"),
 ("SRC6 an AI file may have no source conversation (unknown provenance)", "CHECK ((origin = 'user' AND source_binding_id IS NULL) OR (origin <> 'user' AND source_binding_id IS NOT NULL)),", "CHECK (origin <> 'user' OR source_binding_id IS NULL),"),
 ("SRC4 a PENDING_NEW conversation can be a source", "CREATE TRIGGER artifacts_source_was_real BEFORE INSERT ON artifacts\nWHEN NEW.source_binding_id IS NOT NULL AND", "CREATE TRIGGER artifacts_source_was_real BEFORE INSERT ON artifacts\nWHEN 0 AND NEW.source_binding_id IS NOT NULL AND"),
 ("SRC5 a RETIRED conversation can no longer be a source", "(SELECT state FROM room_bindings WHERE id = NEW.source_binding_id) = 'PENDING_NEW'", "(SELECT state FROM room_bindings WHERE id = NEW.source_binding_id) <> 'ACTIVE'"),
]
survivors = 0
for name, a, b in MUTS:
    if a not in base: print("%-60s ANCHOR MISSING" % name); survivors += 1; continue
    d = tempfile.mkdtemp(prefix='agc_mut_')
    mut = os.path.join(d, 'mutated.sql')
    open(mut, 'w').write(base.replace(a, b, 1))
    env = dict(os.environ, AGC_MIGRATION_SQL=mut, AGC_SCHEMA_SQL=SCHEMA)
    r = subprocess.run([sys.executable, os.path.join(HERE, 'migration_test.py')], capture_output=True, text=True, env=env)
    out = r.stdout + r.stderr
    if r.returncode == 0 and 'PASS  DB' in out: print("%-60s SURVIVED  <-- not caught" % name); survivors += 1
    else:
        how = 'failing checks' if 'FAIL  DB' in out else 'crash (the migration/fixture was rejected)'
        print("%-60s caught (%s)" % (name, how))
    shutil.rmtree(d)
print("\n%d breakages, %d survivors" % (len(MUTS), survivors))
sys.exit(1 if survivors else 0)
