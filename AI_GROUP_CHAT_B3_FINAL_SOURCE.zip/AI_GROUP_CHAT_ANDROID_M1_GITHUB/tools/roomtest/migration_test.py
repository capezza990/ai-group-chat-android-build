import sqlite3, re, os, sys, time, shutil, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'assets')
SCHEMA = os.environ.get('AGC_SCHEMA_SQL', os.path.join(ASSETS, 'room_schema_v1.sql'))
MIGRATION = os.environ.get('AGC_MIGRATION_SQL', os.path.join(ASSETS, 'room_migration_v1_to_v2.sql'))
ROOMDB_JAVA = os.environ.get('AGC_ROOMDB_JAVA', os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java', 'com', 'aigroupchat', 'bridge', 'room', 'sqlite', 'RoomDb.java'))
_m = re.search(r'IMPORT_LEGACY_BINDING_SQL\s*=\s*"([^"]+)"', open(ROOMDB_JAVA, encoding='utf-8').read())
IMPORT_SQL = _m.group(1) if _m else None   # the statement the app uses to copy an old preference binding into provider_bindings
WORK = tempfile.mkdtemp(prefix='agc_mig_')   # scratch databases live here, never in the source tree
os.chdir(WORK)

NOW = 1_800_000_000_000
def split(path):
    out=[]
    for chunk in re.split(r'(?m)^-- @@\s*$', open(path).read()):
        lines=[l for l in chunk.split('\n') if not l.strip().startswith('--')]
        t='\n'.join(lines).strip()
        if t: out.append(t)
    return out

def v1_db(path, scenario):
    if os.path.exists(path): os.remove(path)
    db = sqlite3.connect(path); db.execute('PRAGMA foreign_keys=ON')
    for s in split(SCHEMA): db.execute(s)
    def room(i, mode='COLLABORATE', arg='chatgpt'): db.execute("INSERT INTO rooms(id,routing_mode,routing_arg,rounds,created_at) VALUES (?,?,?,?,?)",(i,mode,arg,1,1))
    def part(r,p,en=1,pos=0,ctx=0): db.execute("INSERT INTO participants VALUES (?,?,?,?,?,'UNKNOWN')",(r,p,en,pos,ctx))
    def msg(r,t,a,text,ts): db.execute("INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES (?,?,?,?,?,?)",('m%d'%ts,r,t,a,text,ts))
    def bind(p,c): db.execute("INSERT INTO provider_bindings VALUES (?,?,?,?,?)",(p,c,'https://x/c/'+c,'title '+c,5))
    if scenario in ('typical','claude_removed'):
        room('default'); part('default','chatgpt',1,0,3); part('default','claude',0 if scenario=='claude_removed' else 1,1,2)
        for i in range(1,21): msg('default','USER' if i%3==1 else 'PROVIDER','user' if i%3==1 else ('chatgpt' if i%3==2 else 'claude'),'text %d'%i,i)
        db.execute("INSERT INTO deliveries VALUES ('d1','default','m2','claude',2,'UNCERTAIN','pu-claude-1','pa-claude-1','','stopped by user',11,12)")
        db.execute("INSERT INTO deliveries VALUES ('d2','default','m1','chatgpt',1,'CAPTURED','pu-gpt-2','pa-gpt-2','m2','',21,22)")
        bind('chatgpt','aaa111'); bind('claude','bbb222')
        room('mock-room','AUTO_PICK',''); part('mock-room','chatgpt',1,0); part('mock-room','claude',1,1); part('mock-room','gemini',1,2); part('mock-room','mock-delta',0,3)
        msg('mock-room','USER','user','hello mock',100); msg('mock-room','PROVIDER','gemini','mock gemini reply',101)
        db.execute("INSERT INTO deliveries VALUES ('dm1','mock-room','m100','gemini',100,'CAPTURED','','','m101','',1,1)")
        room('selfcheck-123'); part('selfcheck-123','mock-a'); msg('selfcheck-123','PROVIDER','mock-a','x',200)
    elif scenario == 'one_ai':           # an EXISTING live room that only has ChatGPT seated, while both AIs have legacy (Engine Lab) bindings
        room('default'); part('default','chatgpt',1,0,4)
        bind('chatgpt','aaa111'); bind('claude','bbb222')
    elif scenario == 'empty_default':    # an existing live room with nobody seated, plus a legacy binding
        room('default'); bind('chatgpt','aaa111')
    elif scenario == 'mock_only':        # no live room, no legacy bindings, just a developer room
        room('mock-room','AUTO_PICK',''); part('mock-room','chatgpt',1,0)
    elif scenario == 'legacy_only':      # Engine Lab bindings, but the live room was never created
        bind('chatgpt','aaa111')
    elif scenario == 'fresh':
        pass
    db.commit(); db.close()

def migrate(path, fail_at=None, natural=3, prefs=None, prefs_first=True):
    """prefs = old SharedPreferences bindings [(provider, conversation, locator, title, bound_at)]; the app imports them inside the upgrade
    transaction BEFORE the migration script (prefs_first=True). prefs_first=False reproduces the old, wrong order (after the script)."""
    db = sqlite3.connect(path); db.isolation_level=None; db.execute('PRAGMA foreign_keys=ON')
    db.execute('BEGIN')
    def do_import():
        for pr in (prefs or []): db.execute(IMPORT_SQL, pr)
    try:
        if prefs_first: do_import()
        for i, s in enumerate(split(MIGRATION)):
            if fail_at is not None and i == fail_at: raise RuntimeError('injected failure')
            db.execute(s.replace(':now', str(NOW)).replace(':natural_turns', str(natural)))
        if not prefs_first: do_import()
        bad = db.execute('PRAGMA foreign_key_check').fetchall()
        if bad: raise RuntimeError('foreign_key_check: %r' % bad)
        db.execute('PRAGMA user_version=2'); db.execute('COMMIT')
    except Exception as e:
        db.execute('ROLLBACK'); db.close(); return e
    db.close(); return None

checks=fails=0
def check(ok, what):
    global checks, fails; checks+=1
    if not ok: fails+=1; print('    FAIL:', what)
def q(db, sql, *a): return db.execute(sql, a).fetchall()
def works(db, sql, *a):
    try: db.execute(sql, a); return True
    except sqlite3.DatabaseError: return False
def raises(db, sql, *a):
    try: db.execute(sql, a); return False
    except sqlite3.DatabaseError: return True

# ================= the Java splitter (the code the app really runs) must produce exactly the statements this test runs
if os.environ.get('AGC_JAVA_STATEMENTS'):
    java_stmts = [x.strip() for x in open(os.environ['AGC_JAVA_STATEMENTS'], encoding='utf-8').read().split('\n=====\n') if x.strip()]
    py_stmts = [x.replace(':now', str(NOW)).replace(':natural_turns', '3') for x in split(MIGRATION)]
    check(java_stmts == py_stmts, 'the app\'s Java statement splitter and this test run the very same %d statements (java %d, python %d)' % (len(py_stmts), len(java_stmts), len(py_stmts)))

# ================= typical upgrade
v1_db('t.db','typical'); before = sqlite3.connect('t.db')
snap = {t: q(before,'SELECT * FROM %s ORDER BY 1,2'%t) for t in ('messages','deliveries','participants','provider_bindings')}
before.close()
err = migrate('t.db'); check(err is None, 'typical migration succeeds: %r' % err)
db = sqlite3.connect('t.db'); db.execute('PRAGMA foreign_keys=ON')
check(q(db,'PRAGMA user_version')[0][0]==2, 'user_version is 2')
check(q(db,"SELECT COUNT(*) FROM sqlite_master WHERE name='_mig_new_default'")[0][0]==0, 'the migration-only marker table is gone after the upgrade')
check(q(db,'PRAGMA integrity_check')[0][0]=='ok' and q(db,'PRAGMA foreign_key_check')==[], 'integrity + foreign_key_check clean')
check(q(db,'SELECT * FROM messages ORDER BY 1,2')==snap['messages'], 'every message identical (same seq, text, order)')
def _norm(rows): return [tuple('' if (i == 8 and v is None) else v for i, v in enumerate(r)) for r in rows]   # column 8 = reply_message_id: NULL means "" (no reply)
check(_norm(q(db,'SELECT * FROM deliveries ORDER BY 1,2'))==snap['deliveries'], 'every delivery identical (id, room, trigger, AI, state, provider ids, reply, error, times; incl. the UNCERTAIN one); only "no reply" changed from empty text to NULL')
check([r[0] for r in q(db,'PRAGMA table_info(deliveries)')]==list(range(12)) and [r[1] for r in q(db,'PRAGMA table_info(deliveries)')]==['id','room_id','trigger_message_id','provider_id','upto_seq','state','provider_user_msg_id','provider_asst_msg_id','reply_message_id','error','created_at','updated_at'], 'deliveries keeps its 12 columns in the same order (the app reads them by position)')
check(q(db,"SELECT reply_message_id FROM deliveries WHERE id='d1'")==[(None,)] and q(db,"SELECT reply_message_id FROM deliveries WHERE id='d2'")==[('m2',)], 'a delivery with no reply now holds NULL; one with a reply keeps its message id')
check(q(db,"SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='deliveries_state'")[0][0]==1 and q(db,"SELECT COUNT(*) FROM sqlite_master WHERE name='deliveries_v2'")[0][0]==0, 'the state index exists again and no scratch table is left behind')
check(q(db,'SELECT * FROM participants ORDER BY 1,2')==snap['participants'], 'every participant identical (enabled flags, positions, context_seq)')
check(q(db,"SELECT id,kind,name FROM rooms ORDER BY id")==[('default','LIVE','Main room'),('mock-room','MOCK','Mock room'),('selfcheck-123','MOCK','selfcheck-123')], 'rooms: default=LIVE, others=MOCK, names set: %r'%q(db,"SELECT id,kind,name FROM rooms ORDER BY id"))
check(q(db,"SELECT id,kind FROM provider_profiles ORDER BY id")==[('chatgpt','CORE'),('claude','CORE'),('gemini','MOCK'),('mock-a','MOCK'),('mock-delta','MOCK')], 'registry: 2 CORE; old mock ids kept as MOCK only: %r'%q(db,"SELECT id,kind FROM provider_profiles ORDER BY id"))
check(q(db,"SELECT COUNT(*) FROM provider_profiles WHERE kind IN ('CORE','CUSTOM') AND id='gemini'")[0][0]==0, 'no Gemini entry in the live registry')
bind = q(db,"SELECT room_id,provider_id,state,conversation_id,restore_locator,display_title,bound_at FROM room_bindings ORDER BY provider_id")
check(bind==[('default','chatgpt','ACTIVE','aaa111','https://x/c/aaa111','title aaa111',5),('default','claude','ACTIVE','bbb222','https://x/c/bbb222','title bbb222',5)], 'bindings copied exactly into the default room: %r'%bind)
check(q(db,"SELECT COUNT(*) FROM room_bindings WHERE room_id<>'default'")[0][0]==0, 'no binding appears in any other room')
check(q(db,"SELECT COUNT(*) FROM provider_bindings")[0][0]==2, 'legacy table kept untouched (Engine Lab / rollback only)')
check(q(db,"SELECT natural_max_turns FROM rooms WHERE id='default'")[0][0]==3 and q(db,"SELECT natural_max_turns FROM rooms WHERE id='mock-room'")[0][0]==0, 'the old Natural-turn preference (3) is written to the live room INSIDE the migration; other rooms stay at 0')

# ================= deliveries cannot reach into another room (v1 let all of this through)
DI="INSERT INTO deliveries(id,room_id,trigger_message_id,provider_id,upto_seq,state,created_at,updated_at) VALUES (?,?,?,?,1,'PENDING',1,1)"
check(raises(db,"INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES ('m1','mock-room','USER','user','sneaky',1)"), 'a duplicate canonical message id requested for another room is rejected by the database (UNIQUE id)')
check(raises(db,DI,'x1','mock-room','m1','chatgpt'), 'a Room-B delivery whose trigger message belongs to Room A is rejected')
check(raises(db,DI,'x1','default','m100','chatgpt'), '...and the other direction (Room-A delivery, Room-B trigger) is rejected too')
check(works(db,DI,'ok1','default','m3','chatgpt') and works(db,DI,'ok2','mock-room','m100','claude'), 'the correct same-room deliveries are accepted')
check(raises(db,"UPDATE deliveries SET reply_message_id='m5' WHERE id='dm1'"), 'a Room-B delivery whose reply message belongs to Room A is rejected')
check(raises(db,"UPDATE deliveries SET reply_message_id='m100' WHERE id='ok1'"), '...and the other direction is rejected too')
check(raises(db,"UPDATE deliveries SET reply_message_id='no-such-message' WHERE id='ok1'"), 'a reply that points at no message at all is rejected (v1 accepted any text)')
check(raises(db,"UPDATE deliveries SET reply_message_id='' WHERE id='ok1'"), 'the empty text is no longer a way to say "no reply": NULL is')
check(works(db,"UPDATE deliveries SET reply_message_id='m4' WHERE id='ok1'") and works(db,"UPDATE deliveries SET reply_message_id='m101' WHERE id='ok2'"), 'a reply in the SAME room is accepted')
check(raises(db,"INSERT INTO deliveries(id,room_id,trigger_message_id,provider_id,upto_seq,state,reply_message_id,created_at,updated_at) VALUES ('x2','mock-room','m100','gemini',1,'CAPTURED','m5',1,1)"), 'a new delivery created with a cross-room reply is rejected')
check(raises(db,"UPDATE deliveries SET room_id='mock-room' WHERE id='ok1'"), 'a delivery cannot be moved to another room')
check(raises(db,DI,'x3','default','m5','gemini'), 'a delivery for an AI that has no seat in that room is rejected')
check(works(db,DI,'ok3','mock-room','m101','mock-delta') and q(db,"SELECT enabled FROM participants WHERE room_id='mock-room' AND provider_id='mock-delta'")==[(0,)], 'but a REMOVED AI (seat row kept with enabled = 0) still has valid history: its delivery is accepted')
check(raises(db,DI,'x4','default','m3','chatgpt'), 'UNIQUE(trigger message, AI) is still enforced after the rebuild')
check(raises(db,"INSERT INTO deliveries(id,room_id,trigger_message_id,provider_id,upto_seq,state,created_at,updated_at) VALUES ('x5','default','m6','chatgpt',1,'BOGUS',1,1)"), 'the delivery state CHECK is still enforced after the rebuild')
check(raises(db,"INSERT INTO deliveries(id,room_id,trigger_message_id,provider_id,upto_seq,state,created_at,updated_at) VALUES ('x6','nowhere','m6','chatgpt',1,'PENDING',1,1)"), 'a delivery in a room that does not exist is rejected')

# ================= constraints that prevent leakage / duplicates
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('x1','default','chatgpt','ACTIVE','zzz',9)"), 'a second ACTIVE binding for the same room+provider is rejected')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('x2','default','chatgpt','PENDING_NEW','',9)"), 'a PENDING_NEW cannot coexist with an ACTIVE one either')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('x3','default','gemini','ACTIVE','q',9)"), 'a binding for an AI that is not seated in that room is rejected (composite FK)')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('x4','mock-room','chatgpt','ACTIVE','',9)"), 'an ACTIVE binding without a conversation id is rejected')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('x5','mock-room','chatgpt','PENDING_NEW','abc',9)"), 'a PENDING_NEW with a conversation id is rejected')
db.execute("UPDATE room_bindings SET state='RETIRED', retired_at=10, retired_reason='rebound' WHERE id='migrated-chatgpt'")
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('new1','default','chatgpt','ACTIVE','ccc333',11)")
check(q(db,"SELECT COUNT(*) FROM room_bindings WHERE room_id='default' AND provider_id='chatgpt'")[0][0]==2 and q(db,"SELECT COUNT(*) FROM room_bindings WHERE room_id='default' AND provider_id='chatgpt' AND state='ACTIVE'")[0][0]==1, 'rebind = retire the old (kept as history) + one new ACTIVE')
check(raises(db,"UPDATE room_bindings SET display_title='tamper' WHERE id='migrated-chatgpt'"), 'a RETIRED binding cannot be edited')
check(raises(db,"DELETE FROM room_bindings WHERE id='migrated-chatgpt'"), 'bindings cannot be deleted')
check(raises(db,"UPDATE room_bindings SET room_id='mock-room' WHERE id='new1'"), 'a binding cannot be moved to another room')
db.execute("UPDATE room_bindings SET state='RETIRED', retired_at=12, retired_reason='max_length' WHERE id='new1'")
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pend1','default','chatgpt','PENDING_NEW','',13)")
db.execute("UPDATE room_bindings SET state='ACTIVE', conversation_id='ddd444' WHERE id='pend1'")
check(q(db,"SELECT conversation_id FROM room_bindings WHERE room_id='default' AND provider_id='chatgpt' AND state='ACTIVE'")==[('ddd444',)], 'rollover: PENDING_NEW becomes ACTIVE once the new thread exists')
# ---- the binding state/conversation rule says what each state needs (it is NOT an equivalence: a cancelled rollover is RETIRED with no conversation).
#      Uses the pair selfcheck-123 + mock-a, which no other check touches, so a broken rule fails exactly these checks.
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pn1','selfcheck-123','mock-a','PENDING_NEW','',50)")
check(works(db,"UPDATE room_bindings SET state='RETIRED', retired_at=51, retired_reason='cleared' WHERE id='pn1'"), 'retiring a PENDING_NEW binding is accepted by the database')
check(q(db,"SELECT state,conversation_id,retired_reason FROM room_bindings WHERE id='pn1'")==[('RETIRED','','cleared')], 'a PENDING_NEW binding (no conversation yet) can be retired: cancelling a rollover works and keeps its history row')
check(raises(db,"UPDATE room_bindings SET display_title='late edit' WHERE id='pn1'"), 'and that retired row is final like every other retired row')
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pn2','selfcheck-123','mock-a','ACTIVE','pn-conv',52)")
check(works(db,"UPDATE room_bindings SET state='RETIRED', retired_at=53, retired_reason='cleared' WHERE id='pn2'"), 'retiring an ACTIVE binding is accepted by the database')
check(q(db,"SELECT state,conversation_id FROM room_bindings WHERE id='pn2'")==[('RETIRED','pn-conv')], 'an ACTIVE binding can still be retired and keeps its conversation id')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pn3','selfcheck-123','mock-a','ACTIVE','',54)"), 'ACTIVE with an empty conversation id is rejected')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pn4','selfcheck-123','mock-a','PENDING_NEW','has-id',54)"), 'PENDING_NEW with a conversation id is rejected')
check(raises(db,"INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pn5','selfcheck-123','mock-a','BOGUS','x',54)"), 'an unknown binding state is rejected')
check(raises(db,"UPDATE room_bindings SET conversation_id='' WHERE id='migrated-claude'"), 'an ACTIVE binding cannot have its conversation id blanked')
check(raises(db,"INSERT INTO rooms(id,routing_mode,created_at,kind) VALUES ('bad','SINGLE',1,'WEIRD')"), 'rooms.kind outside LIVE/MOCK is rejected')
check(raises(db,"UPDATE rooms SET natural_max_turns=99 WHERE id='default'"), 'natural_max_turns outside 0..20 is rejected')
check(raises(db,"UPDATE messages SET text='x'"), 'messages are still append-only')
check(raises(db,"INSERT INTO participants(room_id,provider_id,position) VALUES ('default','nobody',9)"), 'seating an AI that is not in the registry is rejected')

# ---- artifacts cannot cross rooms
db.execute("INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('a1','default','claude','migrated-claude','source.zip','PENDING_CAPTURE',1)")
db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES ('a2','mock-room','user','b.txt','READY',1,?,1,'b.txt')", ('c'*64,))
db.execute("INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('m2','default','a1')")
check(raises(db,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('m100','mock-room','a1')"), 'attaching a room-A artifact to a room-B message is rejected')
check(raises(db,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('m2','default','a2')"), 'attaching a room-B artifact to a room-A message is rejected')
check(raises(db,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('m2','mock-room','a2')"), 'a message cannot be claimed by the wrong room')
H='a'*64
db.execute("UPDATE artifacts SET state='READY', sha256=?, size=3, storage_path='p', mime='application/zip' WHERE id='a1'", (H,))
db.execute("INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('a1','default','claude','migrated-claude','PENDING',1)")
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('a1','default','chatgpt','migrated-claude','PENDING',1)"), 'a transfer must name the binding of the SAME provider')
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('a2','mock-room','chatgpt','pend1','PENDING',1)"), 'a transfer cannot use another room\'s binding')
check(raises(db,"UPDATE artifacts SET sha256=? WHERE id='a1'", 'b'*64), 'a READY artifact cannot change its hash')
check(raises(db,"UPDATE artifacts SET mime='text/plain' WHERE id='a1'"), 'a READY artifact cannot change its type (MIME)')
check(raises(db,"UPDATE artifacts SET size=4 WHERE id='a1'") and raises(db,"UPDATE artifacts SET storage_path='q' WHERE id='a1'") and raises(db,"UPDATE artifacts SET display_name='other.zip' WHERE id='a1'"), 'size, path and name are frozen too')
check(raises(db,"UPDATE artifacts SET state='FAILED' WHERE id='a1'"), 'READY is terminal: it cannot be downgraded to FAILED (the loophole ChatGPT found)')
check(raises(db,"DELETE FROM artifacts WHERE id='a1'"), 'a READY artifact that a message or transfer references cannot be deleted (foreign keys)')
db.execute("INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('a9','default','claude','migrated-claude','late.zip','PENDING_CAPTURE',1)")
check(raises(db,"UPDATE artifacts SET state='READY' WHERE id='a9'"), 'entering READY without a file is rejected')
check(raises(db,"UPDATE artifacts SET state='READY', sha256='abc', size=1, storage_path='p' WHERE id='a9'"), 'entering READY with a malformed hash is rejected')
check(raises(db,"UPDATE artifacts SET state='READY', sha256=?, size=-1, storage_path='p' WHERE id='a9'", H), 'entering READY with a negative size is rejected')
check(raises(db,"UPDATE artifacts SET state='READY', sha256=?, size=1, storage_path='' WHERE id='a9'", H), 'entering READY without a storage path is rejected')
db.execute("UPDATE artifacts SET state='FAILED' WHERE id='a9'"); db.execute("UPDATE artifacts SET state='PENDING_CAPTURE' WHERE id='a9'")
db.execute("UPDATE artifacts SET state='READY', sha256=?, size=0, storage_path='empty.txt' WHERE id='a9'", (H,))
check(q(db,"SELECT size,state FROM artifacts WHERE id='a9'")==[(0,'READY')], 'an EMPTY file (size 0) is a valid READY artifact; a not-ready artifact can fail and retry')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('a8','default','user','x','READY',1)"), 'inserting a READY artifact without a file is rejected')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES ('a8','default','user','x','READY',1,'abc',1,'p')"), 'inserting a READY artifact with a short hash is rejected')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES ('a8','default','user','x','READY',1,?,1,'p')", 'g'*64), 'inserting a READY artifact with a 64-character NON-hex hash is rejected')
db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES ('a5','default','user','upper.txt','READY',1,?,1,'u')", ('ABCDEF0123456789'*4,))
check(q(db,"SELECT COUNT(*) FROM artifacts WHERE id='a5'")[0][0]==1, 'an upper-case hex hash is accepted')
db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('a4','default','user','pend','PENDING_CAPTURE',1)")
check(raises(db,"UPDATE artifacts SET state='READY', sha256=?, size=1, storage_path='p' WHERE id='a4'", 'g'*64), 'moving to READY with a 64-character NON-hex hash is rejected')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES ('a8','default','user','x','READY',1,?,-5,'p')", H), 'inserting a READY artifact with a negative size is rejected')
db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES ('a6','default','user','gc.txt','READY',1,?,1,'gc.txt')", (H,))
db.execute("DELETE FROM artifacts WHERE id='a6'")
check(q(db,"SELECT COUNT(*) FROM artifacts WHERE id='a6'")[0][0]==0, 'an UNREFERENCED READY artifact CAN be deleted (cleanup / garbage collection); its contents just never change')
db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('a7','default','user','tmp','PENDING_CAPTURE',1)")
db.execute("DELETE FROM artifacts WHERE id='a7'")
check(q(db,"SELECT COUNT(*) FROM artifacts WHERE id='a7'")[0][0]==0, 'a not-yet-READY artifact can still be cleaned up')
check(raises(db,"UPDATE artifacts SET room_id='mock-room' WHERE id='a1'"), 'an artifact cannot move rooms')
check(raises(db,"DELETE FROM messages WHERE id='m2'"), 'a message that owns an artifact cannot be deleted (and no message can)')

# ---- a normal new room is LIVE by default (it can never silently become a developer room)
db.execute("INSERT INTO rooms(id,routing_mode,created_at,name) VALUES ('live2','AUTO_PICK',1,'Second live room')")
check(q(db,"SELECT kind FROM rooms WHERE id='live2'")==[('LIVE',)], 'a room created without a kind is LIVE')
# ---- two LIVE rooms, the SAME provider instances seated in both, different active conversations
db.execute("INSERT INTO participants(room_id,provider_id,position,context_seq) VALUES ('live2','chatgpt',0,7)")
db.execute("INSERT INTO participants(room_id,provider_id,position,context_seq) VALUES ('live2','claude',1,0)")
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('l2-chatgpt','live2','chatgpt','ACTIVE','zzz999',20)")
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('l2-claude','live2','claude','ACTIVE','yyy888',20)")
check(q(db,"SELECT room_id,conversation_id FROM room_bindings WHERE provider_id='chatgpt' AND state='ACTIVE' ORDER BY room_id")==[('default','ddd444'),('live2','zzz999')], 'the same ChatGPT instance has a DIFFERENT active conversation in each room')
check(q(db,"SELECT context_seq FROM participants WHERE provider_id='chatgpt' AND room_id IN ('default','live2') ORDER BY room_id")==[(3,),(7,)], 'and an independent context position in each room')
check(q(db,"SELECT COUNT(*) FROM room_bindings WHERE provider_id='chatgpt' AND conversation_id='ddd444' AND state='ACTIVE' AND room_id<>'default'")[0][0]==0, 'the thread-conflict lookup finds none for an unshared thread (and would list the other room for a shared one)')
db.execute("INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES ('L2m1','live2','PROVIDER','claude','room B reply',300)")
db.execute("INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at,sha256,size,storage_path) VALUES ('b1','live2','claude','l2-claude','b.zip','READY',1,?,5,'live2/b1')", ('d'*64,))
check(raises(db,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('L2m1','live2','a1')"), 'room B message + room A artifact: rejected')
check(raises(db,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('m2','default','b1')"), 'room A message + room B artifact: rejected')
check(raises(db,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('L2m1','default','b1')"), 'room B message claimed by room A: rejected')
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','live2','chatgpt','migrated-chatgpt','PENDING',1)"), "room B artifact + room A's retired binding: rejected")
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','live2','chatgpt','pend1','PENDING',1)"), "room B artifact + room A's ACTIVE binding: rejected")
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','default','chatgpt','pend1','PENDING',1)"), "room B artifact stamped as room A: rejected")
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','live2','claude','l2-chatgpt','PENDING',1)"), "room B artifact + right room but the other AI's binding: rejected")
# a transfer to a binding of the SAME room and provider that is RETIRED / PENDING_NEW: only the new trigger can stop this
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('a1','default','chatgpt','migrated-chatgpt','PENDING',1)"), 'a new transfer to a RETIRED binding (same room, same AI) is rejected')
db.execute("UPDATE room_bindings SET state='RETIRED', retired_at=30, retired_reason='max_length' WHERE id='l2-claude'")
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('l2-claude-new','live2','claude','PENDING_NEW','',31)")
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','live2','claude','l2-claude-new','PENDING',1)"), 'a new transfer to a PENDING_NEW binding (no usable conversation yet) is rejected')
db.execute("UPDATE room_bindings SET state='ACTIVE', conversation_id='nnn000' WHERE id='l2-claude-new'")
db.execute("INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','live2','claude','l2-claude-new','PENDING',1)")
check(q(db,"SELECT COUNT(*) FROM artifact_transfers WHERE binding_id='l2-claude-new'")[0][0]==1, 'once the new conversation exists (ACTIVE) a transfer is accepted')
db.execute("INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('L2m1','live2','b1')")
db.execute("INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,updated_at) VALUES ('b1','live2','chatgpt','l2-chatgpt','PENDING',1)")
check(q(db,"SELECT COUNT(*) FROM artifact_transfers WHERE artifact_id='b1'")[0][0]==2, 'the correct room-B message, artifact and binding are accepted')
db.execute("UPDATE room_bindings SET state='RETIRED', retired_at=40, retired_reason='rebound' WHERE id='l2-chatgpt'")
# a transfer row is tied for good to the exact artifact / room / AI / binding it was created for.
# The targets below are valid for EVERY foreign key, so only the identity trigger can stop these updates.
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('l2-chatgpt-new','live2','chatgpt','ACTIVE','rrr777',42)")
db.execute("INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('b2','live2','claude','l2-claude','b2.zip','PENDING_CAPTURE',1)")
check(raises(db,"UPDATE artifact_transfers SET binding_id='l2-chatgpt-new' WHERE artifact_id='b1' AND binding_id='l2-chatgpt'"), 'a transfer cannot be re-pointed at a newer ACTIVE binding of the same room and AI (history stays tied to the conversation it was created for)')
check(raises(db,"UPDATE artifact_transfers SET binding_id='l2-chatgpt' WHERE artifact_id='b1' AND binding_id='l2-claude-new'") , 'a transfer cannot be re-pointed to an older binding either')
check(raises(db,"UPDATE artifact_transfers SET artifact_id='b2' WHERE artifact_id='b1' AND binding_id='l2-chatgpt'"), 'a transfer cannot switch to another artifact of the same room')
check(raises(db,"UPDATE artifact_transfers SET provider_id='claude', binding_id='l2-claude-new' WHERE artifact_id='b1' AND binding_id='l2-chatgpt'"), 'a transfer cannot switch to the other AI even with a matching binding')
check(q(db,"SELECT artifact_id,binding_id,provider_id,room_id FROM artifact_transfers WHERE artifact_id='b1' AND binding_id='l2-chatgpt'")==[('b1','l2-chatgpt','chatgpt','live2')], 'the transfer row is unchanged after every refused edit')
db.execute("UPDATE artifact_transfers SET state='SENDING', attempts=1, error='retry', updated_at=43 WHERE artifact_id='b1' AND binding_id='l2-chatgpt'")
check(q(db,"SELECT state,attempts,error,updated_at FROM artifact_transfers WHERE artifact_id='b1' AND binding_id='l2-chatgpt'")==[('SENDING',1,'retry',43)], 'a transfer\'s state, attempts, error and time CAN still change (starting to send counts one attempt)')
db.execute("UPDATE artifact_transfers SET state='STAGED', updated_at=44 WHERE artifact_id='b1' AND binding_id='l2-chatgpt'")
db.execute("UPDATE artifact_transfers SET state='VERIFIED', updated_at=45 WHERE artifact_id='b1' AND binding_id='l2-chatgpt'")
check(q(db,"SELECT state FROM artifact_transfers WHERE binding_id='l2-chatgpt'")==[('VERIFIED',)], 'history survives: a transfer row stays valid and updatable after its binding is retired')

# ================= C4: the artifact and transfer state machines are enforced by the database itself
HX='e'*64
def new_art(i, state='READY', room='default'):
    if state == 'READY': db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at,sha256,size,storage_path) VALUES (?,?,'user',?,'READY',1,?,1,?)", (i, room, i+'.txt', HX, room+'/'+i))
    else: db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES (?,?,'user',?,?,1)", (i, room, i+'.txt', state))
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('c-bad','default','user','x','BOGUS',1)"), 'an artifact state outside PENDING_CAPTURE / READY / FAILED is rejected')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('c-bad','default','','x','PENDING_CAPTURE',1)"), 'an artifact must say where it came from (origin cannot be empty)')
# --- artifact state matrix: exactly these moves are possible
def artifact_matrix():
    ok = set()
    for n, a in enumerate(('PENDING_CAPTURE','READY','FAILED')):
        for b in ('PENDING_CAPTURE','READY','FAILED'):
            i = 'am%d%s' % (n, b[:2]); new_art(i, a)
            sql = "UPDATE artifacts SET state=?, sha256=?, size=1, storage_path='p' WHERE id=?" if b == 'READY' and a != 'READY' else "UPDATE artifacts SET state=? WHERE id=?"
            args = (b, HX, i) if b == 'READY' and a != 'READY' else (b, i)
            if works(db, sql, *args): ok.add((a, b))
    return ok
AM = artifact_matrix()
EXPECT_AM = {('PENDING_CAPTURE','PENDING_CAPTURE'),('PENDING_CAPTURE','READY'),('PENDING_CAPTURE','FAILED'),('FAILED','FAILED'),('FAILED','PENDING_CAPTURE'),('READY','READY')}
check(AM == EXPECT_AM, 'artifact moves allowed by the database are exactly: PENDING_CAPTURE -> READY/FAILED, FAILED -> PENDING_CAPTURE (retry), READY never moves: %r' % sorted(AM ^ EXPECT_AM))
# --- an AI's file remembers the EXACT conversation (binding) it was produced in; presence is never inferred from the AI alone
db.execute("INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('src-ok','default','claude','migrated-claude','made.zip','PENDING_CAPTURE',1)")
check(q(db,"SELECT source_binding_id FROM artifacts WHERE id='src-ok'")==[('migrated-claude',)], 'an AI file can name the conversation (binding) it was produced in')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('src-x1','live2','claude','migrated-claude','x','PENDING_CAPTURE',1)"), "a binding of room A cannot be the source of a room-B file")
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('src-x2','default','chatgpt','migrated-claude','x','PENDING_CAPTURE',1)"), "the source binding must belong to the AI named as origin (a Claude conversation cannot be ChatGPT's)")
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('src-x3','default','claude','no-such-binding','x','PENDING_CAPTURE',1)"), 'an unknown source binding is rejected')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('src-x4','default','user','migrated-claude','x','PENDING_CAPTURE',1)"), 'a user file has no source conversation')
check(raises(db,"INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('src-n1','default','claude','unknown-source.zip','PENDING_CAPTURE',1)"), 'an AI file WITHOUT a source conversation is rejected: its provenance is never unknown')
db.execute("INSERT INTO artifacts(id,room_id,origin,display_name,state,created_at) VALUES ('src-u1','default','user','mine.txt','PENDING_CAPTURE',1)")
check(q(db,"SELECT source_binding_id FROM artifacts WHERE id='src-u1'")==[(None,)], 'a user file with no source conversation (NULL) is fine')
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at,retired_at,retired_reason) VALUES ('src-alt','default','claude','RETIRED','alt-conv',1,2,'rebound')")
check(raises(db,"UPDATE artifacts SET source_binding_id='src-alt' WHERE id='src-ok'"), 'a file cannot be moved to ANOTHER valid conversation of the same AI and room: only the identity rule can stop this (the key and the CHECK both accept it)')
check(raises(db,"UPDATE artifacts SET source_binding_id=NULL WHERE id='src-ok'") and raises(db,"UPDATE artifacts SET source_binding_id='pend1' WHERE id='src-u1'") and raises(db,"UPDATE artifacts SET source_binding_id='migrated-claude' WHERE id='src-u1'"), 'the source conversation is fixed for good: it cannot be removed, added later, or changed')
# --- a file can only come from a conversation that really existed
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('pn-src','mock-room','gemini','PENDING_NEW','',60)")
SRC_INS = "INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES (?,'mock-room','gemini',?,'g.bin','PENDING_CAPTURE',1)"
check(raises(db,SRC_INS,'src-p1','pn-src'), 'a file cannot name a PENDING_NEW conversation as its source (that conversation never existed)')
db.execute("UPDATE room_bindings SET state='RETIRED', retired_at=61, retired_reason='cleared' WHERE id='pn-src'")
check(works(db,SRC_INS,'src-p2','pn-src'), 'once that binding is RETIRED it is history and a valid source (the AI may have been rebound while still answering)')
db.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('act-src','mock-room','gemini','ACTIVE','cG',62)")
check(works(db,SRC_INS,'src-p3','act-src'), 'an ACTIVE conversation is a valid source')
# --- attachments are history
new_art('att1'); db.execute("INSERT INTO message_artifacts(message_id,room_id,artifact_id,position) VALUES ('m3','default','att1',0)")
check(raises(db,"UPDATE message_artifacts SET position=1 WHERE artifact_id='att1'"), 'a message attachment cannot be edited')
check(raises(db,"DELETE FROM message_artifacts WHERE artifact_id='att1'"), 'a message attachment cannot be removed')
# --- transfers need a READY artifact and start clean
new_art('pc', 'PENDING_CAPTURE'); new_art('fl', 'FAILED')
TI="INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,attempts,updated_at) VALUES (?,'default','claude','migrated-claude',?,?,1)"
check(raises(db,TI,'pc','PENDING',0), 'a transfer for an artifact that is still PENDING_CAPTURE is rejected (no file yet)')
check(raises(db,TI,'fl','PENDING',0), 'a transfer for a FAILED artifact is rejected')
new_art('rd1'); new_art('rd2'); new_art('rd3')
check(raises(db,TI,'rd1','SENDING',0) and raises(db,TI,'rd1','STAGED',0) and raises(db,TI,'rd1','VERIFIED',0) and raises(db,TI,'rd1','FAILED',0), 'a new transfer can only start as PENDING')
check(raises(db,TI,'rd1','PENDING',1), 'a new transfer starts with 0 attempts')
check(raises(db,TI,'rd1','BOGUS',0), 'a transfer state outside PENDING / SENDING / STAGED / VERIFIED / FAILED is rejected')
check(raises(db,"INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,attempts,updated_at) VALUES ('rd1','default','claude','migrated-claude','PENDING',-1,1)"), 'negative attempts are rejected')
# --- transfer state matrix: exactly these moves are possible
def transfer_matrix():
    ok = set(); n = 0
    for a in ('PENDING','SENDING','STAGED','VERIFIED','FAILED'):
        for b in ('PENDING','SENDING','STAGED','VERIFIED','FAILED'):
            n += 1; i = 'tm%d' % n; new_art(i)
            db.execute(TI, (i, 'PENDING', 0))
            att = 0
            if a in ('SENDING','STAGED','VERIFIED','FAILED'): db.execute("UPDATE artifact_transfers SET state='SENDING', attempts=1 WHERE artifact_id=?", (i,)); att = 1
            if a in ('STAGED','VERIFIED'): db.execute("UPDATE artifact_transfers SET state='STAGED' WHERE artifact_id=?", (i,))
            if a == 'VERIFIED': db.execute("UPDATE artifact_transfers SET state='VERIFIED' WHERE artifact_id=?", (i,))
            if a == 'FAILED': db.execute("UPDATE artifact_transfers SET state='FAILED', error='x' WHERE artifact_id=?", (i,))
            delta = 1 if (a != 'SENDING' and b == 'SENDING') else 0   # starting to send counts exactly one attempt
            if works(db, "UPDATE artifact_transfers SET state=?, attempts=? WHERE artifact_id=?", b, att + delta, i): ok.add((a, b))
            # free the single-flight slot for the next trial
            db.execute("UPDATE artifact_transfers SET state='FAILED' WHERE artifact_id=? AND state='SENDING'", (i,))
    return ok
TM = transfer_matrix()
EXPECT_TM = {('PENDING','PENDING'),('PENDING','SENDING'),('PENDING','FAILED'),('SENDING','SENDING'),('SENDING','STAGED'),('SENDING','FAILED'),('STAGED','STAGED'),('STAGED','VERIFIED'),('STAGED','FAILED'),('VERIFIED',None),('FAILED','FAILED'),('FAILED','PENDING'),('FAILED','SENDING')}
EXPECT_TM.discard(('VERIFIED',None))
check(TM == EXPECT_TM, 'transfer moves allowed by the database are exactly: PENDING -> SENDING/FAILED, SENDING -> STAGED/FAILED, STAGED -> VERIFIED/FAILED, FAILED -> PENDING/SENDING; VERIFIED never moves: %r' % sorted(TM ^ EXPECT_TM))
if os.environ.get('AGC_JAVA_RULES'):   # the Java enums (what the app's code believes) must allow exactly what the database allows
    jr = [l.split() for l in open(os.environ['AGC_JAVA_RULES'], encoding='utf-8').read().splitlines() if l.strip()]
    check({(a, b) for k, a, b in jr if k == 'ARTIFACT'} == AM, 'ArtifactState.canMoveTo allows exactly the artifact moves the database allows: %r' % sorted({(a, b) for k, a, b in jr if k == 'ARTIFACT'} ^ AM))
    check({(a, b) for k, a, b in jr if k == 'TRANSFER'} == TM, 'TransferState.canMoveTo allows exactly the transfer moves the database allows: %r' % sorted({(a, b) for k, a, b in jr if k == 'TRANSFER'} ^ TM))
# --- VERIFIED is final in every respect
vid = q(db,"SELECT artifact_id FROM artifact_transfers WHERE state='VERIFIED' AND artifact_id LIKE 'tm%' LIMIT 1")[0][0]
check(raises(db,"UPDATE artifact_transfers SET error='late' WHERE artifact_id=?", vid) and raises(db,"UPDATE artifact_transfers SET updated_at=99 WHERE artifact_id=?", vid), 'a VERIFIED transfer cannot be touched at all (not even its error text or time)')
# --- attempts: only +1, only when sending starts
db.execute(TI, ('rd1','PENDING',0))
check(raises(db,"UPDATE artifact_transfers SET state='SENDING' WHERE artifact_id='rd1'"), 'starting to send without counting the attempt is rejected')
check(raises(db,"UPDATE artifact_transfers SET state='SENDING', attempts=2 WHERE artifact_id='rd1'"), 'starting to send counts exactly one attempt (not two)')
check(raises(db,"UPDATE artifact_transfers SET attempts=1 WHERE artifact_id='rd1'"), 'attempts cannot grow while the state does not change to SENDING')
db.execute("UPDATE artifact_transfers SET state='SENDING', attempts=1 WHERE artifact_id='rd1'")
check(raises(db,"UPDATE artifact_transfers SET state='FAILED', attempts=0 WHERE artifact_id='rd1'"), 'attempts can never go down')
check(raises(db,"UPDATE artifact_transfers SET state='STAGED', attempts=2 WHERE artifact_id='rd1'"), 'staging a transfer does not add an attempt')
# --- global single-flight: only one transfer in the whole database may be SENDING
db.execute(TI, ('rd2','PENDING',0))
check(raises(db,"UPDATE artifact_transfers SET state='SENDING', attempts=1 WHERE artifact_id='rd2'"), 'a second transfer cannot start while one is SENDING (global single-flight, any room, any AI)')
new_art('l2a', 'READY', 'live2')
db.execute("INSERT INTO artifact_transfers(artifact_id,room_id,provider_id,binding_id,state,attempts,updated_at) VALUES ('l2a','live2','claude','l2-claude-new','PENDING',0,1)")
check(raises(db,"UPDATE artifact_transfers SET state='SENDING', attempts=1 WHERE artifact_id='l2a'"), '...not even in another room')
db.execute("UPDATE artifact_transfers SET state='FAILED', error='interrupted' WHERE artifact_id='rd1'")
check(works(db,"UPDATE artifact_transfers SET state='SENDING', attempts=1 WHERE artifact_id='rd2'"), 'once the first one leaves SENDING, the next may start')
db.execute("UPDATE artifact_transfers SET state='FAILED' WHERE artifact_id='rd2'")
check(works(db,"UPDATE artifact_transfers SET state='SENDING', attempts=2 WHERE artifact_id='rd1'") and q(db,"SELECT attempts FROM artifact_transfers WHERE artifact_id='rd1'")==[(2,)], 'a FAILED transfer can be retried: the second attempt is counted')
db.execute("UPDATE artifact_transfers SET state='FAILED' WHERE artifact_id='rd1'")
db.commit(); db.close()

# ---- WHY foreign keys must be ON: with enforcement off the very same cross-room rows are accepted
off = sqlite3.connect('t.db'); off.execute('PRAGMA foreign_keys=OFF')
check(not raises(off,"INSERT INTO message_artifacts(message_id,room_id,artifact_id) VALUES ('L2m1','live2','a1')"), 'with foreign keys OFF the cross-room link is NOT stopped (so the app must enforce them ON at every open)')
off.close()

# ================= other starting points
for scen in ('claude_removed','legacy_only','fresh','one_ai','mock_only','empty_default'):  # natural_turns checked for legacy_only below
    v1_db('s.db', scen); err = migrate('s.db'); check(err is None, scen+' migration succeeds: %r'%err)
    d = sqlite3.connect('s.db'); d.execute('PRAGMA foreign_keys=ON')
    check(q(d,'PRAGMA foreign_key_check')==[] and q(d,'PRAGMA integrity_check')[0][0]=='ok', scen+': integrity clean')
    if scen=='claude_removed': check(q(d,"SELECT enabled FROM participants WHERE room_id='default' AND provider_id='claude'")==[(0,)] and q(d,"SELECT COUNT(*) FROM room_bindings WHERE provider_id='claude'")[0][0]==1, 'a removed (disabled) AI keeps its seat row and its binding')
    if scen=='legacy_only': check(q(d,"SELECT id,kind FROM rooms")==[('default','LIVE')] and q(d,"SELECT provider_id,enabled FROM participants WHERE room_id='default' ORDER BY position")==[('chatgpt',1),('claude',1)] and q(d,"SELECT provider_id,state FROM room_bindings")==[('chatgpt','ACTIVE')], 'legacy-only bindings: the live room is created, both core AIs seated, the binding kept: %r'%q(d,"SELECT * FROM room_bindings"))
    if scen=='legacy_only': check(q(d,"SELECT natural_max_turns FROM rooms WHERE id='default'")==[(3,)], 'the preference also reaches a live room created by the migration')
    if scen=='one_ai': check(q(d,"SELECT provider_id,enabled,context_seq FROM participants WHERE room_id='default'")==[('chatgpt',1,4)] and q(d,"SELECT COUNT(*) FROM rooms")[0][0]==1 and q(d,"SELECT provider_id FROM room_bindings")==[('chatgpt',)] and q(d,"SELECT COUNT(*) FROM provider_bindings")[0][0]==2 and q(d,"SELECT COUNT(*) FROM sqlite_master WHERE name='_mig_new_default'")[0][0]==0, 'an EXISTING one-AI room stays one-AI (Claude is NOT added); only its seated AI gets a room binding; the legacy table keeps both: %r'%q(d,"SELECT room_id,provider_id FROM participants"))
    if scen=='empty_default': check(q(d,"SELECT COUNT(*) FROM participants")[0][0]==0 and q(d,"SELECT COUNT(*) FROM room_bindings")[0][0]==0, 'an existing room with nobody seated is NOT seated by the migration (membership is only ever preserved)')
    if scen=='mock_only': check(q(d,"SELECT id FROM rooms")==[('mock-room',)] and q(d,"SELECT natural_max_turns FROM rooms")==[(0,)] and q(d,"SELECT COUNT(*) FROM room_bindings")[0][0]==0, 'no live room and no bindings: no default room is invented and the old Natural-turn preference is NOT forced onto a developer room (the app applies it when it first creates the live room)')
    if scen=='fresh': check(q(d,'SELECT COUNT(*) FROM rooms')[0][0]==0 and q(d,'SELECT COUNT(*) FROM room_bindings')[0][0]==0 and q(d,'SELECT COUNT(*) FROM providers')[0][0]==2, 'empty install: nothing invented; registry has only ChatGPT and Claude')
    d.close()

# ================= old bindings that live ONLY in the old preferences (no provider_bindings row yet) must survive the upgrade
check(IMPORT_SQL is not None and 'provider_bindings' in IMPORT_SQL, 'the import statement was found in RoomDb.java')
PREFS = [('chatgpt','pref-aaa','https://chatgpt.com/c/pref-aaa','Pref title A',7), ('claude','pref-bbb','https://claude.ai/chat/pref-bbb','Pref title B',8)]
def room_bind_rows(path):
    d = sqlite3.connect(path); d.execute('PRAGMA foreign_keys=ON')
    rows = q(d, "SELECT room_id,provider_id,state,conversation_id,restore_locator,display_title,bound_at FROM room_bindings ORDER BY provider_id")
    leg = q(d, "SELECT COUNT(*) FROM provider_bindings")[0][0]; d.close(); return rows, leg
def v1_prefs_only(path):          # a live room with both AIs seated, but NO provider_bindings rows at all
    v1_db(path, 'fresh'); c = sqlite3.connect(path); c.execute('PRAGMA foreign_keys=ON')
    c.execute("INSERT INTO rooms(id,routing_mode,routing_arg,rounds,created_at) VALUES ('default','AUTO_PICK','chatgpt',1,1)")
    c.execute("INSERT INTO participants VALUES ('default','chatgpt',1,0,3,'UNKNOWN')"); c.execute("INSERT INTO participants VALUES ('default','claude',1,1,2,'UNKNOWN')")
    c.commit(); c.close()
v1_prefs_only('pp.db'); err = migrate('pp.db', prefs=PREFS); rows, leg = room_bind_rows('pp.db')
check(err is None and rows == [('default','chatgpt','ACTIVE','pref-aaa','https://chatgpt.com/c/pref-aaa','Pref title A',7), ('default','claude','ACTIVE','pref-bbb','https://claude.ai/chat/pref-bbb','Pref title B',8)],
      'v1 has no binding rows but the old preferences do: after the upgrade both are ACTIVE room bindings with conversation, locator, title and time intact: %r %r' % (err, rows))
check(leg == 2, 'and the legacy provider_bindings table (Engine Lab) has them too')
v1_prefs_only('pw.db'); err = migrate('pw.db', prefs=PREFS, prefs_first=False); rows, leg = room_bind_rows('pw.db')
check(err is None and rows == [], 'WHY THE ORDER MATTERS: importing the preferences AFTER the migration script leaves the rooms with no binding (the bug this order prevents)')
v1_prefs_only('pd.db'); c = sqlite3.connect('pd.db'); c.execute("INSERT INTO provider_bindings VALUES ('chatgpt','db-aaa','https://chatgpt.com/c/db-aaa','DB title',5)"); c.commit(); c.close()
err = migrate('pd.db', prefs=PREFS); rows, leg = room_bind_rows('pd.db')
check(err is None and [(r[1], r[3]) for r in rows] == [('chatgpt','db-aaa'), ('claude','pref-bbb')], 'a binding already in the database wins over an older preference; the other AI is filled from its preference: %r' % rows)
v1_db('pl.db','fresh'); err = migrate('pl.db', prefs=PREFS[:1]); d = sqlite3.connect('pl.db'); d.execute('PRAGMA foreign_keys=ON')
check(err is None and q(d,"SELECT id,kind FROM rooms")==[('default','LIVE')] and q(d,"SELECT provider_id FROM participants ORDER BY position")==[('chatgpt',),('claude',)] and q(d,"SELECT provider_id,state,conversation_id FROM room_bindings")==[('chatgpt','ACTIVE','pref-aaa')],
      'no live room yet but an old preference binding: the migration creates it, seats both AIs and binds the preference thread: %r' % err)
d.close()
v1_prefs_only('pr.db'); err = migrate('pr.db', prefs=PREFS, fail_at=12); d = sqlite3.connect('pr.db')
check(err is not None and q(d,'SELECT COUNT(*) FROM provider_bindings')[0][0]==0 and q(d,'PRAGMA user_version')[0][0]==0 and q(d,"SELECT COUNT(*) FROM sqlite_master WHERE name='room_bindings'")[0][0]==0,
      'a failure after the preference import rolls the import back too (nothing half-applied; the preferences are still unconsumed and get a second chance)')
d.close()

# ================= an old delivery that crosses rooms is NOT silently repaired or dropped: the upgrade aborts and v1 stays untouched
def v1_with_bad_delivery(path, kind):
    v1_db(path, 'typical'); c = sqlite3.connect(path); c.execute('PRAGMA foreign_keys=ON')
    rows = {'trigger_room':   ('bad','mock-room','m1','claude','PENDING',''),        # trigger message m1 belongs to the default room
            'reply_room':     ('bad','default','m3','chatgpt','CAPTURED','m100'),     # reply m100 belongs to mock-room
            'reply_missing':  ('bad','default','m3','chatgpt','CAPTURED','gone'),     # reply points at no message (v1 had no key here)
            'unseated_ai':    ('bad','default','m3','gemini','PENDING','')}[kind]     # gemini has no seat in the default room
    c.execute("INSERT INTO deliveries VALUES (?,?,?,?,1,?,'','',?,'',1,1)", (rows[0],rows[1],rows[2],rows[3],rows[4],rows[5])); c.commit(); c.close()
for kind in ('trigger_room','reply_room','reply_missing','unseated_ai'):
    v1_with_bad_delivery('bd.db', kind)
    c = sqlite3.connect('bd.db'); before = {tb: q(c,'SELECT * FROM %s ORDER BY 1,2'%tb) for tb in ('messages','deliveries','participants')}; c.close()
    err = migrate('bd.db'); d = sqlite3.connect('bd.db')
    after = {tb: q(d,'SELECT * FROM %s ORDER BY 1,2'%tb) for tb in ('messages','deliveries','participants')}
    check(err is not None and q(d,'PRAGMA user_version')[0][0]==0 and after==before and q(d,"SELECT COUNT(*) FROM sqlite_master WHERE name IN ('deliveries_v2','room_bindings','providers')")[0][0]==0,
          'old delivery with a %s problem: the upgrade aborts, the bad row is kept as it was, and nothing of v2 exists afterwards: %r' % (kind, err))
    d.close()

# ================= an inconsistent v1 database aborts the whole migration (foreign_key_check is not just logged)
v1_db('o.db','typical'); c=sqlite3.connect('o.db'); c.execute('PRAGMA foreign_keys=OFF')
c.execute("INSERT INTO participants VALUES ('ghost-room','chatgpt',1,0,0,'UNKNOWN')"); c.commit(); c.close()
err=migrate('o.db'); d=sqlite3.connect('o.db')
check(err is not None and q(d,'PRAGMA user_version')[0][0]==0 and q(d,"SELECT COUNT(*) FROM sqlite_master WHERE name='room_bindings'")[0][0]==0, 'an orphan row in v1 aborts the migration and leaves v1 untouched: %r'%err)
d.close()

# ================= a failure half-way rolls everything back
v1_db('r.db','typical'); before = sqlite3.connect('r.db'); tables_before = sorted(x[0] for x in q(before,"SELECT name FROM sqlite_master WHERE type='table'")); before.close()
for point in (3, 10, 20, 30):
    shutil.copy('t.db','/dev/null') if False else None
    v1_db('r.db','typical'); err = migrate('r.db', fail_at=point)
    d = sqlite3.connect('r.db')
    check(err is not None and sorted(x[0] for x in q(d,"SELECT name FROM sqlite_master WHERE type='table'"))==tables_before and q(d,'PRAGMA user_version')[0][0]==0, 'failure at statement %d leaves the v1 database exactly as it was (rolled back)'%point)
    d.close()

print(('PASS  ' if fails==0 else 'FAIL  ')+'DB v1->v2 migration (%d checks, %d failures)'%(checks,fails)); sys.exit(1 if fails else 0)
