"""Prepares EVERY SQL statement found in RoomDb.java against the real v2 schema (schema + migration), so a typo in a table or column
name is caught here instead of crashing on the phone. It reads the statements from the Java source (it does not retype them).
This only proves the statements are valid for the schema; their behaviour is covered by migration_test.py and the Java store tests."""
import os, re, sqlite3, sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, '..', '..', 'app', 'src', 'main')
src = open(os.environ.get('AGC_ROOMDB_JAVA', os.path.join(ROOT, 'java', 'com', 'aigroupchat', 'bridge', 'room', 'sqlite', 'RoomDb.java')), encoding='utf-8').read()
consts = dict(re.findall(r'static final String (\w+) =\s*((?:"[^"]*"\s*\+?\s*)+);', src))
consts = {k: ''.join(re.findall(r'"([^"]*)"', v)) for k, v in consts.items() if k in ('MSG_COLS', 'DEL_COLS', 'ROOM_INFO_COLS')}
variants = []
for live in (True, False):  # listProviders builds its WHERE clause conditionally: check both shapes
    s = src.replace('(liveOnly ? "WHERE pp.kind IN (\'CORE\',\'CUSTOM\') " : "")', '"WHERE pp.kind IN (\'CORE\',\'CUSTOM\') "' if live else '""')
    for k, v in consts.items(): s = s.replace('" + %s + "' % k, v).replace('"SELECT " + %s' % k, '"SELECT ' + v)
    s = re.sub(r'"\s*\+\s*\n\s*"', '', s); s = re.sub(r'"\s*\n\s*\+\s*"', '', s)
    variants.append(s)
sqls = set()
for s in variants: sqls.update(re.findall(r'"((?:SELECT|INSERT|UPDATE|DELETE)[^"]{15,})"', s))
def split(p):
    out = []
    for c in re.split(r'(?m)^-- @@\s*$', open(p, encoding='utf-8').read()):
        t = '\n'.join(l for l in c.split('\n') if not l.strip().startswith('--')).strip()
        if t: out.append(t)
    return out
db = sqlite3.connect(':memory:'); db.execute('PRAGMA foreign_keys=ON')
for s in split(os.path.join(ROOT, 'assets', 'room_schema_v1.sql')): db.execute(s)
for s in split(os.path.join(ROOT, 'assets', 'room_migration_v1_to_v2.sql')): db.execute(s.replace(':now', '1').replace(':natural_turns', '0'))
bad = 0
for s in sorted(sqls):
    try: db.execute('EXPLAIN ' + s, ['x'] * s.count('?')).fetchall()
    except Exception as e: bad += 1; print('    FAIL:', e, '\n       ', s[:200])
# the values handed to the preference-import statement must follow its column order (the SQL tests supply their own values, so check the source)
m = re.search(r'execSQL\(IMPORT_LEGACY_BINDING_SQL,\s*new Object\[\]\{([^}]*)\}', src)
want = 'b.providerId, b.providerConversationId, b.restoreLocator, b.displayTitle, b.boundAt'
if not m or [x.strip() for x in m.group(1).split(',')] != [x.strip() for x in want.split(',')]:
    bad += 1; print('    FAIL: the preference import passes its values in the wrong order: %r' % (m.group(1) if m else None))
# RoomDb cannot run on the JVM, so its room-isolation guards are checked in the source: the idempotent paths must call the shared guards,
# and the NULL "no reply" the database now stores must be mapped back to the empty text the app uses
GUARDS = [
    ('createArtifact refuses an AI file without a source conversation', r'if \(!Artifact\.ORIGIN_USER\.equals\(origin\) && sourceBindingId == null\) throw new IllegalArgumentException'),
    ('createArtifact passes the source conversation in the right place and cleans the name', r'execSQL\(SQL_CREATE_ARTIFACT, new Object\[\]\{id, roomId, origin, sourceBindingId, ArtifactNames\.clean\(displayName\), mime == null \? "" : mime, now\}\)'),
    ('createArtifact checks the source conversation against room AND AI (in that order) and that it really existed (ACTIVE or RETIRED)', r"FROM room_bindings WHERE id=\? AND room_id=\? AND provider_id=\? AND state IN \('ACTIVE','RETIRED'\)\", new String\[\]\{sourceBindingId, roomId, origin\}"),
    ('artifactsNotReady lists exactly the files that are not READY', r"FROM artifacts WHERE state <> 'READY' ORDER BY rowid"),
    ('createArtifact refuses a user file with a source', r'if \(Artifact\.ORIGIN_USER\.equals\(origin\)\) throw new IllegalArgumentException\("a user file has no source conversation"\)'),
    ('appendMessage checks the room of an existing message', r'if \(existing != null\) return RoomIntegrity\.messageInRoom\(existing, roomId\);'),
    ('createDelivery checks the room of an existing delivery', r'return RoomIntegrity\.deliveryInRoom\(readDelivery\(c\), roomId\);'),
    ('readDelivery maps a NULL reply to the empty text', r'd\.replyMessageId = c\.isNull\(8\) \? "" : c\.getString\(8\);'),
]
for what, rx in GUARDS:
    if not re.search(rx, src): bad += 1; print('    FAIL: RoomDb source: %s' % what)
# A brand-new delivery through the REAL createDelivery path: take the exact columns RoomDb.createDelivery writes (from its source), insert them into a
# migrated v2 database, and prove (1) it succeeds, (2) "no reply yet" is stored as NULL, (3) the exact UPDATE RoomDb.setDeliveryReply runs
# accepts a same-room reply and rejects another room's. If createDelivery ever wrote reply_message_id = '' every new delivery would fail here.
def _method(name):
    i = src.index('public ' + name) if ('public ' + name) in src else src.index(name)
    j = src.index('\n    @Override', i + 10) if '\n    @Override' in src[i + 10:] else len(src)
    return src[i:j]
cd_body = _method('Delivery createDelivery(')
cols = re.findall(r'cv\.put\("(\w+)"', cd_body)
if 'reply_message_id' in cols: bad += 1; print('    FAIL: createDelivery writes reply_message_id (it must be left out so the database stores NULL): %r' % cols)
sample = {'id': 'new-d', 'room_id': 'A', 'trigger_message_id': 'mA', 'provider_id': 'chatgpt', 'upto_seq': 1, 'state': 'PENDING', 'created_at': 1, 'updated_at': 1}
if not cols or any(c not in sample for c in cols): bad += 1; print('    FAIL: createDelivery writes columns this check does not know: %r' % cols)
else:
    for r in ('A', 'B'):
        db.execute("INSERT INTO rooms(id,routing_mode,created_at,name) VALUES (?,'AUTO_PICK',1,?)", (r, r))
        db.execute("INSERT INTO participants(room_id,provider_id,position) VALUES (?, 'chatgpt', 0)", (r,))
        db.execute("INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES (?,?, 'USER','user','x',1)", ('m' + r, r))
        db.execute("INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES (?,?, 'PROVIDER','chatgpt','y',2)", ('r' + r, r))
    try:
        db.execute('INSERT INTO deliveries(%s) VALUES (%s)' % (', '.join(cols), ', '.join('?' * len(cols))), [sample[c] for c in cols])
        if db.execute("SELECT reply_message_id FROM deliveries WHERE id='new-d'").fetchall() != [(None,)]:
            bad += 1; print('    FAIL: a new delivery must start with NULL as its reply')
        upd = re.search(r'execSQL\("(UPDATE deliveries SET reply_message_id=\? WHERE id=\?)"', _method('void setDeliveryReply('))
        if not upd: bad += 1; print('    FAIL: could not find the setDeliveryReply UPDATE in RoomDb')
        else:
            try: db.execute(upd.group(1), ['rB', 'new-d']); bad += 1; print("    FAIL: setDeliveryReply accepted another room's reply")
            except sqlite3.DatabaseError: pass
            db.execute(upd.group(1), ['rA', 'new-d'])
            if db.execute("SELECT reply_message_id FROM deliveries WHERE id='new-d'").fetchall() != [('rA',)]: bad += 1; print('    FAIL: the same-room reply was not stored')
    except sqlite3.DatabaseError as e:
        bad += 1; print('    FAIL: a brand-new delivery made with createDelivery\'s columns was rejected: %s' % e)
# The artifact and transfer flow, run through the EXACT statements RoomDb uses (read from its source). RoomDb cannot run on the JVM, so this proves that these
# statements, used in the order the code uses them, behave: create -> finalize -> attach -> transfer -> send -> stage -> verify, plus retry, single-flight and restart recovery.
consts = {k: ''.join(re.findall(r'"([^"]*)"', v)) for k, v in re.findall(r'static final String (SQL_\w+) =\s*((?:"[^"]*"\s*\+?\s*)+);', src)}
need = ['SQL_CREATE_ARTIFACT','SQL_FINALIZE_ARTIFACT','SQL_FAIL_ARTIFACT','SQL_RETRY_ARTIFACT','SQL_ATTACH','SQL_DELETE_UNREFERENCED','SQL_ACTIVE_BINDING_ID','SQL_ENSURE_TRANSFER','SQL_OTHER_SENDING','SQL_TRANSITION','SQL_INTERRUPT_TRANSFERS','SQL_INTERRUPT_ARTIFACTS']
if any(k not in consts for k in need): bad += 1; print('    FAIL: missing SQL constants in RoomDb: %r' % [k for k in need if k not in consts])
else:
    f = sqlite3.connect(':memory:'); f.execute('PRAGMA foreign_keys=ON'); f.isolation_level = None
    for x in split(os.path.join(ROOT, 'assets', 'room_schema_v1.sql')): f.execute(x)
    for x in split(os.path.join(ROOT, 'assets', 'room_migration_v1_to_v2.sql')): f.execute(x.replace(':now', '1').replace(':natural_turns', '0'))
    for r in ('R', 'S'):
        f.execute("INSERT INTO rooms(id,routing_mode,created_at,name) VALUES (?,'AUTO_PICK',1,?)", (r, r))
        for pidx, pid in enumerate(('chatgpt', 'claude')): f.execute("INSERT INTO participants(room_id,provider_id,position) VALUES (?,?,?)", (r, pid, pidx))
        f.execute("INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES (?,?,'USER','user','hi',1)", ('m' + r, r))
    f.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at,retired_at,retired_reason) VALUES ('bRold','R','chatgpt','RETIRED','cOld',0,1,'rebound')")   # an OLD conversation comes first in the table
    f.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('bR','R','chatgpt','ACTIVE','cR',1)")
    f.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('bR2','R','claude','ACTIVE','cR2',1)")
    f.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('bS','S','chatgpt','ACTIVE','cS',1)")
    HEX = 'ab' * 32
    def n(sql, *a): return f.execute(sql, a).rowcount
    def ok(cond, what):
        global bad
        if not cond: bad += 1; print('    FAIL: artifact flow: ' + what)
    def raised(sql, *a):
        try: f.execute(sql, a); return False
        except sqlite3.DatabaseError: return True
    f.execute(consts['SQL_CREATE_ARTIFACT'], ('a1', 'R', 'user', None, 'a1.txt', 'text/plain', 1))
    ok(f.execute("SELECT state,size FROM artifacts WHERE id='a1'").fetchall() == [('PENDING_CAPTURE', -1)], 'a new artifact is PENDING_CAPTURE with no size')
    ok(raised(consts['SQL_CREATE_ARTIFACT'], 'a1', 'R', 'user', None, 'dup', '', 1), 'a duplicate artifact id is refused')
    ok(n(consts['SQL_FINALIZE_ARTIFACT'], 'text/plain', 5, HEX, 'R/a1', 'a1') == 1 and f.execute("SELECT state,size,sha256,storage_path FROM artifacts WHERE id='a1'").fetchall() == [('READY', 5, HEX, 'R/a1')], 'finalize makes it READY with its hash, size and path')
    ok(n(consts['SQL_FINALIZE_ARTIFACT'], 'text/plain', 6, HEX, 'R/a1', 'a1') == 0, 'a READY artifact cannot be finalized again with different data (no row matches)')
    ok(n(consts['SQL_FAIL_ARTIFACT'], 'a1') == 0, 'a READY artifact cannot be failed')
    f.execute(consts['SQL_CREATE_ARTIFACT'], ('a2', 'R', 'claude', 'bR2', 'out.zip', '', 2))
    ok(f.execute("SELECT source_binding_id FROM artifacts WHERE id='a2'").fetchall() == [('bR2',)], "an AI file keeps the conversation (binding) it was produced in")
    ok(raised(consts['SQL_CREATE_ARTIFACT'], 'p1', 'R', 'claude', 'bS', 'x', '', 3), "another room's conversation cannot be the source")
    ok(raised(consts['SQL_CREATE_ARTIFACT'], 'p2', 'R', 'claude', 'bR', 'x', '', 3), "another AI's conversation cannot be the source")
    ok(raised(consts['SQL_CREATE_ARTIFACT'], 'p3', 'R', 'user', 'bR2', 'x', '', 3), 'a user file cannot name a source conversation')
    ok(n(consts['SQL_FAIL_ARTIFACT'], 'a2') == 1 and n(consts['SQL_FAIL_ARTIFACT'], 'a2') == 0, 'a PENDING_CAPTURE artifact fails once')
    ok(n(consts['SQL_RETRY_ARTIFACT'], 'a2') == 1 and n(consts['SQL_RETRY_ARTIFACT'], 'a2') == 0, 'a FAILED artifact can be retried once (back to PENDING_CAPTURE)')
    f.execute(consts['SQL_ATTACH'], ('mR', 'R', 'a1', 0))
    ok(raised(consts['SQL_ATTACH'], 'mS', 'S', 'a1', 0), "an artifact of room R cannot be attached to room S's message")
    ok(n(consts['SQL_DELETE_UNREFERENCED'], 'a1') == 0, 'an attached artifact is not deleted')
    ok(n(consts['SQL_DELETE_UNREFERENCED'], 'a2') == 1, 'an unreferenced artifact is deleted')
    ok(f.execute(consts['SQL_ACTIVE_BINDING_ID'], ('R', 'chatgpt')).fetchall() == [('bR',)] and f.execute(consts['SQL_ACTIVE_BINDING_ID'], ('S', 'claude')).fetchall() == [], 'the ACTIVE binding is found per room and AI; none when the AI has no conversation there')
    f.execute(consts['SQL_ENSURE_TRANSFER'], ('a1', 'R', 'chatgpt', 'bR', 5)); f.execute(consts['SQL_ENSURE_TRANSFER'], ('a1', 'R', 'chatgpt', 'bR', 6))
    ok(f.execute("SELECT COUNT(*),state,attempts,updated_at FROM artifact_transfers WHERE artifact_id='a1'").fetchall() == [(1, 'PENDING', 0, 5)], 'ensure-transfer is idempotent: one PENDING row, the first one is kept')
    f.execute(consts['SQL_CREATE_ARTIFACT'], ('a3', 'R', 'user', None, 'late.txt', '', 3))
    ok(raised(consts['SQL_ENSURE_TRANSFER'], 'a3', 'R', 'chatgpt', 'bR', 7), 'no transfer for an artifact that is not READY')
    def move(art, bind, frm, to, err=None):   # the same two steps RoomDb.transitionTransfer takes
        if to == 'SENDING' and f.execute(consts['SQL_OTHER_SENDING'], (art, bind)).fetchone()[0] > 0: return 0
        pad = list(frm) + [frm[0]] * (4 - len(frm))
        return n(consts['SQL_TRANSITION'], to, to, err, 9, art, bind, *pad)
    ok(move('a1', 'bR', ['PENDING'], 'SENDING') == 1 and f.execute("SELECT state,attempts FROM artifact_transfers WHERE artifact_id='a1'").fetchall() == [('SENDING', 1)], 'PENDING -> SENDING counts one attempt')
    ok(move('a1', 'bR', ['PENDING'], 'SENDING') == 0, 'the same move again finds no matching row (state already changed)')
    ok(move('a1', 'bR', ['SENDING'], 'STAGED') == 1 and f.execute("SELECT state,attempts,error FROM artifact_transfers WHERE artifact_id='a1'").fetchall() == [('STAGED', 1, '')], 'SENDING -> STAGED keeps the attempt count and keeps the (empty) error when none is given')
    ok(move('a1', 'bR', ['STAGED'], 'VERIFIED') == 1 and f.execute("SELECT state,attempts,error FROM artifact_transfers WHERE artifact_id='a1'").fetchall() == [('VERIFIED', 1, '')], 'STAGED -> VERIFIED commits only after acceptance')
    f.execute("INSERT INTO artifacts(id,room_id,origin,display_name,mime,size,sha256,storage_path,state,created_at) VALUES ('a7','R','user','staged.txt','',1,?,'R/a7','READY',1)", (HEX,))
    f.execute(consts['SQL_ENSURE_TRANSFER'], ('a7', 'R', 'chatgpt', 'bR', 8))
    ok(move('a7', 'bR', ['PENDING'], 'SENDING') == 1 and move('a7', 'bR', ['SENDING'], 'STAGED') == 1, 'a transfer can remain STAGED while the provider composer awaits submission')
    f.execute("INSERT INTO artifacts(id,room_id,origin,display_name,mime,size,sha256,storage_path,state,created_at) VALUES ('a4','R','user','b.txt','',1,?,'R/a4','READY',1)", (HEX,))
    f.execute("INSERT INTO artifacts(id,room_id,origin,display_name,mime,size,sha256,storage_path,state,created_at) VALUES ('a5','S','user','c.txt','',1,?,'S/a5','READY',1)", (HEX,))
    f.execute(consts['SQL_ENSURE_TRANSFER'], ('a4', 'R', 'chatgpt', 'bR', 8)); f.execute(consts['SQL_ENSURE_TRANSFER'], ('a5', 'S', 'chatgpt', 'bS', 8))
    ok(n(consts['SQL_DELETE_UNREFERENCED'], 'a4') == 0 and f.execute("SELECT COUNT(*) FROM artifacts WHERE id='a4'").fetchone()[0] == 1, 'an artifact that has a transfer but no message is NOT deleted, and no error is raised')
    ok(move('a4', 'bR', ['PENDING'], 'SENDING') == 1, 'first transfer starts sending')
    ok(f.execute(consts['SQL_OTHER_SENDING'], ('a5', 'bS')).fetchone()[0] == 1 and f.execute(consts['SQL_OTHER_SENDING'], ('a4', 'bR')).fetchone()[0] == 0, 'single-flight query: another room sees one transfer already sending; the sending one does not count itself')
    ok(raised(consts['SQL_TRANSITION'], 'SENDING', 'SENDING', None, 9, 'a5', 'bS', 'PENDING', 'PENDING', 'PENDING', 'PENDING'), 'even if the code forgot to check, the database refuses a second SENDING transfer')
    ok(move('a4', 'bR', ['SENDING'], 'FAILED', 'page not ready') == 1 and f.execute("SELECT state,error,attempts FROM artifact_transfers WHERE artifact_id='a4'").fetchall() == [('FAILED', 'page not ready', 1)], 'SENDING -> FAILED records the reason')
    ok(f.execute(consts['SQL_OTHER_SENDING'], ('a5', 'bS')).fetchone()[0] == 0 and move('a5', 'bS', ['PENDING'], 'SENDING') == 1, 'once the first one failed, the other room may start')
    ok(move('a4', 'bR', ['FAILED'], 'SENDING') == 0 and move('a5', 'bS', ['SENDING'], 'FAILED', 'x') == 1 and move('a4', 'bR', ['FAILED'], 'SENDING') == 1 and f.execute("SELECT attempts FROM artifact_transfers WHERE artifact_id='a4'").fetchone()[0] == 2, 'retry of a FAILED transfer counts the second attempt (and only runs when nothing else is sending)')
    f.execute("INSERT INTO artifacts(id,room_id,origin,source_binding_id,display_name,state,created_at) VALUES ('a6','R','claude','bR2','pending.bin','PENDING_CAPTURE',1)")
    ok(n(consts['SQL_INTERRUPT_TRANSFERS'], 11) == 2 and n(consts['SQL_INTERRUPT_ARTIFACTS']) == 2 and f.execute("SELECT state,error FROM artifact_transfers WHERE artifact_id='a4'").fetchall() == [('FAILED', 'interrupted (app restart)')] and f.execute("SELECT state,error FROM artifact_transfers WHERE artifact_id='a7'").fetchall() == [('FAILED', 'interrupted (app restart)')] and f.execute("SELECT state FROM artifacts WHERE id IN ('a3','a6') ORDER BY id").fetchall() == [('FAILED',), ('FAILED',)] and f.execute("SELECT state FROM artifacts WHERE id='a1'").fetchall() == [('READY',)],
       'restart recovery: SENDING and STAGED transfers plus artifacts still waiting for bytes become FAILED; READY artifacts are untouched')
    ok(n(consts['SQL_INTERRUPT_TRANSFERS'], 12) == 0 and n(consts['SQL_INTERRUPT_ARTIFACTS']) == 0, 'recovery does nothing when nothing was in progress')
# The exact reply an AI file came from (RoomDb.sourceReplyRef): the statement must return exactly one row for a normal file and the Java must refuse anything else.
if 'SQL_SOURCE_REPLY' not in consts: bad += 1; print('    FAIL: RoomDb has no SQL_SOURCE_REPLY')
else:
    g = sqlite3.connect(':memory:'); g.execute('PRAGMA foreign_keys=ON'); g.isolation_level = None
    for x in split(os.path.join(ROOT, 'assets', 'room_schema_v1.sql')): g.execute(x)
    for x in split(os.path.join(ROOT, 'assets', 'room_migration_v1_to_v2.sql')): g.execute(x.replace(':now', '1').replace(':natural_turns', '0'))
    g.execute("INSERT INTO rooms(id,routing_mode,created_at,name) VALUES ('R','AUTO_PICK',1,'R')")
    for pidx, pid in enumerate(('chatgpt', 'claude')): g.execute("INSERT INTO participants(room_id,provider_id,position) VALUES ('R',?,?)", (pid, pidx))
    g.execute("INSERT INTO room_bindings(id,room_id,provider_id,state,conversation_id,bound_at) VALUES ('bC','R','claude','ACTIVE','cC',1)")
    for mid, who in (('mR1', 'USER'), ('mR2', 'USER'), ('rR1', 'PROVIDER'), ('rR2', 'PROVIDER')):
        g.execute("INSERT INTO messages(id,room_id,author_type,author_id,text,created_at) VALUES (?,'R',?,?,'x',1)", (mid, who, 'user' if who == 'USER' else 'claude'))
    g.execute("INSERT INTO deliveries(id,room_id,trigger_message_id,provider_id,upto_seq,state,provider_asst_msg_id,reply_message_id,created_at,updated_at) VALUES ('d1','R','mR1','claude',1,'CAPTURED','asst-1','rR1',1,1)")
    g.execute("INSERT INTO deliveries(id,room_id,trigger_message_id,provider_id,upto_seq,state,provider_asst_msg_id,reply_message_id,created_at,updated_at) VALUES ('d2','R','mR2','claude',1,'CAPTURED','asst-2','rR2',1,1)")
    for aid in ('x1', 'x2'): g.execute(consts['SQL_CREATE_ARTIFACT'], (aid, 'R', 'claude', 'bC', 'report.pdf', '', 1))
    g.execute(consts['SQL_ATTACH'], ('rR1', 'R', 'x1', 0)); g.execute(consts['SQL_ATTACH'], ('rR2', 'R', 'x2', 0))
    rows = lambda a: g.execute(consts['SQL_SOURCE_REPLY'], (a,)).fetchall()
    for what, cond in (('two files with the same name resolve to their own replies', rows('x1') == [('asst-1', 'claude', 'R')] and rows('x2') == [('asst-2', 'claude', 'R')]),
                       ('an unknown artifact gives no row', rows('nope') == []),
                       ('a file attached to two messages gives two rows (the Java refuses it)', (g.execute(consts['SQL_ATTACH'], ('rR2', 'R', 'x1', 1)) is not None) and len(rows('x1')) == 2)):
        if not cond: bad += 1; print('    FAIL: reply identity: ' + what)
    m = re.search(r'public String sourceReplyRef\(String artifactId\) \{(.*?)\n    \}', src, re.S); body = m.group(1) if m else ''
    for what, pat in (('user files and unknown artifacts return empty', r'a == null \|\| a\.fromUser\(\)\) return ""'),
                      ('the AI and the room must match the artifact', r'!a\.origin\.equals\(c\.getString\(1\)\) \|\| !a\.roomId\.equals\(c\.getString\(2\)\)\) return ""'),
                      ('exactly one row is accepted', r'rows == 1 && ref != null \? ref : ""')):
        if not re.search(pat, body): bad += 1; print('    FAIL: RoomDb.sourceReplyRef source rule missing: ' + what)
if len(sqls) < 30: bad += 1; print('    FAIL: only %d statements found; the extraction is broken' % len(sqls))
print(('PASS  ' if bad == 0 else 'FAIL  ') + 'RoomDb SQL (%d statements prepare against schema v2)' % len(sqls)); sys.exit(1 if bad else 0)
