#!/usr/bin/env bash
# Runs the pure-Java tests (canonical room core, Stop-label matcher) and the SQLite schema + v1->v2 migration tests.
# Mutation checks (break a rule on purpose, a test must fail): python3 migration_mutations.py ; python3 store_mutations.py
# Needs a JDK. The Android stub jar is only needed because ProviderBinding references android classes;
# none of them is called by the tests. Override with ANDROID_JAR=/path/to/android.jar.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../../app/src/main/java"
ANDROID_JAR="${ANDROID_JAR:-/usr/share/java/com.android.android-23.jar}"
OUT="$(mktemp -d)"
javac -encoding UTF-8 -d "$OUT" -cp "$ANDROID_JAR" -sourcepath "$SRC" \
  "$SRC"/com/aigroupchat/bridge/room/*.java "$SRC"/com/aigroupchat/bridge/LabelMatch.java \
  "$HERE/RoomControllerTest.java" "$HERE/LabelMatchTest.java" "$HERE/SqlScriptTest.java" "$HERE/UpgradeV2Test.java" "$HERE/ArtifactStoreTest.java" "$HERE/ArtifactStorageTest.java" "$HERE/ArtifactGateTest.java" "$HERE/ArtifactFlowTest.java" "$HERE/ArtifactUiRulesTest.java" \
  "$SRC/com/aigroupchat/bridge/engine/ProviderSurfaceLease.java" "$SRC/com/aigroupchat/bridge/engine/ProviderSurfaceOperation.java" "$SRC/com/aigroupchat/bridge/engine/ProviderTransferIdentity.java" \
  "$HERE/ProviderSurfaceLeaseTest.java" "$HERE/ProviderSurfaceOperationTest.java" "$HERE/ProviderTransferIdentityTest.java" "$HERE/FileCaptureCoreTest.java" "$HERE/FileCaptureFlowTest.java" "$HERE/ArtifactLifecycleTest.java"
java -cp "$OUT:$ANDROID_JAR" LabelMatchTest
java -cp "$OUT:$ANDROID_JAR" RoomControllerTest
python3 "$HERE/schema_test.py"
java -cp "$OUT:$ANDROID_JAR" UpgradeV2Test
java -cp "$OUT:$ANDROID_JAR" ArtifactStoreTest "$OUT/java_artifact_rules.txt"
java -cp "$OUT:$ANDROID_JAR" ArtifactStorageTest
java -cp "$OUT:$ANDROID_JAR" ArtifactGateTest
java -cp "$OUT:$ANDROID_JAR" ArtifactFlowTest
java -cp "$OUT:$ANDROID_JAR" ArtifactUiRulesTest
java -cp "$OUT:$ANDROID_JAR" ProviderSurfaceLeaseTest
java -cp "$OUT:$ANDROID_JAR" ProviderSurfaceOperationTest
java -cp "$OUT:$ANDROID_JAR" FileCaptureCoreTest
java -cp "$OUT:$ANDROID_JAR" FileCaptureFlowTest
java -cp "$OUT:$ANDROID_JAR" ArtifactLifecycleTest
java -cp "$OUT:$ANDROID_JAR" ProviderTransferIdentityTest
java -cp "$OUT:$ANDROID_JAR" SqlScriptTest "$SRC/../assets" "$OUT/java_statements.txt"
python3 "$HERE/roomdb_sql_check.py"
python3 "$HERE/ui_source_check.py" && python3 "$HERE/ui_source_check.py" --selftest
python3 "$HERE/file_ui_source_check.py" && python3 "$HERE/file_ui_source_check.py" --selftest
python3 "$HERE/upload_source_check.py"
python3 "$HERE/capture_source_check.py" && python3 "$HERE/capture_source_check.py" --selftest
python3 "$HERE/wiring_source_check.py" && python3 "$HERE/wiring_source_check.py" --selftest
AGC_JAVA_RULES="$OUT/java_artifact_rules.txt" AGC_JAVA_STATEMENTS="$OUT/java_statements.txt" python3 "$HERE/migration_test.py"
