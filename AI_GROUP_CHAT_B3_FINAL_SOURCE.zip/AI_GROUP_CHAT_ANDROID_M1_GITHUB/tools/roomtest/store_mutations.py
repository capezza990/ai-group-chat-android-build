"""Mutation check for the room/registry/binding rules in InMemoryRoomStore: break one rule at a time and confirm RoomControllerTest notices.
Run: python3 tools/roomtest/store_mutations.py   (needs javac and the android-23 stub jar, like run_tests.sh)"""
import os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.abspath(os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java'))
JAR = os.environ.get('ANDROID_JAR', '/usr/share/java/com.android.android-23.jar')
STORE = 'com/aigroupchat/bridge/room/InMemoryRoomStore.java'
WRITER = 'com/aigroupchat/bridge/room/BindingWriter.java'
BOOT = 'com/aigroupchat/bridge/room/RoomBootstrap.java'
INTEG = 'com/aigroupchat/bridge/room/RoomIntegrity.java'
CTRL = 'com/aigroupchat/bridge/room/RoomController.java'
ASTATE = 'com/aigroupchat/bridge/room/ArtifactState.java'
NAMES = 'com/aigroupchat/bridge/room/ArtifactNames.java'
TSTATE = 'com/aigroupchat/bridge/room/TransferState.java'
STORAGE = 'com/aigroupchat/bridge/room/ArtifactStorage.java'
GATE = 'com/aigroupchat/bridge/room/ArtifactGate.java'
SERVICE = 'com/aigroupchat/bridge/room/ArtifactService.java'
PROMPT = 'com/aigroupchat/bridge/room/RoomPromptBuilder.java'
base = open(os.path.join(SRC, STORE)).read()
writer = open(os.path.join(SRC, WRITER)).read()
boot = open(os.path.join(SRC, BOOT)).read()
integ = open(os.path.join(SRC, INTEG)).read()
ctrl = open(os.path.join(SRC, CTRL)).read()
astate = open(os.path.join(SRC, ASTATE)).read()
tstate = open(os.path.join(SRC, TSTATE)).read()
# (No mutation for the CORE-first registry order here: in the in-memory store the two CORE AIs are always inserted first, so removing the sort changes nothing.
#  The SQLite ORDER BY in RoomDb.listProviders is NOT mutation-tested yet.)
MUTS = [
 ("J1  messagesBetween ignores the room", "if (m.roomId.equals(roomId) && m.seq > afterSeq && m.seq <= uptoSeq) out.add(m);", "if (m.seq > afterSeq && m.seq <= uptoSeq) out.add(m);"),
 ("J2  latestMessages ignores the room", "for (RoomMessage m : messages.values()) if (m.roomId.equals(roomId)) all.add(m);", "for (RoomMessage m : messages.values()) all.add(m);"),
 ("J3  participants of every room are returned", "for (RoomParticipant p : participants.values()) if (p.roomId.equals(roomId)) out.add(p.copy());", "for (RoomParticipant p : participants.values()) out.add(p.copy());"),
 ("J4  seat key ignores the room", "private static String pk(String room, String provider) { return room + \"|\" + provider; }", "private static String pk(String room, String provider) { return provider; }"),
 ("J5  getBinding returns another room's binding", "if (r.roomId.equals(roomId) && r.providerId.equals(providerId) && !BindingRecord.RETIRED.equals(r.state)) return r;", "if (r.providerId.equals(providerId) && !BindingRecord.RETIRED.equals(r.state)) return r;"),
 ("J6  binding without a seat accepted", "if (!participants.containsKey(pk(roomId, b.providerId))) throw new IllegalStateException(\"FK: \" + b.providerId + \" is not seated in room \" + roomId);", ""),
 ("J7  binding without a conversation id accepted", "if (b.providerConversationId == null || b.providerConversationId.isEmpty()) throw new IllegalArgumentException(\"an ACTIVE binding needs a conversation id\");", ""),
 ("J8  the same thread is re-bound (history spam)", "&& cur.conversationId.equals(b.providerConversationId)) return; // same thread: nothing to do", "&& false) return;"),
 ("J9  rebinding forgets the old thread (no history)", "if (cur != null) { cur.state = BindingRecord.RETIRED; cur.retiredAt = b.boundAt; cur.retiredReason = \"rebound\"; }", "if (cur != null) { bindingRecords.remove(cur); }"),
 ("J10 rebind reason wrong", "cur.retiredReason = \"rebound\"", "cur.retiredReason = \"cleared\""),
 ("J11 clearing deletes the history", "if (cur != null) { cur.state = BindingRecord.RETIRED; cur.retiredAt = now; cur.retiredReason = \"cleared\"; }", "if (cur != null) { bindingRecords.remove(cur); }"),
 ("J12 history is oldest first", "for (int i = bindingRecords.size() - 1; i >= 0; i--) {", "for (int i = 0; i < bindingRecords.size(); i++) {"),
 ("J13 retired bindings count as thread use", "BindingRecord.ACTIVE.equals(r.state) && r.conversationId.equals(conversationId)", "r.conversationId.equals(conversationId)"),
 ("J14 thread lookup includes the asking room", "&& !r.roomId.equals(exceptRoomId) && !out.contains(r.roomId)", "&& !out.contains(r.roomId)"),
 ("J15 unknown AI can be seated", "if (!providers.containsKey(providerId)) throw new IllegalStateException(\"FK: unknown provider \" + providerId);", ""),
 ("J16 unknown room can be seated", "if (!rooms.containsKey(roomId)) throw new IllegalStateException(\"FK: unknown room \" + roomId);\n            if (!providers.containsKey(providerId))", "if (!providers.containsKey(providerId))"),
 ("J17 live list shows developer mocks", "if (!liveOnly || p.isLive()) out.add(p);", "out.add(p);"),
 ("J19 a mock can overwrite a core AI", "if (!providers.containsKey(providerId)) providers.put(providerId, new ProviderInfo(providerId, providerId, displayName, \"MOCK\", \"\", \"mock\"));", "providers.put(providerId, new ProviderInfo(providerId, providerId, displayName, \"MOCK\", \"\", \"mock\"));"),
 ("J20 createRoom overwrites an existing room", "if (rooms.containsKey(roomId)) throw new IllegalStateException(\"room already exists: \" + roomId);", ""),
 ("J21 implicit rooms are LIVE", "roomInfos.put(roomId, new RoomInfo(roomId, roomId, RoomKind.MOCK, 0, now));", "roomInfos.put(roomId, new RoomInfo(roomId, roomId, RoomKind.LIVE, 0, now));"),
 ("J22 natural turns above 20 accepted", "if (turns < 0 || turns > 20) throw new IllegalArgumentException(\"natural_max_turns must be 0..20\");", ""),
 ("J23 natural turns on an unknown room accepted", "if (info == null) throw new IllegalStateException(\"FK: unknown room \" + roomId);", "if (info == null) return;"),
 ("J24 natural turns shared by all rooms", "roomInfos.put(roomId, info.withNaturalMaxTurns(turns));", "for (String k : new ArrayList<>(roomInfos.keySet())) roomInfos.put(k, roomInfos.get(k).withNaturalMaxTurns(turns));"),
 ("J25 rollback forgets bindings", "roomInfos = ri; providers = pr; bindingRecords = br;", "roomInfos = ri; providers = pr;"),
 ("J26 rollback forgets rooms", "roomInfos = ri; providers = pr; bindingRecords = br;", "providers = pr; bindingRecords = br;"),
 ("J27 rollback forgets the registry", "roomInfos = ri; providers = pr; bindingRecords = br;", "roomInfos = ri; bindingRecords = br;"),
 ("J28 context position shared across rooms", "if (p != null && seq > p.contextSeq) p.contextSeq = seq;", "for (RoomParticipant q : participants.values()) if (q.providerId.equals(providerId) && seq > q.contextSeq) q.contextSeq = seq;"),
 ("J31 appendMessage hands back another room's message", "return RoomIntegrity.messageInRoom(existing, roomId);", "return existing;"),
 ("J32 createDelivery hands back another room's delivery", "return RoomIntegrity.deliveryInRoom(d, roomId).copy();", "return d.copy();"),
 ("J33 delivery trigger may belong to another room", "if (!trigger.roomId.equals(roomId)) throw new IllegalStateException(\"FK: trigger message belongs to another room\");", ""),
 ("J34 delivery AI needs no seat", "if (!participants.containsKey(pk(roomId, providerId))) throw new IllegalStateException(\"FK: \" + providerId + \" has no seat in room \" + roomId); // a removed AI keeps its seat row", ""),
 ("J35 delivery reply may belong to another room", "if (!reply.roomId.equals(d.roomId)) throw new IllegalStateException(\"FK: reply message belongs to another room\");", ""),
 ("J36 a removed AI loses its history (seat must be enabled)", "if (!participants.containsKey(pk(roomId, providerId))) throw new IllegalStateException(\"FK: \" + providerId + \" has no seat", "if (!participants.containsKey(pk(roomId, providerId)) || !participants.get(pk(roomId, providerId)).enabled) throw new IllegalStateException(\"FK: \" + providerId + \" has no seat"),
 ("J29 removing an AI removes it from every room", "RoomParticipant p = participants.get(pk(roomId, providerId));\n            if (p != null) p.enabled = enabled;", "for (RoomParticipant q : participants.values()) if (q.providerId.equals(providerId)) q.enabled = enabled;"),
 ("J30 clearing a binding clears it in every room", "BindingRecord cur = current(roomId, providerId);\n            if (cur != null) { cur.state = BindingRecord.RETIRED; cur.retiredAt = now;", "for (BindingRecord cur : bindingRecords) if (cur.providerId.equals(providerId) && !BindingRecord.RETIRED.equals(cur.state)) { cur.state = BindingRecord.RETIRED; cur.retiredAt = now;"),
]

# BindingWriter breakages: (name, anchor, replacement) applied to BindingWriter.java
W_MUTS = [
 ("W1  a failing write is swallowed (reports success)", 'return "the room could not save it (" + reason(e) + ")";', 'return null;'),
 ("W2  the failure reason is dropped", 'return "the room could not save it (" + reason(e) + ")";', 'return "the room could not save it";'),
 ("W3  no read-back after the write", 'if (saved == null || !b.providerConversationId.equals(saved.providerConversationId)) return "the room did not keep it";', ''),
 ("W4  read-back accepts any binding", '!b.providerConversationId.equals(saved.providerConversationId)', 'false'),
 ("W5  an unreadable read-back counts as success", 'return "the room could not confirm it was saved (" + reason(e) + ")";', 'return null;'),
 ("W6  clear is not confirmed", 'if (store.getBinding(roomId, providerId) != null) return "the room still has the old connection";', ''),
 ("W7  a failing clear is swallowed", 'return "the room could not clear it (" + reason(e) + ")";', 'return null;'),
]

# RoomBootstrap breakages (applied to RoomBootstrap.java)
B_MUTS = [
 ("B1  every live room inherits the old preference", "if (live && HISTORICAL_LIVE_ROOM.equals(roomId) && legacy != 0)", "if (live && legacy != 0)"),
 ("B2  developer rooms inherit it too", "if (live && HISTORICAL_LIVE_ROOM.equals(roomId) && legacy != 0)", "if (legacy != 0)"),
 ("B3  the old value is not clamped", "int legacy = Math.max(0, Math.min(20, legacyNaturalTurns));", "int legacy = legacyNaturalTurns;"),
 ("B4  an existing room is overwritten with the old value", "            if (info == null) {\n                info = store.createRoom(roomId, newRoomName, live ? RoomKind.LIVE : RoomKind.MOCK, now);\n                seedNewRoom(store, roomId); // the ONLY place first seats are made: when the room is created, in this same transaction\n                int legacy = Math.max(0, Math.min(20, legacyNaturalTurns));\n                if (live && HISTORICAL_LIVE_ROOM.equals(roomId) && legacy != 0) store.setNaturalMaxTurns(roomId, legacy);\n            }", "            if (info == null) {\n                info = store.createRoom(roomId, newRoomName, live ? RoomKind.LIVE : RoomKind.MOCK, now);\n                seedNewRoom(store, roomId); // the ONLY place first seats are made: when the room is created, in this same transaction\n            }\n            int legacy = Math.max(0, Math.min(20, legacyNaturalTurns));\n            if (live && HISTORICAL_LIVE_ROOM.equals(roomId) && legacy != 0) store.setNaturalMaxTurns(roomId, legacy);"),
 ("B5  the mode/kind check is gone", "if (live != (info.kind == RoomKind.LIVE))", "if (false)"),
 ("B6  developer AIs are not registered", "if (!live) for (ProviderCatalog.Entry e : ProviderCatalog.all()) store.ensureMockProvider(e.id, e.name);", ""),
 ("B7  live mode registers developer AIs", "if (!live) for (ProviderCatalog.Entry e : ProviderCatalog.all()) store.ensureMockProvider(e.id, e.name);", "for (ProviderCatalog.Entry e : ProviderCatalog.all()) store.ensureMockProvider(e.id, e.name);"),
 ("B8  a missing room is created as the wrong kind", "live ? RoomKind.LIVE : RoomKind.MOCK, now);", "RoomKind.LIVE, now);"),
 ("B10 a new room is never seated", "seedNewRoom(store, roomId); // the ONLY place first seats are made: when the room is created, in this same transaction", ""),
 ("B11 any room with no seat rows is seated on open (the inference bug)", "            if (live != (info.kind == RoomKind.LIVE))", "            if (store.participants(roomId).isEmpty()) seedNewRoom(store, roomId);\n            if (live != (info.kind == RoomKind.LIVE))"),
 ("B12 a new developer room is not seated", "seedNewRoom(store, roomId); // the ONLY place first seats", "if (live) seedNewRoom(store, roomId); // the ONLY place first seats"),
 ("B13 every room is re-seated on every open", "            if (live != (info.kind == RoomKind.LIVE))", "            seedNewRoom(store, roomId);\n            if (live != (info.kind == RoomKind.LIVE))"),
 ("B14 a new room's first seats are announced", "store.upsertParticipant(roomId, \"chatgpt\", 0);", "store.appendMessage(roomId, \"seed-\" + roomId, RoomMessage.SYSTEM, \"system\", \"seated\", null, 0L); store.upsertParticipant(roomId, \"chatgpt\", 0);"),
 ("B15 the first routing is not led by ChatGPT", "with(RoutingMode.AUTO_PICK, \"chatgpt\", 1)", "with(RoutingMode.AUTO_PICK, \"\", 1)"),
 ("B16 only ChatGPT is seated", "        store.upsertParticipant(roomId, \"claude\", 1);\n", ""),
 ("B17 Claude gets the wrong position", "store.upsertParticipant(roomId, \"claude\", 1);", "store.upsertParticipant(roomId, \"claude\", 0);"),
 ("B9  not atomic (no rollback of a half-done startup)", "store.atomic(() -> {", lambda t: t.replace("store.atomic(() -> {", "((java.util.function.Supplier<Object>) () -> {", 1).replace("            return null;\n        });\n", "            return null;\n        }).get();\n", 1)),
]

# RoomIntegrity breakages (applied to RoomIntegrity.java)
I_MUTS = [
 ("I1  messageInRoom accepts another room's message", "if (!existing.roomId.equals(roomId)) throw new IllegalStateException(\"message id \"", "if (false) throw new IllegalStateException(\"message id \""),
 ("I2  deliveryInRoom accepts another room's delivery", "if (!existing.roomId.equals(roomId)) throw new IllegalStateException(\"a request for that message", "if (false) throw new IllegalStateException(\"a request for that message"),
 ("I3  messageInRoom rejects the SAME room (inverted)", "if (!existing.roomId.equals(roomId)) throw new IllegalStateException(\"message id \"", "if (existing.roomId.equals(roomId)) throw new IllegalStateException(\"message id \""),
 ("I4  deliveryInRoom rejects the SAME room (inverted)", "if (!existing.roomId.equals(roomId)) throw new IllegalStateException(\"a request for that message", "if (existing.roomId.equals(roomId)) throw new IllegalStateException(\"a request for that message"),
]

# RoomController join/leave notices and the registry-driven Add AI list (applied to RoomController.java)
ADD_BODY_END = "                return null;\n            });\n        }\n    }\n\n    /** The AIs that could still be added"
# (No breakage for 'rejoin keeps the old position': the controller passes the position, but both stores ignore it when re-seating, so it is an equivalent
#  mutant here; the stores' own tests cover that rule.)
C_MUTS = [
 ("C1  a later addition is never announced", "if (announce) announceEvent(", "if (false) announceEvent("),
 ("C2  the silent flag is ignored (room creation announces)", "if (announce) announceEvent(", "if (true) announceEvent("),
 ("C3  a rejoin is announced as a first join", "existing == null ? TEXT_JOINED : TEXT_REJOINED", "TEXT_JOINED"),
 ("C4  adding someone already seated announces again", "if (existing != null && existing.enabled) return null;", ""),
 ("C6  removing someone not seated still announces", "if (p != null && p.enabled) { // removing someone who is not seated changes nothing and says nothing", "if (p != null) {"),
 ("C7  removal is not announced", "announceEvent(TEXT_LEFT, providerId);", ""),
 ("C8  the 'left' wording changes", 'TEXT_LEFT = "%s has left the Roundtable."', 'TEXT_LEFT = "%s left."'),
 ("C9  the Add AI list includes AIs already seated", "if (!seated.contains(p.id)) out.add(p);", "out.add(p);"),
 ("C10 a live room is offered developer mocks", "for (ProviderInfo p : store.listProviders(liveOnly)) if (!seated", "for (ProviderInfo p : store.listProviders(false)) if (!seated"),
 ("C11 seat + notice are not one transaction (add)", "store.atomic(() -> {\n                RoomParticipant existing = seat(providerId);", "((java.util.function.Supplier<Object>) () -> {\n                RoomParticipant existing = seat(providerId);"),
 ("C12 seat + notice are not one transaction (remove)", "store.atomic(() -> {\n                RoomParticipant p = seat(providerId);", "((java.util.function.Supplier<Object>) () -> {\n                RoomParticipant p = seat(providerId);"),
 ("C13 the notice names the AI by its id, not its name", "String.format(wording, name)", "String.format(wording, providerId)"),
]
ONLY = os.environ.get('MUT_ONLY')   # e.g. MUT_ONLY=C runs only the C breakages (the full set takes minutes)
def selected(name): return not ONLY or name.startswith(tuple(ONLY.split(',')))

D_MUTS = [
 ("D1  every new room is called Room 2", "while (used.contains(\"Room \" + n)) n++;", ""),
 ("D2  numbering starts at 1", "int n = 2;", "int n = 1;"),
 ("D3  a new room is a developer room", "\"Room \" + n, RoomKind.LIVE, now)", "\"Room \" + n, RoomKind.MOCK, now)"),
 ("D4  only live rooms' names are skipped", "for (RoomInfo r : store.listRooms()) used.add(r.name);", "for (RoomInfo r : store.listRooms()) if (r.kind == RoomKind.LIVE) used.add(r.name);"),
 ("D6  a new room is created without its first seats", "            seedNewRoom(store, made.id);\n", ""),
 ("D5  a new room reuses a fixed id", "\"room-\" + ids.get()", "\"room-1\""),
]

# Artifact and transfer breakages. A_MUTS apply to InMemoryRoomStore.java, E_MUTS to the two state enums.
# (No breakage for 'the sending transfer blocks itself' in InMemoryRoomStore.transitionTransfer: the single-flight loop only runs when the transfer is NOT already sending,
#  so `other != t` can never matter there. The SQLite twin has the real self-exclusion (SQL_OTHER_SENDING), covered by upgrade_mutations K17.)
# (No breakage for 'the active conversation is any conversation' in InMemoryRoomStore.activeBindingId: current() differs from activeRecord() only for a PENDING_NEW binding,
#  which the store API cannot create; the SQLite query filters state='ACTIVE' itself, covered by upgrade_mutations K15.)
A_MUTS = [
 ("A1  an artifact may be created in a room that does not exist", "            if (!rooms.containsKey(roomId)) throw new IllegalStateException(\"FK: unknown room \" + roomId);\n            if (artifacts.containsKey(id))", "            if (artifacts.containsKey(id))"),
 ("A2  a duplicate artifact id is accepted", "            if (artifacts.containsKey(id)) throw new IllegalStateException(\"artifact already exists: \" + id);\n", ""),
# (A3 'an artifact may have no origin' is an equivalent breakage since the provenance rule: an empty origin is not 'user', so a source conversation is required, and none can match an AI called '')
 ("A4  finalize accepts a bad hash, size or path", "            if (size < 0 || !validSha(sha256) || storagePath == null || storagePath.isEmpty()) throw new IllegalArgumentException(\"a READY artifact needs size >= 0, a 64-character hex SHA-256 and a storage path\");\n", ""),
 ("A5  finalize works from any state", "            if (a.state != ArtifactState.PENDING_CAPTURE) return false;\n            artifacts.put(id, new Artifact(a.id", "            artifacts.put(id, new Artifact(a.id"),
 ("A6  a READY artifact can be re-finalized with other data", "return a.size == size && a.sha256.equalsIgnoreCase(sha256) && a.storagePath.equals(storagePath) && (mime == null || a.mime.equals(mime));", "{ artifacts.put(id, new Artifact(a.id, a.roomId, a.origin, a.displayName, a.mime, size, sha256, storagePath, ArtifactState.READY, a.createdAt)); return true; }"),
 ("A7  finalize ignores the type", "mime == null ? a.mime : mime, size, sha256, storagePath, ArtifactState.READY", "a.mime, size, sha256, storagePath, ArtifactState.READY"),
 ("A8  any artifact can be failed or retried", "if (a == null || a.state != from) return false;", "if (a == null) return false;"),
 ("A9  an artifact can be attached across rooms", "            if (!a.roomId.equals(m.roomId)) throw new IllegalStateException(\"FK: artifact and message belong to different rooms\");\n", ""),
 ("A10 the same file can be attached twice", "            for (String[] row : attachments) if (row[0].equals(messageId) && row[1].equals(artifactId)) throw new IllegalStateException(\"already attached\");\n", ""),
 ("A11 attachments ignore their position", "            rows.sort((x, y) -> Integer.compare(Integer.parseInt(x[2]), Integer.parseInt(y[2])));\n", ""),
 ("A12 attachmentsBetween ignores the room", "if (m == null || !m.roomId.equals(roomId) || m.seq <= afterSeq", "if (m == null || m.seq <= afterSeq"),
 ("A13 the range includes its lower end", "m.seq <= afterSeq || m.seq > uptoSeq", "m.seq < afterSeq || m.seq > uptoSeq"),
 ("A14 the range excludes its upper end", "m.seq <= afterSeq || m.seq > uptoSeq", "m.seq <= afterSeq || m.seq >= uptoSeq"),
 ("A15 attachmentsBetween is not in message order", "            out.sort((x, y) -> x.messageSeq != y.messageSeq ? Long.compare(x.messageSeq, y.messageSeq) : Integer.compare(x.position, y.position));\n", ""),
 ("A16 an attached artifact can be deleted", "            for (String[] row : attachments) if (row[1].equals(id)) return false;\n", ""),
 ("A17 an artifact with transfers can be deleted", "            for (ArtifactTransfer t : transfers.values()) if (t.artifactId.equals(id)) return false;\n", ""),
 ("A18 a transfer can be made for a file that is not READY", "            if (a.state != ArtifactState.READY) throw new IllegalStateException(\"a transfer needs a READY artifact\");\n", ""),
 ("A19 a transfer can be made across rooms", "            if (!a.roomId.equals(roomId)) throw new IllegalStateException(\"FK: artifact belongs to another room\");\n            if (a.state != ArtifactState.READY)", "            if (a.state != ArtifactState.READY)"),
 ("A20 ensureTransfer makes a new transfer every time", "if (t == null) { t = new ArtifactTransfer(artifactId, roomId, providerId, b.id, TransferState.PENDING, 0, \"\", now);", "if (true) { t = new ArtifactTransfer(artifactId, roomId, providerId, b.id, TransferState.PENDING, 0, \"\", now);"),
 ("A21 a transition ignores the states the caller named", "            for (TransferState f : from) if (t.state == f) ok = true;\n", "            ok = true;\n"),
 ("A22 illegal transfer moves are accepted", "if (!ok || !t.state.canMoveTo(to)) return false;", "if (!ok) return false;"),
 ("A23 no global single-flight", "                for (ArtifactTransfer other : transfers.values()) if (other != t && other.state == TransferState.SENDING) return false; // global single-flight\n", ""),
 ("A25 attempts are never counted", "(to == TransferState.SENDING && t.state != TransferState.SENDING ? 1 : 0);", "0;"),
 ("A26 staying in SENDING counts another attempt", "(to == TransferState.SENDING && t.state != TransferState.SENDING ? 1 : 0);", "(to == TransferState.SENDING ? 1 : 0);"),
 ("A27 a transition without text wipes the old error", "error != null ? error : t.error", "error"),
 ("A28 restart recovery ignores artifacts waiting for bytes", "            for (Artifact a : new ArrayList<>(artifacts.values())) if (a.state == ArtifactState.PENDING_CAPTURE && moveArtifact(a.id, ArtifactState.PENDING_CAPTURE, ArtifactState.FAILED)) n++;\n", ""),
 ("A34 any source conversation is accepted", "                if (!found) throw new IllegalStateException(\"FK: the source conversation is not a conversation of \" + origin + \" in this room\");\n", ""),
 ("A35 a source conversation of another room is accepted", "if (r.id.equals(sourceBindingId) && r.roomId.equals(roomId) && r.providerId.equals(origin) && !BindingRecord.PENDING_NEW.equals(r.state)) found = true;", "if (r.id.equals(sourceBindingId) && r.providerId.equals(origin) && !BindingRecord.PENDING_NEW.equals(r.state)) found = true;"),
 ("A36 a source conversation of another AI is accepted", "if (r.id.equals(sourceBindingId) && r.roomId.equals(roomId) && r.providerId.equals(origin) && !BindingRecord.PENDING_NEW.equals(r.state)) found = true;", "if (r.id.equals(sourceBindingId) && r.roomId.equals(roomId) && !BindingRecord.PENDING_NEW.equals(r.state)) found = true;"),
 ("A37 a user file may name a source conversation", "                if (Artifact.ORIGIN_USER.equals(origin)) throw new IllegalArgumentException(\"a user file has no source conversation\");\n", ""),
 ("A38 finalizing a file forgets its source conversation", "new Artifact(a.id, a.roomId, a.origin, a.sourceBindingId, a.displayName, mime == null ? a.mime : mime, size", "new Artifact(a.id, a.roomId, a.origin, null, a.displayName, mime == null ? a.mime : mime, size"),
 ("A39 failing or retrying a file forgets its source conversation", "new Artifact(a.id, a.roomId, a.origin, a.sourceBindingId, a.displayName, a.mime, a.size, a.sha256, a.storagePath, to, a.createdAt)", "new Artifact(a.id, a.roomId, a.origin, null, a.displayName, a.mime, a.size, a.sha256, a.storagePath, to, a.createdAt)"),
 ("A29 restart recovery fails every transfer", "if (t.state == TransferState.SENDING || t.state == TransferState.STAGED) { transfers.put(e.getKey(), t.with(TransferState.FAILED, t.attempts, \"interrupted (app restart)\", now)); n++; }", "if (t.state != TransferState.FAILED) { transfers.put(e.getKey(), t.with(TransferState.FAILED, t.attempts, \"interrupted (app restart)\", now)); n++; }"),
 ("A30 restart recovery writes no reason", "t.with(TransferState.FAILED, t.attempts, \"interrupted (app restart)\", now)", "t.with(TransferState.FAILED, t.attempts, \"\", now)"),
 ("A31 a failed transaction keeps its artifacts", "                artifacts = ar; attachments = at; transfers = tr;\n", "                attachments = at; transfers = tr;\n"),
 ("A32 a failed transaction keeps its attachments", "                artifacts = ar; attachments = at; transfers = tr;\n", "                artifacts = ar; transfers = tr;\n"),
 ("A33 a failed transaction keeps its transfers", "                artifacts = ar; attachments = at; transfers = tr;\n", "                artifacts = ar; attachments = at;\n"),
]
E_MUTS = [
 ("E1  READY may be failed", ASTATE, "return (this == PENDING_CAPTURE && (to == READY || to == FAILED)) || (this == FAILED && to == PENDING_CAPTURE);", "return (this == PENDING_CAPTURE && (to == READY || to == FAILED)) || (this == FAILED && to == PENDING_CAPTURE) || (this == READY && to == FAILED);"),
 ("E2  FAILED may jump to READY", ASTATE, "(this == FAILED && to == PENDING_CAPTURE);", "(this == FAILED && (to == PENDING_CAPTURE || to == READY));"),
 ("E3  PENDING may jump to VERIFIED", TSTATE, "(this == PENDING && (to == SENDING || to == FAILED))", "(this == PENDING && (to == SENDING || to == FAILED || to == VERIFIED))"),
 ("E4  VERIFIED may be updated", TSTATE, "if (this == VERIFIED) return false;", "if (this == VERIFIED) return to == VERIFIED;"),
 ("E5  FAILED may become VERIFIED", TSTATE, "(this == FAILED && (to == PENDING || to == SENDING))", "(this == FAILED && (to == PENDING || to == SENDING || to == VERIFIED))"),
 ("E6  SENDING may go back to PENDING", TSTATE, "(this == SENDING && (to == STAGED || to == FAILED))", "(this == SENDING && (to == STAGED || to == FAILED || to == PENDING))"),
]
TEST_CLASSES = [c for c in ('RoomControllerTest', 'ArtifactStoreTest', 'ArtifactStorageTest', 'ArtifactGateTest', 'ArtifactFlowTest', 'ProviderSurfaceLeaseTest', 'ProviderSurfaceOperationTest', 'ProviderTransferIdentityTest', 'FileCaptureCoreTest', 'FileCaptureFlowTest', 'ArtifactLifecycleTest') if os.path.exists(os.path.join(HERE, c + '.java'))]

# Breakages in the file store, the gate, the service and the controller's file code: (name, file, anchor, replacement)
# Equivalent breakages that were removed on purpose:
#   V19  dropping the 'already queued' check: a duplicate queue entry is dropped later by startCapture's re-check of the CURRENT state (V18 covers that guard).
#   V21  letting retryTransfer try SENDING -> PENDING: the store refuses that move anyway (TransferState.canMoveTo), so the extra state changes nothing.
# (No breakage for 'ArtifactNames reads chars instead of code points': a surrogate pair passes through half by half and reassembles, so the cleaned text is identical;
#  the cap and the emoji test cover the part that matters (NM13).)
X_MUTS = [
 ("ST1 no size limit", STORAGE, "if (size > maxBytes) throw new TooLargeException(maxBytes);", ""),
 ("ST2 the size limit is off by one", STORAGE, "if (size > maxBytes) throw", "if (size >= maxBytes) throw"),
 ("ST3 the hash ignores the bytes", STORAGE, "                    md.update(buf, 0, n);\n                    out.write(buf, 0, n);", "                    out.write(buf, 0, n);"),
 ("ST4 a failed write leaves its temporary file", STORAGE, "if (!done) tmp.delete();", ""),
 ("ST5 a stored file can be overwritten", STORAGE, "        if (target.exists()) throw new IOException(\"a file is already stored for artifact \" + artifactId);\n", ""),
 ("ST6 names starting with a dot are accepted", STORAGE, "|| s.equals(\"..\") || s.startsWith(\".\")) return false;", "|| s.equals(\"..\")) return false;"),
 ("ST7 a slash is accepted in names", STORAGE, "c == '-' || c == '_' || c == '.')", "c == '-' || c == '_' || c == '.' || c == '/')"),
 ("ST8 recorded paths are not checked", STORAGE, "if (parts.length != 2 || !safeName(parts[0]) || !safeName(parts[1])) return null;", "if (parts.length < 2) return null;"),
 ("ST10 integrity ignores the size", STORAGE, "if (f == null || f.length() != a.size) return false;", "if (f == null) return false;"),
 ("ST11 integrity accepts files that are not READY", STORAGE, "if (a == null || a.state != ArtifactState.READY) return false;", "if (a == null) return false;"),
 ("ST12 delete follows crafted paths", STORAGE, "        File f = fileOf(relativePath);\n        return f == null || f.delete();", "        File f = new File(root, relativePath == null ? \"\" : relativePath);\n        return f.delete() || !f.exists();"),
 ("ST13 the hash is written in capitals", STORAGE, "sb.append(Character.forDigit((x >> 4) & 15, 16))", "sb.append(Character.toUpperCase(Character.forDigit((x >> 4) & 15, 16)))"),
 ("ST14 the recorded path is not relative to the room", STORAGE, "return new Stored(roomId + \"/\" + artifactId, size, hex(md.digest()));", "return new Stored(artifactId, size, hex(md.digest()));"),
 ("G2  the same file on two messages is two transfers' worth", GATE, "if (!needed.containsKey(a.artifact.id)) needed.put(a.artifact.id, a.artifact);", "needed.put(a.artifact.id + a.messageId, a.artifact);"),
 ("G3  a file that could not be saved does not block", GATE, "case FAILED: return GateDecision.blocked(", "case FAILED: if (true) continue; return GateDecision.blocked("),
 ("G4  a file whose bytes are not stored yet does not make the turn wait", GATE, "case PENDING_CAPTURE: awaiting.add(a); continue;", "case PENDING_CAPTURE: continue;"),
 ("G5  a file already in the conversation is sent again", GATE, "            if (t != null && t.state == TransferState.VERIFIED) continue;\n", ""),
 ("G6  the stored bytes are never re-checked", GATE, "if (intact != null && !intact.test(a)) return", "if (false) return"),
 ("G7  an AI with no conversation is let through", GATE, "if (t == null) return GateDecision.blocked(who +", "if (t == null) continue; if (false) return GateDecision.blocked(who +"),
 ("G8  the retry limit is ignored", GATE, "if (t.attempts >= MAX_ATTEMPTS) return", "if (false) return"),
 ("G9  a transfer in progress does not make the turn wait", GATE, "case SENDING: sending = true; break;", "case SENDING: break;"),
 ("G10 the gate opens while a transfer is still sending", GATE, "if (startable.isEmpty() && awaiting.isEmpty() && !sending) return !staged.isEmpty() ? GateDecision.readyToSend(staged) : GateDecision.open();", "if (startable.isEmpty() && awaiting.isEmpty()) return !staged.isEmpty() ? GateDecision.readyToSend(staged) : GateDecision.open();"),
 ("G11 the retry limit is five", GATE, "MAX_ATTEMPTS = 3;", "MAX_ATTEMPTS = 5;"),
 ("G12 the gate looks at the whole history", GATE, "store.attachmentsBetween(roomId, afterSeq, uptoSeq)", "store.attachmentsBetween(roomId, 0, uptoSeq)"),
 ("V1  a finished transfer keeps the slot", SERVICE, "} finally { release(); pumpCaptures(); }", "} finally { pumpCaptures(); }"),
 ("V3  a lost race starts the upload anyway", SERVICE, "        if (!moved) { releaseQuietly(); return false; }   // someone else moved it, or the database says another transfer is sending\n", ""),
 ("V4  a changed file is uploaded", SERVICE, "|| file == null || !storage.isIntact(a)) {", "|| file == null) {"),
 ("V7  the failure reason is dropped", SERVICE, "reason == null || reason.isEmpty() ? \"the transfer failed\" : reason", "\"the transfer failed\""),
 ("V8  every transfer is recorded as a success", SERVICE, "ok ? TransferState.STAGED : TransferState.FAILED", "TransferState.STAGED"),
 ("V9  a captured file may be any size", SERVICE, "storage.write(a.roomId, a.id, in, maxFileBytes)", "storage.write(a.roomId, a.id, in, Long.MAX_VALUE)"),
 ("V10 a failed capture leaves the file waiting forever", SERVICE, "            store.failArtifact(a.id);\n            if (stored != null) storage.delete(stored);\n        } catch (IOException | RuntimeException e) {", "            if (stored != null) storage.delete(stored);\n        } catch (IOException | RuntimeException e) {"),
 ("V11 a captured file's type is lost", SERVICE, "store.finalizeArtifact(a.id, mime, s.size, s.sha256, s.relativePath)", "store.finalizeArtifact(a.id, null, s.size, s.sha256, s.relativePath)"),
 ("V13 a failed intake leaves a ghost file record", SERVICE, "            store.deleteUnreferencedArtifact(id);\n            throw e;", "            throw e;"),
 ("V14 a file that messages use can be discarded", SERVICE, "if (a == null || !store.deleteUnreferencedArtifact(artifactId)) return false;", "if (a == null) return false; store.deleteUnreferencedArtifact(artifactId);"),
 ("V15 the stored bytes are not re-checked by the gate", SERVICE, "new ArtifactGate(store, storage::isIntact)", "new ArtifactGate(store, null)"),
 ("V16 captures are never queued", SERVICE, "                if (!queued) captureQueue.addLast(a);", ""),
 ("V20 Stop leaves the waiting captures in line", SERVICE, "        for (Artifact a : dropped) store.failArtifact(a.id);", ""),
 ("ST9 integrity ignores the hash", STORAGE, "return sha256Of(in).equalsIgnoreCase(a.sha256);", "{ sha256Of(in); return true; }"),
 ("ST15 a zero-byte read ends the stored file early (the old loop)", STORAGE, "while ((n = in.read(buf)) != -1) {\n                    if (n == 0) { if (++empty > MAX_EMPTY_READS) throw new IOException(\"the incoming stream is not making progress\"); continue; }", "while ((n = in.read(buf)) > 0) {\n                    if (n == 0) { if (++empty > MAX_EMPTY_READS) throw new IOException(\"the incoming stream is not making progress\"); continue; }"),
 ("ST16 a zero-byte read ends the hash early (the old loop)", STORAGE, "        while ((n = in.read(buf)) != -1) {\n            if (n == 0) { if (++empty > MAX_EMPTY_READS) throw new IOException(\"the stream is not making progress\"); continue; }", "        while ((n = in.read(buf)) > 0) {\n            if (n == 0) { if (++empty > MAX_EMPTY_READS) throw new IOException(\"the stream is not making progress\"); continue; }"),
 ("G1  an AI's own file counts as present in ANY conversation (the rebind bug)", GATE, "if (producedInCurrentConversation(a.artifact, providerId, activeBinding)) continue;", "if (providerId.equals(a.artifact.origin)) continue;"),
 ("G13 the rule forgets which AI", GATE, "return a.sourceBindingId != null && activeBindingId != null && providerId.equals(a.origin) && a.sourceBindingId.equals(activeBindingId);", "return a.sourceBindingId != null && activeBindingId != null && a.sourceBindingId.equals(activeBindingId);"),
 ("G14 an unknown source counts as present", GATE, "return a.sourceBindingId != null && activeBindingId != null && providerId.equals(a.origin) && a.sourceBindingId.equals(activeBindingId);", "return activeBindingId != null && providerId.equals(a.origin) && (a.sourceBindingId == null || a.sourceBindingId.equals(activeBindingId));"),
 ("G15 the rule ignores the conversation (AI name alone)", GATE, "return a.sourceBindingId != null && activeBindingId != null && providerId.equals(a.origin) && a.sourceBindingId.equals(activeBindingId);", "return providerId.equals(a.origin);"),
 ("V2  two jobs can run at once", SERVICE, "if (!acquire(job)) return false;\n        final long now = clock.getAsLong();", "acquire(job);\n        final long now = clock.getAsLong();"),
 ("V5  a crashing transport crashes the turn", SERVICE, "        } catch (RuntimeException e) {\n            if (job.claim()) finishTransfer(t, false, e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());\n        }", "        } catch (RuntimeException e) { throw e; }"),
 ("V6  a repeated or late callback is counted again", SERVICE, "synchronized boolean claim() { if (claimed) return false; claimed = true; return true; }", "synchronized boolean claim() { return true; }"),
 ("V12 Stop does not take over the running job", SERVICE, "if (job == null || !job.claim()) return;", "if (job == null) return;"),
 ("V17 the next capture never starts by itself", SERVICE, "            closeQuietly(in);\n            release();\n            pumpCaptures();\n        }\n    }", "            closeQuietly(in);\n            release();\n        }\n    }"),
 ("V18 a file already READY is fetched again", SERVICE, "if (current == null || current.state != ArtifactState.PENDING_CAPTURE) return false;", "if (current == null) return false;"),
 ("V21 Stop does not free the slot of a transfer", SERVICE, "TransferState.FAILED, \"cancelled\", clock.getAsLong()); }\n            finally { release(); pumpCaptures(); }", "TransferState.FAILED, \"cancelled\", clock.getAsLong()); }\n            finally { }"),
 ("V22 Stop does not fail a running capture", SERVICE, "try { store.failArtifact(job.a.id); }", "try { }"),
 ("V23 Stop records a cancelled transfer as VERIFIED", SERVICE, "new TransferState[]{TransferState.SENDING}, TransferState.FAILED, \"cancelled\", clock.getAsLong()); }\n            finally", "new TransferState[]{TransferState.SENDING}, TransferState.VERIFIED, \"cancelled\", clock.getAsLong()); }\n            finally"),
 ("V24 Stop asks both transports to stop", SERVICE, "            if (transport != null) cancelQuietly(transport::cancel);\n            try { store.transitionTransfer(job.t", "            if (transport != null) cancelQuietly(transport::cancel); if (capture != null) cancelQuietly(capture::cancel);\n            try { store.transitionTransfer(job.t"),
 ("V25 bytes that arrive after Stop are accepted", SERVICE, "if (job.claim()) finishCapture(a, in, mime); else closeQuietly(in);", "finishCapture(a, in, mime);"),
 ("V26 bytes that arrive after Stop are not even closed", SERVICE, "if (job.claim()) finishCapture(a, in, mime); else closeQuietly(in);", "if (job.claim()) finishCapture(a, in, mime);"),
 ("V27 Stop between taking the slot and starting is ignored", SERVICE, "if (job.stopped) { // Stop arrived between taking the slot and starting:", "if (false) { // Stop arrived between taking the slot and starting:"),
 ("V28 the running job is not registered when the slot is taken", SERVICE, "busy = true; activeJob = job; return true;", "busy = true; return true;"),
 ("V29 Stop does not mark the job as stopped", SERVICE, "        job.stopped = true;\n", ""),
 ("F16 prompts mention files in plain-text chats too", PROMPT, "return n == null || n.isEmpty() ? \"\" : \" [Attached: \"", "return \" [Attached: \""),
 ("F18 the prompt note leaves out the size", PROMPT, "+ (a.artifact.size >= 0 ? \", \" + formatSize(a.artifact.size) : \"\")", "+ \"\""),
 ("F19 a file the AI made in its current conversation is announced to it", PROMPT, "                if (ArtifactGate.producedInCurrentConversation(a.artifact, me.providerId, activeBinding)) continue; // it made this file in the conversation it is in now\n", ""),
 ("F20 a file whose message is not shown is not named", PROMPT, "if (!unseen.isEmpty()) lines.add(", "if (false) lines.add("),
 ("F21 kilobytes are counted as 1000", PROMPT, "bytes / 1024.0", "bytes / 1000.0"),
 ("F22 the conversation of a new file is read when the answer ARRIVES", CTRL, "final String sourceBinding = run.activeBindingId;", "final String sourceBinding = store.activeBindingId(roomId, run.active.providerId);"),
 ("F23 a new file never records its conversation", CTRL, "before.providerId, sourceBinding, toSave.get(i).name", "before.providerId, null, toSave.get(i).name"),
 ("F24 the conversation is not noted when the request is sent", CTRL, "            r.activeBindingId = store.activeBindingId(roomId, step.providerId);   // provenance of any file this answer produces\n", ""),
 ("F1  the controller never asks the gate", CTRL, "if (artifacts != null) { // files: nothing is asked of this AI", "if (false) { // files: nothing is asked of this AI"),
 ("F2  a blocked turn is sent anyway", CTRL, "if (g.kind == GateDecision.Kind.BLOCKED) return finishLocked(g.reason);", "if (false) return finishLocked(g.reason);"),
 ("F3  a turn that must wait is sent anyway", CTRL, "if (g.kind == GateDecision.Kind.WORKING) {\n                    r.waiting = true;", "if (false) {\n                    r.waiting = true;"),
 ("F4  a waiting turn is never woken", CTRL, "            if (run == null || run.stopping || !run.waiting) return;\n            run.waiting = false;", "            if (true) return;\n            run.waiting = false;"),
 ("F25 start-up recovery leaves a crashed capture's file in place", CTRL, "if (svc != null) svc.reconcileStorage(); // ...and a complete file", "if (false) svc.reconcileStorage(); // ...and a complete file"),
 ("V30 a failed upload leaves earlier staged files staged (the composer was cleaned)", SERVICE, "if (!ok && composerCleaned) failStaged(", "if (false) failStaged("),
 ('ZI1 an upload may target a RETIRED binding', 'com/aigroupchat/bridge/engine/ProviderTransferIdentity.java', 'if (requireActive && !BindingRecord.ACTIVE.equals(r.state)) return null;\n', ''),
 ('ZI2 the room is not compared', 'com/aigroupchat/bridge/engine/ProviderTransferIdentity.java', 'if (!t.bindingId.equals(r.id) || !t.roomId.equals(r.roomId) || !t.providerId.equals(r.providerId)) continue;', 'if (!t.bindingId.equals(r.id) || !t.providerId.equals(r.providerId)) continue;'),
 ('ZI3 the provider is not compared', 'com/aigroupchat/bridge/engine/ProviderTransferIdentity.java', 'if (!t.bindingId.equals(r.id) || !t.roomId.equals(r.roomId) || !t.providerId.equals(r.providerId)) continue;', 'if (!t.bindingId.equals(r.id) || !t.roomId.equals(r.roomId)) continue;'),
 ('ZI4 cleanup may target a PENDING_NEW binding', 'com/aigroupchat/bridge/engine/ProviderTransferIdentity.java', 'if (BindingRecord.PENDING_NEW.equals(r.state) || r.conversationId == null || r.conversationId.isEmpty()) return null;\n            return new Target(r.id, r.conversationId, r.roomId, r.providerId);\n        }\n        return null;\n    }\n\n    private static Target resolve', 'if (r.conversationId == null || r.conversationId.isEmpty()) return null;\n            return new Target(r.id, r.conversationId, r.roomId, r.providerId);\n        }\n        return null;\n    }\n\n    private static Target resolve'),
 ('ZI5 the physical check ignores the provider', 'com/aigroupchat/bridge/engine/ProviderTransferIdentity.java', 'return providerId.equals(physicalProviderId) && conversationId.equals(physicalConversationId);', 'return conversationId.equals(physicalConversationId);'),
 ('ZI6 the physical check ignores the conversation', 'com/aigroupchat/bridge/engine/ProviderTransferIdentity.java', 'return providerId.equals(physicalProviderId) && conversationId.equals(physicalConversationId);', 'return providerId.equals(physicalProviderId);'),
 ('ZO1 the idle expiry ignores newer operations', 'com/aigroupchat/bridge/engine/ProviderSurfaceOperation.java', '&& binding != null && binding.equals(bindingId) && sequence == expectedVersion;', '&& binding != null && binding.equals(bindingId);'),
 ('ZO2 an idle batch is recognised for any conversation', 'com/aigroupchat/bridge/engine/ProviderSurfaceOperation.java', '&& binding != null && binding.equals(bindingId);\n    }', '&& binding != null;\n    }'),
 ('ZO3 a running turn is not noticed', 'com/aigroupchat/bridge/engine/ProviderSurfaceOperation.java', 'return activeTurn != null && current();', 'return false;'),
 ('ZO4 a running upload is not noticed', 'com/aigroupchat/bridge/engine/ProviderSurfaceOperation.java', 'return activeStage != null && current();', 'return false;'),
 ('ZC1 acceptance commits nothing', CTRL, 'svc.commitStaged(run.stagedForActiveSend);', 'svc.commitStaged(new ArrayList<>());'),
 ('ZC2 the gate forgets which rows are staged', GATE, '{ staged.add(t); continue; }', '{ continue; }'),
 ('ZN1 resetting staged rows does not tell the transport', SERVICE, 'if (changed > 0 && notifyTransport && transport != null) transport.invalidateStaged(roomId, providerId, bindingId);', ''),
 ('ZN2 an expired staged batch stays STAGED in the database', SERVICE, 'transport.setStagedExpiryListener((room, provider, binding) ->\n                failStagedBinding(room, provider, binding, "staged attachment expired before the turn was sent", false));', 'transport.setStagedExpiryListener((room, provider, binding) -> { });'),
 ('ZD1 Stop before the prompt is handed over is treated as sent', CTRL, 'else if (!run.activeDispatched) {', 'else if (false) {'),
 ('ZD2 the prompt is never marked as handed over', CTRL, '                    run.activeDispatched = true;\n', ''),
 ('ZD3 the hand-over flag of an earlier step is kept', CTRL, '            r.activeDispatched = false;\n', ''),
 ('ZD4 a request that was not sent ends as uncertain', CTRL, 'DeliveryState.CANCELLED, why + " (request not sent)"', 'DeliveryState.UNCERTAIN, why + " (request not sent)"'),
 ("ZC3 acceptance commits the rows that are still staged and ignores the others", SERVICE, "if (!stagedNow.containsAll(unique.keySet())) {", "if (false) {"),
 ('ZR1 the reply id is ignored when matching', 'com/aigroupchat/bridge/engine/FileOfferMatcher.java', 'final boolean exact = replyRef != null && !replyRef.isEmpty();\n        boolean replyPresent', 'final boolean exact = false;\n        boolean replyPresent'),
 ('ZR2 offers of another reply are accepted', 'com/aigroupchat/bridge/engine/FileOfferMatcher.java', 'if (!replyRef.equals(o.msgId)) continue;\n                replyPresent = true;', 'replyPresent = true;'),
 ('ZR3 a reply that is gone is not reported', 'com/aigroupchat/bridge/engine/FileOfferMatcher.java', 'if (exact && !replyPresent) return new Result(', 'if (false && !replyPresent) return new Result('),
 ("ZR4 a reply promises the newest message's files, not its own", 'com/aigroupchat/bridge/engine/FileOfferMatcher.java', 'if (exact ? !providerAsstMsgId.equals(o.msgId) : o.fromEnd != 0) continue;', 'if (o.fromEnd != 0) continue;'),
 ('ZR5 what a reply promises is decided by the newest rule', 'com/aigroupchat/bridge/engine/FileOfferMatcher.java', 'match(ArtifactNames.clean(o.name), offers, exact ? providerAsstMsgId : "");', 'match(ArtifactNames.clean(o.name), offers, "");'),
 ('ZR6 the capture flow ignores the reply identity', 'com/aigroupchat/bridge/engine/FileCaptureFlow.java', 'FileOffer.parseList(json), r.replyRef == null ? "" : r.replyRef);', 'FileOffer.parseList(json), "");'),
 ('ZR7 a manual retry does not need the reply identity', SERVICE, 'if (!a.fromUser() && store.sourceReplyRef(artifactId).isEmpty()) return false;', ''),
 ("ZR8 the screen's retry rule ignores the reply identity", SERVICE, 'a.state == ArtifactState.FAILED && !a.fromUser() && !store.sourceReplyRef(artifactId).isEmpty();', 'a.state == ArtifactState.FAILED && !a.fromUser();'),
 ('ZR9 a file attached to two messages still gets an identity', STORE, 'if (messageId != null) return "";   // attached to more than one message', 'if (messageId != null) { }   // attached to more than one message'),
 ("ZR10 another AI's or room's delivery is accepted as the source", STORE, 'if (ref != null || !a.origin.equals(d.providerId) || !a.roomId.equals(d.roomId)) return "";', 'if (ref != null) return "";'),
# ZR11 (removing the user-file guard in InMemoryRoomStore.sourceReplyRef) is an EQUIVALENT breakage: a user file can never match a delivery's AI, so the origin check (ZR10) already refuses it; the guard stays as defense in depth.
 ('ZR12 the downloader reports success before the streams are closed', 'com/aigroupchat/bridge/engine/NativeDownloader.java', '            try (InputStream input = in; OutputStream out = new FileOutputStream(target)) {', '            ok = true;\n            try (InputStream input = in; OutputStream out = new FileOutputStream(target)) {'),
 ('ZR13 the message id of an offer is dropped', 'com/aigroupchat/bridge/engine/FileOffer.java', '(String) mt, (String) mi));', '(String) mt, ""));'),
 ('ZT1 a link that cannot be fetched is clicked instead of refused (the original bug)', 'com/aigroupchat/bridge/engine/FileCaptureFlow.java', "        if (!offer.fetchable()) { fail(\"that file's link is not one the app will open\"); return; }   // never \"clicked just because it cannot be fetched\"\n", "        if (!offer.fetchable()) { click(); return; }\n"),
 ('ZT2 any link may be clicked', 'com/aigroupchat/bridge/engine/FileOffer.java', 'kind == Kind.BUTTON || (kind == Kind.LINK && href.regionMatches(true, 0, "sandbox:", 0, 8))', 'kind == Kind.BUTTON || kind == Kind.LINK'),
 ('ZT3 the sandbox: scheme is case-sensitive', 'com/aigroupchat/bridge/engine/FileOffer.java', 'href.regionMatches(true, 0, "sandbox:", 0, 8)', 'href.regionMatches(false, 0, "sandbox:", 0, 8)'),
 ('ZT4 any address with a colon may be clicked', 'com/aigroupchat/bridge/engine/FileOffer.java', 'href.regionMatches(true, 0, "sandbox:", 0, 8)', 'href.contains(":")'),
 ('ZT5 plain http counts as fetchable', 'com/aigroupchat/bridge/engine/FileOffer.java', '(href.startsWith("https://") || href.startsWith("blob:")', '(href.startsWith("http") || href.startsWith("blob:")'),
 ('ZT6 the fingerprint drops the reply id', 'com/aigroupchat/bridge/engine/FileCaptureFlow.java', ' + ",\\"fromEnd\\":" + o.fromEnd + ",\\"msgId\\":" + js(o.msgId) + "}";', ' + ",\\"fromEnd\\":" + o.fromEnd + "}";'),
 ('ZT7 the fingerprint drops the address', 'com/aigroupchat/bridge/engine/FileCaptureFlow.java', '"\\",\\"href\\":" + js(o.href)\n                + ",\\"fromEnd\\":"', '"\\""\n                + ",\\"fromEnd\\":"'),
 ('ZT8 the fingerprint drops the message position', 'com/aigroupchat/bridge/engine/FileCaptureFlow.java', '\n                + ",\\"fromEnd\\":" + o.fromEnd + ",\\"msgId\\":"', '\n                + ",\\"msgId\\":"'),
 ('ZL1 detaching does not cancel the running job', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', '        service.cancelInFlight();   // FIRST: the running job is cancelled/resolved while the transports still reach the live pages\n', ''),
 ('ZL2 detaching unlinks the pages before cancelling', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', '        service.cancelInFlight();   // FIRST: the running job is cancelled/resolved while the transports still reach the live pages\n        service.setListener(null);  // nobody is listening any more\n        upload.setTarget(null);\n        capture.setTarget(null);\n', '        upload.setTarget(null);\n        capture.setTarget(null);\n        service.cancelInFlight();   // FIRST: the running job is cancelled/resolved while the transports still reach the live pages\n        service.setListener(null);\n'),
 ('ZL3 detaching keeps the old listener', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', '        service.setListener(null);  // nobody is listening any more\n', ''),
 ('ZL4 anyone can detach', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', 'if (whoever == null || owner != whoever) return false;', 'if (whoever == null) return false;'),
 ('ZL5 a new owner does not replace the old one', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', "        if (owner != null) detachLocked();   // a new screen replaces the old one: the old screen's running job is resolved first\n", ''),
 ('ZL6 an upload with no pages hangs the slot', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', 'if (t == null) { callback.onFailed("the provider pages are not available right now"); return; }   // never leave the single-flight slot hanging', 'if (t == null) return;'),
 ('ZL7 a capture with no pages hangs the slot', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', 'if (t == null) { callback.onFailed("the provider pages are not available right now"); return; }\n            t.capture(', 'if (t == null) return;\n            t.capture('),
 ("ZL8 a new screen's transport never gets the expiry listener", 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', 'if (t != null && l != null) t.setStagedExpiryListener(l);', ''),
 ('ZL9 staged-row invalidation never reaches the page', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', 'if (t != null) t.invalidateStaged(roomId, providerId, bindingId);', ''),
 ('ZL10 an upload cancel is not forwarded', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', '@Override public void cancel() { ArtifactService.Transport t = target; if (t != null) t.cancel(); }', '@Override public void cancel() { }'),
 ('ZL11 a capture cancel is not forwarded', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', '@Override public void cancel() { ArtifactService.CaptureTransport t = target; if (t != null) t.cancel(); }', '@Override public void cancel() { }'),
 ('ZL12 attaching without an owner is accepted', 'com/aigroupchat/bridge/room/ArtifactLifecycle.java', 'if (newOwner == null) throw new IllegalArgumentException("an owner is required");', ''),
 ("F5  Stop leaves the files moving", CTRL, "fin.run(); if (wasWaiting && artifacts != null) artifacts.cancelInFlight(); return; }", "fin.run(); return; }"),
 ("F6  a turn can wait forever when nothing can move the files", CTRL, "if (started || artifacts.isBusy()) return;   // a job is running", "if (true) return;   // a job is running"),
 ("F7  a late-joining AI is not sent the old files", CTRL, "Math.min(me.contextSeq, trigger.seq - 1)", "trigger.seq - 1"),
 ("F8  a file that is not ready can be attached", CTRL, "if (a.state != ArtifactState.READY) throw new IllegalArgumentException(", "if (false) throw new IllegalArgumentException("),
 ("F9  another room's file can be attached", CTRL, "if (!a.roomId.equals(roomId)) throw new IllegalArgumentException(\"that file belongs to another room\");\n", ""),
 ("F10 a file attached twice is not caught", CTRL, "if (!seen.add(aid)) throw new IllegalArgumentException(\"the same file was attached twice\");", ""),
 ("F11 a reply's files are never captured", CTRL, "if (!created.isEmpty() && svc != null) svc.startCaptures(created);", ""),
 ("F12 an answer that is only files is called empty", CTRL, "if ((text == null || text.trim().isEmpty()) && !files.isEmpty()) {", "if (false) {"),
 ("F13 a reply's files are kept even without file support", CTRL, "final List<RoomProvider.FileIntent> files = svc == null || offered == null ? new ArrayList<>() : offered;", "final List<RoomProvider.FileIntent> files = offered == null ? new ArrayList<>() : offered;"),
 ("F14 a restart does not recover interrupted file work", CTRL, "        store.markArtifactWorkInterrupted(now); // an upload or capture that was running when the app died", "        // an upload or capture that was running when the app died"),
 ("F15 prompts do not mention the attached file", PROMPT, ".append(fit(trigger.text)).append(attachNote(attached, trigger.id));", ".append(fit(trigger.text));"),
 ("F17 a status line does not say what the turn waits for", CTRL, "return run.waiting ? base + \" - \" + run.waitNote : base;", "return base;"),

 ("NM1 path separators are kept in a name", NAMES, "if (cp == '/' || cp == '\\\\') sb.append('_');", "if (false) sb.append('_');"),
 ("NM2 only the forward slash is replaced", NAMES, "if (cp == '/' || cp == '\\\\') sb.append('_');", "if (cp == '/') sb.append('_');"),
 ("NM3 control characters are kept", NAMES, "else if (Character.isISOControl(cp) || isInvisibleMark(cp)) continue;", "else if (isInvisibleMark(cp)) continue;"),
 ("NM4 invisible direction marks are kept", NAMES, "else if (Character.isISOControl(cp) || isInvisibleMark(cp)) continue;", "else if (Character.isISOControl(cp)) continue;"),
 ("NM5 an empty name stays empty", NAMES, "if (n.isEmpty() || n.equals(\".\") || n.equals(\"..\")) return FALLBACK;", "if (n.equals(\".\") || n.equals(\"..\")) return FALLBACK;"),
 ("NM6 '..' is allowed as a name", NAMES, "if (n.isEmpty() || n.equals(\".\") || n.equals(\"..\")) return FALLBACK;", "if (n.isEmpty() || n.equals(\".\")) return FALLBACK;"),
 ("NM7 '.' is allowed as a name", NAMES, "if (n.isEmpty() || n.equals(\".\") || n.equals(\"..\")) return FALLBACK;", "if (n.isEmpty() || n.equals(\"..\")) return FALLBACK;"),
 ("NM8 a missing name becomes empty", NAMES, "if (raw == null) return FALLBACK;", "if (raw == null) return \"\";"),
 ("NM9 surrounding white space is kept", NAMES, "String n = trim(sb.toString());", "String n = sb.toString();"),
 ("NM10 a long name is not shortened", NAMES, "return cap(n);", "return n;"),
 ("NM11 shortening always drops the extension", NAMES, "if (extLen > MAX_EXTENSION) {", "if (true) {"),
 ("NM12 the cap is one character too long", NAMES, "int keep = MAX_LENGTH - extLen;", "int keep = MAX_LENGTH - extLen + 1;"),
 ("NM13 shortening counts characters, not code points (splits emoji)", NAMES, "String cut = base.substring(0, base.offsetByCodePoints(0, Math.min(keep, base.codePointCount(0, base.length()))));", "String cut = base.substring(0, Math.min(keep, base.length()));"),
 ("A42 an AI file without a source conversation is accepted", STORE, "            if (!Artifact.ORIGIN_USER.equals(origin) && sourceBindingId == null) throw new IllegalArgumentException(\"an AI file must name the conversation it came from\");\n", ""),
 ("F26 a reply's files are recorded even when the request had no conversation", CTRL, "final boolean unknownSource = !files.isEmpty() && sourceBinding == null;", "final boolean unknownSource = false;"),
 ("F27 a reply whose files could not be recorded still routes onward", CTRL, "                            : unknownSource ? finishLocked(who + \" sent a file, but the room does not know which conversation it came from, so the file was not saved\")\n                            : startStepLocked();", "                            : startStepLocked();"),
 ("A40 the store saves the raw name", STORE, "ArtifactNames.clean(displayName), mime, -1L", "displayName, mime, -1L"),
 ("A41 artifactsNotReady also lists READY files", STORE, "for (Artifact a : artifacts.values()) if (a.state != ArtifactState.READY) out.add(a);", "for (Artifact a : artifacts.values()) out.add(a);"),
 ("OR1 startup clean-up leaves the orphan file", SERVICE, "            if (storage.deleteOrphan(a.roomId, a.id)) n++;\n            if (a.fromUser()", "            if (a.fromUser()"),
 ("OR2 a user's half-saved file is never forgotten", SERVICE, "            if (a.fromUser() && store.deleteUnreferencedArtifact(a.id)) n++;\n", ""),
 ("OR3 an AI's failed file is forgotten too", SERVICE, "if (a.fromUser() && store.deleteUnreferencedArtifact(a.id)) n++;", "if (store.deleteUnreferencedArtifact(a.id)) n++;"),
 ("OR4 stale temporary parts are never cleaned", SERVICE, "        if (!isBusy()) n += storage.cleanTemp();\n", ""),
 ("OR5 temporary parts are cleaned even while a job runs", SERVICE, "if (!isBusy()) n += storage.cleanTemp();", "n += storage.cleanTemp();"),
 ("OR8 discarding a half-saved file leaves its bytes", SERVICE, "        storage.deleteOrphan(a.roomId, a.id);   // a file that never got a recorded path", "        // storage.deleteOrphan(a.roomId, a.id);   // a file that never got a recorded path"),
 ("OR6 retrying a capture leaves the orphan in the way", SERVICE, "        storage.deleteOrphan(a.roomId, a.id);\n        return true;\n    }\n\n    /** The user chose", "        return true;\n    }\n\n    /** The user chose"),
 ("OR7 a capture does not clear a leftover at its place", SERVICE, "                if (now != null && now.state == ArtifactState.PENDING_CAPTURE) storage.deleteOrphan(a.roomId, a.id);", ""),
 ("ST17 deleteOrphan accepts unsafe ids", STORAGE, "        if (!safeName(roomId) || !safeName(artifactId)) return false;\n        File f = new File(new File(root, roomId), artifactId);\n        return f.isFile() && f.delete();", "        File f = new File(new File(root, roomId == null ? \"\" : roomId), artifactId == null ? \"\" : artifactId);\n        return f.isFile() && f.delete();"),
 ("ST18 deleteOrphan also removes folders", STORAGE, "return f.isFile() && f.delete();\n    }\n\n    /** Removes leftover temporary", "return f.exists() && f.delete();\n    }\n\n    /** Removes leftover temporary"),
 ("ST19 cleanTemp removes nothing", STORAGE, "if (f.isFile() && f.delete()) n++;", "if (f.isFile()) n++;"),
 ("F24 the reply line in the room uses raw file names", CTRL, ".append(ArtifactNames.clean(files.get(i).name));", ".append(files.get(i).name);"),
]
ANCH = os.environ.get('MUT_CHECK_ANCHORS')   # only report breakages whose target text no longer exists (fast, no compile)
def run(mutated, target=STORE):
    if ANCH: return 'fail', ''
    d = tempfile.mkdtemp(prefix='agc_jm_')
    try:
        shutil.copytree(SRC, os.path.join(d, 'src'))
        if mutated is not None: open(os.path.join(d, 'src', target), 'w').write(mutated)
        out = os.path.join(d, 'out'); os.makedirs(out)
        s = os.path.join(d, 'src', 'com', 'aigroupchat', 'bridge')
        files = [os.path.join(s, 'room', f) for f in os.listdir(os.path.join(s, 'room')) if f.endswith('.java')] + [os.path.join(s, 'LabelMatch.java')] + [os.path.join(HERE, c + '.java') for c in TEST_CLASSES]
        c = subprocess.run(['javac', '-encoding', 'UTF-8', '-d', out, '-cp', JAR, '-sourcepath', os.path.join(d, 'src')] + files, capture_output=True, text=True)
        if c.returncode != 0: return 'compile', c.stderr[:300]
        for cls in TEST_CLASSES:   # a breakage is "caught" as soon as ANY test class fails
            r = subprocess.run(['java', '-cp', out + ':' + JAR, cls], capture_output=True, text=True, timeout=300)
            if r.returncode != 0: return 'fail', r.stdout
        return 'pass', ''
    finally:
        shutil.rmtree(d)
if not ANCH and run(None)[0] != 'pass': print('baseline does not pass'); sys.exit(2)
survivors = 0
for name, a, b in MUTS:
    if not selected(name): continue
    if a not in base: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(base.replace(a, b, 1))
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, a, b in W_MUTS:
    if not selected(name): continue
    if a not in writer: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(writer.replace(a, b, 1), WRITER)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, a, b in B_MUTS:
    if not selected(name): continue
    if a not in boot: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(b(boot) if callable(b) else boot.replace(a, b, 1), BOOT)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, a, b in I_MUTS:
    if not selected(name): continue
    if a not in integ: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(integ.replace(a, b, 1), INTEG)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, a, b in C_MUTS:
    if not selected(name): continue
    if a not in ctrl: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    t = ctrl.replace(a, b, 1)
    if name.startswith('C11'): t = t.replace(ADD_BODY_END, ADD_BODY_END.replace("            });\n        }\n    }", "            }).get();\n        }\n    }", 1), 1)
    if name.startswith('C12'): t = t.replace("                return null;\n            });\n            drain = run", "                return null;\n            }).get();\n            drain = run", 1)
    kind, out = run(t, CTRL)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, a, b in D_MUTS:
    if not selected(name): continue
    if a not in boot: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(boot.replace(a, b, 1), BOOT)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, a, b in A_MUTS:
    if not selected(name): continue
    if a not in open(os.path.join(SRC, STORE)).read(): print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(open(os.path.join(SRC, STORE)).read().replace(a, b, 1), STORE)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, f, a, b in E_MUTS:
    if not selected(name): continue
    srcf = open(os.path.join(SRC, f)).read()
    if a not in srcf: print('%-52s ANCHOR MISSING' % name); survivors += 1; continue
    kind, out = run(srcf.replace(a, b, 1), f)
    if kind == 'pass': print('%-52s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-52s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-52s caught' % name)
for name, f, a, b in X_MUTS:
    if not selected(name): continue
    srcf = open(os.path.join(SRC, f)).read()
    if a not in srcf: print('%-60s ANCHOR MISSING' % name); survivors += 1; continue
    if os.environ.get('DRY'): continue
    kind, out = run(srcf.replace(a, b, 1), f)
    if kind == 'pass': print('%-60s SURVIVED  <-- not caught' % name); survivors += 1
    elif kind == 'compile': print('%-60s compile error (mutation invalid): %s' % (name, out.strip().splitlines()[0] if out.strip() else '')); survivors += 1
    else: print('%-60s caught' % name)
print('\n%d breakages, %d survivors' % (len(MUTS) + len(W_MUTS) + len(B_MUTS) + len(I_MUTS) + len(C_MUTS) + len(D_MUTS) + len(A_MUTS) + len(E_MUTS) + len(X_MUTS), survivors)); sys.exit(1 if survivors else 0)
