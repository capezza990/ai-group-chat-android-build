"""Source rules for the screen (RoomActivity cannot run on the JVM, so its membership rules are checked in the source):
  1. Seating is NEVER inferred from "this room has no participants", and the screen never seats anyone silently (first seats are made by RoomBootstrap at creation).
  2. Every place that changes membership or the open room (remove, undo, add, switch, new room) refuses while a run is active, BEFORE it changes anything.
  3. controller.removeParticipant / addParticipant are only called from those guarded places.
Run:  python3 ui_source_check.py            (checks the real file)
      python3 ui_source_check.py --selftest (breaks the rules on purpose; the check must notice every time)"""
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
REAL = os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java', 'com', 'aigroupchat', 'bridge', 'room', 'ui', 'RoomActivity.java')
GUARDED = ['removeAi', 'undoRemove', 'showAddDialog', 'showRooms', 'switchRoom', 'newRoom', 'openProvider', 'switchMode', 'confirmNewRoom']
BUSY = re.compile(r'blockedByWork\(')   # the one helper that asks BOTH the room controller and the app-wide file service
CHANGES = re.compile(r'controller\.(?:addParticipant|removeParticipant)\(|recreate\(\)|putString\(KEY_LIVE_ROOM|createLiveRoom\(')

def methods(src):
    starts = [(m.start(), m.group(1)) for m in re.finditer(r'(?m)^    (?:private|public|protected)(?:\s+static)?(?:\s+final)?\s+[\w<>\[\], ]+\s+(\w+)\s*\([^)]*\)\s*\{', src)]
    out = {}
    for i, (pos, name) in enumerate(starts):
        out[name] = src[pos:(starts[i + 1][0] if i + 1 < len(starts) else len(src))]
    return out

def check(src):
    problems = []
    if re.search(r'participants\(\)\.isEmpty\(\)', src): problems.append('seating or any decision is inferred from "participants().isEmpty()"')
    if re.search(r'addParticipant\([^;]*,\s*false\s*\)', src): problems.append('the screen seats someone silently (addParticipant(..., false)); only RoomBootstrap seats, at creation')
    ms = methods(src)
    helper = ms.get('blockedByWork', '')
    if not (re.search(r'controller != null && controller\.isBusy\(\)', helper) and re.search(r'fileServiceBusy\(\)', helper)): problems.append('blockedByWork must ask BOTH the room controller and the file service')
    if not re.search(r'artifactService != null && artifactService\.isBusy\(\)', ms.get('fileServiceBusy', '')): problems.append('fileServiceBusy must ask the shared file service')
    for name in GUARDED:
        body = ms.get(name)
        if body is None: problems.append('method %s not found' % name); continue
        g = BUSY.search(body); c = CHANGES.search(body)
        if not g: problems.append('%s has no busy check' % name)
        elif c and g.start() > c.start(): problems.append('%s changes things BEFORE its busy check' % name)
    for name, body in ms.items():
        if name in GUARDED: continue
        if re.search(r'controller\.(?:addParticipant|removeParticipant)\(', body): problems.append('%s changes membership but is not a guarded action' % name)
    return problems

def selftest(real):
    muts = [
        ('Remove loses its busy check', re.sub(r'(private void removeAi\(String providerId\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('Add dialog loses its busy check', re.sub(r'(private void showAddDialog\(\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('Rooms list loses its busy check', re.sub(r'(private void showRooms\(\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('switchRoom loses its busy check', re.sub(r'(private void switchRoom\(String id\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('New room loses its busy check', re.sub(r'(private void newRoom\(\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('the helper forgets the file service', real.replace('if (fileServiceBusy()) { toast(BUSY_FILES); return true; }', '', 1)),
        ('the helper forgets the room controller', real.replace('if (controller != null && controller.isBusy()) { toast(runMessage); return true; }', '', 1)),
        ('openProvider loses its busy check', re.sub(r'(private void openProvider\(String id\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('switchMode loses its busy check', re.sub(r'(private void switchMode\(\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1)),
        ('Undo loses its busy check', real.replace('if (blockedByWork("Wait for the current run to finish, or tap Stop first.")) return; // a rejoin is a membership change: same rule as Add and Remove\n', '', 1)),
        ('new mock room loses BOTH its busy checks', re.sub(r'(\n\s*)if \(blockedByWork\(BUSY_ROOMS\)\) return;   // re-checked: work may have started while the dialog was open', r'', re.sub(r'(private void confirmNewRoom\(\) \{\n)\s*if \(blockedByWork\([^\n]*\n', r'\1', real, count=1), count=1)),
        ('seating inferred from an empty room again', real.replace('        // First seats are made by RoomBootstrap', '        if (controller.participants().isEmpty()) { controller.addParticipant("chatgpt", false); }\n        // First seats are made by RoomBootstrap', 1)),
        ('a new unguarded place removes people', real.replace('    private void toggleRail() {', '    private void sneaky(String id) { controller.removeParticipant(id); }\n\n    private void toggleRail() {', 1)),
        ('the busy check comes after the change', real.replace('if (undoProviderId == null) return;\n        if (blockedByWork(', 'if (undoProviderId == null) return;\n        controller.addParticipant(undoProviderId, true);\n        if (blockedByWork(', 1)),
    ]
    bad = 0
    for name, text in muts:
        if text == real: print('    FAIL: mutation did not apply: %s' % name); bad += 1; continue
        if not check(text): print('    FAIL: not noticed: %s' % name); bad += 1
    print(('PASS  ' if bad == 0 else 'FAIL  ') + 'screen membership rules, self-test (%d breakages, %d not noticed)' % (len(muts), bad)); return bad

if __name__ == '__main__':
    src = open(os.environ.get('AGC_ROOMACTIVITY', REAL), encoding='utf-8').read()
    if '--selftest' in sys.argv: sys.exit(1 if selftest(src) else 0)
    p = check(src)
    for x in p: print('    FAIL: ' + x)
    print(('PASS  ' if not p else 'FAIL  ') + 'screen membership rules (RoomActivity source)'); sys.exit(1 if p else 0)
