"""Breaks the upgrade order / the preference-import statement on purpose; the Java order test or migration_test.py must notice.
Run: python3 tools/roomtest/upgrade_mutations.py"""
import os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.abspath(os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java'))
JAR = os.environ.get('ANDROID_JAR', '/usr/share/java/com.android.android-23.jar')
UP = 'com/aigroupchat/bridge/room/sqlite/UpgradeV2.java'
DB = 'com/aigroupchat/bridge/room/sqlite/RoomDb.java'
upgrade = open(os.path.join(SRC, UP)).read(); roomdb = open(os.path.join(SRC, DB)).read()
MUTS = [
 ("U1  script runs before the preference import (the bug)", UP, "s.importLegacyPreferenceBindings();\n        s.runMigrationScript();", "s.runMigrationScript();\n        s.importLegacyPreferenceBindings();"),
 ("U2  preference import skipped", UP, "        s.importLegacyPreferenceBindings();\n", ""),
 ("U3  foreign-key check skipped", UP, "        s.checkForeignKeys();\n", ""),
 ("U4  foreign-key check before the script", UP, "s.runMigrationScript();\n        s.checkForeignKeys();", "s.checkForeignKeys();\n        s.runMigrationScript();"),
 ("U5  a failing import is swallowed", UP, "        s.importLegacyPreferenceBindings();\n", "        try { s.importLegacyPreferenceBindings(); } catch (RuntimeException ignored) { }\n"),
 ("K1  a stored binding no longer wins over a preference", DB, "INSERT OR IGNORE INTO provider_bindings", "INSERT OR REPLACE INTO provider_bindings"),
 ("K2  import loses the restore locator", DB, "bound_at) VALUES (?,?,?,?,?)\";", "bound_at) VALUES (?,?,'',?,?)\";"),
 ("K4  import passes title and locator swapped", DB, "b.restoreLocator, b.displayTitle, b.boundAt});", "b.displayTitle, b.restoreLocator, b.boundAt});"),
 ("K5  RoomDb.appendMessage hands back another room's message", DB, "return RoomIntegrity.messageInRoom(existing, roomId);", "return existing;"),
 ("K6  RoomDb.createDelivery hands back another room's delivery", DB, "return RoomIntegrity.deliveryInRoom(readDelivery(c), roomId);", "return readDelivery(c);"),
 ("K7  RoomDb.readDelivery no longer maps NULL to empty text", DB, "c.isNull(8) ? \"\" : c.getString(8)", "c.getString(8)"),
 ("K8  createDelivery writes the empty text as the reply (every new delivery would be rejected)", DB, "cv.put(\"created_at\", now); cv.put(\"updated_at\", now);\n            db().insertOrThrow(\"deliveries\"", "cv.put(\"created_at\", now); cv.put(\"updated_at\", now); cv.put(\"reply_message_id\", \"\");\n            db().insertOrThrow(\"deliveries\""),
 ("K9  setDeliveryReply writes to the wrong column", DB, "UPDATE deliveries SET reply_message_id=? WHERE id=?", "UPDATE deliveries SET error=? WHERE id=?"),
 ("K10 finalize works on any state", DB, "SET state='READY', mime=?, size=?, sha256=?, storage_path=? WHERE id=? AND state='PENDING_CAPTURE'", "SET state='READY', mime=?, size=?, sha256=?, storage_path=? WHERE id=?"),
 ("K11 fail works on any state", DB, "UPDATE artifacts SET state='FAILED' WHERE id=? AND state='PENDING_CAPTURE'", "UPDATE artifacts SET state='FAILED' WHERE id=?"),
 ("K12 retry works on any state", DB, "UPDATE artifacts SET state='PENDING_CAPTURE' WHERE id=? AND state='FAILED'", "UPDATE artifacts SET state='PENDING_CAPTURE' WHERE id=?"),
 ("K13 an attached artifact can be deleted", DB, "AND NOT EXISTS (SELECT 1 FROM message_artifacts m WHERE m.artifact_id = artifacts.id) \"\n            + \"AND NOT EXISTS", "AND 1=1 \"\n            + \"AND NOT EXISTS"),
 ("K14 an artifact with transfers can be deleted", DB, "AND NOT EXISTS (SELECT 1 FROM artifact_transfers t WHERE t.artifact_id = artifacts.id)\";", "AND 1=1\";"),
 ("K15 any binding counts as the active one", DB, "SELECT id FROM room_bindings WHERE room_id=? AND provider_id=? AND state='ACTIVE'", "SELECT id FROM room_bindings WHERE room_id=? AND provider_id=?"),
 ("K16 a second ensure-transfer fails instead of being ignored", DB, "INSERT OR IGNORE INTO artifact_transfers", "INSERT INTO artifact_transfers"),
 ("K17 the sending transfer counts itself as 'another'", DB, "AND NOT (artifact_id=? AND binding_id=?)\";", "AND (artifact_id=? AND binding_id=? OR 1)\";"),
 ("K18 starting to send does not count an attempt", DB, "THEN 1 ELSE 0 END)", "THEN 0 ELSE 0 END)"),
 ("K19 a transition ignores the current state", DB, "AND binding_id=? AND state IN (?,?,?,?)", "AND binding_id=? AND (1 OR state IN (?,?,?,?))"),
 ("K20 restart recovery touches every transfer", DB, "error='interrupted (app restart)', updated_at=? WHERE state IN ('SENDING','STAGED')", "error='interrupted (app restart)', updated_at=? WHERE 1"),
 ("K21 restart recovery fails every artifact", DB, "UPDATE artifacts SET state='FAILED' WHERE state='PENDING_CAPTURE'", "UPDATE artifacts SET state='FAILED' WHERE state<>'FAILED'"),
 ("K40 the reply identity accepts several delivery rows", DB, "return rows == 1 && ref != null ? ref : \"\";", "return ref != null ? ref : \"\";"),
 ("K41 another AI's or room's delivery is accepted as the source", DB, "if (!a.origin.equals(c.getString(1)) || !a.roomId.equals(c.getString(2))) return \"\";", "if (false) return \"\";"),
 ("K42 a user file gets a reply identity", DB, "if (a == null || a.fromUser()) return \"\";\n            String ref = null;", "if (a == null) return \"\";\n            String ref = null;"),
 ("K22 a new artifact starts FAILED", DB, "VALUES (?,?,?,?,?,?,'PENDING_CAPTURE',?)", "VALUES (?,?,?,?,?,?,'FAILED',?)"),
 ("K30 createArtifact swaps the source conversation and the name", DB, "new Object[]{id, roomId, origin, sourceBindingId, ArtifactNames.clean(displayName), mime == null", "new Object[]{id, roomId, origin, ArtifactNames.clean(displayName), sourceBindingId, mime == null"),
 ("K31 the source conversation is checked against the wrong room and AI", DB, "new String[]{sourceBindingId, roomId, origin}", "new String[]{sourceBindingId, origin, roomId}"),
 ("K32 a user file may name a source conversation (RoomDb)", DB, "if (Artifact.ORIGIN_USER.equals(origin)) throw new IllegalArgumentException(\"a user file has no source conversation\");", ""),
 ("K34 RoomDb accepts an AI file without a source conversation", DB, "            if (!Artifact.ORIGIN_USER.equals(origin) && sourceBindingId == null) throw new IllegalArgumentException(\"an AI file must name the conversation it came from\");\n", ""),
 ("K33 a PENDING_NEW conversation is accepted as a source (RoomDb)", DB, "AND provider_id=? AND state IN ('ACTIVE','RETIRED')\"", "AND provider_id=?\""),
 ("K34 RoomDb saves the raw file name", DB, "ArtifactNames.clean(displayName), mime == null", "displayName, mime == null"),
 ("K35 RoomDb artifactsNotReady lists READY files too", DB, "FROM artifacts WHERE state <> 'READY' ORDER BY rowid", "FROM artifacts WHERE 1 ORDER BY rowid"),
 ("K3  import writes the wrong table", DB, "INSERT OR IGNORE INTO provider_bindings(provider_id, conversation_id, restore_locator, display_title, bound_at)", "INSERT OR IGNORE INTO participants(room_id, provider_id, enabled, position, context_seq)"),
]
def run(mut_file, text):
    d = tempfile.mkdtemp(prefix='agc_um_')
    try:
        shutil.copytree(SRC, os.path.join(d, 'src'))
        env = dict(os.environ)
        if mut_file: 
            open(os.path.join(d, 'src', mut_file), 'w').write(text)
            env['AGC_ROOMDB_JAVA'] = os.path.join(d, 'src', DB)
        out = os.path.join(d, 'out'); os.makedirs(out)
        c = subprocess.run(['javac', '-encoding', 'UTF-8', '-d', out, '-cp', JAR, '-sourcepath', os.path.join(d, 'src'),
                            os.path.join(d, 'src', UP), os.path.join(HERE, 'UpgradeV2Test.java')], capture_output=True, text=True)
        if c.returncode != 0: return 'compile', c.stderr[:300]
        j = subprocess.run(['java', '-cp', out + ':' + JAR, 'UpgradeV2Test'], capture_output=True, text=True)
        if j.returncode != 0: return 'caught by the order test', ''
        p = subprocess.run([sys.executable, os.path.join(HERE, 'migration_test.py')], capture_output=True, text=True, env=env)
        if p.returncode != 0: return 'caught by the migration test', ''
        q = subprocess.run([sys.executable, os.path.join(HERE, 'roomdb_sql_check.py')], capture_output=True, text=True, env=env)
        return ('pass', '') if q.returncode == 0 else ('caught by the SQL/source check', '')
    finally: shutil.rmtree(d)
if run(None, '')[0] != 'pass': print('baseline does not pass'); sys.exit(2)
surv = 0
for name, f, a, b in MUTS:
    base = upgrade if f == UP else roomdb
    if a not in base: print('%-60s ANCHOR MISSING' % name); surv += 1; continue
    kind, info = run(f, base.replace(a, b, 1))
    if kind == 'pass' or kind == 'compile': print('%-60s %s <-- not caught %s' % (name, kind.upper(), info)); surv += 1
    else: print('%-60s %s' % (name, kind))
print('\n%d breakages, %d survivors' % (len(MUTS), surv)); sys.exit(1 if surv else 0)
