#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[2]
surface=(ROOT/'app/src/main/java/com/aigroupchat/bridge/engine/WebProviderSurface.java').read_text()
transport=(ROOT/'app/src/main/java/com/aigroupchat/bridge/engine/WebArtifactTransport.java').read_text()
service=(ROOT/'app/src/main/java/com/aigroupchat/bridge/room/ArtifactService.java').read_text()
controller=(ROOT/'app/src/main/java/com/aigroupchat/bridge/room/RoomController.java').read_text()
bad=[]
def ok(cond,msg):
    print(('PASS  ' if cond else 'FAIL  ')+msg)
    if not cond: bad.append(msg)
ok('providerConversationId.equals(transfer.bindingId)' not in surface, 'DB binding-row id is never compared to the provider conversation id')
ok('beginStage(expectedConversationId)' in surface and 'beginTurn(b.providerConversationId)' in surface, 'stage and send use the same provider-conversation operation key')
ok('ProviderTransferIdentity.forUpload' in transport and 'store.bindingHistory' in transport, 'upload resolves binding-row id to conversation id through room binding history')
ok('invalidateIdleStagedOperation' in surface and 'surfaceOperation.hasActiveTurn()' in surface and 'surfaceOperation.isIdleStaged(expectedConversationId)' in surface, 'staged invalidation cleans only an idle staged surface and never an active turn')
ok('scheduleIdleStagedExpiry' in surface and 'STAGED_IDLE_TIMEOUT_MS' in surface and 'setStagedExpiryListener' in service, 'idle retained staged operation has bounded expiry tied back to DB state')
m=re.search(r'private void pollUploadVisible\(UploadAttempt a\) \{(.*?)\n    \}', surface, re.S)
ok(m is not None and m.group(1).count('postDelayed(() -> pollUploadVisible(a)') == 1, 'upload visibility polling schedules exactly one next poll')
ok('commitStaged(run.stagedForActiveSend)' in controller and 'List<ArtifactTransfer> stagedForActiveSend' in controller, 'acceptance commits the exact staged transfer snapshot for this send')
ok('transport.invalidateStaged(roomId, providerId, bindingId)' in service, 'failing staged rows notifies the transport for surface cleanup')
m2=re.search(r'private void cleanupAttachmentsAndRetire\(FailureCb cb\) \{(.*?)\n    \}', surface, re.S)
body=m2.group(1) if m2 else ''
ok('expectedConversation.equals(spec.conversationIdOf(web.getUrl()))' in body and body.find('spec.conversationIdOf(web.getUrl())') != -1 and body.find('spec.conversationIdOf(web.getUrl())') < body.find('cleanupStaleAttachments'), 'cleanup checks the page is physically on the staged conversation BEFORE it clicks any remove control')
if bad: sys.exit(1)
print('Upload source check: 9 checks, 0 failures')
