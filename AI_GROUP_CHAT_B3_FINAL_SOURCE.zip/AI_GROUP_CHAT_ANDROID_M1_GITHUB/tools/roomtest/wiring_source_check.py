#!/usr/bin/env python3
"""Source rules for the final wiring of the ONE app-wide file service (the screen and the runtime are Android code and cannot run on the JVM).
  python3 wiring_source_check.py            checks the real sources
  python3 wiring_source_check.py --selftest breaks every rule on purpose in a copy of the text; the check must notice each one"""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / 'app/src/main/java/com/aigroupchat/bridge'

def load():
    return {'activity': (MAIN / 'room/ui/RoomActivity.java').read_text(), 'runtime': (MAIN / 'room/ui/ArtifactRuntime.java').read_text(),
            'lifecycle': (MAIN / 'room/ArtifactLifecycle.java').read_text(),
            'all': {str(p.relative_to(MAIN)): p.read_text() for p in MAIN.rglob('*.java')}}

def method(src, signature):
    i = src.find(signature)
    if i < 0: return ''
    depth, j = 0, src.index('{', i)
    for k in range(j, len(src)):
        if src[k] == '{': depth += 1
        elif src[k] == '}':
            depth -= 1
            if depth == 0: return src[i:k + 1]
    return ''

def rules(f):
    A, R, L = f['activity'], f['runtime'], f['lifecycle']
    create, destroy = method(A, 'protected void onCreate('), method(A, 'protected void onDestroy()')
    detach = method(L, 'private void detachLocked()')
    out = []
    def need(c, msg): out.append((bool(c), msg))
    need(sum(t.count('new ArtifactService(') for t in f['all'].values()) == 1 and 'new ArtifactService(' in L, 'exactly ONE ArtifactService is ever created in the app, inside ArtifactLifecycle.create')
    ia, ic, ir = create.find('ArtifactRuntime.get(this, db)'), create.find('controller.setArtifactService(artifactService)'), create.find('controller.recoverOnStart()')
    need(0 < ia < ic < ir and create.find('addLive("claude"') < ia, 'the screen wires the shared service AFTER its pages exist and BEFORE start-up recovery')
    need('runtime.attachLive(this, surfaces)' in create and 'runtime.attachMock(this)' in create and 'artifactService = runtime.service()' in create, 'live mode attaches the pages, mock mode the mock transports, and the screen uses the shared instance')
    ib, id_ = destroy.find('controller.abandon("room closed")'), destroy.find('runtime.detach(this)')
    need(0 < ib < id_ < destroy.find('s.destroy()'), 'on destroy the shared service is detached AFTER the run is abandoned and BEFORE any page is destroyed')
    send = A[A.find('sendBtn.setOnClickListener('):A.find('sendBtn.setOnClickListener(') + 700]
    need('else if (fileServiceBusy()) { artifactService.cancelInFlight(); refreshAll(); }' in send and send.find('controller.stop()') < send.find('artifactService.cancelInFlight()') < send.find('else send()'), 'Stop also cancels a file job that has no run (a manual retry)')
    need('static synchronized ArtifactRuntime get(' in R and 'if (instance == null)' in R and R.count('new ArtifactRuntime(') == 1, 'the runtime is a process-wide singleton')
    need(re.search(r'new WebArtifactTransport\(surfaces, db\)', R) and re.search(r'new WebCaptureTransport\(surfaces, db,', R), 'upload and capture are built from the SAME pages and the shared database')
    need('lifecycle.detach(owner)' in R and 'lifecycle.attach(owner,' in R, 'the runtime only forwards attach/detach to the lifecycle')
    need(not re.search(r'(?m)^\s*private\s+(?:final\s+)?(?:Context|Activity|RoomActivity)\s', R) and 'getApplicationContext()' in R, 'the runtime never keeps a screen or an activity context')
    need(0 < detach.find('service.cancelInFlight()') < detach.find('service.setListener(null)') < detach.find('upload.setTarget(null)'), 'detaching cancels the running job FIRST, then drops the listener, then unlinks the transports')
    need('owner != whoever' in L and 'if (owner != null) detachLocked();' in L, 'only the attached owner can detach and a new owner replaces the old one safely')
    send_lines = [l for l in A.split('\n') if re.search(r'sendBtn\.(?:setText\(|setContentDescription\(|setBackground\(shape\()stopping', l)]
    need(len(send_lines) == 3 and all('anyBusy' in l and not re.search(r'(?<!any)busy \?', l) for l in send_lines) and 'final boolean anyBusy = busy || fileServiceBusy();' in A,
         'the Send/Stop button\'s symbol, spoken description and colour all use ONE flag (run busy OR file service busy)')
    return out

if '--selftest' in sys.argv:
    f0 = load()
    def with_(key, fn):
        g = dict(f0); g['all'] = dict(f0['all']); old = f0[key]; new = fn(old)
        if new == old: return None
        g[key] = new
        path = {'activity': 'room/ui/RoomActivity.java', 'runtime': 'room/ui/ArtifactRuntime.java', 'lifecycle': 'room/ArtifactLifecycle.java'}[key]
        g['all'][path] = new   # the one-service rule counts over ALL files, so the mutated text must be visible there too
        return g
    def second_service(t): return t.replace('    private ArtifactRuntime runtime;', '    private ArtifactService sneaky = new ArtifactService(null, null, null, null, null, null, 0);\n    private ArtifactRuntime runtime;', 1)
    def swap_recover(t):
        t = t.replace('        int recovered = controller.recoverOnStart();\n', '', 1)
        return t.replace('        runtime = ArtifactRuntime.get(this, db);', '        int recovered = controller.recoverOnStart();\n        runtime = ArtifactRuntime.get(this, db);', 1)
    def late_detach(t):
        t = t.replace('        if (runtime != null) runtime.detach(this); // cancels/resolves', '        // cancels/resolves', 1)
        return t.replace('        for (WebProviderSurface s : surfaces.values()) s.destroy();', '        for (WebProviderSurface s : surfaces.values()) s.destroy();\n        if (runtime != null) runtime.detach(this);', 1)
    breaks = [
        ('a second service is created by the screen', 'activity', second_service),
        ('the shared service is not wired at all', 'activity', lambda t: t.replace('        controller.setArtifactService(artifactService);\n        int recovered', '        int recovered', 1)),
        ('start-up recovery runs before the wiring', 'activity', swap_recover),
        ('the screen never detaches', 'activity', lambda t: t.replace('        if (runtime != null) runtime.detach(this); // cancels/resolves', '        // cancels/resolves', 1)),
        ('the screen detaches only after destroying its pages', 'activity', late_detach),
        ('Stop does not cancel a file job without a run', 'activity', lambda t: t.replace('else if (fileServiceBusy()) { artifactService.cancelInFlight(); refreshAll(); }', '', 1)),
        ('mock mode attaches nothing', 'activity', lambda t: t.replace('if (live) runtime.attachLive(this, surfaces); else runtime.attachMock(this);', 'if (live) runtime.attachLive(this, surfaces);', 1)),
        ('the runtime is no singleton', 'runtime', lambda t: t.replace('if (instance == null) instance =', 'instance =', 1)),
        ('capture is built from other pages', 'runtime', lambda t: t.replace('new WebCaptureTransport(surfaces, db,', 'new WebCaptureTransport(new java.util.LinkedHashMap<>(), db,', 1)),
        ('the runtime keeps a context', 'runtime', lambda t: t.replace('    private final RoomDb db;', '    private final RoomDb db;\n    private Context screen;', 1)),
        ('the runtime forgets to detach', 'runtime', lambda t: t.replace('lifecycle.detach(owner)', 'owner.hashCode()', 1)),
        ('detach unlinks before cancelling', 'lifecycle', lambda t: t.replace('        service.cancelInFlight();   // FIRST', '        upload.setTarget(null);\n        service.cancelInFlight();   // FIRST', 1)),
        ('the Send button\'s description ignores a file job', 'activity', lambda t: t.replace('anyBusy ? "Stop" : "Send"', 'busy ? "Stop" : "Send"', 1)),
        ('the Send button\'s colour ignores a file job', 'activity', lambda t: t.replace('anyBusy ? 0xFFB3475A : BLUE', 'busy ? 0xFFB3475A : BLUE', 1)),
        ('the Send button\'s symbol ignores a file job', 'activity', lambda t: t.replace('stopping ? "\\u2026" : anyBusy ? "\\u25A0" : "\\u27A4"', 'stopping ? "\\u2026" : busy ? "\\u25A0" : "\\u27A4"', 1)),
        ('anyone can detach', 'lifecycle', lambda t: t.replace('if (whoever == null || owner != whoever) return false;', 'if (whoever == null) return false;', 1)),
        ('a new owner does not replace the old one', 'lifecycle', lambda t: t.replace('        if (owner != null) detachLocked();   // a new screen replaces', '        // a new screen replaces', 1)),
    ]
    bad = 0
    for what, key, fn in breaks:
        g = with_(key, fn)
        if g is None: print('FAIL  self-test anchor missing: ' + what); bad += 1; continue
        if all(ok for ok, _ in rules(g)): print('FAIL  not noticed: ' + what); bad += 1
    print(('PASS  ' if bad == 0 else 'FAIL  ') + 'wiring source rules self-test (%d breakages, %d not noticed)' % (len(breaks), bad))
    sys.exit(1 if bad else 0)

bad = 0
for ok, msg in rules(load()):
    print(('PASS  ' if ok else 'FAIL  ') + msg)
    if not ok: bad += 1
sys.exit(1 if bad else 0)
