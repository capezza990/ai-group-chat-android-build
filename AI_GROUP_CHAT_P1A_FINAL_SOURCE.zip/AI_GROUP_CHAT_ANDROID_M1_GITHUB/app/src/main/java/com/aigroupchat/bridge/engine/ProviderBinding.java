package com.aigroupchat.bridge.engine;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/** The room never parses URLs: an adapter produces this and the room stores it. The id/locator, not the
 *  title, is the binding. (No cookies or tokens are ever stored here.) */
public final class ProviderBinding {
    public final String providerId;
    public final String providerConversationId;
    public final String restoreLocator;
    public final String displayTitle;
    public final long boundAt;

    public ProviderBinding(String providerId, String conversationId, String restoreLocator, String displayTitle, long boundAt) {
        this.providerId = providerId;
        this.providerConversationId = conversationId;
        this.restoreLocator = restoreLocator;
        this.displayTitle = displayTitle == null ? "" : displayTitle;
        this.boundAt = boundAt;
    }

    public JSONObject toJson() throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("providerId", providerId);
        o.put("conversationId", providerConversationId);
        o.put("restoreLocator", restoreLocator);
        o.put("title", displayTitle);
        o.put("boundAt", boundAt);
        return o;
    }

    public static ProviderBinding fromJson(JSONObject o) {
        if (o == null) return null;
        String id = o.optString("conversationId", "");
        if (id.isEmpty()) return null;
        return new ProviderBinding(o.optString("providerId", ""), id, o.optString("restoreLocator", ""),
                o.optString("title", ""), o.optLong("boundAt", 0L));
    }

    public static final class Store {
        private final SharedPreferences prefs;

        public Store(Context c) { prefs = c.getSharedPreferences("engine_bindings", Context.MODE_PRIVATE); }

        public ProviderBinding get(String providerId) {
            try { return fromJson(new JSONObject(prefs.getString(providerId, "{}"))); }
            catch (Exception e) { return null; }
        }

        public void put(ProviderBinding b) {
            try { prefs.edit().putString(b.providerId, b.toJson().toString()).apply(); } catch (Exception ignored) {}
        }

        public void clear(String providerId) { prefs.edit().remove(providerId).apply(); }
    }
}
